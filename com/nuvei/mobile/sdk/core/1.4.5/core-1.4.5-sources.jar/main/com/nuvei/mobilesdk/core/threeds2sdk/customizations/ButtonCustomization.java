package com.nuvei.mobilesdk.core.threeds2sdk.customizations;

import com.nuvei.mobilesdk.core.threeds2sdk.customizations.Customization;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

public class ButtonCustomization extends Customization {
    private String backgroundColor;
    private int cornerRadius;

    public void setBackgroundColor(String hexColorCode) throws InvalidInputException {
        this.backgroundColor = hexColorCode;
    }

    public void setCornerRadius(int cornerRadius) throws InvalidInputException {
        this.cornerRadius = cornerRadius;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public int getCornerRadius() {
        return cornerRadius;
    }
}

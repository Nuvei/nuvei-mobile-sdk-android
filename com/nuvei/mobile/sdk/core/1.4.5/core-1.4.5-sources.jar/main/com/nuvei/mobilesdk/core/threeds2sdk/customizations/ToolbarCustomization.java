package com.nuvei.mobilesdk.core.threeds2sdk.customizations;

import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

public class ToolbarCustomization extends Customization {
    private String backgroundColor;
    private String headerText;
    private String buttonText;

    public void setBackgroundColor(String hexColorCode) throws InvalidInputException {
        this.backgroundColor = hexColorCode;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public void setHeaderText (String headerText) throws InvalidInputException {
        this.headerText = headerText;
    }

    public String getHeaderText() {
        return headerText;
    }

    public void setButtonText(String buttonText) throws InvalidInputException {
        this.buttonText = buttonText;
    }

    public String getButtonText() {
        return buttonText;
    }
}

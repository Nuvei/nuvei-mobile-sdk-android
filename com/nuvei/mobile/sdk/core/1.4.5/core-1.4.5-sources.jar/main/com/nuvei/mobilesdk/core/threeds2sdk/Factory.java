package com.nuvei.mobilesdk.core.threeds2sdk;

import com.nuvei.mobilesdk.core.threeds2sdk.RuntimeErrorEvent;
import com.nuvei.mobilesdk.core.threeds2sdk.ThreeDS2Service;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.ToolbarCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.UiCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ChallengeParameters;
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ConfigParameters;

public class Factory {
    public ChallengeParameters newChallengeParameters() {
        return new ChallengeParameters();
    }

    public ConfigParameters newConfigParameters() {
        return new ConfigParameters();
    }

    public UiCustomization newUiCustomization() {
        return new UiCustomization();
    }

    public ThreeDS2Service newThreeDS2Service() {
        return new ThreeDS2Service();
    }

    public RuntimeErrorEvent newRuntimeErrorEvent(String errorCode, String errorMessage) {
        return new RuntimeErrorEvent(errorCode, errorMessage);
    }

    public ToolbarCustomization newToolbarCustomization() {
        return new ToolbarCustomization();
    }
}

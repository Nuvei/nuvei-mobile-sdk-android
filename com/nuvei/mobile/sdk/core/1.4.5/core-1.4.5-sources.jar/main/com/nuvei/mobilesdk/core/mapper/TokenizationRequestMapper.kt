package com.nuvei.mobilesdk.core.mapper

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants

class TokenizationRequestMapper : Mapper<NVPayment, JsonObject> {
    override fun map(source: NVPayment): JsonObject {
        val jsonObject = JsonObject()
        jsonObject.addProperty(NetworkConstants.sessionToken, source.sessionToken)
        
        val card = source.cardData ?: source.paymentOption.card
        if (card != null) {
            jsonObject.add("cardData", Gson().toJsonTree(card))
        }
        
        return jsonObject
    }
}

package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class BillingAddress(
    @SerializedName("addressMatch") val addressMatch: String? = null,
    @SerializedName("city") val city: String? = null,
    @SerializedName("country") val country: String? = null,
    @SerializedName("address") val address: String? = null,
    @SerializedName("addressLine2") val addressLine2: String? = null,
    @SerializedName("addressLine3") val addressLine3: String? = null,
    @SerializedName("zip") val zip: String? = null,
    @SerializedName("state") val state: String? = null,
    @SerializedName("email") val email: String? = null,
    @SerializedName("phone") val phone: String? = null,
    @SerializedName("cell") val cell: String? = null,
    @SerializedName("firstName") val firstName: String? = null,
    @SerializedName("lastName") val lastName: String? = null,
    @SerializedName("county") val county: String? = null,
    @SerializedName("homePhone") val homePhone: String? = null,
    @SerializedName("workPhone") val workPhone: String? = null
) : Serializable
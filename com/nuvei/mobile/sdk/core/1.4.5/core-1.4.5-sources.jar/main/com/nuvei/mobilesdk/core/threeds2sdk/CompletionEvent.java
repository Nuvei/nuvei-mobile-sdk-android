package com.nuvei.mobilesdk.core.threeds2sdk;

public class CompletionEvent {

    private final String sdkTransactionID, transactionStatus;

    public CompletionEvent(String sdkTransactionID, String transactionStatus) {
        this.sdkTransactionID = sdkTransactionID;
        this.transactionStatus = transactionStatus;
    }

    /**
     * The getSDKTransactionID method shall return the 3DS SDK transaction ID.
     * The EMV 3DS Protocol Specification defines this transaction ID.
     *
     * @return This method returns the 3DS SDK Transaction ID as a string.
     */
    public String getSDKTransactionID() {
        return sdkTransactionID;
    }

    /**
     * The getTransactionStatus method shall return the transaction status that
     * was received by the 3DS SDK in the final CRes.
     *
     * @return This method returns the transaction status as a String.
     */
    public String getTransactionStatus() {
        return transactionStatus;
    }
}

package com.nuvei.mobilesdk.core.threeds2sdk.exceptions;

/**
 * The InvalidInputException class shall represent a run-time exception that
 * occurs due to one of the following reasons:<ul>
 * <li>Parameter value is mandatory, but was not provided.
 * <li>Parameter value does not conform to the specified format.
 * <li>Parameter value exceeds the maximum limit.
 * <li>Parameter value does not meet the minimum length criteria.
 * </ul>
 */
public class InvalidInputException extends RuntimeException {
    public InvalidInputException(String message) {
        super(message, null);
    }
    public InvalidInputException(String message, Throwable cause) {
        super(message, cause);
    }
}

package com.nuvei.mobilesdk.core.threeds2sdk;

import android.animation.LayoutTransition;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.nuvei.mobilesdk.core.EdgeToEdgeHelper;
import com.nuvei.mobilesdk.core.R;
import com.nuvei.mobilesdk.core.nimbusds.jose.util.Base64URL;
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeExecutor;
import com.nuvei.mobilesdk.core.threeds2sdk.Transaction;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.ButtonCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.LabelCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.TextBoxCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.ToolbarCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.UiCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CRes;
import com.nuvei.mobilesdk.core.listeners.SDKChallengeDataListener;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;

/**
 * HTML UI:
 * EMVCo_3DS_Spec_v220_122018.pdf
 * 4.2.5 HTML UI Display Requirements
 * - [Req 371] Display the HTML as provided by the ACS
 * - [Req 372] Display only the UI elements provided by the ACS in the Branding, Challenge/Processing and Information zones
 * - [Req 373] Display the Cancel action in the top corner of the header zone as depicted in Figure 4.1
 * - Screen title should be provided by the requester app
 * - Cancel button title should be provided by the requester app
 * <p>
 * - [Req 159] After submitting the CReq message to the ACS, display the 3DS App Processing screen
 * until the CRes message is received or timeout exceeded.
 * <p>
 * 4.2.7.3 3DS SDK
 * The 3DS SDK shall:
 * - [Req 166] Extract the HTML data from the ACS HTML data element and display the requested
 * content upon receiving the CRes message from the ACS.
 * - [Req 167] Intercept and block any requests by the web view to fetch external resources.
 * - [Req 168] Build a view that includes the 3DS Requestor header and place at the top of the view
 * containing the ACS HTML as specified in the HTML UI templates.
 * - [Req 169] Use a web view to display the UI to the Cardholder. (WebView, View Controller, etc.).
 * - [Req 170] Process Cardholder actions, for example the Cancel action.
 * - [Req 171] Return control to the 3DS Requestor App when the Cancel action in the 3DS Requestor
 * header is selected.
 * On HTML submit:
 * - The web view will return, either a parameter string (HTML Action = GET) or form data (HTML
 * Action = POST) containing the cardholder’s data input.
 * - The SDK passes the received data, unchanged, to the ACS in the Challenge HTML Data Entry data
 * element of the CReq message. The SDK shall not modify or reformat the data.
 * The 3DS SDK transmits the CReq message to the ACS.
 */
public class ChallengeActivity extends AppCompatActivity
        implements ChallengeExecutor.Listener
        // UL tester app integration start
        //, SdkChallengeInterface, TextChallenge, SingleSelectChallenge, MultiSelectChallenge, OutOfBandChallenge, WebChallenge
        // UL tester app integration end
{

    private final static String TAG = "[3DSSDK][Ch.Activity]";

    private static final String STATE_REFRESH_UI = "refresh_ui";
    private static final String LAST_CRES = "last_cres";
    private static final String WHITELISTING = "WHITELISTING";

    private static final String HtmlVerify = "HTTPS://EMV3DS/challenge";

    private enum ChallengeType {
        SINGLE_TEXT_INPUT,
        SINGLE_SELECT,
        MULTI_SELECT,
        OUT_OF_BAND,
        HTML_UI
    }

    private ChallengeType challengeType;

    private TextView headerTextView;
    private TextView textView1;
    private TextView textView2;
    private LinearLayout warningIconAndTextsRootContainer;
    private EditText challengeEditText;
    private ImageView warningIcon;
    private LinearLayout warningIconAndTextsRoot;
    private LinearLayout selectionContainer;
    private ArrayList<RadioButton> radioButtons;
    private ArrayList<CheckBox> checkBoxes;
    private Button challengeSubmitButton;
    private LinearLayout.LayoutParams singleBtnParams;
    private LinearLayout.LayoutParams firstBtnParams;
    private LinearLayout.LayoutParams secondBtnParams;
    private LinearLayout whitelistingInfoView;
    private CheckBox whitelistingCheckBox;
    private LinearLayout whyInfoView;
    private TextView whyInfoHiddenView;
    private LinearLayout expandInfoView;
    private LinearLayout buttonsContainer;
    private TextView expandInfoHiddenView;

    private boolean refreshUI = false;

    private Transaction transaction;

    private API api;

    private Dialog progressView;

    private boolean isPortrait = true;
    private boolean isOobFlow = false;

    private LinearLayout container;
    private LinearLayout.LayoutParams containerLayoutParams;
    private WebView webView;

    static WeakReference<ChallengeActivity> instance = new WeakReference(null);

    private ChallengeExecutor challengeExecutor = null;

    private Boolean whitelisting = null;

    public static Intent getIntent(Context context, CRes cres) {
        Intent intent = new Intent(context, ChallengeActivity.class);
        intent.putExtra(LAST_CRES, cres);
        return intent;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        isPortrait = getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT;

        // Create Scrollview
        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollViewParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(scrollViewParams);

        // Create parent LinearLayout
        container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        containerLayoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        container.setLayoutParams(containerLayoutParams);

        scrollView.addView(container);
        setContentView(scrollView, scrollViewParams);

        EdgeToEdgeHelper.INSTANCE.enableEdgeToEdge(getWindow(),scrollView.getRootView());

        instance = new WeakReference(this);

        if (0 != (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                WebView.setWebContentsDebuggingEnabled(true);
            }
        }

        transaction = Transaction.currentTransaction;

        challengeExecutor = transaction.getChallengeExecutor();
        challengeExecutor.setListener(this);

        if (savedInstanceState != null) {
            refreshUI = savedInstanceState.getBoolean(STATE_REFRESH_UI, false);
            CRes lastCres = (CRes) savedInstanceState.getSerializable(LAST_CRES);
            if (lastCres != null) {
                challengeExecutor.setLastCres(lastCres);
            }
            if (savedInstanceState.containsKey(WHITELISTING)) {
                whitelisting = savedInstanceState.getBoolean(WHITELISTING);
            }
        }

        /*
         * When the activity UI is ready, the SDK must notify the RefApp
         * that it can start the test case automation.
         **/
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast
//                        (new Intent(UL_HANDLE_CHALLENGE_ACTION));
//            }
//        }, 1000);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            isPortrait = false;
            handleOrientation();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            isPortrait = true;
            handleOrientation();
        }

    }

    private void handleOrientation() {
        if (isPortrait) {
            if (buttonsContainer != null) {
                buttonsContainer.setOrientation(LinearLayout.VERTICAL);
                buttonsContainer.setGravity(Gravity.CENTER_HORIZONTAL);
            }

            if (firstBtnParams != null) {
                firstBtnParams.setMargins(32, 24, 32, 0);
                firstBtnParams.height = convertDpToPx(45);
            }

            if (secondBtnParams != null) {
                secondBtnParams.setMargins(32, 24, 32, 0);
                secondBtnParams.height = convertDpToPx(45);
            }

            if (singleBtnParams != null) {
                singleBtnParams.setMargins(32, 30, 32, 0);
            }
        } else {
            if (buttonsContainer != null) {
                buttonsContainer.setOrientation(LinearLayout.HORIZONTAL);
                buttonsContainer.setGravity(Gravity.CENTER_VERTICAL);
            }

            if (firstBtnParams != null) {
                firstBtnParams.weight = 1;
                firstBtnParams.setMargins(32, 0, 32, 0);
            }

            if (secondBtnParams != null) {
                secondBtnParams.weight = 1;
                secondBtnParams.setMargins(32, 0, 32, 0);
            }

            if (singleBtnParams != null) {
                singleBtnParams.setMargins(32, 0, 32, 0);
            }
        }

        if (headerTextView != null) {
            LinearLayout.LayoutParams headerParams = (LinearLayout.LayoutParams) headerTextView.getLayoutParams();
            headerParams.setMargins(32, isPortrait ? 30 : 10, 32, 0);
            headerTextView.setLayoutParams(headerParams);
        }

        if (warningIconAndTextsRootContainer != null) {
            LinearLayout.LayoutParams warningIconAndTextsRootContainerParams = (LinearLayout.LayoutParams) warningIconAndTextsRootContainer.getLayoutParams();
            warningIconAndTextsRootContainerParams.setMargins(32, isPortrait ? 80 : 10, 32, 0);
            warningIconAndTextsRootContainer.setLayoutParams(warningIconAndTextsRootContainerParams);
        }

        if (challengeEditText != null) {
            LinearLayout.LayoutParams editTextParams = (LinearLayout.LayoutParams) challengeEditText.getLayoutParams();
            editTextParams.setMargins(32, isPortrait ? 20 : 0, 32, 0);
            challengeEditText.setLayoutParams(editTextParams);
        }

        if (selectionContainer != null) {
            LinearLayout.LayoutParams selectionContainerParams = (LinearLayout.LayoutParams) selectionContainer.getLayoutParams();
            selectionContainerParams.setMargins(32, isPortrait ? 20 : 0, 32, 0);
            selectionContainer.setLayoutParams(selectionContainerParams);
        }

        if (challengeSubmitButton != null) {
            LinearLayout.LayoutParams multiSelectionButtonParams = (LinearLayout.LayoutParams) challengeSubmitButton.getLayoutParams();
            multiSelectionButtonParams.setMargins(32, isPortrait ? 24 : 0, 32, 0);
            challengeSubmitButton.setLayoutParams(multiSelectionButtonParams);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(STATE_REFRESH_UI, true);
        outState.putBoolean(STATE_REFRESH_UI, true);
        outState.putSerializable(LAST_CRES, challengeExecutor.getLastCres());
        if (whitelisting != null) {
            outState.putBoolean(WHITELISTING, whitelisting);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

//        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast
//                (new Intent(UL_HANDLE_CHALLENGE_ACTION));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (refreshUI) {
            refreshUI();
        } else {
            Serializable cres = getIntent().getSerializableExtra(LAST_CRES);
            if (cres instanceof CRes) {
                handleCRes((CRes) cres, false);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        refreshUI = true;
    }

    @Override
    public void onDetachedFromWindow() {
        hideLoadingImmediately(true);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDestroy() {
        instance = new WeakReference(null);
        hideLoadingImmediately(true);
        super.onDestroy();
    }

    private void refreshUI() {
        Log.d(TAG, "Refresh UI of OOB challenge");
        handleCRes(challengeExecutor.getLastCres(), true);
    }

    private void showLoading() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed()) {
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if ((Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && ChallengeActivity.this.isDestroyed()) || ChallengeActivity.this.isFinishing()) {
                    return;
                }
                if (progressView == null) {
                    progressView = transaction.getProgressView(ChallengeActivity.this);
                }
                progressView.show();
            }
        });
    }

    private void hideLoading() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed()) {
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                hideLoadingImmediately(false);
            }
        });
    }

    private void hideLoadingImmediately(boolean force) {
        if (!force && Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed()) {
            return;
        }
        if (progressView != null) {
            progressView.dismiss();
        }
    }

    private int convertDpToPx(float dp) {
        Resources r = getResources();

        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                r.getDisplayMetrics()
        );
    }

    public void handleCRes(CRes cres) {
        handleCRes(cres, false);
    }

    private void printHTML(String acsHTML) {
        //Log.d(TAG, "handleCRes(): isOobRefresh acsHTML = " + acsHTML);
        String[] htmlRows = acsHTML.split("\\n");
        Log.d(TAG, "printHTML(): " + htmlRows.length + " rows in html");
        for (String htmlRow: htmlRows) {
            if (htmlRow.length() < 4000) {
                Log.d(TAG, "printHTML(): " + htmlRow);
            } else {
                Log.d(TAG, "printHTML(): long row start -> " + htmlRow.length());
                do {
                    String htmlRowShort = htmlRow.substring(0, 4000);
                    Log.d(TAG, "printHTML(): |" + htmlRowShort + "|");
                    htmlRow = htmlRow.substring(4000);
                } while (htmlRow.length() >= 4000);
                Log.d(TAG, "printHTML(): |" + htmlRow + "|");
                Log.d(TAG, "printHTML(): long row end -> " + htmlRow.length());
            }
        }
    }
    private void handleCRes(final CRes cres, final boolean isOobRefresh) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int uiType = 0;
                try {
                    uiType = Integer.parseInt(cres.getAcsUiType());
                } catch (NumberFormatException ex) {
                    transaction.runtimeError("-1012", "Failed to parse CRes message - acsUiType is not a number (\"" + cres.getAcsUiType() + "\")");
                    finish();
                    return;
                }

                // First, remove all the previously set subviews
                container.removeAllViews();
                challengeEditText = null;
                radioButtons = null;
                checkBoxes = null;
                challengeSubmitButton = null;
                whyInfoView = null;
                whyInfoHiddenView = null;
                expandInfoView = null;
                expandInfoHiddenView = null;

                setupToolbarAndHeaderCustomizations();

                // Handle HTML UI type
                if (uiType == 5) {
                    challengeType = ChallengeType.HTML_UI;

                    Log.d(TAG, "handleCRes(): case 05");

                    if (isOobRefresh) {
                        String acsHTMLRefresh = cres.getAcsHTMLRefresh();
                        String acsHTML = acsHTMLRefresh != null ? acsHTMLRefresh : cres.getAcsHTML();
                        if (acsHTML != null) {
                            acsHTML = new Base64URL(acsHTML).decodeToString();
                            printHTML(acsHTML);
                            initWebview(acsHTML);

                            return;
                        }
                    }

                    String acsHTML = cres.getAcsHTML();
                    if (acsHTML != null) {
                        acsHTML = new Base64URL(acsHTML).decodeToString();
                        printHTML(acsHTML);
                        initWebview(acsHTML);

                        return;
                    }

                    transaction.runtimeError("-1013", "Failed to parse CRes message - acsUiType is \"05\" but \"acsHTML\" is null");
                    finish();
                    return;
                }

                //images container
                LinearLayout imageContainer = new LinearLayout(ChallengeActivity.this);
                imageContainer.setOrientation(LinearLayout.HORIZONTAL);
                imageContainer.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams imageContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                imageContainer.setLayoutParams(imageContainerParams);

                //issuer image
                final ImageView issuerImage = new ImageView(ChallengeActivity.this);
                issuerImage.setAdjustViewBounds(true);
                issuerImage.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                LinearLayout.LayoutParams issuerImageParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    issuerImageParams.setMarginStart(32);
                    issuerImageParams.setMarginEnd(12);
                } else {
                    issuerImageParams.setMargins(32, 0, 12, 0);
                }
                issuerImageParams.height = 150;
                issuerImageParams.weight = 1;
                issuerImage.setLayoutParams(issuerImageParams);
                CRes.Image image1 = cres.getIssuerImage();

                String issuerImageUrl = null;

                if (image1 != null) {
                    issuerImageUrl = getImageUrlByDPI(image1);
                }

                if (api == null) {
                    api = new API();
                }

                if (issuerImageUrl != null) {
                    api.get(issuerImageUrl, new API.ImageCallback() {
                        @Override
                        public void onResponse(final byte[] bytes) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                    issuerImage.setImageBitmap(bitmap);
                                }
                            });
                        }

                        @Override
                        public void onFailure(Exception e) {

                        }
                    });
                }

                //ps image
                final ImageView psImage = new ImageView(ChallengeActivity.this);
                psImage.setAdjustViewBounds(true);
                psImage.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                LinearLayout.LayoutParams psImageParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    psImageParams.setMarginStart(12);
                    psImageParams.setMarginEnd(32);
                } else {
                    psImageParams.setMargins(12, 0, 32, 0);
                }
                psImageParams.height = 150;
                psImageParams.weight = 1;
                psImage.setLayoutParams(psImageParams);
                CRes.Image image2 = cres.getPsImage();

                String psImageUrl = null;

                if (image2 != null) {
                    psImageUrl = getImageUrlByDPI(image2);
                }

                if (psImageUrl != null) {
                    api.get(psImageUrl, new API.ImageCallback() {
                        @Override
                        public void onResponse(final byte[] bytes) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                    psImage.setImageBitmap(bitmap);
                                }
                            });
                        }

                        @Override
                        public void onFailure(Exception e) {

                        }
                    });
                }

                imageContainer.addView(issuerImage);
                imageContainer.addView(psImage);

                // Header title
                TextView header = new TextView(ChallengeActivity.this);
                LinearLayout.LayoutParams headerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                header.setLayoutParams(headerParams);
                header.setGravity(Gravity.START);
                header.setMaxEms(45);
                header.setText(cres.getChallengeInfoHeader());
                header.setTextSize(18f);
                header.setTypeface(header.getTypeface(), Typeface.BOLD_ITALIC);
                headerTextView = header;

                // text info 1
                TextView text1 = new TextView(ChallengeActivity.this);
                LinearLayout.LayoutParams text1Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                text1.setLayoutParams(text1Params);
                text1.setMaxEms(350);
                textView1 = text1;

                // text info 2
                TextView text2 = new TextView(ChallengeActivity.this);
                LinearLayout.LayoutParams text2Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                text2Params.setMargins(0, 12, 0, 0);
                text2.setLayoutParams(text2Params);
                text2.setMaxEms(45);
                text2.setTypeface(header.getTypeface(), Typeface.BOLD_ITALIC);
                text2.setText(cres.getChallengeInfoLabel());
                textView2 = text2;

                //warning icon
                warningIcon = new ImageView(ChallengeActivity.this);
                LinearLayout.LayoutParams warningIconParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                warningIconParams.setMargins(0, 0, 32, 0);
                warningIconParams.height = convertDpToPx(40f);
                warningIconParams.width = convertDpToPx(40f);
                warningIcon.setLayoutParams(warningIconParams);
                warningIcon.setImageResource(android.R.drawable.stat_notify_error);
                ImageViewCompat.setImageTintList(warningIcon, ColorStateList.valueOf(Color.RED));


                //warning icon & texts root
                warningIconAndTextsRoot = new LinearLayout(ChallengeActivity.this);
                warningIconAndTextsRoot.setOrientation(LinearLayout.HORIZONTAL);
                warningIconAndTextsRoot.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams warningIconAndTextsRootParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                warningIconAndTextsRoot.setLayoutParams(warningIconAndTextsRootParams);

                LinearLayout warningIconAndTextsRootContainer = new LinearLayout(ChallengeActivity.this);
                warningIconAndTextsRootContainer.setOrientation(LinearLayout.VERTICAL);
                warningIconAndTextsRootContainer.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams warningIconAndTextsRootContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                warningIconAndTextsRootContainer.setLayoutParams(warningIconAndTextsRootContainerParams);
                warningIconAndTextsRootContainer.addView(warningIconAndTextsRoot);
                warningIconAndTextsRootContainer.addView(text2);
                ChallengeActivity.this.warningIconAndTextsRootContainer = warningIconAndTextsRootContainer;

                if (cres.getChallengeInfoTextIndicator() != null && cres.getChallengeInfoTextIndicator().equals("Y")) {
                    warningIconAndTextsRoot.addView(warningIcon);
                }

                if (isOobRefresh && cres.getChallengeAddInfo() != null) {
                    warningIcon.setVisibility(View.GONE);
                    text1.setText(cres.getChallengeAddInfo());
                } else {
                    text1.setText(cres.getChallengeInfoText());
                }

                setupHeaderCostumization(header);

                warningIconAndTextsRoot.addView(text1);

                View whitelistingInfoViews = null;

                // Handle Native UI type
                switch (uiType) {
                    case 1:
                        Log.d(TAG, "handleCRes(): case 01");

                        challengeType = ChallengeType.SINGLE_TEXT_INPUT;

                        //input
                        final EditText editText = new EditText(ChallengeActivity.this);
                        LinearLayout.LayoutParams editTextParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        editText.setLayoutParams(editTextParams);
                        editText.setEms(45);
                        setupTextBoxUI(editText);

                        container.addView(imageContainer);
                        container.addView(header);
                        container.addView(warningIconAndTextsRootContainer);
                        container.addView(editText);

                        buttonsContainer = new LinearLayout(ChallengeActivity.this);

                        if (isPortrait) {
                            buttonsContainer.setOrientation(LinearLayout.VERTICAL);
                            buttonsContainer.setGravity(Gravity.CENTER_HORIZONTAL);
                        } else {
                            buttonsContainer.setOrientation(LinearLayout.HORIZONTAL);
                            buttonsContainer.setGravity(Gravity.CENTER_VERTICAL);
                        }
                        LinearLayout.LayoutParams buttonsContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        buttonsContainerParams.setMargins(0, 30, 0, 0);
                        buttonsContainer.setLayoutParams(buttonsContainerParams);

                        challengeEditText = editText;

                        if (cres.getSubmitAuthenticationLabel() != null) {
                            //verify button
                            Button firstBtn = new Button(ChallengeActivity.this);
                            firstBtn.setBackgroundColor(Color.parseColor("#4684C1"));
                            firstBtn.setTextColor(Color.WHITE);
                            firstBtn.setAllCaps(false);
                            firstBtnParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            firstBtn.setMaxEms(45);

                            setupButtonCustomization(firstBtn, UiCustomization.ButtonType.VERIFY);

                            firstBtn.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    challengeExecutor.performChallengeWithData(editText.getText().toString(), whitelisting);
                                }
                            });

                            firstBtn.setLayoutParams(firstBtnParams);
                            firstBtn.setText(cres.getSubmitAuthenticationLabel());
                            buttonsContainer.addView(firstBtn);

                            challengeSubmitButton = firstBtn;
                        }

                        if (cres.getResendInformationLabel() != null) {
                            //resend code button
                            Button secondBtn = new Button(ChallengeActivity.this);
                            secondBtn.setBackgroundColor(Color.parseColor("#7F7F7F"));
                            secondBtn.setAllCaps(false);
                            secondBtn.setTextColor(Color.WHITE);
                            secondBtnParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            secondBtn.setMaxEms(45);

                            setupButtonCustomization(secondBtn, UiCustomization.ButtonType.RESEND);

                            secondBtn.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    challengeExecutor.performChallengeResendCode();
                                }
                            });

                            secondBtn.setLayoutParams(secondBtnParams);
                            secondBtn.setText(cres.getResendInformationLabel());
                            buttonsContainer.addView(secondBtn);
                        }

                        container.addView(buttonsContainer);
                        whitelistingInfoViews = setupWhitelistingInfoViews(cres, header.getTypeface());
                        if (whitelistingInfoViews != null) {
                            container.addView(whitelistingInfoViews);
                        }
                        container.addView(setupExpandViews(cres, header.getTypeface()));

                        SDKChallengeDataListener.getInstance().handleChallenge();

                        break;

                    case 2:
                        Log.d(TAG, "handleCRes(): case 02");

                        challengeType = ChallengeType.SINGLE_SELECT;

                        radioButtons = new ArrayList<>();

                        container.addView(imageContainer);
                        container.addView(header);
                        container.addView(warningIconAndTextsRootContainer);

                        //selection container
                        LinearLayout selectionContainer = new LinearLayout(ChallengeActivity.this);
                        selectionContainer.setOrientation(LinearLayout.VERTICAL);
                        LinearLayout.LayoutParams selectionContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        selectionContainer.setLayoutParams(selectionContainerParams);
                        ChallengeActivity.this.selectionContainer = selectionContainer;

                        boolean shouldSelect = true;

                        if (cres.getChallengeSelectInfo() != null && cres.getChallengeSelectInfo().size() > 0) {
                            for (Map<String, String> map : cres.getChallengeSelectInfo()) {
                                LinearLayout singleSelection = new LinearLayout(ChallengeActivity.this);
                                RadioButton radioBtn = new RadioButton(ChallengeActivity.this);
                                radioBtn.setText(map.entrySet().iterator().next().getValue());

                                if (shouldSelect) {
                                    radioBtn.setChecked(true);
                                    shouldSelect = false;
                                }

                                radioButtons.add(radioBtn);
                                singleSelection.addView(radioBtn);
                                selectionContainer.addView(singleSelection);

                            }
                            container.addView(selectionContainer);
                        }


                        for (RadioButton radioButton : radioButtons) {
                            radioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    if (isChecked) {
                                        for (RadioButton radioButton : radioButtons) {
                                            if (radioButton != buttonView) {
                                                radioButton.setChecked(false);
                                            }
                                        }
                                    }
                                }
                            });
                        }

                        if (cres.getSubmitAuthenticationLabel() != null) {
                            //verify button
                            Button button = new Button(ChallengeActivity.this);
                            button.setAllCaps(false);
                            button.setBackgroundColor(Color.parseColor("#4684C1"));
                            button.setTextColor(Color.WHITE);
                            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            button.setLayoutParams(buttonParams);
                            buttonParams.height = convertDpToPx(45);
                            button.setMaxEms(45);

                            setupButtonCustomization(button, UiCustomization.ButtonType.VERIFY);

                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    for (int i = 0; i < radioButtons.size(); i++) {
                                        if (radioButtons.get(i).isChecked()) {
                                            String key = new ArrayList<>(cres.getChallengeSelectInfo().get(i).keySet()).get(0);
                                            challengeExecutor.performChallengeWithData(key, whitelisting);
                                        }

                                    }
                                }
                            });

                            button.setText(cres.getSubmitAuthenticationLabel());
                            container.addView(button);
                            singleBtnParams = buttonParams;

                            challengeSubmitButton = button;
                        }

                        whitelistingInfoViews = setupWhitelistingInfoViews(cres, header.getTypeface());
                        if (whitelistingInfoViews != null) {
                            container.addView(whitelistingInfoViews);
                        }
                        container.addView(setupExpandViews(cres, header.getTypeface()));

                        SDKChallengeDataListener.getInstance().handleChallenge();

                        break;

                    case 3:
                        Log.d(TAG, "handleCRes(): case 03");

                        challengeType = ChallengeType.MULTI_SELECT;

                        checkBoxes = new ArrayList<>();

                        container.addView(imageContainer);
                        container.addView(header);
                        container.addView(warningIconAndTextsRootContainer);

                        //selection container
                        LinearLayout multiSelectionContainer = new LinearLayout(ChallengeActivity.this);
                        multiSelectionContainer.setOrientation(LinearLayout.VERTICAL);
                        LinearLayout.LayoutParams multiSelectionContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        multiSelectionContainer.setLayoutParams(multiSelectionContainerParams);
                        ChallengeActivity.this.selectionContainer = multiSelectionContainer;

                        if (cres.getChallengeSelectInfo() != null && cres.getChallengeSelectInfo().size() > 0) {
                            for (Map<String, String> map : cres.getChallengeSelectInfo()) {
                                //mobile
                                LinearLayout multiSelection = new LinearLayout(ChallengeActivity.this);
                                CheckBox checkBox = new CheckBox(ChallengeActivity.this);
                                checkBox.setText(map.entrySet().iterator().next().getValue());

                                checkBoxes.add(checkBox);
                                multiSelection.addView(checkBox);
                                multiSelectionContainer.addView(multiSelection);
                            }
                            container.addView(multiSelectionContainer);
                        }

                        if (cres.getSubmitAuthenticationLabel() != null) {
                            //verify button
                            final Button multiSelectionButton = new Button(ChallengeActivity.this);
                            multiSelectionButton.setAllCaps(false);
                            multiSelectionButton.setTextColor(Color.WHITE);
                            multiSelectionButton.setBackgroundColor(Color.parseColor("#4684C1"));
                            LinearLayout.LayoutParams multiSelectionButtonParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            multiSelectionButtonParams.height = convertDpToPx(45);
                            multiSelectionButton.setMaxEms(45);

                            setupButtonCustomization(multiSelectionButton, UiCustomization.ButtonType.VERIFY);

                            multiSelectionButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    StringBuilder stringBuilder = new StringBuilder();
                                    for (int i = 0; i < checkBoxes.size(); i++) {
                                        if (checkBoxes.get(i).isChecked()) {
                                            String key = new ArrayList<>(cres.getChallengeSelectInfo().get(i).keySet()).get(0);
                                            stringBuilder.append(key).append(",");
                                        }
                                    }
                                    if (stringBuilder.length() > 0) {
                                        stringBuilder.setLength(stringBuilder.length() - 1);
                                    }
                                    challengeExecutor.performChallengeWithData(stringBuilder.toString(), whitelisting);
                                }
                            });

                            multiSelectionButton.setLayoutParams(multiSelectionButtonParams);
                            multiSelectionButton.setText(cres.getSubmitAuthenticationLabel());
                            container.addView(multiSelectionButton);

                            challengeSubmitButton = multiSelectionButton;
                        }

                        whitelistingInfoViews = setupWhitelistingInfoViews(cres, header.getTypeface());
                        if (whitelistingInfoViews != null) {
                            container.addView(whitelistingInfoViews);
                        }
                        container.addView(setupExpandViews(cres, header.getTypeface()));

                        SDKChallengeDataListener.getInstance().handleChallenge();

                        break;

                    case 4:
                        isOobFlow = true;
                        Log.d(TAG, "handleCRes(): case 04");

                        challengeType = ChallengeType.OUT_OF_BAND;

                        container.addView(imageContainer);
                        container.addView(header);
                        container.addView(warningIconAndTextsRootContainer);

                        if (cres.getOobContinueLabel() != null) {
                            //continue button
                            Button oobButton = new Button(ChallengeActivity.this);
                            oobButton.setBackgroundColor(Color.parseColor("#4684C1"));
                            oobButton.setAllCaps(false);
                            oobButton.setTextColor(Color.WHITE);
                            LinearLayout.LayoutParams oobButtonParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            oobButtonParams.height = convertDpToPx(45);
                            oobButton.setMaxEms(45);

                            setupButtonCustomization(oobButton, UiCustomization.ButtonType.CONTINUE);

                            oobButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    challengeExecutor.performChallengeOobContinue(whitelisting);
                                }
                            });

                            oobButton.setLayoutParams(oobButtonParams);
                            oobButton.setText(cres.getOobContinueLabel());
                            container.addView(oobButton);

                            challengeSubmitButton = oobButton;
                        }

                        whitelistingInfoViews = setupWhitelistingInfoViews(cres, header.getTypeface());
                        if (whitelistingInfoViews != null) {
                            container.addView(whitelistingInfoViews);
                        }
                        container.addView(setupExpandViews(cres, header.getTypeface()));

                        if (!isOobRefresh) {
                            SDKChallengeDataListener.getInstance().handleChallenge();
                        }

                        break;
                    default:
                        transaction.runtimeError(
                                "-1014",
                                "Failed to parse CRes message - acsUiType is unrecognized (\"" + cres.getAcsUiType() + "\")");
                        finish();
                        return;
                }

                handleOrientation();
            }
        });
    }

    @Nullable
    private String getImageUrlByDPI(CRes.Image image) {

        String imageUrl = null;

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        float dpi = metrics.density;

        if (dpi > 1.5) {
            imageUrl = image.getExtraHigh();

        } else if (dpi == 1.5) {
            imageUrl = image.getHigh();
        } else if (dpi < 1.5) {
            imageUrl = image.getMedium();
        }

        return imageUrl;
    }

    private void setupTextBoxUI(EditText editText) {
        TextBoxCustomization textBoxCustomization = transaction.uiCustomization.getTextBoxCustomization();

        //TextBox Customizations
        if (textBoxCustomization != null) {
            GradientDrawable shape = new GradientDrawable();

            //TextBox border width
            int borderWidth = textBoxCustomization.getBorderWidth();
            if (borderWidth != 0) {
                //TextBox border color
                String borderColor = textBoxCustomization.getBorderColor();
                if (borderColor != null) {
                    shape.setStroke(borderWidth, Color.parseColor(borderColor));
                }
            }

            //TextBox border radius
            int borderRadius = textBoxCustomization.getCornerRadius();
            if (borderRadius != 0) {
                shape.setCornerRadius(borderRadius);
            }

            //TextBox text color
            String editTextTextColor = textBoxCustomization.getTextColor();
            if (editTextTextColor != null) {
                editText.setTextColor(Color.parseColor(editTextTextColor));
            }

            //TextBox text size
            int editTextTextSize = textBoxCustomization.getTextFontSize();
            if (editTextTextSize != 0) {
                editText.setTextSize(editTextTextSize);
            }

            //TextBox text font
            String editTextTextFont = textBoxCustomization.getTextFontName();
            if (editTextTextFont != null) {
                editText.setTypeface(Typeface.create(editTextTextFont, Typeface.NORMAL));
            }

            editText.setBackground(shape);
        }
    }

    private LinearLayout setupWhitelistingInfoViews(CRes cres, Typeface typeface) {
        String whitelistingInfoText = cres.getWhitelistingInfoText();
        if (whitelistingInfoText == null) {
            return null;
        }

        whitelisting = false;

        // Container
        whitelistingInfoView = new LinearLayout(this);
        whitelistingInfoView.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams moreInfoContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        moreInfoContainerParams.setMargins(32, 10, 32, 0);
        whitelistingInfoView.setLayoutParams(moreInfoContainerParams);
        whitelistingInfoView.setLayoutTransition(new LayoutTransition());

        // Checkbox
        whitelistingCheckBox = new CheckBox(this);
        LinearLayout.LayoutParams whitelistingCheckBoxParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        whitelistingCheckBoxParams.setMargins(32, 10, 32, 0);
        whitelistingCheckBox.setLayoutParams(whitelistingCheckBoxParams);
        whitelistingCheckBox.setMaxEms(45);
        whitelistingCheckBox.setTypeface(typeface, Typeface.NORMAL);
        whitelistingCheckBox.setText(whitelistingInfoText);
        whitelistingInfoView.addView(whitelistingCheckBox);
        whitelistingCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            whitelisting = isChecked;
        });

        return whitelistingInfoView;
    }

    private LinearLayout setupExpandViews(CRes cres, Typeface typeface) {
        //More info container
        LinearLayout moreInfoContainer = new LinearLayout(ChallengeActivity.this);
        moreInfoContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams moreInfoContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        moreInfoContainerParams.setMargins(32, 10, 32, 0);
        moreInfoContainer.setLayoutParams(moreInfoContainerParams);
        moreInfoContainer.setLayoutTransition(new LayoutTransition());

        if (cres.getWhyInfoText() != null) {

            //separator 1
            View separator1 = new View(ChallengeActivity.this);
            LinearLayout.LayoutParams separator1Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            separator1Params.height = 4;
            separator1Params.setMargins(0, 10, 0, 0);
            separator1.setLayoutParams(separator1Params);
            separator1.setBackgroundColor(Color.LTGRAY);

            //Why info hidden view
            whyInfoHiddenView = new TextView(ChallengeActivity.this);
            LinearLayout.LayoutParams whyInfoHiddenViewParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            whyInfoHiddenViewParams.setMargins(60, 12, 60, 24);
            whyInfoHiddenView.setLayoutParams(whyInfoHiddenViewParams);
            whyInfoHiddenView.setText(cres.getWhyInfoText());
            whyInfoHiddenView.setVisibility(View.GONE);

            //Why info view
            whyInfoView = new LinearLayout(ChallengeActivity.this);
            whyInfoView.setOrientation(LinearLayout.HORIZONTAL);
            whyInfoView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            whyInfoView.setGravity(Gravity.CENTER_VERTICAL);
            whyInfoView.setPadding(24, 12, 24, 12);
            whyInfoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (whyInfoHiddenView.getVisibility() == View.GONE) {
                        whyInfoHiddenView.setVisibility(View.VISIBLE);
                    } else {
                        whyInfoHiddenView.setVisibility(View.GONE);
                    }
                }
            });

            //Why info arrow icon
            ImageView whyInfoArrow = new ImageView(ChallengeActivity.this);
            LinearLayout.LayoutParams whyInfoArrowParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            whyInfoArrowParams.height = 32;
            whyInfoArrowParams.width = 32;
            whyInfoArrow.setLayoutParams(whyInfoArrowParams);
            whyInfoArrow.setImageResource(android.R.drawable.arrow_down_float);
            whyInfoArrow.setColorFilter(ContextCompat.getColor(ChallengeActivity.this, android.R.color.darker_gray));


            //why info label
            TextView whyInfoLabel = new TextView(ChallengeActivity.this);
            LinearLayout.LayoutParams whyInfoLabelParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            whyInfoLabelParams.setMargins(32, 0, 0, 0);
            whyInfoLabel.setLayoutParams(whyInfoLabelParams);
            whyInfoLabel.setMaxEms(45);
            whyInfoLabel.setTypeface(typeface, Typeface.BOLD_ITALIC);
            whyInfoLabel.setText(cres.getWhyInfoLabel());

            whyInfoView.addView(whyInfoArrow);
            whyInfoView.addView(whyInfoLabel);

            moreInfoContainer.addView(whyInfoView);
            moreInfoContainer.addView(whyInfoHiddenView);
            moreInfoContainer.addView(separator1);
        }

        if (cres.getExpandInfoText() != null) {
            //separator 2
            View separator2 = new View(ChallengeActivity.this);
            LinearLayout.LayoutParams separator2Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            separator2Params.height = 4;
            separator2Params.setMargins(0, 10, 0, 0);
            separator2.setLayoutParams(separator2Params);
            separator2.setBackgroundColor(Color.LTGRAY);

            //expand info hidden view
            expandInfoHiddenView = new TextView(ChallengeActivity.this);
            LinearLayout.LayoutParams expandInfoHiddenViewParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            expandInfoHiddenViewParams.setMargins(60, 12, 60, 24);
            expandInfoHiddenView.setLayoutParams(expandInfoHiddenViewParams);
            expandInfoHiddenView.setText(cres.getExpandInfoText());
            expandInfoHiddenView.setVisibility(View.GONE);

            //expand info view
            expandInfoView = new LinearLayout(ChallengeActivity.this);
            expandInfoView.setOrientation(LinearLayout.HORIZONTAL);
            expandInfoView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            expandInfoView.setPadding(24, 12, 24, 12);
            expandInfoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (expandInfoHiddenView.getVisibility() == View.GONE) {
                        expandInfoHiddenView.setVisibility(View.VISIBLE);
                    } else {
                        expandInfoHiddenView.setVisibility(View.GONE);
                    }
                }
            });

            //expand info arrow icon
            ImageView expandInfoArrow = new ImageView(ChallengeActivity.this);
            LinearLayout.LayoutParams expandInfoArrowParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            expandInfoArrowParams.height = 32;
            expandInfoArrowParams.width = 32;
            expandInfoArrow.setLayoutParams(expandInfoArrowParams);
            expandInfoArrow.setImageResource(android.R.drawable.arrow_down_float);
            expandInfoArrow.setColorFilter(ContextCompat.getColor(ChallengeActivity.this, android.R.color.darker_gray));

            //expand info label
            TextView expandInfoLabel = new TextView(ChallengeActivity.this);
            LinearLayout.LayoutParams expandInfoLabelParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            expandInfoLabelParams.setMargins(32, 0, 0, 0);
            expandInfoLabel.setLayoutParams(expandInfoLabelParams);
            expandInfoLabel.setMaxEms(45);
            expandInfoLabel.setTypeface(typeface, Typeface.BOLD_ITALIC);
            expandInfoLabel.setText(cres.getExpandInfoLabel());

            expandInfoView.addView(expandInfoArrow);
            expandInfoView.addView(expandInfoLabel);

            moreInfoContainer.addView(expandInfoView);
            moreInfoContainer.addView(expandInfoHiddenView);
            moreInfoContainer.addView(separator2);
        }

        return moreInfoContainer;
    }

    private void setupHeaderCostumization(TextView headerTextView) {
        LabelCustomization labelCustomization = transaction.uiCustomization.getLabelCustomization();

        //Header customizations
        if (labelCustomization != null) {

            //header text color
            String headingTextColor = labelCustomization.getHeadingTextColor();
            if (headingTextColor != null) {
                headerTextView.setTextColor(Color.parseColor(headingTextColor));
            }

            //header text font
            String headingTextFontName = labelCustomization.getHeadingTextFontName();
            if (headingTextFontName != null) {
                headerTextView.setTypeface(Typeface.create(headingTextFontName, Typeface.NORMAL));
            }

            //header text size
            int headingTextSize = labelCustomization.getHeadingTextFontSize();
            if (headingTextSize != 0) {
                headerTextView.setTextSize(headingTextSize);
            }
        }
    }

    private void setupToolbarAndHeaderCustomizations() {
        ToolbarCustomization toolbarCustomization = transaction.uiCustomization.getToolbarCustomization();
        if (toolbarCustomization == null) {
            toolbarCustomization = new ToolbarCustomization();
        }

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        //Toolbar
        Toolbar toolbar = new Toolbar(this);
        if (toolbarCustomization.getBackgroundColor() != null) {
            toolbar.setBackgroundColor(Color.parseColor(toolbarCustomization.getBackgroundColor()));
        } else {
            toolbar.setBackgroundColor(Color.parseColor("#40c1ac"));
        }

        RelativeLayout relativeLayout = new RelativeLayout(this);
        RelativeLayout.LayoutParams relativeLayoutParams = new RelativeLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        relativeLayout.setLayoutParams(relativeLayoutParams);

        //toolbar title
        TextView toolbarTitle = new TextView(this);
        RelativeLayout.LayoutParams toolbarTitleLayoutParams = new RelativeLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        toolbarTitleLayoutParams.addRule(RelativeLayout.CENTER_VERTICAL);
        toolbarTitleLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_START);
        toolbarTitle.setLayoutParams(toolbarTitleLayoutParams);

        toolbarTitle.setText(val(toolbarCustomization.getHeaderText(), "Secure Checkout"));
        toolbarTitle.setTypeface(Typeface.create(val(toolbarCustomization.getTextFontName(), "sans-serif"), Typeface.BOLD));
        toolbarTitle.setTextSize(val(toolbarCustomization.getTextFontSize(), 18));
        toolbarTitle.setTextColor(Color.parseColor(val(toolbarCustomization.getTextColor(), "#ffffff")));
        relativeLayout.addView(toolbarTitle);

        //toolbar cancel btn
        Button button = new Button(this);
        RelativeLayout.LayoutParams buttonLayoutParams = new RelativeLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        buttonLayoutParams.setMargins(0, 0, 0, 0);
        buttonLayoutParams.addRule(RelativeLayout.CENTER_VERTICAL);
        buttonLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_END);
        button.setLayoutParams(buttonLayoutParams);
        button.setText("Cancel");
        button.setBackground(null);
        button.setTextColor(Color.parseColor("#ffffff"));
        setupButtonCustomization(button, UiCustomization.ButtonType.CANCEL);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                privateClickCancelButton();
            }
        });


        relativeLayout.addView(button);

        //Action bar customizations
        if (toolbarCustomization != null) {

            //toolbar background
            String background = toolbarCustomization.getBackgroundColor();
            if (background != null) {
                toolbar.setBackgroundColor(Color.parseColor(background));
            }

            //toolbar header text
            String header = toolbarCustomization.getHeaderText();
            if (header != null) {
                toolbarTitle.setText(header);
            }

            //toolbar header text color
            String headerTextColor = toolbarCustomization.getTextColor();
            if (headerTextColor != null) {
                toolbarTitle.setTextColor(Color.parseColor(headerTextColor));
            }

            //toolbar header text size
            int headerTextSize = toolbarCustomization.getTextFontSize();
            if (headerTextSize != 0) {
                toolbarTitle.setTextSize(headerTextSize);
            }

            //toolbar header text font
            String headerFont = toolbarCustomization.getTextFontName();
            if (headerFont != null) {
                toolbarTitle.setTypeface(Typeface.create(headerFont, Typeface.NORMAL));
            }

            //toolbar cancel button text
            String buttonText = toolbarCustomization.getButtonText();
            if (buttonText != null) {
                button.setText(buttonText);
            }
        }

        toolbar.addView(relativeLayout);
        container.addView(toolbar);

    }

    private void setupButtonCustomization(Button button, UiCustomization.ButtonType type) {
        ButtonCustomization buttonCustomization =
                transaction.uiCustomization.getButtonCustomization(type);

        if (buttonCustomization == null) {
            return;
        }

        GradientDrawable shape = new GradientDrawable();

        //Button background
        String buttonBackground = buttonCustomization.getBackgroundColor();
        if (buttonBackground != null) {
            shape.setColor(Color.parseColor(buttonBackground));
        }

        //Button radius
        int buttonCornerRadius = buttonCustomization.getCornerRadius();
        if (buttonCornerRadius != 0) {
            shape.setCornerRadius(buttonCornerRadius);
        }

        //Button radius
        String buttonTextColor = buttonCustomization.getTextColor();
        if (buttonTextColor != null) {
            button.setTextColor(Color.parseColor(buttonTextColor));
        }

        //Button size
        int buttonTextSize = buttonCustomization.getTextFontSize();
        if (buttonTextSize != 0) {
            button.setTextSize(buttonTextSize);
        }

        //Button font
        String buttonTextFont = buttonCustomization.getTextFontName();
        if (buttonTextFont != null) {
            button.setTypeface(Typeface.create(buttonTextFont, Typeface.NORMAL));
        }

        button.setBackground(shape);
    }

    private String val(@Nullable String value, @NonNull String defaultValue) {
        return value != null && !value.isEmpty() ? value : defaultValue;
    }

    private Integer val(@Nullable Integer value, @NonNull Integer defaultValue) {
        return value != null && value != 0 ? value : defaultValue;
    }

    private void initWebview(String acsHTML) {
        webView = new WebView(this);
        RelativeLayout.LayoutParams webViewLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        webView.setLayoutParams(webViewLayoutParams);
        container.addView(webView);

        // Set parent RelativeLayout to your screen
//        setContentView(container, containerLayoutParams);

        webView.getSettings().setJavaScriptEnabled(false);
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                SDKChallengeDataListener.getInstance().handleChallenge();
            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                Log.d(TAG, "webView.webViewClient.shouldInterceptRequest(" + url + ") LOLLIPOP+");

                if (url.startsWith("data:text/html")) {
                    return null;
                } else {
                    handleWebViewUrl(url);
                    return new WebResourceResponse(
                            "text/html",
                            "UTF-8",
                            new ByteArrayInputStream(new byte[0])
                    );
                }
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                Log.d(TAG, "webView.webViewClient.shouldInterceptRequest(" + url + ") NOT LOLLIPOP+");

                if (url.startsWith("data:text/html")) {
                    return null;
                } else {
                    handleWebViewUrl(url);
                    return new WebResourceResponse(
                            "text/html",
                            "UTF-8",
                            new ByteArrayInputStream(new byte[0])
                    );
                }
            }
        });

        webView.loadData(acsHTML, "text/html; charset=utf-8", "UTF-8");
    }

    private void handleWebViewUrl(String url) {
        boolean intercept = url.toLowerCase().startsWith(HtmlVerify.toLowerCase());
        Log.d(TAG, "handleWebViewUrl(" + url + "): intercept = " + intercept);
        if (intercept) {
            String htmlData = url.startsWith(HtmlVerify) ?
                    url.replace(HtmlVerify + "?", "") :
                    url.replace(HtmlVerify.toLowerCase() + "?", "");
            challengeExecutor.performChallengeWithHtml(htmlData);
        }
    }

    private void privateClickCancelButton() {
        Log.d(TAG, "clickCancelButton()");
        challengeExecutor.performChallengeCancel();
        transaction.cancelled();
        finish();
    }

    // UL tester app integration start
//    @Override
//    public BaseSdkChallenge getCurrentChallenge() {
//        return this;
//    }
//
//    @Override
//    public void clickSubmitButton() {
//        Log.d(TAG, "clickSubmitButton()");
//        if (challengeSubmitButton != null) {
//            challengeSubmitButton.performClick();
//        }
//    }
//
//    @Override
//    public void clickCancelButton() {
//        Log.d(TAG, "clickCancelButton()");
//        privateClickCancelButton();
//    }
//
//    @Override
//    public com.ults.listeners.ChallengeType getChallengeType() {
//        Log.d(TAG, "getChallengeType()");
//        switch (challengeType) {
//            case SINGLE_TEXT_INPUT:
//                return com.ults.listeners.ChallengeType.SINGLE_TEXT_INPUT;
//            case SINGLE_SELECT:
//                return com.ults.listeners.ChallengeType.SINGLE_SELECT;
//            case MULTI_SELECT:
//                return com.ults.listeners.ChallengeType.MULTI_SELECT;
//            case OUT_OF_BAND:
//                return com.ults.listeners.ChallengeType.OUT_OF_BAND;
//            case HTML_UI:
//                return com.ults.listeners.ChallengeType.HTML_UI;
//        }
//
//        throw new RuntimeException("Unknown Challenge Type");
//    }
//
//    @Override
//    public void expandTextsBeforeScreenshot() {
//        Log.d(TAG, "expandTextsBeforeScreenshot()");
//        if (whyInfoView != null && whyInfoHiddenView != null && whyInfoHiddenView.getVisibility() == View.GONE) {
//            whyInfoView.callOnClick();
//        }
//        if (expandInfoView != null && expandInfoHiddenView != null && expandInfoHiddenView.getVisibility() == View.GONE) {
//            expandInfoView.callOnClick();
//        }
//    }
//
//    @Override
//    public void setWhitelistChecked(boolean b) {
//        Log.d(TAG, "setWhitelistChecked(" + b + ")");
//        Log.d("MKMK", "setWhitelistChecked(" + b + ")");
//        whitelistingCheckBox.setChecked(b);
//        whitelisting = b;
//    }
//
//    // TextChallenge
//
//    /**
//     * This function has to fill the challenge's edittext with the input value
//     *
//     * @param value: the text challenge value
//     */
//    @Override
//    public void typeTextChallengeValue(String value) {
//        Log.d(TAG, "TextChallengeListener.typeTextChallengeValue(" + value + ")");
//        if (challengeEditText != null) {
//            challengeEditText.setText(value);
//            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//        }
//    }
//
//    // SingleSelectorChallengeListener
//
//    /**
//     * It selects the option (radio button) that has the index as the entered value of the parameter
//     * index
//     *
//     * @param index: the index of the selected option. For example if the challenge shows three
//     *               options, and the
//     *               value of this parameter is 1, then the SDK should choose(select) the first option
//     */
//    @Override
//    public void selectObject(int index) {
//        Log.d(TAG, "SingleSelectorChallengeListener.selectObject(" + index + ")");
//        if (radioButtons != null && !radioButtons.isEmpty()) {
//            radioButtons.get(index).toggle();
//        }
//    }
//
//    // MultiSelectChallengeListener
//
//    /**
//     * This function has to return all the checkboxes ordered per row (from left to right then and from top to down)
//     */
//    @Override
//    public Object[] getCheckboxesOrdered() {
//        Log.d(TAG, "MultiSelectChallengeListener.getCheckboxesOrdered()");
//        if (checkBoxes != null) {
//            return checkBoxes.toArray();
//        } else {
//            return new ArrayList<>().toArray();
//        }
//    }
//
//    // WebChallengeListener
//
//    /**
//     * In any web challenge scenario, there is a web view object that
//     * presents the HTML data, and this
//     * function should return that object
//     */
//    @Override
//    public Object getWebView() {
//        Log.d(TAG, "WebChallengeListener.getWebView()");
//        return webView;
//    }
//
//    @Override
//    public void setLandscapeOrientation(boolean b) {
//        // Add your own implementation here sample code bellow
//        if (b) {
//            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//        } else {
//            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
//        }
//    }
    // UL tester app integration end

    @Override
    public void onStartedLoading() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showLoading();
            }
        });
    }

    @Override
    public void onFinishedLoading() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                hideLoading();
            }
        });
    }

    @Override
    public void finishActivity() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }
}

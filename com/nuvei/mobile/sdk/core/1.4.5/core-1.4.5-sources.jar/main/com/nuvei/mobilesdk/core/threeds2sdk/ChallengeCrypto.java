package com.nuvei.mobilesdk.core.threeds2sdk;

import android.util.Log;

import com.nuvei.mobilesdk.core.nimbusds.jose.EncryptionMethod;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEAlgorithm;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEHeader;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEObject;
import com.nuvei.mobilesdk.core.nimbusds.jose.Payload;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.DirectEncrypter;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import org.apache.cxf.rs.security.jose.jwa.ContentAlgorithm;
import org.apache.cxf.rs.security.jose.jwe.JweDecryption;
import org.apache.cxf.rs.security.jose.jwe.JweUtils;

import java.text.ParseException;

class ChallengeCrypto implements API.ResponseDecryptor {

    private final static String TAG = "[3DSSDK][ChallengeCrypto]";

    private byte[] sdkCek;

    ChallengeCrypto(byte[] sdkCek) {
        this.sdkCek = sdkCek;
    }

    String encrypt(String creq, String transactionId) throws JOSEException, ParseException {
        Log.d(TAG, "encrypt: transactionId = " + transactionId);
        Log.d(TAG, "encrypt: creq = " + creq);
        JWEHeader.Builder builder = new JWEHeader.Builder(JWEAlgorithm.DIR, EncryptionMethod.A128CBC_HS256);
        builder.keyID(transactionId);
        Payload payload = new Payload(creq);
        JWEObject jweObject = new JWEObject(builder.build(), payload);
        Log.d(TAG, "encrypt: sdkCek = " + sdkCek);
        jweObject.encrypt(new DirectEncrypter(sdkCek));
        //TODO: sometimes the sdk crash here - "jweObject.encrypt(new DirectEncrypter(sdkCek));"

        String serializedObj = jweObject.serialize();
        jweObject = JWEObject.parse(serializedObj);
        String creqJWE = jweObject.serialize();
        Log.d(TAG, "encrypt: creqJWE = " + creqJWE);
        return creqJWE;
    }

    @Override
    public String decrypt(String encrypted) {
        Log.d(TAG, "decrypt: cresJWE = " + encrypted);
        Log.d(TAG, "decrypt: sdkCek = " + sdkCek);

        // Validate input
        String[] components = encrypted.split("\\.");
        if (components.length != 5) {
            throw new InvalidInputException("CRes is invalid (Code 1)");
        }
        String authHeader = components[0];
        if (authHeader.endsWith("=") || authHeader.contains("/") || authHeader.contains(" ") || authHeader.contains("+") || authHeader.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }
        String initVector = components[2];
        if (initVector.endsWith("=") || initVector.contains("/") || initVector.contains(" ") || initVector.contains("+") || initVector.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }
        String ciphertext = components[3];
        if (ciphertext.endsWith("=") || ciphertext.contains("/") || ciphertext.contains(" ") || ciphertext.contains("+") || ciphertext.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }
        String authTag = components[4];
        if (authTag.endsWith("=") || authTag.contains("/") || authTag.contains(" ") || authTag.contains("+") || authTag.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }

        JweDecryption jweDecryption = JweUtils.getDirectKeyJweDecryption(sdkCek, ContentAlgorithm.A128CBC_HS256);
        String cres = jweDecryption.decrypt(encrypted).getContentText();
        Log.d(TAG, "decrypt: cres = " + cres);
        return cres;
    }
}
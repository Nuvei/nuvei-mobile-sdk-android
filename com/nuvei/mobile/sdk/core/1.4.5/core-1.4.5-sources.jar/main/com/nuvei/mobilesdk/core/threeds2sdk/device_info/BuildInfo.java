package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.format.DateFormat;

import com.nuvei.mobilesdk.core.threeds2sdk.device_info.BaseDeviceInfo;

class BuildInfo extends BaseDeviceInfo {

    private static final String DATE_FORMAT_PATTERN = "E, dd MMM yyyy HH:mm:ss z";

    //Build
    //Build is used to determine information about the current  build, extracted from system properties.
    private static final String DI_DD_Android_BOARD = "A042"; //Name of the underlying board, such as "goldfish".
    private static final String DI_DD_Android_BOOTLOADER = "A043"; //System bootloader version number.
    private static final String DI_DD_Android_BRAND = "A044"; //Consumer-visible brand with which the product/hardware will be associated, if any.
    private static final String DI_DD_Android_DEVICE = "A045"; //Name of the industrial design.
    private static final String DI_DD_Android_DISPLAY = "A046"; //Build ID string that is displayed to the user.
    private static final String DI_DD_Android_FINGERPRINT = "A047"; //String that uniquely identifies this build.
    private static final String DI_DD_Android_HARDWARE = "A048"; //Name of the hardware (from the kernel command line or /proc).
    private static final String DI_DD_Android_ID = "A049"; //Either a changelist number, or a label like "M4-rc20".
    private static final String DI_DD_Android_MANUFACTURER = "A050"; //Manufacturer of the product/hardware.
    private static final String DI_DD_Android_PRODUCT = "A051"; //Name of the overall product.
    private static final String DI_DD_Android_RADIO = "A052"; //Radio firmware version number.
    private static final String DI_DD_Android_SERIAL = "A053"; //Hardware serial number, if available.
    private static final String DI_DD_Android_SUPPORTED_32_BIT_ABIS = "A054"; //Ordered list of 32-bit ABIs supported by this device. The most preferred ABI is the first element in the list.
    private static final String DI_DD_Android_SUPPORTED_64_BIT_ABIS = "A055"; //Ordered list of 64-bit ABIs supported by this device. The most preferred ABI is the first element in the list.
    private static final String DI_DD_Android_TAGS = "A056"; //Comma-separated tags describing the build, such as "unsigned,debug".
    private static final String DI_DD_Android_TIME = "A057"; //Build time.
    private static final String DI_DD_Android_TYPE = "A058"; //Type of build, such as "user" or "eng".
    private static final String DI_DD_Android_USER = "A059";

    //Build.VERSION
    //Indicates various version strings.
    private static final String DI_DD_Android_CODENAME = "A060"; //The current development codename, or the string "REL" if this is a release build.
    private static final String DI_DD_Android_INCREMENTAL = "A061"; //The internal value used by the underlying source control to represent this build.
    private static final String DI_DD_Android_PREVIEW_SDK_INT = "A062"; //The developer preview revision of a prerelease SDK.
    private static final String DI_DD_Android_SDK_INT = "A063"; //The user-visible SDK version of the framework; its possible values are defined in Build.VERSION_CODES.
    private static final String DI_DD_Android_SECURITY_PATCH = "A064"; //The user-visible security patch level.

    BuildInfo() {
        collectBuildInfo();
        collectBuildVersionInfo();
        collectAndroidLollipopInfo();
        collectAndroidMInfo();
    }

    @SuppressLint("HardwareIds")
    private void collectBuildInfo() {
        putData(DI_DD_Android_BOARD, Build.BOARD);
        putData(DI_DD_Android_BOOTLOADER, Build.BOOTLOADER);
        putData(DI_DD_Android_BRAND, Build.BRAND);
        putData(DI_DD_Android_DEVICE, Build.DEVICE);
        putData(DI_DD_Android_DISPLAY, Build.DISPLAY);
        putData(DI_DD_Android_FINGERPRINT, Build.FINGERPRINT);
        putData(DI_DD_Android_HARDWARE, Build.HARDWARE);
        putData(DI_DD_Android_ID, Build.ID);
        putData(DI_DD_Android_MANUFACTURER, Build.MANUFACTURER);
        putData(DI_DD_Android_PRODUCT, Build.PRODUCT);
        putData(DI_DD_Android_RADIO, Build.RADIO);
        putData(DI_DD_Android_SERIAL, Build.SERIAL);
        putData(DI_DD_Android_TAGS, Build.TAGS);
        putData(DI_DD_Android_TIME, DateFormat.format(DATE_FORMAT_PATTERN, Build.TIME).toString());
        putData(DI_DD_Android_TYPE, Build.TYPE);
        putData(DI_DD_Android_USER, Build.USER);
    }

    private void collectAndroidLollipopInfo() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            putData(DI_DD_Android_SUPPORTED_32_BIT_ABIS, Build.SUPPORTED_32_BIT_ABIS);
            putData(DI_DD_Android_SUPPORTED_64_BIT_ABIS, Build.SUPPORTED_64_BIT_ABIS);
        } else {
            dpna.put(DI_DD_Android_SUPPORTED_32_BIT_ABIS, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_SUPPORTED_64_BIT_ABIS, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private void collectBuildVersionInfo() {
        putData(DI_DD_Android_CODENAME, Build.VERSION.CODENAME);
        putData(DI_DD_Android_INCREMENTAL, Build.VERSION.INCREMENTAL);
        putData(DI_DD_Android_SDK_INT, String.valueOf(Build.VERSION.SDK_INT));
    }

    private void collectAndroidMInfo() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            putData(DI_DD_Android_PREVIEW_SDK_INT, String.valueOf(Build.VERSION.PREVIEW_SDK_INT));
            putData(DI_DD_Android_SECURITY_PATCH, Build.VERSION.SECURITY_PATCH);
        } else {
            dpna.put(DI_DD_Android_PREVIEW_SDK_INT, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_SECURITY_PATCH, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }
}

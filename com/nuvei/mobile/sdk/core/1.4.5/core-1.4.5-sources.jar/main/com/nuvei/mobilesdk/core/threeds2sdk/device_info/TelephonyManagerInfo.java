package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import androidx.core.content.ContextCompat;

class TelephonyManagerInfo extends BaseDeviceInfo {

    // Telephony Manager
    // User approval is not required for API 22 and earlier because these permissions are granted during installation.)
    // (This group of parameters requires the following permissions: android.permission.SEND_SMS and android.permission.READ_PHONE_STATE
    private static final String DI_DD_Android_DeviceId = "A001";// Android: IMEI for GSM phones and MEID or ESN for CDMA phones
    private static final String DI_DD_Android_SubscriberId = "A002";// Android: For example, IMSI for GSM phones
    private static final String DI_DD_Android_IMEI = "A003";// Android: IMEI
    private static final String DI_DD_Android_GID1 = "A004";// Group identifier level 1 for a GSM phone.
    private static final String DI_DD_Android_Line1Number = "A005"; //Phone number string for line 1.
    private static final String DI_DD_Android_MmsUAProfUrl = "A006"; //MMS user agent profile URL.
    private static final String DI_DD_Android_MmsUserAgent = "A007"; //MMS user agent
    private static final String DI_DD_Android_NetworkCountryIso = "A008"; // ISO country code equivalent of the current registered operator's MCC
    private static final String DI_DD_Android_NetworkOperator = "A009"; //Numeric name(mobile country code + mobile network code) of the current registered operator.
    private static final String DI_DD_Android_NetworkOperatorName = "A010"; //Alphabetic name of the current registered operator.
    private static final String DI_DD_Android_NetworkType = "A011"; //NETWORK_TYPE_xx xx for the current data connection.
    private static final String DI_DD_Android_PhoneCount = "A012"; // Number of phones available.
    private static final String DI_DD_Android_PhoneType = "A013"; //Constant that indicates the device phone type.
    private static final String DI_DD_Android_SimCountryIso = "A014"; //ISO country code equivalent for the SIM provider's country code.
    private static final String DI_DD_Android_SimOperator = "A015"; //MCC+MNC (mobile country code + mobile network code) of the SIM provider.
    private static final String DI_DD_Android_SimOperatorName = "A016"; //Service Provider Name (SPN).
    private static final String DI_DD_Android_SimSerialNumber = "A017"; //Serial number of the SIM, if applicable.
    private static final String DI_DD_Android_SimState = "A018"; //Constant that indicates the state of the default SIM card.
    private static final String DI_DD_Android_VoiceMailAlphaTag = "A019"; //Alphabetic identifier associated with the voice mail number.
    private static final String DI_DD_Android_VoiceMailNumber = "A020"; //Voice mail number.
    private static final String DI_DD_Android_HasIccCard = "A021"; //Returns true if an ICC card is present.
    private static final String DI_DD_Android_IsHearingAidCompatibilitySupported = "A022"; //Indicates whether the phone supports hearing aid compatibility.
    /**
     * Determines if the device is considered roaming on the current network, for GSM purposes.
     */
    private static final String DI_DD_Android_isNetworkRoaming = "A023";
    /**
     * Determines if the current device supports SMS service.
     * Available only for API 21 or higher.
     */
    private static final String DI_DD_Android_isSmsCapable = "A024";
    /**
     * Determines whether the phone supports TTY mode.
     * Available only for API 23 or higher.
     */
    private static final String DI_DD_Android_isTtyModeSupported = "A025";
    /**
     * Determines if the current device is "voice capable".
     * Available only for API 22 or higher.
     */
    private static final String DI_DD_Android_isVoiceCapable = "A026";
    /**
     * Determines whether the device is a world phone.
     * Available only for API 23 or higher.
     */
    private static final String DI_DD_Android_isWorldPhone = "A027";

    TelephonyManagerInfo(Context context) {
        collectTelephonyManagerInfo(context);
    }

    @SuppressLint({"HardwareIds", "MissingPermission"})
    private void collectTelephonyManagerInfo(Context context) {
        String deviceId = null;
        String error = DI_DPNA_RE_PlatformVersionOrDeprecated;
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager != null) {
            if (hasPhonePermission(context) && hasPrivilegedPhonePermissionForOS(context)) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        deviceId = telephonyManager.getImei();
                        if (deviceId == null) {
                            deviceId = telephonyManager.getMeid();
                        }
                    } else {
                        deviceId = telephonyManager.getDeviceId();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                error = DI_DPNA_RE_MissingPermission;
            }
        }

        if (deviceId != null) {
            putData(DI_DD_Android_DeviceId, deviceId);
//            dpna.put("D021", deviceId);
        } else {
            dpna.put(DI_DD_Android_DeviceId, error);
        }

        collectNetworkInfo(context);
    }

    @SuppressLint("HardwareIds")
    private void collectNetworkInfo(Context context) {
        TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);

        if (tm != null) {
            collectAndroidMInfo(tm,  context);
            collectAndroidLollipopInfo(tm);
            collectAndroidLollipopMR1Info(context, tm);
            collectPhoneStatePermissionInfo(context, tm);

            putData(DI_DD_Android_DeviceId, Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID));
            putData(DI_DD_Android_NetworkCountryIso, tm.getNetworkCountryIso());
            putData(DI_DD_Android_NetworkOperator, tm.getNetworkOperator());
            putData(DI_DD_Android_NetworkOperatorName, tm.getNetworkOperatorName());
            putData(DI_DD_Android_PhoneType, String.valueOf(tm.getPhoneType()));
            putData(DI_DD_Android_SimCountryIso, tm.getSimCountryIso());
            putData(DI_DD_Android_SimOperator, tm.getSimOperator());
            putData(DI_DD_Android_SimOperatorName, tm.getSimOperatorName());
            putData(DI_DD_Android_SimState, String.valueOf(tm.getSimState()));
            putData(DI_DD_Android_isNetworkRoaming, String.valueOf(tm.isNetworkRoaming()));
            if (hasPhonePermission(context)) {
                putData(DI_DD_Android_MmsUAProfUrl, tm.getMmsUAProfUrl());
                putData(DI_DD_Android_MmsUserAgent, tm.getMmsUserAgent());
            } else {
                putData(DI_DD_Android_MmsUAProfUrl, DI_DPNA_RE_MissingPermission);
                putData(DI_DD_Android_MmsUserAgent, DI_DPNA_RE_MissingPermission);
            }

            Boolean isIccPresent = Environment.getExternalStorageState()
                    .equals(Environment.MEDIA_MOUNTED);
            Boolean isIccSupportedDevice = Environment.isExternalStorageRemovable();
            String hasIcc = String.valueOf(isIccPresent && isIccSupportedDevice);
            putData(DI_DD_Android_HasIccCard, hasIcc);
        } else {
            dpna.put(DI_DD_Android_DeviceId, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_SubscriberId, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_IMEI, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_NetworkCountryIso, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_NetworkOperator, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_NetworkOperatorName, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_NetworkType, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_PhoneType, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_SimCountryIso, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_SimOperator, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_SimOperatorName, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_SimSerialNumber, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_SimState, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_VoiceMailAlphaTag, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_VoiceMailNumber, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isNetworkRoaming, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_HasIccCard, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_IsHearingAidCompatibilitySupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isTtyModeSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isWorldPhone, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isSmsCapable, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isVoiceCapable, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_GID1, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_Line1Number, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_MmsUAProfUrl, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_MmsUserAgent, DI_DPNA_RE_MarketOrRegionalRestriction);
        }
        collectCountOfNumbers(context);
    }

    @SuppressLint({"HardwareIds", "MissingPermission"})
    private void collectPhoneStatePermissionInfo(Context context, TelephonyManager tm) {
        if (hasPrivilegedPhonePermission(context)) {
            putData(DI_DD_Android_SubscriberId, tm.getSubscriberId());
            putData(DI_DD_Android_SimSerialNumber, tm.getSimSerialNumber());
        } else {
            dpna.put(DI_DD_Android_SubscriberId, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Android_SimSerialNumber, DI_DPNA_RE_MissingPermission);
        }

        if (hasPhonePermission(context)) {
            collectAndroidOInfo(tm, context);

            if (tm.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
                if (hasPrivilegedPhonePermissionForOS(context)) {
                    putData(DI_DD_Android_GID1, tm.getGroupIdLevel1());
                } else {
                    putData(DI_DD_Android_GID1, DI_DPNA_RE_MissingPermission);
                }
            } else {
                dpna.put(DI_DD_Android_GID1, DI_DPNA_RE_PlatformVersionOrDeprecated);
            }
            if (hasPrivilegedPhonePermissionForOS(context)) {
                putData(DI_DD_Android_Line1Number, tm.getLine1Number());
            } else {
                putData(DI_DD_Android_Line1Number, DI_DPNA_RE_MissingPermission);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                putData(DI_DD_Android_NetworkType, parseNetworkType(tm.getDataNetworkType()));
            } else {
                putData(DI_DD_Android_NetworkType, parseNetworkType(tm.getNetworkType()));
            }
            putData(DI_DD_Android_VoiceMailAlphaTag, tm.getVoiceMailAlphaTag());
            putData(DI_DD_Android_VoiceMailNumber, tm.getVoiceMailNumber());
        } else {
            dpna.put(DI_DD_Android_IMEI, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Android_GID1, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Android_Line1Number, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Android_NetworkType, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Android_VoiceMailAlphaTag, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Android_VoiceMailNumber, DI_DPNA_RE_MissingPermission);
        }
    }

    private void collectAndroidLollipopMR1Info(Context context, TelephonyManager tm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            putData(DI_DD_Android_isVoiceCapable, String.valueOf(tm.isVoiceCapable()));
            collectCountOfNumbers(context);
        } else {
            dpna.put(DI_DD_Android_isVoiceCapable, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private void collectAndroidLollipopInfo(TelephonyManager tm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            putData(DI_DD_Android_isSmsCapable, String.valueOf(tm.isSmsCapable()));
        } else {
            dpna.put(DI_DD_Android_isSmsCapable, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private void collectAndroidMInfo(TelephonyManager tm, Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            putData(DI_DD_Android_IsHearingAidCompatibilitySupported,
                    String.valueOf(tm.isHearingAidCompatibilitySupported()));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (hasPhonePermission(context)) {
                    putData(DI_DD_Android_isWorldPhone, String.valueOf(tm.isWorldPhone()));
                    putData(DI_DD_Android_isTtyModeSupported, String.valueOf(tm.isTtyModeSupported()));
                } else {
                    putData(DI_DD_Android_isWorldPhone, DI_DPNA_RE_MissingPermission);
                    putData(DI_DD_Android_isTtyModeSupported, DI_DPNA_RE_MissingPermission);
                }
            } else {
                putData(DI_DD_Android_isTtyModeSupported, String.valueOf(tm.isTtyModeSupported()));
                if (hasPhonePermission(context)) {
                    putData(DI_DD_Android_isWorldPhone, String.valueOf(tm.isWorldPhone()));
                } else {
                    putData(DI_DD_Android_isWorldPhone, DI_DPNA_RE_MissingPermission);
                }
            }


        } else {
            dpna.put(DI_DD_Android_IsHearingAidCompatibilitySupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isTtyModeSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isWorldPhone, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    @SuppressLint({"MissingPermission", "HardwareIds"})
    private void collectAndroidOInfo(TelephonyManager tm, Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (hasPrivilegedPhonePermission(context)) {
                putData(DI_DD_Android_IMEI, tm.getImei());
            }
        } else {
            putData(DI_DD_Android_IMEI, tm.getDeviceId());
        }
    }

    private String parseNetworkType(int networkType) {
        String networkTypeString = "NETWORK_TYPE_";
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_1xRTT:
                networkTypeString += "1xRTT";
            case TelephonyManager.NETWORK_TYPE_CDMA:
                networkTypeString += "CDMA";
            case TelephonyManager.NETWORK_TYPE_EDGE:
                networkTypeString += "EDGE";
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                networkTypeString += "EHRPD";
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
                networkTypeString += "EVDO_0";
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
                networkTypeString += "EVDO_A";
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
                networkTypeString += "EVDO_B";
            case TelephonyManager.NETWORK_TYPE_GPRS:
                networkTypeString += "GPRS";
            case TelephonyManager.NETWORK_TYPE_HSDPA:
                networkTypeString += "HSDPA";
            case TelephonyManager.NETWORK_TYPE_HSPA:
                networkTypeString += "HSPA";
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                networkTypeString += "HSPA+";
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                networkTypeString += "HSUPA";
            case TelephonyManager.NETWORK_TYPE_IDEN:
                networkTypeString += "iDen";
            case TelephonyManager.NETWORK_TYPE_LTE:
                networkTypeString += "LTE";
            case TelephonyManager.NETWORK_TYPE_UMTS:
                networkTypeString += "UMTS";
            default:
                networkTypeString += "UNKNOWN";
        }
        return networkTypeString;
    }

    @SuppressLint("NewApi")
    private void collectCountOfNumbers(Context context) {
        SubscriptionManager subscriptionManager =
                (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (subscriptionManager != null) {
            String countOfNumbers = String.valueOf(subscriptionManager.getActiveSubscriptionInfoCountMax());
            putData(DI_DD_Android_PhoneCount, countOfNumbers);
        } else {
            dpna.put(DI_DD_Android_PhoneCount, DI_DPNA_RE_MarketOrRegionalRestriction);
        }
    }

    private boolean hasPhonePermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasPrivilegedPhonePermission(Context context) {
        return (ContextCompat.checkSelfPermission(context, "android.permission.READ_PRIVILEGED_PHONE_STATE") == PackageManager.PERMISSION_GRANTED);
    }

    private boolean hasPrivilegedPhonePermissionForOS(Context context) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O || hasPrivilegedPhonePermission(context);
    }
}


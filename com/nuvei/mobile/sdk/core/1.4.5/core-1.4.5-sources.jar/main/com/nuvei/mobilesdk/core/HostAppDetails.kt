package com.nuvei.mobilesdk.core

import android.content.Context
import android.telephony.TelephonyManager
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

class HostAppDetails(
    @Transient val packageName: String? = null,
    @Transient val isTestApp: Boolean? = null,
    @Transient var simCountryCode: String? = null
    ) {

    companion object {

        fun setup(context: Context) {
            Nuvei.hostAppDetails = HostAppDetails(
                packageName = context.applicationContext.packageName,
                isTestApp =  context.applicationContext.packageName.startsWith("com.nuvei."),
                simCountryCode = (context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager)?.networkCountryIso?.uppercase()
            )
        }

        fun getIPAddress(useIPv4: Boolean): String {
            try {
                val interfaces: List<NetworkInterface> = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (intf in interfaces) {
                    val addrs: List<InetAddress> = Collections.list(intf.inetAddresses)
                    for (addr in addrs) {
                        if (!addr.isLoopbackAddress) {
                            val sAddr = addr.hostAddress
                            //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                            val isIPv4 = sAddr.indexOf(':') < 0
                            if (useIPv4) {
                                if (isIPv4) return sAddr
                            } else {
                                if (!isIPv4) {
                                    val delim = sAddr.indexOf('%') // drop ip6 zone suffix
                                    return if (delim < 0) sAddr.uppercase() else sAddr.substring(0, delim).uppercase()
                                }
                            }
                        }
                    }
                }
            } catch (ignored: java.lang.Exception) {
            }
            return "0.0.0.0"
        }
    }
}
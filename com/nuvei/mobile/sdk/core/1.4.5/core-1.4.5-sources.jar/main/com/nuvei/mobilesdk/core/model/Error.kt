package com.nuvei.mobilesdk.core.model

enum class Error(val errorCode: Int, val errorDescription: String) {
    IS_PROCESSING(10000, "Previous transaction still processing"),
    INVALID_INPUT(10001, "Invalid input"),
    INTERNAL_ERROR(10002, "Internal error"),
    USER_CANCELLED(10003, "User cancelled"),
    PROTOCOL_ERROR(10004, "PROTOCOL_ERROR"),
    TIMED_OUT(10005, "TIMED_OUT"),
    MISSING_TRANSACTION_ID(10006, "Internal Error"),
    MISSING_THREE_D(10007, "Internal Error"),
    NOT_SET_UP(10008, "SDK not initialized, please call Nuvei.setup(..) function"),
    FORCE_WEB_CHALLENGE(10009, "forceWebChallenge must be true in this version"),
    GENERAL_3D_ERROR(-5, "General 3D error"),
    MISSING_PARAMETER(10010, "Nuvei Mobile SDK cannot initialize."),
    FEATURE_NOT_ENABLED(10011, "Feature not enabled"),
    CLIENT_VALIDATION_FAILED(10002, "Client-side validation failed"),
    BACKEND_ERROR(10013, "Backend error"),
    NETWORK_FAILURE(10014, "Network failure or timeout")
    ;
}
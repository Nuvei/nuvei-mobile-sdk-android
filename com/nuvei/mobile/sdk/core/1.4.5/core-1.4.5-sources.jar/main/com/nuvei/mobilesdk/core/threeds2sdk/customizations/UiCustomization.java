package com.nuvei.mobilesdk.core.threeds2sdk.customizations;

import com.nuvei.mobilesdk.core.threeds2sdk.customizations.ButtonCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.LabelCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.TextBoxCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.ToolbarCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import java.util.TreeMap;

public class UiCustomization {

    public enum ButtonType {SUBMIT, CONTINUE, NEXT, CANCEL, RESEND, VERIFY}

    private final TreeMap<String, ButtonCustomization> buttons = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private ToolbarCustomization toolbarCustomization;
    private LabelCustomization labelCustomization;
    private TextBoxCustomization textBoxCustomization;

    /**
     * The setButtonCustomization method shall accept a ButtonCustomization object along with a predefined button type. The 3DS SDK uses this object for customizing buttons.
     *
     * Note: The 3DS SDK implementer shall maintain a dictionary of buttons passed via this method for use during customization.
     *
     * @param buttonCustomization A ButtonCustomization object.
     * @param buttonType          A pre-defined list of button types.
     *                            For more information, see Enum ButtonType.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized void setButtonCustomization(ButtonCustomization buttonCustomization, ButtonType buttonType) throws InvalidInputException {
        buttons.put(buttonType.toString(), buttonCustomization);
    }

    /**
     * This method is a variation of the setButtonCustomization method.
     * The setButtonCustomization method shall accept a ButtonCustomization object and an implementer-specific button type. The 3DS SDK uses this object for customizing buttons.
     *
     * Note: This method shall be used when the SDK implementer wants to use a button type that is not included in the predefined Enum ButtonType.
     * The SDK implementer shall maintain a dictionary of buttons passed via this method for use during customization.
     *
     * @param buttonCustomization A ButtonCustomization object.
     * @param buttonType          Implementer-specific button type.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized void setButtonCustomization(ButtonCustomization buttonCustomization, String buttonType) throws InvalidInputException {
        if (null == buttonType || buttonType.isEmpty()) {
            throw new InvalidInputException("buttonType is null or empty");
        }
        for (ButtonType bt : ButtonType.values()) {
            // implementation choice: it is probably unwise to differentiate between "VERIFY" and "Verify".
            if (bt.toString().equalsIgnoreCase(buttonType)) {
                // the spec clearly states "that is not included in the predefined Enum ButtonType"
                throw new InvalidInputException("\"String\" buttonType should not be one of the enum values");
            }
        }
        buttons.put(buttonType, buttonCustomization);
    }

    /**
     * The setToolbarCustomization method shall accept a ToolbarCustomization object. The 3DS SDK uses this object for customizing toolbars.
     *
     * @param toolbarCustomization A ToolbarCustomization object.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized void setToolbarCustomization(ToolbarCustomization toolbarCustomization) throws InvalidInputException {
        this.toolbarCustomization = toolbarCustomization;
    }

    /**
     * The setLabelCustomization method shall accept a LabelCustomization object. The 3DS SDK uses this object for customizing labels.
     *
     * @param labelCustomization A LabelCustomization object.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized void setLabelCustomization(LabelCustomization labelCustomization) throws InvalidInputException {
        this.labelCustomization = labelCustomization;
    }

    /**
     * The setTextBoxCustomization method shall accept a TextBoxCustomization object. The 3DS SDK uses this object for customizing text boxes.
     *
     * @param textBoxCustomization A TextBoxCustomization object.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized void setTextBoxCustomization(TextBoxCustomization textBoxCustomization) throws InvalidInputException {
        this.textBoxCustomization = textBoxCustomization;
    }

    /**
     * The getButtonCustomization method shall return a ButtonCustomization object for a specified button type.
     *
     * @param buttonType A pre-defined list of button types.
     *                   For more information, see Enum ButtonType.
     * @return This method returns a ButtonCustomization object.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized ButtonCustomization getButtonCustomization(ButtonType buttonType) throws InvalidInputException {
        return buttons.get(buttonType.toString());
    }

    /**
     * @param buttonType Implementer-specific button type.
     * @return This method returns a ButtonCustomization object.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     */
    public synchronized ButtonCustomization getButtonCustomization(String buttonType) throws InvalidInputException {
        return buttons.get(buttonType);
    }

    /**
     * The getToolbarCustomization method shall return a ToolbarCustomization object for a toolbar.
     * @return This method returns a ToolbarCustomization object.
     */
    public synchronized ToolbarCustomization getToolbarCustomization() {
        return toolbarCustomization;
    }

    /**
     * The getLabelCustomization method shall return a LabelCustomization object.
     * @return This method returns a LabelCustomization object.
     */
    public synchronized LabelCustomization getLabelCustomization() {
        return labelCustomization;
    }

    /**
     * The getTextBoxCustomization method shall return a TextBoxCustomization object.
     * @return This method returns a TextBoxCustomization object.
     */
    public synchronized TextBoxCustomization getTextBoxCustomization() {
        return textBoxCustomization;
    }
}

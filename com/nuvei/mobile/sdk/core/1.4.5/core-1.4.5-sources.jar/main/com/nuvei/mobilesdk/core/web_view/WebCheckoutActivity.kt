package com.nuvei.mobilesdk.core.web_view

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.Gravity
import android.view.MenuItem
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.nuvei.mobilesdk.core.EdgeToEdgeHelper
import com.nuvei.mobilesdk.core.Keys

public class WebCheckoutActivity : AppCompatActivity() {
    private lateinit var container: LinearLayout
    private lateinit var webview: WebView

    private val devCompletionRedirectUrl = "https://devmobile.sccdev-qa.com/autoclose.html"
    private val completionRedirectUrl = "https://cdn.safecharge.com/safecharge_resources/v1/websdk/autoclose.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val url = intent.getStringExtra(Keys.checkoutPaymentMethodUrl) ?: return

        // Create parent LinearLayout
        container = LinearLayout(this).also {
            it.orientation = LinearLayout.VERTICAL
            findViewById<ViewGroup>(android.R.id.content)
                .addView(
                    it, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
        }

        setupToolbar().also {
            it.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            container.addView(it)
        }

        webview = WebView(this).also {
            container.addView(
                it, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0,
                    1F
                )
            )
        }

        webview.webChromeClient = WebChromeClient()
        webview.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)

                if (url?.startsWith(devCompletionRedirectUrl, true) == true) {
                    setResult(RESULT_OK, intent)
                    finish()
                }
            }
        }
        webview.clearCache(true)
        webview.clearHistory()
        webview.settings.javaScriptEnabled = true
        webview.addJavascriptInterface(this, "android")

        webview.loadUrl(url)
        EdgeToEdgeHelper.enableEdgeToEdge(window, container.rootView)
    }

    private fun setupToolbar(): Toolbar {
        supportActionBar?.hide()

        val toolbar = Toolbar(this)

        toolbar.addView(TextView(this).also { title ->
            title.text = ""
            title.layoutParams = Toolbar.LayoutParams(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.WRAP_CONTENT).also {
                it.gravity = Gravity.START
            }
            title.setTextColor(Color.WHITE)
            title.textSize = 18F
            title.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })

        toolbar.addView(Button(this).also { button ->
            button.text = "Cancel"
            button.layoutParams = Toolbar.LayoutParams(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.WRAP_CONTENT).also {
                it.gravity = Gravity.END
            }
            button.background = null
            button.setTextColor(Color.WHITE)
            button.setOnClickListener {
                onBackPressed()
            }
        })

        return toolbar
    }

    @JavascriptInterface
    fun onData(value: String) {
        com.nuvei.mobilesdk.core.Nuvei.onWebViewResult(value)
        this@WebCheckoutActivity.finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                com.nuvei.mobilesdk.core.Nuvei.onUserCanceled()
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        com.nuvei.mobilesdk.core.Nuvei.onUserCanceled()
        super.onBackPressed()
    }
}

package com.nuvei.mobilesdk.core.threeds2sdk.customizations;

import com.nuvei.mobilesdk.core.threeds2sdk.customizations.Customization;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

public class LabelCustomization extends Customization {
    private String headingTextColor;
    private String headingTextFontName;
    private int headingTextFontSize;

    public void setHeadingTextColor(String hexColorCode) throws InvalidInputException {
        this.headingTextColor = hexColorCode;
    }

    public void setHeadingTextFontName(String fontName) throws InvalidInputException {
        this.headingTextFontName = fontName;
    }

    public void setHeadingTextFontSize(int fontSize) throws InvalidInputException {
        this.headingTextFontSize = fontSize;
    }

    public String getHeadingTextColor() {
        return headingTextColor;
    }

    public String getHeadingTextFontName() {
        return headingTextFontName;
    }

    public int getHeadingTextFontSize() {
        return headingTextFontSize;
    }
}

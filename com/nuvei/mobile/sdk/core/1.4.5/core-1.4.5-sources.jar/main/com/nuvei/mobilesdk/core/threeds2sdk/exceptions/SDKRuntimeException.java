package com.nuvei.mobilesdk.core.threeds2sdk.exceptions;

/**
 * This exception shall be thrown if an internal error is encountered by the 3DS SDK.
 */
public class SDKRuntimeException extends RuntimeException {
    public static final String ENCRYPTION_KEY_GENERATION_FAILURE_CODE = "ENCRYPTION_KEY_GENERATION_FAILURE_CODE";

    private String errorCode = null;

    public SDKRuntimeException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }
}

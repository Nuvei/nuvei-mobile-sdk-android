package com.nuvei.mobilesdk.core.threeds2sdk.customizations;

import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

public class Customization {
    private String textFontName;
    private String textColor;
    private int textFontSize;

    public void setTextFontName (String fontName) throws InvalidInputException {
        this.textFontName = fontName;
    }

    public void setTextColor (String hexColorCode) throws InvalidInputException {
        this.textColor = hexColorCode;
    }

    public void setTextFontSize (int fontSize) throws InvalidInputException {
        this.textFontSize = fontSize;
    }

    public String getTextFontName() {
        return textFontName;
    }

    public String getTextColor() {
        return textColor;
    }

    public int getTextFontSize() {
        return textFontSize;
    }
}

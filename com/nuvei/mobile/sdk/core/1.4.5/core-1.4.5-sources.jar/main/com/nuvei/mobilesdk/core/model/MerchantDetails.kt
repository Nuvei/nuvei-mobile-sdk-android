package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class MerchantDetails(
    @SerializedName("customField1") val customField1: String? = null,
    @SerializedName("customField2") val customField2: String? = null,
    @SerializedName("customField3") val customField3: String? = null,
    @SerializedName("customField4") val customField4: String? = null,
    @SerializedName("customField5") val customField5: String? = null,
    @SerializedName("customField6") val customField6: String? = null,
    @SerializedName("customField7") val customField7: String? = null,
    @SerializedName("customField8") val customField8: String? = null,
    @SerializedName("customField9") val customField9: String? = null,
    @SerializedName("customField10") val customField10: String? = null,
    @SerializedName("customField11") val customField11: String? = null,
    @SerializedName("customField12") val customField12: String? = null,
    @SerializedName("customField13") val customField13: String? = null,
    @SerializedName("customField14") val customField14: String? = null,
    @SerializedName("customField15") val customField15: String? = null
): Serializable
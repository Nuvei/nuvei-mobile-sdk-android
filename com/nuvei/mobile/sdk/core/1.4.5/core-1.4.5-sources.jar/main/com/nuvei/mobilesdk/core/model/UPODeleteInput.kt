package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class UPODeleteInput(
    @SerializedName("sessionToken") val sessionToken: String,
    @SerializedName("merchantSiteId") val merchantSiteId: String,
    @SerializedName("merchantId") val merchantId: String,
    @SerializedName("userPaymentOptionId") val userPaymentOptionId: String?,
    @SerializedName("sourceApplication") val sourceApplication: String? = null
): Serializable
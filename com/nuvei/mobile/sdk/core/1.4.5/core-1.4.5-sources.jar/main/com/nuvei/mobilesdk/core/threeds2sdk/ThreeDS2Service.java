package com.nuvei.mobilesdk.core.threeds2sdk;

import android.content.Context;
import android.util.Log;
import android.util.Pair;

import com.google.gson.Gson;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.UiCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.device_info.DeviceInfo;
import com.nuvei.mobilesdk.core.threeds2sdk.enums.Severity;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.SDKAlreadyInitializedException;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.SDKNotInitializedException;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.SDKRuntimeException;
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ConfigParameters;

import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

// https://simulator-mutual-3ds.selftestplatform.com/v2.2.0/3dsServer/1598/
public class ThreeDS2Service {

    Set<String> supportedVersions = new HashSet<>();

    private final AtomicBoolean inited = new AtomicBoolean(false);

    private Map<String, DSPublicKey> dsPublicKeys;

    private UiCustomization uiCustomization;

    private ConfigParameters configParameters;

    private Context applicationContext;

    private final String sdkVersion = "1.3.2"; // RELEASE

    private final static String sdkReferenceNumber = "3DS_LOA_SDK_PPFU_020100_00007";

    /**
     * Singleton
     */
    private static ThreeDS2Service instance = new ThreeDS2Service();

    public static ThreeDS2Service getInstance() {
        return instance;
    }

    public ThreeDS2Service() {
        supportedVersions.add("2.1.0");
        supportedVersions.add("2.2.0");

        Log.d("[3DSSDK]", "ThreeDS2Service()");
        HashMap<String, DSPublicKey> dsPublicKeys = new HashMap<>();
        String id;
        DSPublicKey pk;

        String rootCA = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxH2NsbizYzPP98axus3e" +
                "xW7lx3whYngREUbhkEi2DJhEuZIYI2bXjefTXqA2yLt1zRQpuE0dk06U3Y5khVPH" +
                "g9RN/gl1vTOkHMwqE7uTmYfoesjmEzBJLfsA39wtIWXv+448tj6HYhx37ntEkmSC" +
                "UOVZuLFJJhA2w23EnUZRZsVHtmsl97ZWMsc5noWUhkPI5lYZ1tF1oN+pkCTbL19p" +
                "y5wQefBBNhrRnV/W5ynVzX2UwD0q3Ujp1zD/exofkadbnd2AJ3CjuETs4jUlo8w6" +
                "GtDn8J2iVrMdiOnW1gT0uUB0GbZ/8NIh2sqV6EzHmVIyFUqyh8dGQB697+qVB+qM" +
                "vkPQfd/RJTn5Tq2hcnWpT5N94vrcQegc8i8JbAxmWniJuCW5a6pcdEMs0Gf09G2n" +
                "235Zhc6HZembwIEg+Dpz6OQEOw5eBPV4iGvOZdI5W+9bPl8v/aTQb7KXdyh07dG/" +
                "yeY+7M0ZDm7Z4pKxbBLueR3EfYc+XxKH6L3G5CwS7zQi3Ga85ogyYS+lrK6aNO1J" +
                "mP/U/wwZozTk4gypN3MvzfbD41nqGrsgn37J+si5zS2eIbA/h+7wqaDzMchcSWjT" +
                "msL9PGRfte66gnLkaXz1OlFizQpggNX0jGG3LTtvErUtqOmnFhd52HaoJ1WQoNPx" +
                "9jN2+UznlZgLgkFg1QHKMYECAwEAAQ==";
//        String rootCA = "MIIF3jCCA8agAwIBAgIJAJMvvesjmDyhMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAk5M" +
//                "MSkwJwYDVQQKDCBVTCBUcmFuc2FjdGlvbiBTZWN1cml0eSBkaXZpc2lvbjEgMB4GA1UECwwXVUwgVFMg" +
//                "M0QtU2VjdXJlIFJPT1QgQ0ExIDAeBgNVBAMMF1VMIFRTIDNELVNlY3VyZSBST09UIENBMB4XDTE2MTIy" +
//                "MDEzNTAwNVoXDTM2MTIxNTEzNTAwNVowfDELMAkGA1UEBhMCTkwxKTAnBgNVBAoMIFVMIFRyYW5zYWN0" +
//                "aW9uIFNlY3VyaXR5IGRpdmlzaW9uMSAwHgYDVQQLDBdVTCBUUyAzRC1TZWN1cmUgUk9PVCBDQTEgMB4G" +
//                "A1UEAwwXVUwgVFMgM0QtU2VjdXJlIFJPT1QgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC" +
//                "AQDEfY2xuLNjM8/3xrG6zd7FbuXHfCFieBERRuGQSLYMmES5khgjZteN59NeoDbIu3XNFCm4TR2TTpTd" +
//                "jmSFU8eD1E3+CXW9M6QczCoTu5OZh+h6yOYTMEkt+wDf3C0hZe/7jjy2PodiHHfue0SSZIJQ5Vm4sUkm" +
//                "EDbDbcSdRlFmxUe2ayX3tlYyxzmehZSGQ8jmVhnW0XWg36mQJNsvX2nLnBB58EE2GtGdX9bnKdXNfZTA" +
//                "PSrdSOnXMP97Gh+Rp1ud3YAncKO4ROziNSWjzDoa0OfwnaJWsx2I6dbWBPS5QHQZtn/w0iHaypXoTMeZ" +
//                "UjIVSrKHx0ZAHr3v6pUH6oy+Q9B939ElOflOraFydalPk33i+txB6BzyLwlsDGZaeIm4Jblrqlx0QyzQ" +
//                "Z/T0bafbflmFzodl6ZvAgSD4OnPo5AQ7Dl4E9XiIa85l0jlb71s+Xy/9pNBvspd3KHTt0b/J5j7szRkO" +
//                "btnikrFsEu55HcR9hz5fEofovcbkLBLvNCLcZrzmiDJhL6Wsrpo07UmY/9T/DBmjNOTiDKk3cy/N9sPj" +
//                "WeoauyCffsn6yLnNLZ4hsD+H7vCpoPMxyFxJaNOawv08ZF+17rqCcuRpfPU6UWLNCmCA1fSMYbctO28S" +
//                "tS2o6acWF3nYdqgnVZCg0/H2M3b5TOeVmAuCQWDVAcoxgQIDAQABo2MwYTAdBgNVHQ4EFgQUmHZrhouC" +
//                "bMBgM5sAiDHv0vAbe/IwHwYDVR0jBBgwFoAUmHZrhouCbMBgM5sAiDHv0vAbe/IwDwYDVR0TAQH/BAUw" +
//                "AwEB/zAOBgNVHQ8BAf8EBAMCAYYwDQYJKoZIhvcNAQELBQADggIBAKRs5Voebxu4yzTMIc2nbwsoxe0Z" +
//                "dAiRU44An3j4gzwuqCic80K4YloiDOIAfRWG7HbF1bG37oSfQBhR0X2zvH/R8BVlSfaqovr78rGOyejN" +
//                "AstfGpmIaYT0zuE2jvjeR+YKmFCornhBojmALzYNQBbFpLUC45He8z5gB2jsnv7l0HRsXJGN11aUQvJg" +
//                "wjQTbc4FbAnWIWvAKcUtyeWiCBvFw/FTx23ZWMUW8jMrjdyiRan7dXc6n5vD/DV3tuM5rMWEA5x07D97" +
//                "DV/wvs/M8I8DL6mI2tEPfwVf/QIW4UONpnlAh6i9DevB+sKrqrilXE91pPOCmBXYXBxbAPW8M3Gh7k2V" +
//                "VW/jL4kqoB4HfH0IDHqIVeSXirSHxovK/fGIqjEuedLWzMMKTcEcYi7LVSqFvFYV/khimumAl8SFVpHQ" +
//                "sQ7LvsKim1CsupkO+fUb44dkaUum6QC/iInk78KRgGV8XZA25yw4w/FJaWek0jnuCJk7V+77N6PGK0Fx" +
//                "mSdrHRNzNSoTkma4PtZITnGNTGqXeTV0Hvr8ClbQfBWpqaZtKB8dTkhRCTUPasYZZLFtj2Y2WcXshMBA" +
//                "hEnBiCsoaIGz1xxcyFH4IoiC2GKbfi5pjXrHfRrtPIr1B4/uWMHxIttEFK3qK/3Vc1bjdX6H4IUWNV62" +
//                "P52kwdsMXNoQ55jw";

        id = "F000000000";
        pk = new DSPublicKey(
                id,
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAr/O0BfXWngO9OJDBsqdR5U2h28" +
                        "jrX6Y+LlblTBaYeT2tW7+ca3YzTFXA8duVUwdlWxl3JZCOOeL1feVP6g0TNOHVCkCnirVDLk" +
                        "cozod4aSkNvx+929aDr1ithqhruf0skBc2sMZGBBCNpso6XGzyAf2uZ2+9DvXoKIUYgcr7PQ" +
                        "mL2Y0awyQN7KCRcusaotYNz2mOPrL/hAv6hTexkNrQKzFcPwCuc6kN6aNjD+p2CJ51/5p02S" +
                        "NS70nPOmwmg63j6f3n7xVykQ56kNc1l5B5xOpeHJmqk3+hyF1dF/47rQmMFicN41QSvZ5AZJ" +
                        "KgWlIn2VQROMkEHkF9ZBRLx1nFTwIDAQAB",
                DSPublicKey.Algorithm.RSA,
                rootCA,
                DSPublicKey.Algorithm.RSA
        );
        dsPublicKeys.put(id, pk);
        id = "F055545342";
        dsPublicKeys.put(id, pk);

        id = "F000000001";
        pk = new DSPublicKey(
                id,
                "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEYktbLuAv0v52erE5LPscomKaOmQsvevxzO" +
                        "yn9k4sF1hqpBc5kUygzxA9Jl0R/2dTuk8ka7UCujk36xeUsLVpWA==",
                DSPublicKey.Algorithm.EC,
                rootCA,
                DSPublicKey.Algorithm.RSA
        );
        dsPublicKeys.put(id, pk);
        id = "F155545342";
        dsPublicKeys.put(id, pk);

        this.dsPublicKeys = dsPublicKeys;
    }

    /**
     * The 3DS Requestor App calls the initialize method at the start of the
     * payment stage of a transaction. The app passes configuration parameters,
     * UI configuration parameters, and (optionally) user locale to this method.
     * Note: Until the ThreeDS2Service instance is initialized, it shall be
     * unusable. The following tasks are performed during initialization:<ul>
     * <li>Security checks
     * <li>Collection of device information for all versions of the protocol
     * that the SDK supports.<br>For more information about the device
     * identification parameters that shall be collected, refer to EMV 3-D
     * Secure SDK - Device Information.
     * </ul>
     * Depending on the 3DS Requestor App implementation, a ThreeDS2Service
     * instance is called either during 3DS Requestor App startup as a
     * background task or when a transaction is initiated. The state is
     * maintained until the cleanup method is called.
     *
     * @param applicationContext An instance of Android application context.
     * @param configParameters   Configuration information that shall be used
     *                           during initialization. For more information, see Class ConfigParameters.
     * @param locale             (optional) String that represents the locale for the app’s
     *                           user interface. For example, the value of locale can be "en_US" in Java.
     *                           Note: If this parameter is not provided, then the default device locale
     *                           is used.
     * @param uiCustomization    (optional) UI configuration information that is
     *                           used to specify the UI layout and theme. For example, font style and font
     *                           size. For more information, see Class UiCustomization.
     * @throws InvalidInputException          This exception shall be thrown in any of
     *                                        the following scenarios:<ul>
     *                                        <li>configParameters is null.
     *                                        <li>The value of configParameters, locale, or uiCustomization is
     *                                        invalid.</ul>
     *                                        For more information, see Class InvalidInputException.
     * @throws SDKAlreadyInitializedException This exception shall be thrown if
     *                                        the 3DS SDK instance has already been initialized.
     * @throws SDKRuntimeException            This exception shall be thrown if an internal
     *                                        error is encountered by the 3DS SDK.
     */
    public void initialize(
            Context applicationContext,
            ConfigParameters configParameters,
            String locale,
            UiCustomization uiCustomization)
            throws InvalidInputException, SDKAlreadyInitializedException, SDKRuntimeException {
        Log.d("[3DSSDK]", "ThreeDS2Service.initialize()");
        if (!inited.compareAndSet(false, true)) {
            throw new SDKAlreadyInitializedException(
                    "initialize() cannot be called twice for the same transaction. " +
                            "cleanup() should be called.");
        }
        if (applicationContext == null) {
            throw new InvalidInputException("applicationContext cannot be null");
        }
        if (configParameters == null) {
            throw new InvalidInputException("configParameters cannot be null");
        }

        this.applicationContext = applicationContext;

        //TODO: tmp - should remove this in the future
        configParameters.addParam(ConfigParameters.HOSTING_APP_GROUP_NAME,
                ConfigParameters.HOSTING_APP_IMAGE,
                "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCABEAKgDASIAAhEBAxEB/8QAHQAAAgIDAQEBAAAAAAAAAAAAAAcGCAECBAMFCf/EADIQAAEDBAIBBAAFAwMFAAAAAAECAwQABQYREiEHEzFBUQgUIiNhFTJxF0JSU2KRk+H/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8A/VOsbArNRXyHkMzGLA/c4aAtSEk90Ep5J+6Nj7qp5/EllwXr8qzxUrW+P/2nLa89uM3AlZIUpDyWyrXxsCgZfJP3RsfdVPk/iRygcuEdv30P0/zTkxLP7ndsGkX91tPrNN8ta/igZnJP3RsfdVSl/iSyluS62IzWm1kf207fE2aT81sy5s1ASoEDqgYGxWa8FKKACskfVfGv2XW3G0etc5CUIPsN9mg+/sVmoHZvLmI3ieLfFlKS6s9c+qmwdC0Bba+QI61Qe1Y2K8UuFW07O6wslJ5KUe+tUHvus1wzZ8e3RS/JXxbHZJNbW2ezcGEvx3AttQ6INB2UUUUBRRRQFFFFAVDvKVrmXjFJcKCgrcWggADZqY1Fs/vz+OWN66soKiynfEfNBU7/AEgzJSkAW2SNK9y2fun3Y8Vu0bxi5ZpDK/zCm1JA13ulyPxMXNTgSLYr9R1rlTdteeTJeCryRcUhwIUoI39UFbnfDeblWhBf7P8A0z90+MExe6W/x7MtMphwSFo0EkHe9UuXvxMXloKR/Sle+t8h1TbxTP5F6wmRf1MFDjSeWt+/VBXed4fzByXIcbt7+luEj9s/dWD8I41cscsC41zaWhalDpQ1Stl/iTubch2Mi2qJaWQDy96c3ivNpOZ2dc6VGLSkkDRNBNXCpPyCPgUjGbT/AKi+U7jAu7qlM2d0cUb69t+1PPj12dk0jLnMm+M/I0q/yIq12+6O8nXkjpA9qCXZj4ctmQRm/wCncY0llaVIWj9PQP8AFfNv2U5NYvRxizsPNvMgcpS0nhofyeq58u8xJuyGrb49Q7PmOrTsISU6G+/eozdbtcXMkEHMLo5aowRySSlSg4r/AI9UEjsXmaUmHcY10UHZsLX609hX+K47D5pvc+3yr7OiOsxkOlhlK0a5KH1S6gIQ3fLgxGZccZeUPSXwP7g+6n9yx+fL8etKiQlc4covrQBo61QfLzjOc+Xhkq8Tor/5F8HSQjtKaaHhZ8y8Jt8slX7zCVaV7ilzlPlC03jxm5aYLC3rgG/SXH9M7BHX1TJ8NNPsYRbjJjlhRYTtBHtQT2ivMrVy1rr/ADQhwKGt9ig9KK0DqCdbrKlce9boNqKwDsbHzRQZqFeVbdOueKy40JsrcWggCprUZz3IhjVkcuJZ9VKASU0FO2fGmZhw87YoHn10asLYcfvDPity1vskSS2oBOqhQ/EhFdXxFlSngrj8d017XnzNwwpWRCHpKUFXp/4oKsP+L842tItyjs9HR+6sJgOOXSJ41l2uUwUyFN9D7Oqhbv4ko6CvVnSCg6AOqauJ581d8PkZB+U0EI5cR18UFYJ3jHM1zZDrdtV2s/B+6sf4Is1zsuPOR7oyW18h0aX0r8R8diU60LOlQQopPtTb8cZg3mNpVNbi+inY6oJo4Uq60eu+qidxyPDLncjjdyUwuZy4emsje6lyBvQI9qqzmWPT7l5YuV2sj7iZkF3klvZ0oj+KB+yrfiGFxxczCjsaIAWPs11i3Y7kbTdzctzcgK9isUo/IWUt5V43bQoqRLjSGkPjlo8gobraT5FmelFxfGZSYj7aElbqxyAGvqgcScex+MoPJt0dCU+6j8V1ttWx+OpuOGlMHpQSdg/xSIf8i3560XDGn5wcuSx+1ISnQ/nquHxhlWYY5DUcnkfmoz0ooQsDWjQPVGH4y26p1q0Rx6h2rqvpI/LwmktsMlLaeglI+KUcjzC+jPUYsmMS2rj+7vrsV4X7zLKgzpcONFLimnS0kj5PsDQOlSCviSriPetVFvkpfaeA2f5pIoyryHjD8W6ZE8mXCkrH6EI4lCT9mudflHKspyNy1Y6yW4oSoKcI2B1QOW25HbLpKdjRHApTR0qvqAjvjs7qt+JZ9AwxdxiXGUX7tIeKW0g67p2YRIvc61In3UhJdPII12B8UEpR/aKKE/2iig2qD+W4kmdikliI16i1JIA1U4rxcQhY9N5CVJPwRugok1hOV/mCDatJ5+4SasTY7RcI/ixdvMcpeLShrVN/8hAA0YTH/rFbeiy2gMoaRx+uPVBRN/BMo9RzVtKtn5SfurFePrPc4njGZDfj8HS30nR+qcJgwt9Q4+vn9sUJZSj9AabS2f8AaEjVBRyfg+UOypS27ZoKWSDxP3Vk/AdruVqxtUeezwUSOtUzjboHe4bH6v8AsFboYbYTwYQhI+gNUG6z0AD2KTNktdxR5Zus9yLxaU7sK17jVON0pVpKtgjvdYQyyT6oZQHFe6uPZoK2edsNyDH30XPGGlOxZclCnmQDxJUobPVc8jGJGK3pm+XllxMWW0EKUkdjdWcfbjvJ4vsIdSDvSkgivJ+LDmftSYjLzY9gtAIH/mgQtotLV4/NzbPaw622klMhxJ5ivGPFnXrx9cIDLbgnw5S3G061vQqwbESHFbLceKy2k9EIQADWqYUNAPpw2Ec/7uKAN0FZYuI5SvAxla4vK9/qHYO+joV9F/A781hEXIywV3JfF55BB9/c1YlMSO2n0W2UaH+3X6a3W0n0w36SCAO08etf4oEbkmarzC1wLDaYJU8vi09tP9nWiRXR4txe445c7jGeaJSUK0tQ7pwxrbbWnS61bo7aj8paAO66hHjjaw2gH5OvegrfD8Q/1m7XS+SWlCUy4XGFa+abvjW7XBy0pt12B/MMEoJI+PipohthGyhlCd++k63XmxGjtOKebZQlavfSaDrT7CihPtRQZrVaQdbFFFAEDj7UBI1vVFFAcRx9qwUp0OqKKAUBoUaGxRRQalCT7it+Kfqiig1CU/VZbQlIIA6oooMBKRvqslI0OqKKDISCOxQkDvqiigwEjnvVYKQQRr3oooDiNa1WeKdnqiig2HtRRRQf/9k=");

        String directoryServerId = configParameters.getParamValue(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_ID);
        String publicKey = configParameters.getParamValue(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_KEY);
        String algName = configParameters.getParamValue(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_ALG_KEY);
        DSPublicKey.Algorithm algorithm = ConfigParameters.DIRECTORY_SERVER_ALG_RSA.equalsIgnoreCase(algName) ? DSPublicKey.Algorithm.RSA : DSPublicKey.Algorithm.EC;
        String rootCA = configParameters.getParamValue(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_ROOT_CA_KEY);
        String rootCaAlgName = configParameters.getParamValue(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_ROOT_CA_ALG_KEY);
        DSPublicKey.Algorithm rootCaAlgorithm = ConfigParameters.DIRECTORY_SERVER_ALG_RSA.equalsIgnoreCase(rootCaAlgName) ? DSPublicKey.Algorithm.RSA : DSPublicKey.Algorithm.EC;
        DSPublicKey dsPublicKey = new DSPublicKey(directoryServerId, publicKey, algorithm, rootCA, rootCaAlgorithm);
        dsPublicKeys.put(directoryServerId, dsPublicKey);
        this.uiCustomization = uiCustomization;
        this.configParameters = configParameters;

        // Generate an EC key pair
//        try {
//            HashMap<Algorithm, JWK> privateKeys = new HashMap<>();
//            ECKey ecJWK = new ECKeyGenerator(Curve.P_256).generate();
//            privateKeys.put(Algorithm.EC, ecJWK);
//            ECKey ecPublicJWK = ecJWK.toPublicJWK();
//
//            // Generate 2048-bit RSA key pair in JWK format, attach some metadata
//            RSAKey rsaJWK = new RSAKeyGenerator(2048)
//                    .keyUse(KeyUse.ENCRYPTION) // indicate the intended use of the key
//                    .keyID(UUID.randomUUID().toString()) // give the key a unique ID
//                    .generate();
//            privateKeys.put(Algorithm.RSA, rsaJWK);
//            RSAKey rsaPublicJWK = rsaJWK.toPublicJWK();
//
//            this.privateKeys = privateKeys;

//            ECDHDecrypter decrypter = new ECDHDecrypter(ecJWK);
//            decrypter.decrypt()

//            RSAKey key = new RSAKey();
//            RSAEncrypter encrypter = new RSAEncrypter();
//
//        } catch (JOSEException e) {
//            e.printStackTrace();
//            throw new SDKRuntimeException("Failed to generate EC key pair", SDKRuntimeException.ENCRYPTION_KEY_GENERATION_FAILURE_CODE, e);
//        }

    }

    public boolean isInitialized() {
        return inited.get();
    }

    /**
     * The createTransaction method creates an instance of Transaction through which the 3DS
     * Requestor App gets the data that is required to perform the transaction.
     * The 3DS Requestor App calls the createTransaction method for each transaction that is to be
     * processed.
     * When the createTransaction method is called:<ul>
     * <li>The 3DS SDK uses the information adhering to the protocol version passed in the optional
     * messageVersion parameter, if it supports the protocol version. If it does not support the
     * protocol version, it generates an InvalidInputException. If the messageVersion parameter is
     * empty or null, the highest protocol version that the 3DS SDK supports is used. If Challenge
     * Flow is triggered for the transaction, the 3DS SDK uses the same protocol version during the
     * challenge process.
     * <li>The 3DS SDK uses a secure random function to generate a Transaction ID in AppId format.
     * This ID is used to uniquely identify each transaction.
     * <li>The 3DS SDK generates a fresh ephemeral key pair. Thi subsequently during the
     * transaction.</ul>
     *
     * @param directoryServerID Registered Application Provider Identifier (RID)
     *                          that is unique to the Payment System.<br>
     *                          RIDs are defined by the ISO 7816-5 standard.<br>
     *                          RIDs are issued by the ISO/IEC 7816- 5 registration authority.<br>
     *                          Contains a 5-byte value.<br>
     *                          The 3DS SDK encrypts the device information by using the DS public key.
     *                          This key is identified based on the directoryServerID that is passed to
     *                          the createTransaction method.<br>
     *                          Note: The 3DS SDK shall have the DS Public Keys of all the 3-D Secure
     *                          participating Directory Servers.
     * @param messageVersion    (optional) Protocol version according to which the
     *                          transaction shall be created.
     * @return This method returns an instance of the Transaction interface.
     * @throws InvalidInputException      This exception shall be thrown if an input
     *                                    parameter is invalid. This also includes an invalid Directory Server ID
     *                                    or a protocol version that the 3DS SDK does not support.
     * @throws SDKNotInitializedException This exception shall be thrown if the
     *                                    3DS SDK instance has not been initialized.
     * @throws SDKRuntimeException        This exception shall be thrown if an internal
     *                                    error is encountered by the 3DS SDK.
     */
    public Transaction createTransaction(
            String directoryServerID,
            String messageVersion)
            throws InvalidInputException, SDKNotInitializedException, SDKRuntimeException {
        String appId = AppId.get(getApplicationContext());
        Log.d("[3DSSDK]", "ThreeDS2Service.createTransaction(" + directoryServerID + ", " + messageVersion + ")");
        if (!inited.get()) {
            throw new SDKNotInitializedException("You must call initialize() first.");
        }
        if (directoryServerID == null) {
            throw new InvalidInputException("directoryServerID cannot be null");
        }
        if (messageVersion == null) {
            throw new InvalidInputException("messageVersion cannot be null");
        }
        if (!supportedVersions.contains(messageVersion)) {
            throw new InvalidInputException("messageVersion is not supported by this SDK version");
        }

        DSPublicKey dsPublicKey = dsPublicKeys.get(directoryServerID);
        if (dsPublicKey == null) {
            Log.d("[3DSSDK]", "ThreeDS2Service.createTransaction(" + directoryServerID + "): dsPublicKeyPem = <null>");
            throw new InvalidInputException("Wrong directoryServerID");
        }
        Log.d("[3DSSDK]", "ThreeDS2Service.createTransaction(" + directoryServerID + "): dsPublicKeyPem = " + dsPublicKey.publicKey);

        String deviceData = new Gson().toJson(new DeviceInfo().collectInfo(getApplicationContext(), appId, sdkVersion));
        //String deviceData = "{\"DV\":\"1.4\"}";
        Log.d("[3DSSDK]", "ThreeDS2Service.createTransaction(" + directoryServerID + "): deviceData = " + deviceData);
        Pair<String, PublicKey> deviceDataAndKey;
        try {
            deviceDataAndKey = CryptoHelper.encrypt(deviceData, dsPublicKey, directoryServerID);
            Log.d("[3DSSDK]", "ThreeDS2Service.createTransaction(" + directoryServerID + "): encryptedDeviceData = " + deviceDataAndKey.first);
        } catch (Exception e) {
            Log.e("[3DSSDK]", "Failed to encrypt device info. e: " + e);
            e.printStackTrace();
            throw new SDKRuntimeException("Failed to encrypt device info", "-1001", e);
        }
        String encryptedDeviceData = deviceDataAndKey.first;
        PublicKey finalDsPublicKey = deviceDataAndKey.second;

        if (encryptedDeviceData == null) {
            Log.e("[3DSSDK]", "Failed to encrypt device info. e: couldn't determine encryption algorithm");
            throw new SDKRuntimeException("Failed to encrypt device info", "-1002", new Throwable());
        }

        try {
            return new Transaction(
                    directoryServerID,
                    dsPublicKey,
                    encryptedDeviceData,
                    appId,
                    sdkReferenceNumber,
                    messageVersion,
                    uiCustomization,
                    configParameters
            );
        } catch (JOSEException e) {
            Log.e("[3DSSDK]", "Failed to generate sdkEphemPubKey. e: " + e);
            e.printStackTrace();
            throw new SDKRuntimeException("Failed to generate sdkEphemPubKey", "-1003", e);
        } catch (NoSuchAlgorithmException e) {
            Log.e("[3DSSDK]", "Failed to generate sdkEphemPubKey. e: " + e);
            e.printStackTrace();
            throw new SDKRuntimeException("Failed to generate sdkEphemPubKey", "-1004", e);
        } catch (NoSuchProviderException e) {
            Log.e("[3DSSDK]", "Failed to generate sdkEphemPubKey. e: " + e);
            e.printStackTrace();
            throw new SDKRuntimeException("Failed to generate sdkEphemPubKey", "-1005", e);
        } catch (InvalidAlgorithmParameterException e) {
            Log.e("[3DSSDK]", "Failed to generate sdkEphemPubKey. e: " + e);
            e.printStackTrace();
            throw new SDKRuntimeException("Failed to generate sdkEphemPubKey", "-1006", e);
        }
    }

    /**
     * The cleanup method frees up resources that are used by the 3DS SDK. It is
     * called only once during a single 3DS Requestor App session.
     *
     * @param applicationContext
     * @throws SDKNotInitializedException
     */
    public void cleanup(Context applicationContext) throws SDKNotInitializedException {
        Log.d("[3DSSDK]", "ThreeDS2Service.cleanup()");
        if (!inited.get()) {
            throw new SDKNotInitializedException("You must call initialize() first.");
        }
    }

    /**
     * The getSDKVersion method shall return the version of the 3DS SDK that is
     * integrated with the 3DS Requestor App. For more information about the 3DS
     * SDK version, refer to 3DS SDK Versioning Requirements.
     *
     * @return Version of the 3DS SDK.
     * @throws SDKNotInitializedException This exception shall be thrown if the 3DS SDK instance has not been initialized.
     * @throws SDKRuntimeException        This exception shall be thrown if an internal error is encountered by the 3DS SDK.
     */
    public String getSDKVersion() throws SDKNotInitializedException, SDKRuntimeException {
        Log.d("[3DSSDK]", "ThreeDS2Service.getSDKVersion()");
        if (!inited.get()) {
            throw new SDKNotInitializedException("You must call initialize() first.");
        }
        return "0.1";
    }

    /**
     * The getWarnings method shall return the warnings produced by the 3DS SDK
     * during initialization.
     *
     * @return List of Warnings.
     */
    public List<Warning> getWarnings() throws SDKNotInitializedException {
        ArrayList<Warning> warnings = new ArrayList<>();
        Log.d("[3DSSDK]", "ThreeDS2Service.getWarnings()");
        if (!inited.get()) {
            warnings.add(new Warning("2", "SDK not initialized!", Severity.HIGH));
        }
        return warnings;
    }

    Context getApplicationContext() {
        return applicationContext;
    }
}

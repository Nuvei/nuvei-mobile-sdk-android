package com.nuvei.mobilesdk.core.mapper

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.model.Verify3dInput

class InitPaymentInputToVerify3dInputMapper : Mapper<JsonObject, JsonObject> {
    override fun map(source: JsonObject): JsonObject {
        val result = Verify3dInput(
                tryOptional { source[NetworkConstants.clientRequestId].asString },
                tryOptional { source[NetworkConstants.sessionToken].asString },
                tryOptional { source[NetworkConstants.userTokenId].asString },
                tryOptional { source[NetworkConstants.merchantId].asString },
                tryOptional { source[NetworkConstants.merchantSiteId].asString },
                tryOptional { source[NetworkConstants.amount].asString },
                tryOptional { source[NetworkConstants.currency].asString },
                tryOptional { source[NetworkConstants.paymentOption].asJsonObject }
        )
        return Gson().toJsonTree(result).asJsonObject
    }
}

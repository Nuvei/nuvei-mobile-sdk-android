package com.nuvei.mobilesdk.core.threeds2sdk;

import com.nuvei.mobilesdk.core.nimbusds.jose.EncryptionMethod;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEAlgorithm;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEHeader;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEObject;
import com.nuvei.mobilesdk.core.nimbusds.jose.Payload;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.DirectEncrypter;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.Curve;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.ECKey;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.gen.ECKeyGenerator;

import org.apache.cxf.rs.security.jose.jwe.JweUtils;
import org.apache.cxf.rs.security.jose.jwk.JsonWebKey;
import org.apache.cxf.rs.security.jose.jwk.JwkUtils;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.Map;

class ScUlTester {
    private final static String sdkReferenceNumber = "3DS_LOA_SDK_PPFU_020100_00007";

    private final ECKey sdkEphemeralKeyPair;
    private final JsonWebKey sdkPrivateJwk;
    private JsonWebKey acsPuplicJwk;

    private byte[] cek = null;

    ScUlTester() throws JOSEException {
        sdkEphemeralKeyPair = new ECKeyGenerator(Curve.P_256).generate();
        sdkPrivateJwk = JwkUtils.fromECPrivateKey(sdkEphemeralKeyPair.toECPrivateKey(), "P-256");
    }

    void setAcsPuplicJwk(Map<String, Object> acsKey) {
        this.acsPuplicJwk = new JsonWebKey(acsKey);
    }

    void generateCek(Map<String, Object> acsPublicKey, Map<String, Object> sdkPrivateKey) {
        JsonWebKey acsJwk = new JsonWebKey(acsPublicKey);
        JsonWebKey sdkJwk = new JsonWebKey(sdkPrivateKey);
        cek = JweUtils.getECDHKey(sdkJwk, acsJwk, null, sdkReferenceNumber.getBytes(StandardCharsets.UTF_8), "dir", 256);
    }

    String encryptUsingNumbus(String creq, byte[] sdkCek, String transactionId) throws JOSEException, ParseException {
        JWEHeader.Builder builder = new JWEHeader.Builder(JWEAlgorithm.DIR, EncryptionMethod.A128CBC_HS256);
        builder.keyID(transactionId);
        Payload payload = new Payload(creq);
        JWEObject jweObject = new JWEObject(builder.build(), payload);
        jweObject.encrypt(new DirectEncrypter(sdkCek));

        String serializedObj = jweObject.serialize();
        jweObject = JWEObject.parse(serializedObj);
        return jweObject.serialize();
    }
}

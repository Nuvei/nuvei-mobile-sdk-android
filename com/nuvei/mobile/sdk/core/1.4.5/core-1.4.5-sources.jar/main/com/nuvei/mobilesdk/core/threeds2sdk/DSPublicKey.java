package com.nuvei.mobilesdk.core.threeds2sdk;

class DSPublicKey {

    enum Algorithm {
        RSA, EC
    }

    String directoryServerId;
    String publicKey;
    Algorithm algorithm;
    String rootCA;
    Algorithm rootCaAlgorithm;

    DSPublicKey(String directoryServerId, String publicKey, Algorithm algorithm, String rootCA, Algorithm rootCaAlgorithm) {
        this.directoryServerId = directoryServerId;
        this.publicKey = publicKey;
        this.algorithm = algorithm;
        this.rootCA = rootCA;
        this.rootCaAlgorithm = rootCaAlgorithm;
    }
}
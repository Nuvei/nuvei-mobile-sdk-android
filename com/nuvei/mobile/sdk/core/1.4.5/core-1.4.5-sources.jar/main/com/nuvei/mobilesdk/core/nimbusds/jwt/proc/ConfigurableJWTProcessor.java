/*
 * nimbus-jose-jwt
 *
 * Copyright 2012-2016, Connect2id Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nuvei.mobilesdk.core.nimbusds.jwt.proc;


import com.nuvei.mobilesdk.core.nimbusds.jose.proc.SecurityContext;
import com.nuvei.mobilesdk.core.nimbusds.jwt.proc.JWTProcessorConfiguration;


/**
 * Configurable processor of {@link com.nuvei.nimbusds.jwt.PlainJWT
 * unsecured} (plain), {@link com.nuvei.nimbusds.jwt.SignedJWT signed} and
 * {@link com.nuvei.nimbusds.jwt.EncryptedJWT encrypted} JSON Web Tokens (JWT).
 *
 * @author Vladimir Dzhuvinov
 * @version 2015-08-22
 */
public interface ConfigurableJWTProcessor<C extends SecurityContext>
	extends JWTProcessor<C>, JWTProcessorConfiguration<C> {

}

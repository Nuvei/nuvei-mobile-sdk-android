package com.nuvei.mobilesdk.core.mapper

import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.R


class CreditCardTypeToIconMapper : Mapper<CreditCardUtils.CardType?, Int?> {
    override fun map(source: CreditCardUtils.CardType?): Int? {
        return when (source) {
            CreditCardUtils.CardType.amex -> R.drawable.amex
            CreditCardUtils.CardType.visa -> R.drawable.visa
            CreditCardUtils.CardType.masterCard -> R.drawable.mastercard
            CreditCardUtils.CardType.diners -> R.drawable.diners
            CreditCardUtils.CardType.discover -> R.drawable.discover
            CreditCardUtils.CardType.jcb -> R.drawable.jcb
            CreditCardUtils.CardType.elo -> com.nuvei.mobilesdk.core.R.drawable.card
            CreditCardUtils.CardType.hipercard -> com.nuvei.mobilesdk.core.R.drawable.card
            CreditCardUtils.CardType.unionPay -> R.drawable.unionpay
            CreditCardUtils.CardType.maestro -> R.drawable.maestro
            else -> null
        }
    }
}
package com.nuvei.mobilesdk.core.threeds2sdk.enums;

public enum Severity {
    /**
     * A low-severity warning.
     */
    LOW,

    /**
     * A medium-severity warning.
     */
    MEDIUM,

    /**
     * A high-severity warning.
     */
    HIGH
}

package com.nuvei.mobilesdk.core.threeds2sdk.parameters;

import java.io.Serializable;

/**
 * The ChallengeParameters class shall hold the parameters that are required to conduct the challenge process.
 * Note: It is mandatory to set values for these parameters.
 */
public class ChallengeParameters implements Serializable {

    private String threeDSServerTransactionID;
    private String acsTransactionID;
    private String acsRefNumber;
    private String acsSignedContent;
    private String threeDSRequestorAppURL;

    /**
     * @return the acsTransactionID
     */
    public String getAcsTransactionID() {
        return acsTransactionID;
    }

    /**
     * @param acsTransactionID the acsTransactionID to set
     */
    public void setAcsTransactionID(String acsTransactionID) {
        this.acsTransactionID = acsTransactionID;
    }

    /**
     * @return the acsRefNumber
     */
    public String getAcsRefNumber() {
        return acsRefNumber;
    }

    /**
     * @param acsRefNumber the acsRefNumber to set
     */
    public void setAcsRefNumber(String acsRefNumber) {
        this.acsRefNumber = acsRefNumber;
    }

    /**
     * @return the acsSignedContent
     */
    public String getAcsSignedContent() {
        return acsSignedContent;
    }

    /**
     * @param acsSignedContent the acsSignedContent to set
     */
    public void setAcsSignedContent(String acsSignedContent) {
        this.acsSignedContent = acsSignedContent;
    }

    public void set3DSServerTransactionID(String threeDSServerTransactionID) {
        this.threeDSServerTransactionID = threeDSServerTransactionID;
    }

    public String get3DSServerTransactionID() {
        return threeDSServerTransactionID;
    }

    public void setThreeDSRequestorAppURL(String threeDSRequestorAppURL) {
        this.threeDSRequestorAppURL = threeDSRequestorAppURL;
    }

    public String getThreeDSRequestorAppURL() {
        return threeDSRequestorAppURL;
    }
}
package com.nuvei.mobilesdk.core.threeds2sdk;

import android.util.Log;

import com.google.gson.Gson;
import com.nuvei.mobilesdk.core.threeds2sdk.ErrorMessage;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CReq;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CRes;

import java.io.IOException;

import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * CReq:
 * - [Req 236] 1 retry
 * - [Req 237] 10 seconds timeout
 * - [Req 239] On timeout pass error (Error Component = C and Error Code = 402) and end transaction
 * - [Req 312] Max timeout (passed by the requesting app) should start from the time the TLS
 * handshake has completed and the first CReq message is sent for processing to the ACS
 * same error as in [Req 239] should be passed to the app
 * <p>
 * - [Req 253] The 3DS SDK shall verify the JWS signature found in the ACS Signed Content data
 * element of the ARes message received from the 3DS Server as defined in 6.2.3.3 using
 * the pre-installed public key of the DS that was called for the transaction.
 * - [Req 254] The 3DS SDK shall generate JWE objects for the CReq messaging to the ACS utilising
 * the keys derived from the 3DS SDK’s own ephemeral key and the ACS Ephemeral key
 * received from the 3DS Server.
 * <p>
 * 6.2.3.3 3DS SDK Secure Channel Setup
 * The 3DS SDK receives the necessary data elements from the ARes message (extracted by the 3DS
 * Server), including QT, ACS Signature, ACS Public Key Certificate, and ACS_URL.
 * The 3DS SDK:
 * - Using the CA public key of the DS CA identified from information provided by the 3DS Server,
 * Validate the JWS from the ACS according to JWS (RFC7515). The 3DS SDK is required to support
 * both "alg" parameters PS256 and ES256. If validation fails, ceases processing and report error.
 * - Completes the Diffie-Hellman key exchange process according to JWA (RFC 7518) in Direct Key
 * Agreement mode using curve P-256, dC and QT to produce a pair of CEKs (one for each direction),
 * which are identified to the ACS Transaction ID received in the ARes message. In order to obtain
 * 256 bits of keying material from the included Concat KDF function assume an "enc" parameter of
 * ECDH-ES+A256KW and assume the algorithmID to be null for the KDF10. The parameter values
 * supported in this version of the specification are:
 * - "alg": ECDH-ES
 * - "apv": SDK Reference Number
 * - "epk": QT (received in the ARes message as acsEphemPubKey which is part of ACS Signed Content)
 * - {"kty":"EC" "crv":"P-256"}
 * - All other parameters: not present
 * - CEK:"kty":oct-256 bits extracted as:
 * - CEK(A-S): 256 bits
 * - CEK(S-A): 256 bits
 * - Deletes the ephemeral key pair (QC, dC)
 * - Zeros the channel counters SDKCounterAtoS (:oct – 8 bits) and SDKCounterStoA (:oct – 8 bits)
 * If valid, the 3DS SDK has confirmed the authenticity of the ACS, that the session keys are fresh,
 * and that the ACS_URL is correct.
 * <p>
 * 6.2.4.1 3DS SDK—CReq
 * For CReq messages sent from the 3DS SDK to the ACS, the 3DS SDK:
 * - Creates a JSON object of the data elements identified in the CReq message defined in Table B.3.
 * - Encrypts the JSON object according to JWE (RFC 7516) using the CEKS-A obtained in Section
 * 6.2.3.3 and JWE Compact Serialization. The parameter values supported in this version of the
 * specification are:
 * - "alg": dir
 * - "enc": either:
 * - A128CBC-HS256
 * - A128GCM
 * - "kid":ACS Transaction ID
 * - All other parameters: not present
 * - If the algorithm is A128CBC-HS256 use the full CEKS-A and a fresh 128-bit random data as IV
 * or if the algorithm is A128GCM use the leftmost 128 bits of CEKS-A with SDKCounterStoA
 * (padded to the left with ‘00’ bytes) as the IV.
 * - Sends the resulting JWE to the ACS as the encrypted CReq message.
 * - Increments SDKCounterStoA. If SDKCounterStoA = zero, ceases processing and reports error.
 * <p>
 * 6.2.4.2 3DS SDK—CRes
 * For CRes messages received by the 3DS SDK from the ACS, the 3DS SDK:
 * - Decrypts the message according to JWE (RFC 7516) using the CEKA-S obtained in Section 6.2.3.3
 * identified by "kid" If decryption fails, ceases processing and reports error.
 * - Checks that ACSCounterAtoS in the decrypted message numericaly equals SDKCounterAtoS. If not
 * ceases processing and reports error.
 * - Increments SDKCounterAtoS. If SDKCounterAtoS = zero, ceases processing and reports error.
 */
class API {

    private final static String TAG = "[3DSSDK][API]";

    private OkHttpClient client = new OkHttpClient.Builder().cache(null).build();
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final MediaType JOSE = MediaType.parse("application/jose; charset=utf-8");

    void get(String url, final ImageCallback listener) {
        final Request request = new Request.Builder()
                .url(url)
                .cacheControl(new CacheControl.Builder().noCache().build())
                .get()
                .build();
        Log.d(TAG, "get(): request = " + request.toString());

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    Log.d(TAG, "get().onResponse: code = " + response.code());
                    byte[] bytes = response.body().bytes();
                    if (bytes != null) {
                        Log.d(TAG, "get().onResponse: body.length = " + bytes.length);
                    }
                    listener.onResponse(bytes);
                } catch (Exception e) {
                    Log.d(TAG, "get().onResponse.catch: e = " + e);
                    listener.onFailure(e);
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "get().onFailure: error = " + e);
                listener.onFailure(e);
            }
        });
    }

    void post(final CReq creq, final Callback listener) {
        String json = new Gson().toJson(creq);
        String url = "";

        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .cacheControl(new CacheControl.Builder().noCache().build())
                .post(body)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                CRes cres = new Gson().fromJson(response.body().charStream(), CRes.class);
                listener.onResponse(creq, cres);
            }

            @Override
            public void onFailure(Call call, IOException e) {
                listener.onFailure(creq, e);
            }
        });
    }

    void post(String url, final ErrorMessage errorMessage, final ErrorCallback listener) {
        String requestJson = new Gson().toJson(errorMessage, ErrorMessage.class);

        RequestBody body = RequestBody.create(JSON, requestJson);
        Request request = new Request.Builder()
                .url(url)
                .cacheControl(new CacheControl.Builder().noCache().build())
                .post(body)
                .build();
        Log.d(TAG, "post(ErrorMessage): request = " + request.toString());
        Log.d(TAG, "post(ErrorMessage): body = " + requestJson);

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onResponse(Call call, final Response response) throws IOException { // response.body().string()
                String responseBody = response.body().string();
                Log.d(TAG, "post(ErrorMessage).onResponse: code = " + response.code());
                Log.d(TAG, "post(ErrorMessage).onResponse: body = " + responseBody);
                ErrorMessage errorMessage = new Gson().fromJson(responseBody, ErrorMessage.class);
                listener.onResponse(errorMessage);
            }

            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "post(ErrorMessage).onFailure: error = " + e);
                listener.onFailure(e);
            }
        });
    }

    void post(String url, final CReq creq, String encryptedBody, final ResponseDecryptor decryptor, final Callback listener) {
        String requestJson = new Gson().toJson(creq, CReq.class);
        RequestBody body = RequestBody.create(JOSE, encryptedBody);
        Request request = new Request.Builder()
                .url(url)
                .cacheControl(new CacheControl.Builder().noCache().build())
                .post(body)
                .build();
        Log.d(TAG, "post(CReq): request = " + request.toString());
        Log.d(TAG, "post(CReq): body = " + requestJson);

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onResponse(Call call, final Response response) throws IOException { // response.body().string()
                String responseBody = response.body().string();
                Log.d(TAG, "post(CReq).onResponse: code = " + response.code());
                Log.d(TAG, "post(CReq).onResponse: body = " + responseBody);
                String contentType = response.headers().get("Content-Type");
                Log.d(TAG, "post(CReq).onResponse: contentType = " + contentType);

                if (contentType != null && contentType.toLowerCase().contains("jose")) {
                    // Encrypted message - probably CRes
                    try {
                        responseBody = decryptor.decrypt(responseBody);
                        Log.d(TAG, "post(CReq).onResponse: body.decrypt = " + responseBody);

                        CRes cres = new Gson().fromJson(responseBody, CRes.class);
                        Log.d(TAG, "post(CReq).onResponse: listener.onResponse(CRes): cres = " + cres);
                        listener.onResponse(creq, cres);
                    } catch (Exception e2) {
                        Log.d(TAG, "post(CReq).onResponse: listener.onFailure(CRes): exception = " + e2);
                        listener.onFailure(creq, e2);
                    }
                } else {
                    // Not encrypted message - may be only error

                    try {
                        ErrorMessage error = new Gson().fromJson(responseBody, ErrorMessage.class);
                        Log.d(TAG, "post(CReq).onResponse: listener.onResponse(ErrorMessage): error = " + error);
                        listener.onProtocolError(creq, error);
                    } catch (Exception e) {
                        Log.d(TAG, "post(CReq).onResponse: listener.onFailure(ErrorMessage): exception = " + e);
                        listener.onFailure(creq, e);
                    }
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "post(CReq).onFailure: error = " + e);
                listener.onFailure(creq, e);
            }
        });
    }

    interface Callback {
        void onResponse(CReq creq, CRes cres);

        void onFailure(CReq creq, Exception e);

        void onProtocolError(CReq creq, ErrorMessage error);
    }

    interface ImageCallback {
        void onResponse(byte[] bytes);

        void onFailure(Exception e);
    }

    interface ErrorCallback {
        void onResponse(ErrorMessage errorMessage);

        void onFailure(Exception e);
    }

    interface ResponseDecryptor {
        String decrypt(String encrypted);
    }
}
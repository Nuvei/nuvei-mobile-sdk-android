package com.nuvei.mobilesdk.core

import com.nuvei.mobilesdk.core.model.NVOutput

interface Callback<T: NVOutput> {
    fun onComplete(response: T)
}

interface TokenizeCallback {
    fun onComplete(token: String?, error: com.nuvei.mobilesdk.core.model.Error?, additionalInfo: Map<String, Any>?)
}
package com.nuvei.mobilesdk.core

import android.graphics.Color
import android.view.View
import android.view.Window
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.max

object EdgeToEdgeHelper {
    @JvmStatic
    fun enableEdgeToEdge(window: Window, rootView: View) {
        // Enable edge-to-edge
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Make bars transparent
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        // Apply insets: status, nav bar, and IME (keyboard)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())

            val bottomInset = max(systemBars.bottom, ime.bottom)
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, bottomInset)
            insets
        }
    }
    @JvmStatic
    fun applyTopInset(rootView: View) {
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { view, insets ->
            val topInset = insets.displayCutout?.safeInsetTop
                ?: insets.getInsets(WindowInsetsCompat.Type.statusBars()).top

            view.setPadding(
                view.paddingLeft,
                topInset,
                view.paddingRight,
                view.paddingBottom
            )
            insets
        }
    }

}
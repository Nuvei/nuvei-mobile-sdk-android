package com.nuvei.mobilesdk.core.nimbusds.jose.crypto.impl;

import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;

import net.jcip.annotations.ThreadSafe;

import java.nio.charset.StandardCharsets;

import javax.crypto.SecretKey;

@ThreadSafe
public class ConcatKDF3DS2 extends ConcatKDF{

    private String partyVInfo;

    /**
     * Creates a new concatenation Key Derivation Function (KDF) with the
     * specified hash algorithm.
     *
     * @param jcaHashAlg The JCA name of the hash algorithm. Must be
     *                   supported and not {@code null}.
     */
    public ConcatKDF3DS2(String jcaHashAlg, String partyVInfo) {
        super(jcaHashAlg);
        this.partyVInfo = partyVInfo;
    }

    public SecretKey deriveKey( SecretKey sharedSecret,
                                int keyLength,
                                byte[] algID,
                                byte[] partyUInfo,
                                byte[] partyVInfo,
                                byte[] suppPubInfo,
                                byte[] suppPrivInfo)
            throws JOSEException {

        String algIdString = "";
        int keylength = 256; //A128CBC-HS256
        algID = ConcatKDF.encodeDataWithLength(algIdString.getBytes(StandardCharsets.UTF_8));
        partyUInfo = ConcatKDF.encodeDataWithLength(new byte[0]);
        partyVInfo = ConcatKDF.encodeDataWithLength(this.partyVInfo.getBytes(StandardCharsets.UTF_8));
        suppPubInfo = ConcatKDF.encodeIntData(keylength);
        suppPrivInfo = ConcatKDF.encodeNoData();

        final byte[] otherInfo = composeOtherInfo(algID, partyUInfo, partyVInfo, suppPubInfo, suppPrivInfo);

        return deriveKey(sharedSecret, keyLength, otherInfo);
    }
}

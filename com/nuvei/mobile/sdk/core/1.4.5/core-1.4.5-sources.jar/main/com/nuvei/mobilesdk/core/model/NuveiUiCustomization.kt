package com.nuvei.mobilesdk.core.model

import android.graphics.Color
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.res.ResourcesCompat
import java.io.Serializable

open class NuveiBaseCustomization(
    var textFontName: Int? = null,
    var textColor: Int = Color.BLACK,
    var textFontSize: Int = 0
) : Serializable

public // NUVEI_MOBILE_SDK
class NuveiButtonCustomization(
    textFontName: Int? = null,
    textColor: Int = Color.BLACK,
    textFontSize: Int = 0,
    var backgroundColor: Int = Color.TRANSPARENT,
    var cornerRadius: Int = 0
): NuveiBaseCustomization(textFontName, textColor, textFontSize) {
    public enum class Type {
        SUBMIT, CONTINUE, NEXT, CANCEL, RESEND, VERIFY
    }
}

class NuveiRecyclerViewCustomization(
    var backgroundColor: Int = Color.parseColor("#F3F5F7"),
    var sectionTextFontName: Int? = null,
    var sectionTextFontSize: Int = 0,
    var sectionTextColor: Int = Color.BLACK,
    var cellBackgroundColor: Int = Color.WHITE,
    var cellTextColor : Int = Color.parseColor("#4A5568"),
    var cellTextFontSize : Int = 14,
    var cellTextFontName : Int? = null
)

public // NUVEI_MOBILE_SDK
class NuveiToolbarCustomization(
        var headerText: String? = null,
        textFontName: Int? = null,
        textFontSize: Int = 0,
        textColor: Int = Color.BLACK,
        var backgroundColor: Int = Color.BLACK,
        var closeButtonBackgroundColor: Int = Color.WHITE,
        @DrawableRes var logoResId: Int? = null
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

public // NUVEI_MOBILE_SDK
class NuveiTextBoxCustomization(
    textFontName: Int? = null,
    textFontSize: Int = 0,
    textColor: Int = Color.BLACK,
    var headingTextFontSize: Int = 0,
    var headingTextFontColor: Int = 0,
    var headingTextFontName: Int? = null,
    var placeholderTextFontSize: Int = 0,
    var placeholderFontColor: Int = 0,
    var borderColor: Int = Color.BLACK,
    var cornerRadius: Int = 0,
    var borderWidth: Int = 0,
    var backgroundColor: Int = Color.WHITE
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

class NuveiErrorTextBoxCustomization(
    textFontName: Int? = null,
    textFontSize: Int = 0,
    textColor: Int = Color.BLACK,
    var borderColor: Int = Color.RED
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

object FieldsUICustomization{
    var backgroundColor: Int = Color.WHITE
    var borderColor: Int = Color.parseColor("#95AAC1")
    var cornerRadius: Int = 3
    var borderWidth: Int = 1

    var textBoxCustomization: NuveiTextBoxCustomization = NuveiTextBoxCustomization(
        headingTextFontSize     = 16,
        headingTextFontColor    = Color.parseColor("#4A5568"),
        backgroundColor         = Color.WHITE,
        placeholderFontColor    = Color.GRAY,
        placeholderTextFontSize = 14,
        textFontSize            = 14,
        textColor               = Color.BLACK,
        borderWidth             = 1,
        cornerRadius            = 5,
        borderColor             = Color.parseColor("#95AAC1")

    )
    var errorBoxCustomization: NuveiErrorTextBoxCustomization = NuveiErrorTextBoxCustomization(
        textFontSize = 10,
        textColor = Color.RED,
        borderColor = Color.RED
    )
}


object SimplyConnectUICustomization{

    var recyclerViewCustomization: NuveiRecyclerViewCustomization = NuveiRecyclerViewCustomization(
        backgroundColor =  Color.parseColor("#F3F5F7"),
        sectionTextFontSize = 16,
        sectionTextColor = Color.BLACK,
        cellBackgroundColor = Color.WHITE,
        cellTextColor = Color.parseColor("#4A5568"),
        cellTextFontSize = 14
    )
    var toolbarCustomization: NuveiToolbarCustomization = NuveiToolbarCustomization(
        backgroundColor = Color.parseColor("#081F2B"),
        textColor = Color.parseColor("#C7CCCF"),
        headerText = "Checkout",
        textFontSize = 16,
        closeButtonBackgroundColor  = Color.WHITE

    )
    var textBoxCustomization: NuveiTextBoxCustomization = NuveiTextBoxCustomization(
        headingTextFontSize = 16,
        headingTextFontColor = Color.BLACK,
        placeholderTextFontSize = 14,
        placeholderFontColor = Color.GRAY,
        textFontSize = 14,
        textColor = Color.BLACK,
        borderColor = Color.parseColor("#95AAC1"),
        cornerRadius = 5,
        borderWidth = 1,
        backgroundColor = Color.WHITE
    )
    var errorBoxCustomization: NuveiErrorTextBoxCustomization = NuveiErrorTextBoxCustomization(
        textFontSize = 12,
        textColor = Color.RED,
        borderColor = Color.RED
    )
    var payButtonCustomization: NuveiButtonCustomization = NuveiButtonCustomization(
        textFontSize = 14,
        textColor = Color.WHITE,
        backgroundColor = Color.parseColor("#493DAA"),
        cornerRadius = 10
    )
    var checkboxButtonCustomization: NuveiButtonCustomization = NuveiButtonCustomization(
        textFontSize    = 14,
        textColor       = Color.parseColor("#D3DCE6"),
        backgroundColor = Color.parseColor("#493DAA")
    )
}

fun TextView.applyNuveiFont(font: Int?) {
    val tf = font?.let { ResourcesCompat.getFont(context, it) }
    if (tf != null) {
        typeface = tf
    }
}
package com.nuvei.mobilesdk.core.mapper

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants

class Authenticate3dToInitPaymentMapper : Mapper<NVPayment, JsonObject> {
    override fun map(source: NVPayment): JsonObject {

        val jsonObject = Gson().toJsonTree(source).asJsonObject
        jsonObject.addProperty(NetworkConstants.webMasterId, NetworkConstants.sdkVersionPrefix + Nuvei.sdkVersion)
        jsonObject.remove("countryCode")
        jsonObject.remove("amount")
        jsonObject.remove("currency")
        // /initPaymentWithCardTokenization only supports billingAddress, not shippingAddress or userDetails
        jsonObject.remove("shippingAddress")
        jsonObject.remove("userDetails")
        return jsonObject

//        return HashMap<String, Any>().apply {
//            put(NetworkConstants.sessionToken, source.sessionToken)
//            put(NetworkConstants.merchantId, source.merchantId)
//            put(NetworkConstants.merchantSiteId, source.merchantSiteId)
//            source.userTokenId?.let { put(NetworkConstants.userTokenId, it) }
//            source.clientRequestId?.let { put(NetworkConstants.clientRequestId, it) }
//            source.clientUniqueId?.let { put(NetworkConstants.clientUniqueId, it) }
//            source.billingAddress?.let { put(NetworkConstants.billingAddress, it) }
//            source.notificationUrl?.let { put(NetworkConstants.notificationUrl, it) }
//            source.customData?.let { put(NetworkConstants.customData, it) }
//            put(NetworkConstants.currency, source.currency)
//            put(NetworkConstants.amount, source.amount)
//            put(NetworkConstants.paymentOption, source.paymentOption)
//            put(NetworkConstants.webMasterId, "sdk_android_ver1.0")
//        }
    }
}
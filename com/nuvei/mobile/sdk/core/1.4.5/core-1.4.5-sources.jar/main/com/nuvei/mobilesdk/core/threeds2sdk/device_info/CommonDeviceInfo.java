package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import androidx.core.content.ContextCompat;
import android.util.DisplayMetrics;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static android.content.Context.LOCATION_SERVICE;

//import com.google.android.gms.ads.identifier.AdvertisingIdClient;


class CommonDeviceInfo extends BaseDeviceInfo {

    private static final String DI_DD_Common_Platform = "C001";// Android / iOS
    private static final String DI_DD_Common_PlatformValue = "Android";
    private static final String DI_DD_Common_DeviceModel = "C002";// Android: Build.MODEL
    private static final String DI_DD_Common_OsName = "C003";// iOS: UIDevice.current.systemName
    private static final String DI_DD_Common_OsVersion = "C004";// iOS: UIDevice.current.systemVersion, Android: Build.VERSION.RELEASE
    private static final String DI_DD_Common_Locale = "C005";
    private static final String DI_DD_Common_TimeZone = "C006";// Android: TimeZone.getDefault()
    private static final String DI_DD_Common_AdvertisingId = "C007";
    private static final String DI_DD_Common_ScreenResolution = "C008";// Android: DisplayMetrics.heightPixels * DisplayMetrics.widthPixels
    private static final String DI_DD_Common_DeviceName = "C009";// iOS: UIDevice.current.localizedModel (On Android, this parameter requires Bluetooth permission during installation)
    private static final String DI_DD_Common_IpAddress = "C010";// (On Android, this parameter requires the following permissions during installation.android.permission.INTERNET and android.permission.ACCESS_NETWORK_STATE)
    private static final String DI_DD_Common_Latitude = "C011";// (Run-time permissions required on Android API 23 and later, iOS and Windows 10 Mobile. Installation-time permissions required on Android 22 and earlier.)
    private static final String DI_DD_Common_Longitude = "C012";// (Run-time permissions required on Android API 23 and later, iOS and Windows 10 Mobile. Installation-time permissions required on Android 22 and earlier.)
    private static final String DI_DD_ApplicationPackageName = "C013";// context.getPackageName()
    private static final String DI_DD_SdkAppId = "C014";
    private static final String DI_DD_SdkVersion = "C015";

    CommonDeviceInfo(Context context, String appId, String sdkVersion) {
        collectCommonInfo(context, appId, sdkVersion);
    }

    private void collectCommonInfo(Context context, String appId, String sdkVersion) {
        putData(DI_DD_Common_Platform, DI_DD_Common_PlatformValue);
        putData(DI_DD_Common_DeviceModel, Build.MODEL);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            putData(DI_DD_Common_OsName, Build.VERSION.BASE_OS);
        } else {
        }

        // TODO: Implement the next values fetching
        putData(DI_DD_Common_OsVersion, Build.VERSION.RELEASE);
        putData(DI_DD_Common_Locale, getCurrentLocale(context));
        putData(DI_DD_Common_TimeZone, TimeZone.getDefault().getDisplayName());
        putData(DI_DD_Common_ScreenResolution, getScreenResolution(context));
        putData(DI_DD_Common_DeviceName, Build.MANUFACTURER + " " + Build.MODEL);
        putData(DI_DD_ApplicationPackageName, context.getPackageName());
        putData(DI_DD_SdkAppId, appId);
        putData(DI_DD_SdkVersion, sdkVersion);

        getIpAddress(context);
        getLocation(context);
        getAdvertisingId(context);
    }

    private void getAdvertisingId(Context context) {
        dpna.put(DI_DD_Common_AdvertisingId, DI_DPNA_RE_NullValue);
//        try {
//            if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS) {
//                String adId = AdvertisingIdClient.getAdvertisingIdInfo(context).getId();
//                putData(DI_DD_Common_AdvertisingId, adId);
//            } else {
//                //Google Play Services are not available, or not updated
//            }
//        } catch (Throwable ex) {
//            dpna.put(DI_DD_Common_AdvertisingId, DI_DPNA_RE_NullValue); //TODO: Need ask client
//        }
    }

    private String getCurrentLocale(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Locale locale = context.getResources().getConfiguration().getLocales().get(0);
            return locale.getLanguage() + "-" + locale.getCountry();
        } else {
            //noinspection deprecation
            Locale locale = context.getResources().getConfiguration().locale;
            return locale.getLanguage() + "-" + locale.getCountry();
        }
    }

    private void getIpAddress(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED) {
            String ipAddress = getIPAddress(true);
            putData(DI_DD_Common_IpAddress, ipAddress);
        } else {
            dpna.put(DI_DD_Common_IpAddress, DI_DPNA_RE_MissingPermission);
        }
    }

    private String getIPAddress(boolean useIPv4) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                        boolean isIPv4 = sAddr.indexOf(':') < 0;

                        if (useIPv4) {
                            if (isIPv4)
                                return sAddr;
                        } else {
                            if (!isIPv4) {
                                int delim = sAddr.indexOf('%'); // drop ip6 zone suffix
                                return delim < 0 ? sAddr.toUpperCase() : sAddr.substring(0, delim).toUpperCase();
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private String getScreenResolution(Context context) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return metrics.heightPixels + "x" + metrics.widthPixels;
    }

    private void getLocation(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            Location location = null;

//            FusedLocationProviderClient fusedLocationProviderClient = new FusedLocationProviderClient(context);
//            location = (Location) Tasks.await(fusedLocationProviderClient.getLastLocation(), 500L, TimeUnit.MILLISECONDS);

            try {
                Class<?> clazz = Class.forName("com.google.android.gms.location.FusedLocationProviderClient");
                Constructor<?> constructor = clazz.getConstructor(Context.class);
                Object fusedLocationProviderClient = constructor.newInstance(context);

                Method getLastLocation = clazz.getDeclaredMethod("getLastLocation");
                location = (Location) getLastLocation.invoke(fusedLocationProviderClient);

            } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
                e.printStackTrace();
            }

            if (location == null) {
                LocationManager locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);

                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                if (location == null) {
                    location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }

                if (location == null) {
                    location = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                }
            }

            if (location != null) {
                putData(DI_DD_Common_Latitude, String.valueOf(location.getLatitude()));
                putData(DI_DD_Common_Longitude, String.valueOf(location.getLongitude()));
            } else {
                dpna.put(DI_DD_Common_Latitude, DI_DPNA_RE_PlatformVersionOrDeprecated);
                dpna.put(DI_DD_Common_Longitude, DI_DPNA_RE_PlatformVersionOrDeprecated);
            }

        } else {
            dpna.put(DI_DD_Common_Latitude, DI_DPNA_RE_MissingPermission);
            dpna.put(DI_DD_Common_Longitude, DI_DPNA_RE_MissingPermission);
        }
    }

    private void setLocation(Location location) {
        putData(DI_DD_Common_Latitude, String.valueOf(location.getLatitude()));
        putData(DI_DD_Common_Longitude, String.valueOf(location.getLongitude()));
    }
}

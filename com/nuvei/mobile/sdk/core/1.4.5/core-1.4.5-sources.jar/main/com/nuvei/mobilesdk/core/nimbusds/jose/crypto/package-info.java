/*
 * nimbus-jose-jwt
 *
 * Copyright 2012-2016, Connect2id Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

/**
 * Implementations of standard Javascript Object Signing and Encryption (JOSE)
 * algorithms.
 *
 * <p>Provides {@link com.nuvei.nimbusds.jose.JWSSigner signers} and
 * {@link com.nuvei.nimbusds.jose.JWSVerifier verifiers} for the following JSON Web
 * Signature (JWS) algorithms:
 *
 * <ul>
 *     <li>For HMAC algorithms HS256, HS384 and HS512:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.MACSigner}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.MACVerifier}
 *         </ul>
 *     <li>For RSA-SSA signatures RS256, RS384, RS512, PS256, PS384 and PS512:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.RSASSASigner}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.RSASSAVerifier}
 *         </ul>
 *      <li>For ECDSA signatures ES256, ES384 and ES512:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.ECDSASigner}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.ECDSAVerifier}
 *         </ul>
 *      <li>For EdDSA signatures Ed25519:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.Ed25519Signer}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.Ed25519Verifier}
 *         </ul>
 * </ul>
 *
 * <p>Provides {@link com.nuvei.nimbusds.jose.JWEEncrypter encrypters} and
 * {@link com.nuvei.nimbusds.jose.JWEDecrypter decrypters} for the following JSON
 * Web Encryption (JWE) algorithms:
 *
 * <ul>
 *     <li>For RSA PKCS#1 v1.5 and RSA OAEP:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.RSAEncrypter}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.RSADecrypter}
 *         </ul>
 *     <li>For AES key wrap and AES GCM key encryption:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.AESEncrypter}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.AESDecrypter}
 *         </ul>
 *     <li>For direct encryption (using a shared symmetric key):
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.DirectEncrypter}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.DirectDecrypter}
 *         </ul>
 *     <li>For Elliptic Curve Diffie-Hellman (ECDH) encryption:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.ECDHEncrypter}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.ECDHDecrypter}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.X25519Encrypter} (for Curve25519 only)
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.X25519Decrypter} (for Curve25519 only)
 *         </ul>
 *     <li>For password-based (PBKDF2) encryption:
 *         <ul>
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.PasswordBasedEncrypter}
 *             <li>{@link com.nuvei.nimbusds.jose.crypto.PasswordBasedDecrypter}
 *         </ul>
 * </ul>
 *
 * <p>References:
 *
 * <ul>
 *     <li><a href="http://tools.ietf.org/html/rfc7518">RFC 7518 (JWA)</a>
 *     <li><a href="http://tools.ietf.org/html/rfc8037">RFC 8037 (CFRG ECDH and
 *         Signatures JOSE)</a>
 * </ul>
 */
package com.nuvei.mobilesdk.core.nimbusds.jose.crypto;

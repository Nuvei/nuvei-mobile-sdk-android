package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class DynamicDescriptor(
    @SerializedName("merchantName") val merchantName: String? = null,
    @SerializedName("merchantPhone") val merchantPhone: String? = null,
    @SerializedName("merchantEmail") val merchantEmail: String? = null,
    @SerializedName("merchantCountry") val merchantCountry: String? = null
): Serializable
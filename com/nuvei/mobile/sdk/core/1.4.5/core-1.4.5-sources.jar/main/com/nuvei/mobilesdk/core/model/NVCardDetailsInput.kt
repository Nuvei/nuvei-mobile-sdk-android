package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class NVCardDetailsInput(
    @SerializedName("sessionToken") val sessionToken: String,
    @SerializedName("merchantId") val merchantId: String,
    @SerializedName("merchantSiteId") val merchantSiteId: String,
    @SerializedName("clientRequestId") var clientRequestId: String? = null,
    @SerializedName("clientUniqueId") var clientUniqueId: String? = null,
    cardNumber: String? = null,
    @SerializedName("userPaymentOptionId") val userPaymentOptionId: String? = null
) : Serializable {

    @SerializedName("cardNumber") val cardNumber: String?

    init {
        this.cardNumber = cardNumber?.replace(" ", "")
    }
}
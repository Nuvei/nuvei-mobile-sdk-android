package com.nuvei.mobilesdk.core.mapper

import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.network.NetworkConstants

class ClientPaymentInputToCompletePaymentInputMapper : Mapper<JsonObject, JsonObject> {
    override fun map(source: JsonObject): JsonObject {
        val paymentOption = source[NetworkConstants.paymentOption].asJsonObject
        paymentOption?.get(NetworkConstants.card)?.asJsonObject?.let {
            val newCard = it
            newCard.remove(NetworkConstants.threeD)
            paymentOption.remove(NetworkConstants.card)
            paymentOption.add(NetworkConstants.card, newCard)
        }
        source.remove(NetworkConstants.paymentOption)
        source.add(NetworkConstants.paymentOption, paymentOption)
        return source
    }
}

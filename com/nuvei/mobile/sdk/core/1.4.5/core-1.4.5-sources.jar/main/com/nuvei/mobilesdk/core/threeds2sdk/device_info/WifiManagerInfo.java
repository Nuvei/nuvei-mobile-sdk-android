package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import androidx.core.content.ContextCompat;

import com.nuvei.mobilesdk.core.threeds2sdk.device_info.BaseDeviceInfo;

class WifiManagerInfo extends BaseDeviceInfo {

    //WifiManager
    //WifiManager provides the primary API for managing all aspects of Wi-Fi connectivity.
    //This group of parameters requires the following permission: android.permission.ACCESS_WIFI_STATE
    private static final String DI_DD_Android_WifiMacAddress = "A028"; //Returns the wireless MAC address of the device.
    private static final String DI_DD_Android_BSSID = "A029"; //Returns the basic service set identifier (BSSID) of the current access point.
    private static final String DI_DD_Android_SSID = "A030"; //Returns the service set identifier (SSID) of the current 802.11 network.
    private static final String DI_DD_Android_NetworkID = "A031"; //Each configured network has a unique small integer ID, used to identify the network when performing operations on the supplicant.
    private static final String DI_DD_Android_is5GHzBandSupported = "A032"; //Determines if this adapter supports the 5 GHz band.
    private static final String DI_DD_Android_isDeviceToApRttSupported = "A033"; //Determines if this adapter supports Device-to-AP RTT.
    private static final String DI_DD_Android_isEnhancedPowerReportingSupported = "A034"; //Determines if this adapter supports advanced power and performance counters.
    private static final String DI_DD_Android_isP2pSupported = "A035"; //Determines if this adapter supports WifiP2pManager.
    private static final String DI_DD_Android_isPreferredNetworkOffloadSupported = "A036"; //Determines if this adapter supports offloaded connectivity scan.
    private static final String DI_DD_Android_isScanAlwaysAvailable = "A037"; //Determines if scanning is always available.
    private static final String DI_DD_Android_isTdlsSupported = "A038"; //Determines if this adapter supports Tunnel Directed Link Setup.

    WifiManagerInfo(Context context) {
        collectWifiManagerInfo(context);
    }

    private void collectWifiManagerInfo(Context context) {
        WifiManager wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);

        if (wm != null) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
                getWifiConnectionInfo(wm.getConnectionInfo());
            } else {
                dpna.put(DI_DD_Android_WifiMacAddress, DI_DPNA_RE_PlatformVersionOrDeprecated);
                dpna.put(DI_DD_Android_BSSID, DI_DPNA_RE_PlatformVersionOrDeprecated);
                dpna.put(DI_DD_Android_SSID, DI_DPNA_RE_PlatformVersionOrDeprecated);
                dpna.put(DI_DD_Android_NetworkID, DI_DPNA_RE_PlatformVersionOrDeprecated);
            }
            collectAndroidLollipopInfo(context, wm);

            dpna.put(DI_DD_Android_isScanAlwaysAvailable, DI_DPNA_RE_PlatformVersionOrDeprecated);
        } else {
            dpna.put(DI_DD_Android_WifiMacAddress, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_BSSID, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_is5GHzBandSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isDeviceToApRttSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isEnhancedPowerReportingSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isP2pSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isPreferredNetworkOffloadSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isScanAlwaysAvailable, DI_DPNA_RE_MarketOrRegionalRestriction);
            dpna.put(DI_DD_Android_isTdlsSupported, DI_DPNA_RE_MarketOrRegionalRestriction);
        }
    }

    @SuppressLint("HardwareIds")
    private void getWifiConnectionInfo(WifiInfo wifiInfo) {
        if (wifiInfo != null) {
            putData(DI_DD_Android_WifiMacAddress, wifiInfo.getMacAddress());
            putData(DI_DD_Android_BSSID, wifiInfo.getBSSID());
            putData(DI_DD_Android_SSID, wifiInfo.getSSID());
            putData(DI_DD_Android_NetworkID, String.valueOf(wifiInfo.getNetworkId()));
        } else {
            dpna.put(DI_DD_Android_WifiMacAddress, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_BSSID, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_SSID, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_NetworkID, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private Boolean isDeviceToApRttSupported(Context context, WifiManager wifiManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_WIFI_RTT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return wifiManager.isDeviceToApRttSupported();
        } else {
            return null;
        }
    }

    private void collectAndroidLollipopInfo(Context context, WifiManager wm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
                putData(DI_DD_Android_is5GHzBandSupported, String.valueOf(wm.is5GHzBandSupported()));

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
//                    putData(DI_DD_Android_isDeviceToApRttSupported, context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_WIFI_RTT));
//                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
//                    putData(DI_DD_Android_isDeviceToApRttSupported, wm.isDeviceToApRttSupported());
//                }
                putData(DI_DD_Android_isDeviceToApRttSupported, wm.isDeviceToApRttSupported());

                putData(DI_DD_Android_isEnhancedPowerReportingSupported,
                        String.valueOf(wm.isEnhancedPowerReportingSupported()));
                putData(DI_DD_Android_isP2pSupported, String.valueOf(wm.isP2pSupported()));
                putData(DI_DD_Android_isPreferredNetworkOffloadSupported,
                        String.valueOf(wm.isPreferredNetworkOffloadSupported()));
                putData(DI_DD_Android_isTdlsSupported, String.valueOf(wm.isTdlsSupported()));
            } else {
                dpna.put(DI_DD_Android_is5GHzBandSupported, DI_DPNA_RE_MissingPermission);
                dpna.put(DI_DD_Android_isDeviceToApRttSupported, DI_DPNA_RE_MissingPermission);
                dpna.put(DI_DD_Android_isEnhancedPowerReportingSupported, DI_DPNA_RE_MissingPermission);
                dpna.put(DI_DD_Android_isP2pSupported, DI_DPNA_RE_MissingPermission);
                dpna.put(DI_DD_Android_isPreferredNetworkOffloadSupported, DI_DPNA_RE_MissingPermission);
                dpna.put(DI_DD_Android_isTdlsSupported, DI_DPNA_RE_MissingPermission);
            }

        } else {
            dpna.put(DI_DD_Android_is5GHzBandSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isDeviceToApRttSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isEnhancedPowerReportingSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isP2pSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isPreferredNetworkOffloadSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_isTdlsSupported, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }
}

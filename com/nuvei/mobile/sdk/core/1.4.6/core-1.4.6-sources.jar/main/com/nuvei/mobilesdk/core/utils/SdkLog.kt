package com.nuvei.mobilesdk.core.utils

import android.util.Log
import androidx.annotation.RestrictTo
import com.nuvei.mobilesdk.core.BuildConfig

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
object SdkLog {

    @JvmStatic
    fun d(tag: String, message: String) {
        if (BuildConfig.DEBUG) Log.d(tag, message)
    }

    @JvmStatic
    fun w(tag: String, message: String) {
        if (BuildConfig.DEBUG) Log.w(tag, message)
    }

    @JvmStatic
    @JvmOverloads
    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (BuildConfig.DEBUG) Log.e(tag, message, throwable)
    }
}

package com.nuvei.mobilesdk.core.threeds2sdk;

import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.impl.ConcatKDF3DS2;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.impl.ECDH;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.utils.ECChecks;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.Curve;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.ECKey;
import com.nuvei.mobilesdk.core.utils.SdkLog;

import net.minidev.json.JSONObject;

import java.security.interfaces.ECPublicKey;
import java.text.ParseException;
import java.util.Map;

import javax.crypto.SecretKey;

public class ChallengeKeys {

    private final static String TAG = "[3DSSDK][ChallengeKeys]";

    private ECKey sdkKey = null;
    private Map<String, Object> acsKey = null;
    private String sdkReferenceNumber = null;
    private byte[] cek = null;

    void setSdkKey(ECKey sdkKey) {
        this.sdkKey = sdkKey;
        cek = null;
    }

    void setAcsKey(Map<String, Object> acsKey) {
        this.acsKey = acsKey;
        cek = null;
    }

    void setSdkReferenceNumber(String sdkReferenceNumber) {
        this.sdkReferenceNumber = sdkReferenceNumber;
        cek = null;
    }

    private void generateEncryptionCek() throws JOSEException, ParseException {
        ECKey acsJwk = ECKey.parse(new JSONObject(acsKey));
        if (!Curve.P_256.equals(acsJwk.getCurve())) {
            throw new JOSEException("ACS ephemeral key is not on curve P-256");
        }
        ECPublicKey acsPublicKey = acsJwk.toECPublicKey();
        if (!ECChecks.isPointOnCurve(acsPublicKey, Curve.P_256.toECParameterSpec())) {
            throw new JOSEException("ACS ephemeral key is not a point on curve P-256");
        }
        SecretKey sharedSecret = ECDH.deriveSharedSecret(acsPublicKey, sdkKey.toECPrivateKey(), null);
        cek = new ConcatKDF3DS2("SHA-256", sdkReferenceNumber)
                .deriveKey(sharedSecret, 256, null, null, null, null, null)
                .getEncoded();
    }

    byte[] getCek() {
        if (cek == null) {
            try {
                generateEncryptionCek();
            } catch (JOSEException | ParseException e) {
                SdkLog.e(TAG, "getCek(): e = " + e);
                // Callers expect an unchecked exception, as Apache CXF threw before.
                throw new IllegalStateException("Failed to derive CEK", e);
            }
        }
        return cek;
    }
}

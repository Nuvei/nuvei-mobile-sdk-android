package com.nuvei.mobilesdk.core.threeds2sdk;

import com.nuvei.mobilesdk.core.utils.SdkLog;

import com.nuvei.mobilesdk.core.nimbusds.jose.EncryptionMethod;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEAlgorithm;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEHeader;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEObject;
import com.nuvei.mobilesdk.core.nimbusds.jose.Payload;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.DirectEncrypter;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;

import java.text.ParseException;

import javax.crypto.spec.SecretKeySpec;

class ChallengeCrypto implements API.ResponseDecryptor {

    private final static String TAG = "[3DSSDK][ChallengeCrypto]";

    private byte[] sdkCek;

    ChallengeCrypto(byte[] sdkCek) {
        this.sdkCek = sdkCek;
    }

    String encrypt(String creq, String transactionId) throws JOSEException, ParseException {
        SdkLog.d(TAG, "encrypt: transactionId = " + transactionId);
        JWEHeader.Builder builder = new JWEHeader.Builder(JWEAlgorithm.DIR, EncryptionMethod.A128CBC_HS256);
        builder.keyID(transactionId);
        Payload payload = new Payload(creq);
        JWEObject jweObject = new JWEObject(builder.build(), payload);
        jweObject.encrypt(new DirectEncrypter(sdkCek));
        //TODO: sometimes the sdk crash here - "jweObject.encrypt(new DirectEncrypter(sdkCek));"

        String serializedObj = jweObject.serialize();
        jweObject = JWEObject.parse(serializedObj);
        String creqJWE = jweObject.serialize();
        return creqJWE;
    }

    @Override
    public String decrypt(String encrypted) {
        // Validate input
        String[] components = encrypted.split("\\.");
        if (components.length != 5) {
            throw new InvalidInputException("CRes is invalid (Code 1)");
        }
        String authHeader = components[0];
        if (authHeader.endsWith("=") || authHeader.contains("/") || authHeader.contains(" ") || authHeader.contains("+") || authHeader.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }
        String initVector = components[2];
        if (initVector.endsWith("=") || initVector.contains("/") || initVector.contains(" ") || initVector.contains("+") || initVector.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }
        String ciphertext = components[3];
        if (ciphertext.endsWith("=") || ciphertext.contains("/") || ciphertext.contains(" ") || ciphertext.contains("+") || ciphertext.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }
        String authTag = components[4];
        if (authTag.endsWith("=") || authTag.contains("/") || authTag.contains(" ") || authTag.contains("+") || authTag.contains("\n")) {
            throw new InvalidInputException("CRes is invalid (Code 2)");
        }

        try {
            JsonWebEncryption jwe = new JsonWebEncryption();
            jwe.setAlgorithmConstraints(new AlgorithmConstraints(
                    AlgorithmConstraints.ConstraintType.PERMIT, KeyManagementAlgorithmIdentifiers.DIRECT));
            jwe.setContentEncryptionAlgorithmConstraints(new AlgorithmConstraints(
                    AlgorithmConstraints.ConstraintType.PERMIT, ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256));
            jwe.setCompactSerialization(encrypted);
            // The CRes comes from outside, so compressed payloads are refused before decompression is attempted.
            if (jwe.getHeader(HeaderParameterNames.ZIP) != null) {
                throw new InvalidInputException("CRes is invalid (Code 3)");
            }
            jwe.setKey(new SecretKeySpec(sdkCek, "AES"));
            return jwe.getPlaintextString();
        } catch (JoseException e) {
            throw new InvalidInputException("CRes is invalid (Code 4)", e);
        }
    }
}
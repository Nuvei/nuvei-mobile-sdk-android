package com.nuvei.mobilesdk.core.web_view

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.Gravity
import android.view.MenuItem
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.nuvei.mobilesdk.core.Constants
import com.nuvei.mobilesdk.core.Constants.Companion.ADD_CARD_3DS_HTML
import com.nuvei.mobilesdk.core.Constants.Companion.FORCE_WEB_3DS2_HTML
import com.nuvei.mobilesdk.core.EdgeToEdgeHelper
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.network.ApiClient

class WebViewActivity : AppCompatActivity() {

    enum class ChallengeType {
        THREE_D1,
        THREE_D2_FORCE_WEB
    }
    private var challengeType: ChallengeType = ChallengeType.THREE_D1

    private lateinit var container: LinearLayout
    private lateinit var webview: WebView

    private var termUrlReached = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        onBackPressedDispatcher.addCallback(this) {
            com.nuvei.mobilesdk.core.Nuvei.onUserCanceled()
            finish()
        }

        val termUrl = intent.getStringExtra(INTENT_KEY_TERM_URL)

        val isCreatePayment = intent.getBooleanExtra(INTENT_KEY_IS_CREATE_PAYMENT, false)

        // Create parent LinearLayout
        container = LinearLayout(this).also {
            it.orientation = LinearLayout.VERTICAL
            findViewById<ViewGroup>(android.R.id.content)
                    .addView(it, LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    ))
        }

        setupToolbar().also {
            it.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            )
            container.addView(it)
        }

        webview = WebView(this).also {
            container.addView(it, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0,
                    1F
            ))
        }

        webview.webChromeClient = WebChromeClient()
        webview.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val isOnTermUrl = termUrl != null && isTermUrl(url, termUrl)
                val resultReady = if (isCreatePayment) termUrlReached else isOnTermUrl
                if (isOnTermUrl) {
                    termUrlReached = true
                }
                if (resultReady) {
                    view?.loadUrl("javascript:android.onData(JSON.stringify(response))")
                }
            }
        }
        webview.clearCache(true)
        webview.clearHistory()
        webview.settings.javaScriptEnabled = true
        webview.addJavascriptInterface(this, "android")

        val acsUrl = intent.getStringExtra(INTENT_KEY_ACS_URL)
        val challengeTypeString = intent.getStringExtra(INTENT_KEY_CHALLENGE_TYPE) ?: ChallengeType.THREE_D1.name
        challengeType = ChallengeType.valueOf(challengeTypeString)
        val html: String = when (challengeType) {
            ChallengeType.THREE_D1 -> {
                val paRequest = intent.getStringExtra(INTENT_KEY_PA_REQUEST)
                getFormattedHtml(acsUrl, paRequest, termUrl)
            }
            ChallengeType.THREE_D2_FORCE_WEB -> {
                val creq = intent.getStringExtra(INTENT_KEY_CREQ)
                getFormattedHtml(acsUrl, creq)
            }
        }

        webview.loadDataWithBaseURL(
                ApiClient.baseUrl,
                html,
                null,
                null,
                null
        )

        EdgeToEdgeHelper.enableEdgeToEdge(window, container.rootView)
    }

    private fun setupToolbar(): Toolbar {
        supportActionBar?.hide()

        val toolbar = Toolbar(this)

        intent.getStringExtra(INTENT_KEY_TOOLBAR_BG_COLOR)?.let { toolbarBgColor ->
            toolbar.setBackgroundColor(Color.parseColor(toolbarBgColor))
        }

        toolbar.addView(TextView(this).also { title ->
            title.text = "Secure Checkout"
            title.layoutParams = Toolbar.LayoutParams(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.WRAP_CONTENT).also {
                it.gravity = Gravity.START
            }
            title.setTextColor(Color.WHITE)
            title.textSize = 18F
            title.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })

        toolbar.addView(Button(this).also { button ->
            button.text = "Cancel"
            button.layoutParams = Toolbar.LayoutParams(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.WRAP_CONTENT).also {
                it.gravity = Gravity.END
            }
            button.background = null
            button.setTextColor(Color.WHITE)
            button.setOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }
        })

        return toolbar
    }

    fun getFormattedHtml(acsUrl: String?, paReq: String?, termUrl: String?): String {
        var html = ADD_CARD_3DS_HTML
        acsUrl?.let {
            html = html.replace(Constants.ADD_CARD_3DS_HTML_ACS_URL_, it)
        }
        paReq?.let {
            html = html.replace(Constants.ADD_CARD_3DS_HTML_PA_REQ, it)
        }
        termUrl?.let {
            html = html.replace(Constants.ADD_CARD_3DS_HTML_TERM_URL, it)
        }
        return html
    }

    fun getFormattedHtml(acsUrl: String?, creq: String?): String {
        var html = FORCE_WEB_3DS2_HTML
        acsUrl?.let {
            html = html.replace(Constants.ADD_CARD_3DS_HTML_ACS_URL_, it)
        }
        creq?.let {
            html = html.replace(Constants.ADD_CARD_3DS_HTML_CREQ, it)
        }
        return html
    }

    @JavascriptInterface
    fun onData(value: String?) {
        // Android calls this on a background thread. Move to the main thread, where termUrlReached is set.
        runOnUiThread {
            if (!termUrlReached) return@runOnUiThread
            com.nuvei.mobilesdk.core.Nuvei.onWebViewResult(value)
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                com.nuvei.mobilesdk.core.Nuvei.onUserCanceled()
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        const val INTENT_KEY_CHALLENGE_TYPE = "INTENT_KEY_CHALLENGE_TYPE"
        const val INTENT_KEY_ACS_URL = "INTENT_KEY_ACS_URL"
        const val INTENT_KEY_PA_REQUEST = "INTENT_KEY_PA_REQUEST"
        const val INTENT_KEY_CREQ = "INTENT_KEY_CREQ"
        const val INTENT_KEY_TERM_URL = "INTENT_KEY_TERM_URL"
        const val INTENT_KEY_TOOLBAR_BG_COLOR = "INTENT_KEY_TOOLBAR_BG_COLOR"
        const val INTENT_KEY_IS_CREATE_PAYMENT = "INTENT_KEY_IS_CREATE_PAYMENT"

        internal fun isTermUrl(url: String?, termUrl: String): Boolean {
            if (url == null) return false
            val loaded = Uri.parse(url)
            val expected = Uri.parse(termUrl)
            return loaded.scheme.equals(expected.scheme, ignoreCase = true) &&
                    loaded.host.equals(expected.host, ignoreCase = true) &&
                    loaded.port == expected.port &&
                    loaded.path == expected.path
        }

        fun create3d1Intent(
                context: Context,
                acsUrl: String?,
                paRequest: String?,
                termUrl: String?,
                toolbarBgColor: String?
        ): Intent? {
            if (acsUrl == null || paRequest == null || termUrl == null) {
                return null
            }

            val bundle = Bundle().apply {
                putString(INTENT_KEY_CHALLENGE_TYPE, ChallengeType.THREE_D1.name)
                putString(INTENT_KEY_ACS_URL, acsUrl)
                putString(INTENT_KEY_PA_REQUEST, paRequest)
                putString(INTENT_KEY_TERM_URL, termUrl)
                putString(INTENT_KEY_TOOLBAR_BG_COLOR, toolbarBgColor)
            }

            return Intent(context, WebViewActivity::class.java).apply {
                putExtras(bundle)
            }
        }

        fun create3d2ForceWebIntent(
                context: Context,
                acsUrl: String?,
                creq: String?,
                termUrl: String?,
                toolbarBgColor: String?,
                isCreatePayment: Boolean
        ): Intent? {
            if (acsUrl == null || creq == null || termUrl == null) {
                return null
            }

            val bundle = Bundle().apply {
                putString(INTENT_KEY_CHALLENGE_TYPE, ChallengeType.THREE_D2_FORCE_WEB.name)
                putString(INTENT_KEY_ACS_URL, acsUrl)
                putString(INTENT_KEY_CREQ, creq)
                putString(INTENT_KEY_TERM_URL, termUrl)
                putString(INTENT_KEY_TOOLBAR_BG_COLOR, toolbarBgColor)
                putBoolean(INTENT_KEY_IS_CREATE_PAYMENT, isCreatePayment)
            }

            return Intent(context, WebViewActivity::class.java).apply {
                putExtras(bundle)
            }
        }
    }
}

package com.nuvei.mobilesdk.core.model

import java.io.Serializable

data class CheckoutTransactionDetails(
    val sessionToken: String,
    val merchantId: String,
    val merchantSiteId: String,
    val googlePayMerchantId: String? = null,
    val googlePayMerchantName: String? = null,
    val googlePayGateway: String? = null,
    val googlePayGatewayMerchantId: String? = null,
    val currency: String,
    val amount: String,
    val clientUniqueId: String? = null,
    val clientRequestId: String? = null,
    val customData: String? = null,
    val billingAddress: BillingAddress? = null,
    val shippingAddress: ShippingAddress? = null,
    val notificationUrl: String? = null,
    val userDetails: UserDetails? = null,
    val merchantDetails: MerchantDetails? = null,
    val dynamicDescriptor: DynamicDescriptor? = null,
    val paymentOption: PaymentOption? = null,
    val countryCode: String? = null,
    val forceWebChallenge: Boolean,
) : Serializable {
    constructor(
        authInput: NVPayment,
        additionalParams: Map<String, Any?>? = null,
        forceWebChallenge: Boolean,
    ) : this(
        authInput.sessionToken,
        authInput.merchantId,
        authInput.merchantSiteId,
        authInput.googlePayMerchantId,
        authInput.googlePayMerchantName,
        authInput.googlePayGateway,
        authInput.googlePayGatewayMerchantId,
        requireNotNull(authInput.currency) { "Currency must not be null" },
        requireNotNull(authInput.amount) { "Amount must not be null" },
        authInput.clientUniqueId,
        authInput.clientRequestId,
        authInput.customData,
        authInput.billingAddress,
        authInput.shippingAddress,
        authInput.notificationUrl,
        authInput.userDetails,
        authInput.merchantDetails,
        authInput.dynamicDescriptor,
        authInput.paymentOption,
        authInput.countryCode,
        forceWebChallenge
    )
//
//    fun getCountryCodeByMerchantOrSIM(context: Context) = (
//            countryCode ?:
//            NVUtils.sharedInstance.simCountryCode()
//            )?.uppercase()
}
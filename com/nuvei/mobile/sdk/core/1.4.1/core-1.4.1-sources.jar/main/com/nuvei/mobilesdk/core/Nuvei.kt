package com.nuvei.mobilesdk.core

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.nuvei.mobilesdk.core.mapper.ClientPaymentResultToGenericOutput
import com.nuvei.mobilesdk.core.model.APMsInput
import com.nuvei.mobilesdk.core.model.APMsOutput
import com.nuvei.mobilesdk.core.model.Error
import com.nuvei.mobilesdk.core.model.NVAuthenticate3dOutput
import com.nuvei.mobilesdk.core.model.NVCardDetailsInput
import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.UPODeleteInput
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.model.NuveiUiCustomization
import com.nuvei.mobilesdk.core.model.Sdk
import com.nuvei.mobilesdk.core.model.UPOCreatePaymentInput
import com.nuvei.mobilesdk.core.model.UPOsInput
import com.nuvei.mobilesdk.core.model.UPOsOutput
import com.nuvei.mobilesdk.core.model.V2AdditionalParams
import com.nuvei.mobilesdk.core.network.ApiClient
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.threeds2sdk.Transaction
import com.nuvei.mobilesdk.core.mapper.Authenticate3dToClientPaymentMapper
import com.nuvei.mobilesdk.core.mapper.Authenticate3dToInitPaymentMapper
import com.nuvei.mobilesdk.core.mapper.ClientPaymentInputToCompletePaymentInputMapper
import com.nuvei.mobilesdk.core.mapper.InitPaymentInputToVerify3dInputMapper
import com.nuvei.mobilesdk.core.mapper.PaymentFrameResponseToGenericOutput
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeStatusReceiver
import com.nuvei.mobilesdk.core.threeds2sdk.CompletionEvent
import com.nuvei.mobilesdk.core.threeds2sdk.ProtocolErrorEvent
import com.nuvei.mobilesdk.core.threeds2sdk.RuntimeErrorEvent
import com.nuvei.mobilesdk.core.threeds2sdk.ThreeDS2Service
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.ToolbarCustomization
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.UiCustomization
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ConfigParameters
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ChallengeParameters
import com.nuvei.mobilesdk.core.web_view.WebViewActivity
import retrofit2.Call
import retrofit2.Response
import java.io.Serializable
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt


inline fun <reified T : Serializable?> Intent.getSerializable(key: String, m_class: Class<T>): T? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        this.getSerializableExtra(key, m_class)
    } else {
        val serializable = this.getSerializableExtra(key)
        return if (serializable is T) serializable else null
    }
}


@SuppressLint("StaticFieldLeak")
object Nuvei {

    private val TAG = this.javaClass.simpleName

    const val sdkVersion = BuildConfig.SDK_VERSION

    enum class Environment {
        STAGING,
        PROD
    }

    var environment: Environment? = null

    var hostAppDetails: HostAppDetails? = null
        get() {
            if (field != null) {
                return field
            } else {
                throw RuntimeException("No host app details. Make sure you call Nuvei.setup(activity) first.")
            }
        }

    var debugInfo: StringBuilder? = null


    enum class CheckoutCompletionAction {
        dismiss, backToCheckout
    }

    private var webviewInternalCallback: InternalCallback<JsonObject>? = null

    var onCheckoutCompletionActionRequired:((AppCompatActivity, NVOutput, ((CheckoutCompletionAction)->Unit))->Unit)? = null
    private var callback: Callback<NVOutput>? = null

    private var isCreatePayment = false

    //var customization: NuveiUiCustomization? = null

    var isLoading = false
    private var ccTempToken: String? = null
    private var forceWebChallenge = false
    private var userAgentString: String? = null
    private var isProcessing = false
    private var activity: Activity? = null
    private var transaction: Transaction? = null


    fun resetDebugInfo() {
        //debugInfo = if (!isPublicRelease) StringBuilder("") else null //TODO: revise
    }

    fun log(message: String) {
//        if (!isPublicRelease) {
//            Log.d(TAG, message)
//            //logOutput += message + "\n" // RELEASE
//        }
    }

    fun setup(context: Context, environment: Environment = Environment.PROD) {
        this.environment = environment
        HostAppDetails.setup(context)

        when (environment) {
            Environment.STAGING -> ApiClient.setup("https://ppp-test.safecharge.com/ppp/api")
            Environment.PROD -> ApiClient.setup("https://secure.safecharge.com/ppp/api")
        }
    }

    fun createUPOPayment(input: UPOCreatePaymentInput, callback: (NVCreatePaymentOutput?) -> Unit) {
        debugInfo?.append("createUPOPayment, ")
        val service = ApiClient.service
        val request = service?.clientPayment(Gson().toJsonTree(input).asJsonObject)
        request?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("createUPOPayment.onResponse, ")
                response.body()?.let {
                    callback(ClientPaymentResultToGenericOutput(emptyMap(), true).map(it) as NVCreatePaymentOutput)
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("createUPOPayment.onFailure, ")
                callback(null)
            }
        })
    }

    fun getPaymentStatus(sessionToken: String, callback: (NVCreatePaymentOutput?) -> Unit) {
        debugInfo?.append("getPaymentStatus, ")
        val input = mapOf(
            "sessionToken" to sessionToken
        )

        ApiClient.service?.getPaymentStatus(Gson().toJsonTree(input).asJsonObject)?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("getPaymentStatus.onResponse, ")
                response.body()?.let {
                    callback(ClientPaymentResultToGenericOutput(emptyMap(), true).map(it) as NVCreatePaymentOutput)
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("getPaymentStatus.onFailure, ")
            }
        })
    }


    fun setup(context: Context) {
        userAgentString = WebView(context).settings.userAgentString
    }

    fun getUPOs(input: UPOsInput, callback: (UPOsOutput?, NVOutput?) -> Unit) {
        debugInfo?.append("getUPOs, ")
        val body = Gson().toJsonTree(input)

        ApiClient.service?.userUPOs(body.asJsonObject)?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: retrofit2.Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("getUPOs.onResponse, ")
                try {
                    val uposResult = Gson().fromJson(response.body(), UPOsOutput::class.java)
                    if (uposResult.error != null && uposResult.error != 0) {
                        callback(null, NVOutput.create(
                            isCreatePayment = false,
                            result = Constants.ERROR,
                            errorCode = uposResult.error,
                            errorDescription = uposResult.reason,
                            rawResult = null
                        ))
                    } else {
                        callback(uposResult, null)
                    }
                } catch (ex: Throwable) {
                    Log.e(TAG, "getUPOs.onResponse: ex = $ex")
                    val errorObject = tryOrNull { Gson().fromJson(response.body(), NVOutput::class.java) }
                    callback(null, errorObject)
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("getUPOs.onFailure, ")
                Log.e(TAG, "getUPOs.onFailure: t = $t")
                callback(null, null)
            }
        })
    }

    fun getAPMs(input: APMsInput, callback: (APMsOutput?, NVOutput?) -> Unit) {
        debugInfo?.append("getAPMs, ")
        val service = ApiClient.service
        val request = service?.getMerchantPaymentMethods(Gson().toJsonTree(input).asJsonObject)
        request?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("getAPMs.onResponse, ")
                response.body()?.let {
                    try {
                        val apmsResult = Gson().fromJson(response.body(), APMsOutput::class.java)
                        if (apmsResult.error != null && apmsResult.error != 0) {
                            callback(null, NVOutput.create(
                                isCreatePayment = false,
                                result = Constants.ERROR,
                                errorCode = apmsResult.error,
                                errorDescription = apmsResult.reason,
                                rawResult = null
                            ))
                        } else {
                            callback(apmsResult, null)
                        }
                    } catch (ex: Throwable) {
                        Log.e(TAG, "getAPMs.onResponse: ex = $ex")
                        val errorObject = tryOrNull { Gson().fromJson(response.body(), NVOutput::class.java) }
                        callback(null, errorObject)
                    }
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("getAPMs.onFailure, ")
            }
        })
    }

    fun internalCreatePayment(
        activity: Activity,
        input: NVPayment,
        additionalParams: Map<String, Any>? = null,
        forceWebChallenge: Boolean = true,
        source: String,
        callback: Callback<NVCreatePaymentOutput>
    ) {
        ApiClient.setSourceApplication(source)
        authenticate3d(
            activity,
            input,
            additionalParams,
            forceWebChallenge,
            isCreatePayment = true,
            ignoreFailure = true
        ) { output ->
            if (output is NVCreatePaymentOutput) {
                callback.onComplete(output)
            } else {
                callback.onComplete(NVCreatePaymentOutput(
                    result = Constants.ERROR,
                    errorCode = Error.INTERNAL_ERROR.errorCode,
                    errorDescription = Error.INTERNAL_ERROR.errorDescription + ", Wrong output object"
                ))
            }
        }
    }

    fun authenticate3d(
        activity: Activity,
        input: NVPayment,
        additionalParams: Map<String, Any>? = null,
        forceWebChallenge: Boolean = true,
        source: String = NetworkConstants.Values.SourceApplication.direct,
        callback: Callback<NVAuthenticate3dOutput>
    ) {
        ApiClient.setSourceApplication(source)

        Nuvei.resetDebugInfo()

        authenticate3d(
            activity,
            input,
            additionalParams,
            forceWebChallenge,
            isCreatePayment = false,
            ignoreFailure = false
        ) { output ->
            if (output is NVAuthenticate3dOutput) {
                callback.onComplete(output)
            } else {
                callback.onComplete(
                    NVAuthenticate3dOutput(
                    result = Constants.ERROR,
                    errorCode = Error.INTERNAL_ERROR.errorCode,
                    errorDescription = Error.INTERNAL_ERROR.errorDescription + ", Wrong output object"
                )
                )
            }
        }
    }

    fun authenticate3d(
        activity: Activity,
        input: NVPayment,
        additionalParams: Map<String, Any>? = null,
        forceWebChallenge: Boolean = true,
        isCreatePayment: Boolean,
        ignoreFailure: Boolean,
        callback: (NVOutput) -> Unit
    ) {
        //NVUtils.sharedInstance.setup(activity, input, additionalParams)

        debugInfo?.append("authenticate3d(forceWebChallenge=$forceWebChallenge, isCreatePayment=$isCreatePayment, ignoreFailure=$ignoreFailure), ")
        if (environment == null) {
            callback(NVOutput.create(
                isCreatePayment = isCreatePayment,
                result = Constants.ERROR,
                errorCode = Error.NOT_SET_UP.errorCode,
                errorDescription = Error.NOT_SET_UP.errorDescription
            ))
            return
        }

//        if (!forceWebChallenge) {
//            callback(NVOutput.create(
//                    isCreatePayment = isCreatePayment,
//                    result = Constants.ERROR,
//                    errorCode = Error.FORCE_WEB_CHALLENGE.errorCode,
//                    errorDescription = Error.FORCE_WEB_CHALLENGE.errorDescription
//            ))
//            return
//        }

        if (isProcessing) {
            callback(NVOutput.create(
                isCreatePayment = isCreatePayment,
                result = Constants.ERROR,
                errorCode = Error.IS_PROCESSING.errorCode,
                errorDescription = Error.IS_PROCESSING.errorDescription
            ))
            return
        }

        Nuvei.callback = object : Callback<NVOutput> {
            override fun onComplete(response: NVOutput) {
                callback(response)
            }
        }
        Nuvei.isCreatePayment = isCreatePayment
        Nuvei.forceWebChallenge = forceWebChallenge
        //userAgentString = WebView(activity).settings.userAgentString
        val initPaymentInput = Authenticate3dToInitPaymentMapper().map(input)
        isProcessing = true
        Log.d(TAG, "authenticate3d: initPaymentInput = $initPaymentInput")
        initPayment(activity, initPaymentInput, ignoreFailure, object : InternalCallback<JsonObject> {
            override fun onSuccess(response: JsonObject) {
                debugInfo?.append("authenticate3d.initPayment.onSuccess, ")
                isProcessing = false
                ccTempToken = ((response[NetworkConstants.paymentOption] as? JsonObject)?.get(
                    NetworkConstants.card) as? JsonObject)?.get(NetworkConstants.ccTempToken)?.asString
                clientPayment(input, initPaymentInput, response, object : InternalCallback<JsonObject> {
                    override fun onSuccess(response: JsonObject) {
                        debugInfo?.append("authenticate3d.clientPayment.onSuccess, ")
                        returnClientPaymentToCallback(response)
                    }

                    override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                        debugInfo?.append("authenticate3d.clientPayment.onFailure, ")
                        callback(NVOutput.create(
                            isCreatePayment = isCreatePayment,
                            result = result,
                            errorCode = errorCode,
                            errorDescription = errorDescription,
                            rawResult = rawResult
                        ))
                    }
                })
            }

            override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                debugInfo?.append("authenticate3d.initPayment.onFailure, ")
                isProcessing = false
                callback(NVOutput.create(
                    isCreatePayment = isCreatePayment,
                    result = result,
                    errorCode = errorCode,
                    errorDescription = errorDescription,
                    rawResult = rawResult
                ))
            }
        })
    }

    private fun returnClientPaymentToCallback(
        clientPaymentOutput: JsonObject
    ) {
        debugInfo?.append("returnClientPaymentToCallback, ")
        Nuvei.callback?.onComplete(
            ClientPaymentResultToGenericOutput(
                mapOf(NetworkConstants.ccTempToken to ccTempToken),
                isCreatePayment
            ).map(clientPaymentOutput))
    }

    private fun initPayment(
        activity: Activity,
        body: JsonObject,
        ignoreFailure: Boolean,
        internalCallback: InternalCallback<JsonObject>,
    ) {
        debugInfo?.append("initPayment, ")
        Nuvei.activity = activity
        ApiClient.service?.initPayment(body)
            ?.enqueue(object : retrofit2.Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    debugInfo?.append("initPayment.onResponse, ")
                    response.body()?.let { res ->
                        Log.d(TAG, "initPayment.onResponse: $res")
                        if (!isCreatePayment){
                            val status = res[NetworkConstants.transactionStatus]?.asString
                                ?: res[NetworkConstants.status]?.asString
                                ?: Constants.ERROR

                            val v2supported = tryOrNull {
                                ((res[NetworkConstants.paymentOption] as? JsonObject)
                                    ?.get(NetworkConstants.card) as? JsonObject)
                                    ?.get(NetworkConstants.threeD)?.asJsonObject?.get(NetworkConstants.v2supported)?.asBoolean
                            } == true

                            val isFinalError = v2supported && res[NetworkConstants.transactionId] == null
                            if (!isFinalError && (ignoreFailure || status != Constants.ERROR)) {
                                internalCallback.onSuccess(res)
                            } else {
                                val errorCode = res[NetworkConstants.gwExtendedErrorCode]?.asInt
                                    ?: res[NetworkConstants.gwErrorCode]?.asInt
                                    ?: res[NetworkConstants.paymentMethodErrorCode]?.asInt
                                    ?: res[NetworkConstants.errCode]?.asInt
                                    ?: -1

                                val errorDescription = res[NetworkConstants.gwErrorReason]?.asString
                                    ?: res[NetworkConstants.paymentMethodErrorReason]?.asString
                                    ?: res[NetworkConstants.reason]?.asString
                                    ?: ""

                                internalCallback.onFailure(
                                    Constants.ERROR,
                                    errorCode,
                                    errorDescription,
                                    response.body()?.asMap()
                                )
                            }
                       }
                        else{
                            internalCallback.onSuccess(res)
                        }
                    } ?: run {
                        debugInfo?.append("initPayment.onResponse(body = null), ")
                        Log.d(TAG, "initPayment.onResponse: null")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription,
                            response.body()?.asMap()
                        )
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    debugInfo?.append("initPayment.onFailure, ")
                    Log.d(TAG, "initPayment.onFailure: $t")
                    internalCallback.onFailure(
                        Constants.ERROR,
                        Error.INTERNAL_ERROR.errorCode,
                        Error.INTERNAL_ERROR.errorDescription,
                        null
                    )
                }
            })
    }

    private fun clientPayment(
        input: NVPayment,
        initPaymentInput: JsonObject,
        initPaymentOutput: JsonObject,
        internalCallback: InternalCallback<JsonObject>
    ) {
        /**
         * {
         *      "internalRequestId":835456938,
         *      "status":"SUCCESS",
         *      "errCode":0,
         *      "reason":"",
         *      "merchantId":"8536594779582844752",
         *      "merchantSiteId":"231188",
         *      "version":"1.0",
         *      "clientRequestId":"2b7b8bbd-14a2-47d2-ab45-6a173e9f26c1",
         *      "sessionToken":"46a4d59e-03cd-4b80-bc56-6283b81c676a",
         *      "orderId":"403801088",
         *      "userTokenId":"ran@sc",
         *      "transactionId":"711000000028789584",
         *      "transactionType":"InitAuth3D",
         *      "transactionStatus":"APPROVED",
         *      "gwErrorCode":0,
         *      "gwExtendedErrorCode":0,
         *      "paymentOption":{
         *          "card":{
         *              "ccCardNumber":"2****7736",
         *              "bin":"222100",
         *              "last4Digits":"7736",
         *              "ccExpMonth":"12",
         *              "ccExpYear":"27",
         *              "acquirerId":"19",
         *              "ccTempToken":"ee347e8c-31ab-446d-8645-dd2b98fe7647",
         *              "threeD":{
         *                  "methodUrl":"https://3dsn.sandbox.safecharge.com/ThreeDSMethod/api/ThreeDSMethod/threeDSMethodURL",
         *                  "version":"2.1.0",
         *                  "v2supported":"true",
         *                  "methodPayload":"eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjBkYWRmMmRlLWM0MDAtNDAwOS1hNzAxLWZmZmE0ZmFhMWVlMCIsInRocmVlRFNNZXRob2ROb3RpZmljYXRpb25VUkwiOiJodHRwczovL3BwcC10ZXN0LnNhZmVjaGFyZ2UuY29tL3BwcC9hcGkvdjEvdGhyZWVEU2VjdXJlL3Yybm90aWZpY2F0aW9uLmRvIn0=",
         *                  "directoryServerId":"A000000004",
         *                  "directoryServerPublicKey":"rsa:MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhZWY6m2y/Wwyjs2RWsHW8n0HHs1RFEgwllrGCsP1enKPQBmjwVLBoM8RevhA4FY972MrYEpfMRb1T7G+GSegSRr4pnWvEIiMq1+1lMUDAd4ckgTj3+Dge9gj/lJGhTUeoXZTuaH805gdqI9RXSxmZkzf7I+maB5J9mc7prPEABxY7xY7KSlGApprPdYKTaST1FM7Z9DdWDFlRaRTMrWoRyJaYhqkw7eN9eBe7BQAS8cxaw5nKoX+tt0j1d5MEIi1Vjr3sDutiLWFBYB8JXtnau+mIiq1L9Qu7wA0pNgJuIKsL+3XApxXjNgB2wRQWtWQUUF6LLl1cPGXEKn2PJuIjQIDAQAB",
         *                  "serverTransId":"0dadf2de-c400-4009-a701-fffa4faa1ee0"
         *              }
         *          }
         *      },
         *      "customData":""
         *  }
         */
        debugInfo?.append("clientPayment, ")

        val body = Authenticate3dToClientPaymentMapper().map(input)

        val nullableThreeD = tryOrNull {
            ((initPaymentOutput[NetworkConstants.paymentOption] as? JsonObject)
                ?.get(NetworkConstants.card) as? JsonObject)
                ?.get(NetworkConstants.threeD)?.asJsonObject
        }
        val v2supported = tryOrNull {
            nullableThreeD?.get(NetworkConstants.v2supported)?.asBoolean
        } == true


        val serverTransId = tryOrNull {
            nullableThreeD?.get(NetworkConstants.serverTransId)?.asString
        }

        if (v2supported) {
            debugInfo?.append("clientPayment(v2supported = true), ")
            nullableThreeD?.let { threeD ->
                val paymentOption = body[NetworkConstants.paymentOption] as? JsonObject
                    ?: JsonObject()
                val card = paymentOption[NetworkConstants.card] as? JsonObject ?: JsonObject()

                threeD.addProperty(NetworkConstants.platformType, "01")
                threeD.addProperty(NetworkConstants.methodCompletionInd, "U")

                initPaymentOutput[NetworkConstants.transactionId]
                    ?.let { body.add(NetworkConstants.relatedTransactionId, Gson().toJsonTree(it)) }
                    ?: run {
                        debugInfo?.append("clientPayment(transactionId = null), ")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription,
                            initPaymentOutput.asMap()
                        )
                        return
                    }

                if (forceWebChallenge) {
                    debugInfo?.append("clientPayment(forceWebChallenge = true), ")
                    threeD.addProperty(NetworkConstants.platformType, "02")
                    val termUrl = ApiClient.notificationURL(input.sessionToken,
                        isCreatePayment
                    )
                    threeD.addProperty(NetworkConstants.notificationURL, termUrl)
                    threeD.addProperty(NetworkConstants.v2AdditionalParams, " [\"challengeWindowSize\": \"05\"]")
                } else {
                    debugInfo?.append("clientPayment(forceWebChallenge = false), ")
                    val directoryServerId = threeD[NetworkConstants.directoryServerId]?.asString

                    val directoryServerPublicKeyAndAlg = threeD[NetworkConstants.directoryServerPublicKey]?.asString?.let { value ->
                        value.split(":").takeIf { it.size >= 2 } ?: value.split(";")
                    }

                    if (directoryServerId?.isNotEmpty() != true || directoryServerPublicKeyAndAlg == null || directoryServerPublicKeyAndAlg.size != 2) {
                        debugInfo?.append("clientPayment(directoryServerId or directoryServerPublicKey = null), ")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription + ", Missing DS details",
                            initPaymentOutput.asMap()
                        )
                        return
                    }

                    // Dynamic key from the API
                    val directoryServerPublicKeyAlg = if (directoryServerPublicKeyAndAlg[0].equals(
                            ConfigParameters.DIRECTORY_SERVER_ALG_RSA, true)) {
                        ConfigParameters.DIRECTORY_SERVER_ALG_RSA
                    } else if (directoryServerPublicKeyAndAlg[0].equals(ConfigParameters.DIRECTORY_SERVER_ALG_EC, true)) {
                        ConfigParameters.DIRECTORY_SERVER_ALG_EC
                    } else {
                        debugInfo?.append("clientPayment(directoryServerPublicKey is wrong - ${directoryServerPublicKeyAndAlg[0]}), ")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription + ", Wrong DS details",
                            initPaymentOutput.asMap()
                        )
                        return
                    }
                    val directoryServerPublicKey = directoryServerPublicKeyAndAlg[1]

                    if (directoryServerPublicKey.isEmpty() || directoryServerPublicKeyAlg.isEmpty()) {
                        debugInfo?.append("clientPayment(directoryServerId or directoryServerPublicKey are empty), ")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription,
                            initPaymentOutput.asMap()
                        )
                        return
                    }

                    body.add(NetworkConstants.directoryServerId, Gson().toJsonTree(directoryServerId))
                    body.add(NetworkConstants.directoryServerPublicKey, Gson().toJsonTree(directoryServerPublicKey))

                    try {
                        val service = ThreeDS2Service.getInstance()

                        if (!service.isInitialized) {
                            val configParams = ConfigParameters()
                            configParams.addParam(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_ID, directoryServerId)
                            configParams.addParam(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_KEY, directoryServerPublicKey)
                            configParams.addParam(ConfigParameters.DIRECTORY_SERVER_GROUP, ConfigParameters.DIRECTORY_SERVER_ALG_KEY, directoryServerPublicKeyAlg)

                            val customization = UiCustomization()
                            val toolbarCustomization = ToolbarCustomization()
                            toolbarCustomization.backgroundColor = "#40C1AC"
                            customization.toolbarCustomization = toolbarCustomization
                            service.initialize(activity?.applicationContext, configParams, "", customization)
                        }

                        val transaction = service.createTransaction(directoryServerId, "2.1.0")
                        val authParams = transaction.authenticationRequestParameters

                        threeD.add(
                            NetworkConstants.sdk, Gson().toJsonTree(
                            Sdk(
                                authParams.sdkTransactionID,
                                authParams.deviceData,
                                authParams.sdkEphemeralPublicKey,
                                authParams.sdkReferenceNumber,
                                authParams.sdkAppID,
                                authParams.messageVersion,
                                input.timeout.toString()
                            )
                        ).asJsonObject)

                        Nuvei.transaction = transaction

                    } catch (e: Exception) {
                        debugInfo?.append("clientPayment(3D exception: ${e.localizedMessage}), ")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription,
                            initPaymentOutput.asMap()
                        )
                        return
                    }
                }

                val displayMetrics = activity?.applicationContext?.resources?.displayMetrics
                val height = displayMetrics?.let { it.heightPixels / it.density }?.roundToInt() ?: 480
                val width = displayMetrics?.let { it.widthPixels / it.density }?.roundToInt() ?: 320
                val browserDetails = mapOf(
                    "acceptHeader" to "text/html,application/xhtml+xml",
                    "ip" to (HostAppDetails.getIPAddress(true)),
                    "javaEnabled" to "TRUE",
                    "javaScriptEnabled" to "TRUE",
                    "language" to getLocale(activity),
                    "colorDepth" to "32",
                    "screenHeight" to "$height",
                    "screenWidth" to "$width",
                    "timeZone" to "${TimeZone.getDefault().rawOffset / 3600000}",
                    "userAgent" to (userAgentString ?: "Mozilla")
                )
                threeD.add(NetworkConstants.browserDetails, Gson().toJsonTree(browserDetails))

                // deviceRenderOptions from EMVCo documentation

                val screenSizeLabel: String by lazy {

                    when {
                        width == 250 && height == 400 -> "01"
                        width == 390 && height == 400 -> "02"
                        width == 500 && height == 600 -> "03"
                        width == 600 && height == 400 -> "04"
                        width > 600 || height > 400 -> "05"
                        else -> "Unknown"
                    }
                }

                val v2AdditionalParams = V2AdditionalParams()
                v2AdditionalParams.challengeWindowSize = screenSizeLabel

                threeD.add("v2AdditionalParams", Gson().toJsonTree(v2AdditionalParams))

                card.add(NetworkConstants.threeD, filterClientAuthorize3d(threeD))
                paymentOption.add(NetworkConstants.card, card)
                body.add(NetworkConstants.paymentOption, Gson().toJsonTree(paymentOption))
            } ?: run {
                debugInfo?.append("clientPayment(missing threeD block), ")
                internalCallback.onFailure(
                    Constants.ERROR,
                    Error.INTERNAL_ERROR.errorCode,
                    Error.INTERNAL_ERROR.errorDescription + ", Missing 3d block",
                    initPaymentOutput.asMap()
                )
                return
            }
        } else {
            debugInfo?.append("clientPayment(v2supported = false), ")
            body.remove(NetworkConstants.relatedTransactionId)
            body.remove(NetworkConstants.threeD)
        }

        clientAuthorize3dOrClientPayment(body) { response, error, rawResult ->
            debugInfo?.append("clientPayment.clientAuthorize3dOrClientPayment, ")
            response?.let { res ->
                val status = res[NetworkConstants.transactionStatus]?.asString
                    ?: Constants.ERROR
                if (status != Constants.ERROR) {
                    handleClientPaymentResponse(initPaymentInput, body, res, serverTransId, v2supported, internalCallback)
                } else {
                    val errorCode = res[NetworkConstants.gwExtendedErrorCode]?.asInt
                        ?: res[NetworkConstants.gwErrorCode]?.asInt
                        ?: res[NetworkConstants.paymentMethodErrorCode]?.asInt
                        ?: res[NetworkConstants.errCode]?.asInt

                    val errorDescription = res[NetworkConstants.gwErrorReason]?.asString
                        ?: res[NetworkConstants.paymentMethodErrorReason]?.asString
                        ?: res[NetworkConstants.reason]?.asString

                    internalCallback.onFailure(
                        Constants.ERROR,
                        errorCode,
                        errorDescription,
                        rawResult ?: response.asMap()
                    )
                }
            } ?: run {
                debugInfo?.append("clientPayment.clientAuthorize3dOrClientPayment(error = $error), ")
                internalCallback.onFailure(
                    Constants.ERROR,
                    Error.INTERNAL_ERROR.errorCode,
                    Error.INTERNAL_ERROR.errorDescription + (error?.localizedMessage?.let { ", $it" } ?: ""),
                    rawResult
                )
            }
        }
    }

    private fun clientAuthorize3dOrClientPayment(input: JsonObject, callback: (JsonObject?, Throwable?, HashMap<String, Any>?)->Unit) {
        debugInfo?.append("clientAuthorize3dOrClientPayment, ")
        val service = ApiClient.service
        val request = if (isCreatePayment){
            input.remove("billingAddress")
            service?.clientPayment(input)
        }  else service?.clientAuthorize3d(input)

        request?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("clientAuthorize3dOrClientPayment.onResponse, ")
                response.body()?.let {
                    callback(it, null, null)
                } ?: callback(null, null, response.body()?.asCustomMap())
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("clientAuthorize3dOrClientPayment.onFailure(t = $t), ")
                callback(null, t, null)
            }
        })
    }

    private fun filterClientAuthorize3d(threeD: JsonElement): JsonElement {
        val allowedKeys = setOf(
            "version",
            "v2AdditionalParams",
            "notificationURL",
            "merchantURL",
            "platformType",
            "browserDetails",
            "account",
            "acquirer",
            "sdk",
            "methodCompletionInd"
        )
        val gson = Gson()
        val threeDMap = gson
            .fromJson<HashMap<String, Any>>(threeD, HashMap::class.java)
            .filterKeys { key -> allowedKeys.contains(key) }
        return gson.toJsonTree(threeDMap)
    }

    fun handleClientPaymentResponse(
        initPaymentInput: JsonObject,
        clientPaymentInput: JsonObject,
        clientPaymentOutput: JsonObject,
        serverTransId: String?,
        v2Supported: Boolean,
        internalCallback: InternalCallback<JsonObject>
    ) {
        debugInfo?.append("handleClientPaymentResponse, ")
        if (clientPaymentOutput[NetworkConstants.transactionType]?.asString == "Auth3D" &&
            clientPaymentOutput[NetworkConstants.transactionStatus]?.asString == "APPROVED" &&
            isCreatePayment
        ) {
            debugInfo?.append("handleClientPaymentResponse(transactionType = Auth3D, transactionStatus = APPROVED, isCreatePayment = true), ")
            internalCallback.onFailure(
                Constants.ERROR,
                Error.GENERAL_3D_ERROR.errorCode,
                Error.GENERAL_3D_ERROR.errorDescription,
                clientPaymentOutput.asMap()
            )
            return
        }

        (((clientPaymentOutput[NetworkConstants.paymentOption] as? JsonObject)
            ?.get(NetworkConstants.card) as? JsonObject)
            ?.get(NetworkConstants.threeD) as? JsonObject)?.let { threeD ->
            debugInfo?.append("handleClientPaymentResponse(threeD nul null), ")

            val status = clientPaymentOutput[NetworkConstants.transactionStatus]?.asString
                ?: Constants.ERROR

            if (v2Supported) {
                debugInfo?.append("handleClientPaymentResponse(v2Supported = true), ")
                log("[MKMK] v2Supported")
                // 3D V2
                when (status) {
                    Constants.APPROVED -> {
                        debugInfo?.append("handleClientPaymentResponse(status = APPROVED), ")
                        // Frictionless
                        handleFrictionless(clientPaymentInput, clientPaymentOutput, threeD, internalCallback)
                    }
                    Constants.REDIRECT -> {
                        debugInfo?.append("handleClientPaymentResponse(status = REDIRECT), ")
                        // Challenge
                        if (forceWebChallenge) {
                            debugInfo?.append("handleClientPaymentResponse(forceWebChallenge = true), ")
                            log("[MKMK] forceWebChallenge")
                            val acsUrl = threeD[NetworkConstants.acsUrl]?.asString
                            val creq = threeD["cReq"]?.asString
                            val sessionToken = clientPaymentInput[NetworkConstants.sessionToken]?.asString
                            if (acsUrl?.isNotEmpty() == true && creq?.isNotEmpty() == true && sessionToken?.isNotEmpty() == true) {
                                log("[MKMK] acsUrl = $acsUrl")
                                log("[MKMK] creq = $creq")
                                log("[MKMK] sessionToken = $sessionToken")
                                forceWebChallengePaymentFrame(
                                    acsUrl = acsUrl,
                                    creq = creq,
                                    sessionToken = sessionToken,
                                    callback = object : InternalCallback<JsonObject> {
                                        override fun onSuccess(response: JsonObject) {
                                            log("[MKMK] forceWebChallengePaymentFrame.onSuccess.response = $response")
                                            val mappedResponse = PaymentFrameResponseToGenericOutput(
                                                mapOf(
                                                    NetworkConstants.ccTempToken to ccTempToken,
                                                    NetworkConstants.transactionId to clientPaymentOutput[NetworkConstants.transactionId].asString
                                                ),
                                                isCreatePayment,
                                                isThreeD2 = true
                                            ).map(response)
                                            val mappedResponseJson = Gson().toJson(mappedResponse)
                                            log("[MKMK] forceWebChallengePaymentFrame.onSuccess.mappedResponseJson = $mappedResponseJson")
                                            callback?.onComplete(mappedResponse)
                                        }

                                        override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                                            log("[MKMK] forceWebChallengePaymentFrame.onFailure.result = $result")
                                            log("[MKMK] forceWebChallengePaymentFrame.onFailure.errorCode = $errorCode")
                                            log("[MKMK] forceWebChallengePaymentFrame.onFailure.errorDescription = $errorDescription")
                                            log("[MKMK] forceWebChallengePaymentFrame.onFailure.rawResult = $rawResult")
                                            internalCallback.onFailure(
                                                Constants.ERROR,
                                                Error.INTERNAL_ERROR.errorCode,
                                                Error.INTERNAL_ERROR.errorDescription,
                                                clientPaymentOutput.asMap()
                                            )
                                        }
                                    }
                                )
                            } else {
                                returnClientPaymentToCallback(clientPaymentOutput)
                            }
                        } else {
                            debugInfo?.append("handleClientPaymentResponse(forceWebChallenge = false), ")
                            handle3d2Challenge(initPaymentInput, clientPaymentInput, clientPaymentOutput, threeD, serverTransId, internalCallback)
                        }
                    }
                    // Handle DECLINED, CANCELLED, ERROR and anything unknown
                    else -> {
                        debugInfo?.append("handleClientPaymentResponse(status = else), ")
                        returnClientPaymentToCallback(clientPaymentOutput)
                    }
                }
            } else {
                debugInfo?.append("handleClientPaymentResponse(v2Supported = false), ")
                // Non 3D or 3D V1
                val acsUrl = tryOrNull { threeD[NetworkConstants.acsUrl]?.asString }
                val paRequest = tryOrNull { threeD[NetworkConstants.paRequest]?.asString }
                val sessionToken = clientPaymentInput[NetworkConstants.sessionToken]?.asString
                if (acsUrl?.isNotEmpty() == true && paRequest?.isNotEmpty() == true && sessionToken?.isNotEmpty() == true) {
                    // 3D V1
                    threeD1PaymentFrame(
                        acsUrl = acsUrl,
                        paRequest = paRequest,
                        sessionToken = sessionToken,
                        autoPayment = true,
                        callback = object : InternalCallback<JsonObject> {
                            override fun onSuccess(response: JsonObject) {
                                debugInfo?.append("handleClientPaymentResponse.threeD1PaymentFrame.onSuccess, ")
                                Log.d(TAG, "forceWebChallengePaymentFrame.response: $response")
                                callback?.onComplete(PaymentFrameResponseToGenericOutput(
                                    mapOf(
                                        NetworkConstants.ccTempToken to ccTempToken,
                                        NetworkConstants.transactionId to clientPaymentOutput[NetworkConstants.transactionId].asString
                                    ),
                                    isCreatePayment,
                                    isThreeD2 = false
                                ).map(response))
                            }

                            override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                                debugInfo?.append("handleClientPaymentResponse.threeD1PaymentFrame.onFailure, ")
                                internalCallback.onFailure(
                                    Constants.ERROR,
                                    Error.INTERNAL_ERROR.errorCode,
                                    Error.INTERNAL_ERROR.errorDescription,
                                    clientPaymentOutput.asMap()
                                )
                            }
                        })
                } else {
                    // Non 3D
                    internalCallback.onSuccess(clientPaymentOutput)
                }
            }
        } ?: run {
            debugInfo?.append("handleClientPaymentResponse(threeD = null), ")
            internalCallback.onFailure(
                Constants.ERROR,
                Error.INTERNAL_ERROR.errorCode,
                Error.INTERNAL_ERROR.errorDescription,
                clientPaymentOutput.asMap()
            )
        }
    }

    private fun threeD1PaymentFrame(
        acsUrl: String?,
        paRequest: String?,
        sessionToken: String,
        autoPayment: Boolean,
        callback: InternalCallback<JsonObject>
    ) {
        debugInfo?.append("threeD1PaymentFrame, ")
        webviewInternalCallback = callback

        /** WebView **/
        activity?.let { ctx ->
            val termUrl = ApiClient.notificationURL(sessionToken, isCreatePayment)
            WebViewActivity.create3d1Intent(ctx, acsUrl, paRequest, termUrl, "#40c1ac")?.let { intent ->
                ctx.startActivity(intent)
            }
        }
    }

    fun handle3d2Challenge(
        initPaymentInput: JsonObject,
        clientPaymentInput: JsonObject,
        clientPaymentOutput: JsonObject,
        threeD: JsonObject,
        serverTransId: String?,
        internalCallback: InternalCallback<JsonObject>
    ) {
        debugInfo?.append("handle3d2Challenge, ")
        val relatedTransactionId = clientPaymentOutput[NetworkConstants.transactionId]
        val parameters = ChallengeParameters()
        val threeDMap = threeD.asCustomMap()
        (threeD[NetworkConstants.sdk] as? JsonObject)?.asCustomMap()?.let { sdk ->
            val acsSignedContent = (threeD[NetworkConstants.sdk] as? JsonObject)?.get(
                NetworkConstants.acsSignedContent)?.asString
            sdk[NetworkConstants.acsSignedContent] = "acsSignedContent.length=${acsSignedContent?.length ?: 0}"
            threeDMap?.set(NetworkConstants.sdk, sdk)
        }
        Log.d(TAG, "threeD = $threeDMap")
        parameters.set3DSServerTransactionID(serverTransId)
        parameters.acsTransactionID = threeD[NetworkConstants.acsTransID].asString
        //TODO: update this value (should arrive from clientAuthorize3d)
        parameters.acsRefNumber = ""
        parameters.acsSignedContent = (threeD[NetworkConstants.sdk] as? JsonObject)?.get(
            NetworkConstants.acsSignedContent)?.asString
        //TODO: update this value (should arrive from clientAuthorize3d, for 3DS SDK v2.2.1)
        parameters.threeDSRequestorAppURL = ""

        transaction?.doChallenge(activity, parameters, object : ChallengeStatusReceiver {
            override fun cancelled() {
                debugInfo?.append("handle3d2Challenge.doChallenge.cancelled, ")
                internalCallback.onFailure(
                    Constants.ERROR,
                    Error.USER_CANCELLED.errorCode,
                    Error.USER_CANCELLED.errorDescription,
                    clientPaymentOutput.asMap()
                )
                transaction?.close()
            }

            override fun protocolError(protocolErrorEvent: ProtocolErrorEvent?) {
                debugInfo?.append("handle3d2Challenge.doChallenge.protocolError($protocolErrorEvent), ")
                protocolErrorEvent?.let {
                    it.errorMessage?.let { error ->
                        internalCallback.onFailure(
                            Constants.ERROR,
                            error.errorCode.toInt(),
                            error.errorDescription,
                            clientPaymentOutput.asMap()
                        )
                    } ?: internalCallback.onFailure(
                        Constants.ERROR,
                        Error.PROTOCOL_ERROR.errorCode,
                        Error.PROTOCOL_ERROR.errorDescription,
                        clientPaymentOutput.asMap()
                    )
                }
                transaction?.close()
            }

            override fun runtimeError(runtimeErrorEvent: RuntimeErrorEvent?) {
                debugInfo?.append("handle3d2Challenge.doChallenge.runtimeError($runtimeErrorEvent), ")
                runtimeErrorEvent?.let {
                    internalCallback.onFailure(
                        Constants.ERROR,
                        it.errorCode.toInt(),
                        it.errorMessage,
                        clientPaymentOutput.asMap()
                    )
                }?: internalCallback.onFailure(
                    Constants.ERROR,
                    Error.INTERNAL_ERROR.errorCode,
                    Error.INTERNAL_ERROR.errorDescription,
                    clientPaymentOutput.asMap()
                )
                transaction?.close()
            }

            override fun completed(completionEvent: CompletionEvent?) {
                debugInfo?.append("handle3d2Challenge.doChallenge.completed(isCreatePayment = ${isCreatePayment}), ")
                if (isCreatePayment) {
                    val completePaymentInput = ClientPaymentInputToCompletePaymentInputMapper()
                        .map(clientPaymentInput)
                    completePaymentInput.add(NetworkConstants.relatedTransactionId, relatedTransactionId)
                    clientAuthorize3dOrClientPayment(completePaymentInput) { completePaymentOutput, error, rawResult ->
                        completePaymentOutput?.let {
                            debugInfo?.append("handle3d2Challenge.doChallenge.completed.clientAuthorize3dOrClientPayment.success, ")
                            returnClientPaymentToCallback(it)
                        } ?: run {
                            debugInfo?.append("handle3d2Challenge.doChallenge.completed.clientAuthorize3dOrClientPayment.failure, ")
                            callback?.onComplete(NVOutput.create(
                                isCreatePayment = isCreatePayment,
                                result = Constants.ERROR,
                                errorCode = Error.INTERNAL_ERROR.errorCode,
                                errorDescription = Error.INTERNAL_ERROR.errorDescription,
                                rawResult = rawResult
                            ))
                        }
                        transaction?.close()
                    }
                } else {
                    val verify3dBody = InitPaymentInputToVerify3dInputMapper().map(initPaymentInput)
                    verify3dBody.add(NetworkConstants.relatedTransactionId, relatedTransactionId)
                    verify3d(verify3dBody, object : InternalCallback<JsonObject> {
                        override fun onSuccess(response: JsonObject) {
                            debugInfo?.append("handle3d2Challenge.doChallenge.completed.verify3d.onSuccess, ")
                            returnClientPaymentToCallback(response)
                            transaction?.close()
                        }

                        override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                            debugInfo?.append("handle3d2Challenge.doChallenge.completed.verify3d.onFailure, ")
                            internalCallback.onFailure(
                                Constants.ERROR,
                                Error.INTERNAL_ERROR.errorCode,
                                Error.INTERNAL_ERROR.errorDescription,
                                clientPaymentOutput.asMap()
                            )
                            transaction?.close()
                        }
                    })
                }
            }

            override fun timedout() {
                debugInfo?.append("handle3d2Challenge.doChallenge.timedout, ")
                internalCallback.onFailure(
                    Constants.ERROR,
                    Error.TIMED_OUT.errorCode,
                    Error.TIMED_OUT.errorDescription,
                    null
                )
                transaction?.close()
            }

        }, clientPaymentInput[NetworkConstants.timeout].asInt)
    }

    private fun verify3d(
        body: JsonObject,
        internalCallback: InternalCallback<JsonObject>
    ) {
        debugInfo?.append("verify3d, ")
        ApiClient.service?.verify3d(body)?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("verify3d.onResponse, ")
                response.body()?.let {
                    internalCallback.onSuccess(it)
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("verify3d.onFailure, ")
                internalCallback.onFailure(
                    Constants.ERROR,
                    Error.INTERNAL_ERROR.errorCode,
                    Error.INTERNAL_ERROR.errorDescription + ", " + t.localizedMessage,
                    null
                )
            }
        })
    }

    private fun handleFrictionless(body: JsonObject, output: JsonObject, threeD: JsonObject, internalCallback: InternalCallback<JsonObject>) {
        debugInfo?.append("handleFrictionless, ")
        internalCallback.onSuccess(output)
    }

    private fun forceWebChallengePaymentFrame(
        acsUrl: String,
        creq: String,
        sessionToken: String,
        callback: InternalCallback<JsonObject>
    ) {
        debugInfo?.append("forceWebChallengePaymentFrame, ")
        webviewInternalCallback = callback

        /** WebView **/
        activity?.let { ctx ->
            val termUrl = ApiClient.notificationURL(sessionToken, isCreatePayment)
            WebViewActivity.create3d2ForceWebIntent(ctx, acsUrl, creq, termUrl, "#40c1ac",
                isCreatePayment
            )?.let { intent ->
                ctx.startActivity(intent)
            }
        }
    }

    fun deleteUPO(
        input: UPODeleteInput,
        callback: (Boolean) -> Unit
    ) {
        debugInfo?.append("deleteUPO, ")
        val request = ApiClient.service?.deleteSavedUPO(Gson().toJsonTree(input).asJsonObject)
        request?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("deleteUPO.onResponse, ")
                response.body()?.let { result ->
                    try {
                        val status = result[NetworkConstants.status].asString
                        if (status == Constants.ERROR) {
                            callback(false)
                        } else {
                            callback(true)
                        }
                    } catch (ex: Throwable) {
                        callback(true)
                    }
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                debugInfo?.append("deleteUPO.onFailure, ")
                callback(false)
            }
        })
    }

    fun onWebViewResult(result: String) {
        debugInfo?.append("onWebViewResult, ")
        webviewInternalCallback?.onSuccess(JsonParser().parse(result).asJsonObject)
    }

    fun onUserCanceled() {
        debugInfo?.append("onUserCanceled, ")
        callback?.onComplete(NVOutput.create(
            isCreatePayment = isCreatePayment,
            result = Constants.CANCELLED,
            errorCode = Error.USER_CANCELLED.errorCode,
            errorDescription = Error.USER_CANCELLED.errorDescription
        ))
    }

    fun internalTokenize(
        activity: Activity,
        input: NVPayment,
        source: String,
        callback: TokenizeCallback
    ) {
        ApiClient.setSourceApplication(source)

        Nuvei.resetDebugInfo()

        tokenize(
            activity,
            input
        ) { ccTempToken, error, additionalInfo ->
            callback.onComplete(ccTempToken, error, additionalInfo)
        }
    }

    fun tokenize(
        activity: Activity,
        input: NVPayment,
        ignoreFailure: Boolean = false,
        callback: (token: String?, error: Error?, additionalInfo: Map<String, Any>?) -> Unit
    ) {

        debugInfo?.append("tokenize, ")
        if (environment == null) {
            callback(null, Error.NOT_SET_UP, null)
            return
        }

        if (isProcessing) {
            callback(null, Error.IS_PROCESSING, null)
            return
        }

        val initPaymentInput = Authenticate3dToInitPaymentMapper().map(input)
        isProcessing = true
        Log.d(TAG, "authenticate3d: cardTokenizationInput = $initPaymentInput")
        cardTokenization(activity, initPaymentInput, ignoreFailure, object : InternalCallback<JsonObject> {
            override fun onSuccess(response: JsonObject) {
                debugInfo?.append("tokenize.cardTokenization.onSuccess, ")
                isProcessing = false
                ccTempToken = response.get(NetworkConstants.ccTempToken).asString

                callback(ccTempToken, null, mapOf("tokenizeResponse" to response))
            }

            override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                debugInfo?.append("tokenize.cardTokenization.onFailure, ")
                isProcessing = false
                callback(null, Error.INTERNAL_ERROR, mapOf(
                    "result" to result,
                    "errorCode" to (errorCode ?: 0),
                    "errorDescription" to (errorDescription ?: ""),
                    "rawResult" to (rawResult ?: emptyMap())
                ))
            }
        })
    }

    private fun cardTokenization(
        activity: Activity,
        body: JsonObject,
        ignoreFailure: Boolean,
        internalCallback: InternalCallback<JsonObject>,
    ) {
        debugInfo?.append("cardTokenization, ")
        Nuvei.activity = activity
        ApiClient.service?.cardTokenization(body)
            ?.enqueue(object : retrofit2.Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    debugInfo?.append("cardTokenization.onResponse, ")
                    response.body()?.let { res ->
                        Log.d(TAG, "cardTokenization.onResponse: $res")
                        val status = /*res[NetworkConstants.transactionStatus]?.asString
                                    ?: */res[NetworkConstants.status]?.asString
                            ?: Constants.ERROR

                        val v2supported = tryOrNull {
                            ((res[NetworkConstants.paymentOption] as? JsonObject)
                                ?.get(NetworkConstants.card) as? JsonObject)
                                ?.get(NetworkConstants.threeD)?.asJsonObject?.get(NetworkConstants.v2supported)?.asBoolean
                        } == true

                        val isFinalError = v2supported && res[NetworkConstants.transactionId] == null
                        if (!isFinalError && (ignoreFailure || status != Constants.ERROR)) {
                            internalCallback.onSuccess(res)
                        } else {
                            val errorCode = res[NetworkConstants.gwExtendedErrorCode]?.asInt
                                ?: res[NetworkConstants.gwErrorCode]?.asInt
                                ?: res[NetworkConstants.paymentMethodErrorCode]?.asInt
                                ?: res[NetworkConstants.errCode]?.asInt

                            val errorDescription = res[NetworkConstants.gwErrorReason]?.asString
                                ?: res[NetworkConstants.paymentMethodErrorReason]?.asString
                                ?: res[NetworkConstants.reason]?.asString

                            internalCallback.onFailure(
                                Constants.ERROR,
                                errorCode,
                                errorDescription,
                                response.body()?.asMap()
                            )
                        }
                    } ?: run {
                        debugInfo?.append("cardTokenization.onResponse(body = null), ")
                        Log.d(TAG, "cardTokenization.onResponse: null")
                        internalCallback.onFailure(
                            Constants.ERROR,
                            Error.INTERNAL_ERROR.errorCode,
                            Error.INTERNAL_ERROR.errorDescription,
                            response.body()?.asMap()
                        )
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    debugInfo?.append("cardTokenization.onFailure, ")
                    Log.d(TAG, "cardTokenization.onFailure: $t")
                    internalCallback.onFailure(
                        Constants.ERROR,
                        Error.INTERNAL_ERROR.errorCode,
                        Error.INTERNAL_ERROR.errorDescription,
                        null
                    )
                }
            })
    }

    fun getCardDetails(
        input: NVCardDetailsInput,
        internalCallback: InternalCallback<NVCardDetailsOutput>? = null
    ) {
        debugInfo?.append("getCardDetails, ")
        val request = ApiClient.service?.getCardDetails(Gson().toJsonTree(input).asJsonObject)
        request?.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                debugInfo?.append("getCardDetails.onResponse, ")
                response.body()?.let { res ->
                    Log.d(TAG, "getCardDetails.onResponse: $res")
                    val status = res[NetworkConstants.status]?.asString ?: Constants.ERROR

                    val v2supported = tryOrNull {
                        ((res[NetworkConstants.paymentOption] as? JsonObject)
                            ?.get(NetworkConstants.card) as? JsonObject)
                            ?.get(NetworkConstants.threeD)?.asJsonObject?.get(NetworkConstants.v2supported)?.asBoolean
                    } == true

                    val isFinalError = v2supported && res[NetworkConstants.transactionId] == null
                    if (!isFinalError || status != Constants.ERROR) {
                        internalCallback?.onSuccess(Gson().fromJson(res, NVCardDetailsOutput::class.java))
                    } else {
                        val errorCode = res[NetworkConstants.gwExtendedErrorCode]?.asInt
                            ?: res[NetworkConstants.gwErrorCode]?.asInt
                            ?: res[NetworkConstants.paymentMethodErrorCode]?.asInt
                            ?: res[NetworkConstants.errCode]?.asInt

                        val errorDescription = res[NetworkConstants.gwErrorReason]?.asString
                            ?: res[NetworkConstants.paymentMethodErrorReason]?.asString
                            ?: res[NetworkConstants.reason]?.asString

                        internalCallback?.onFailure(
                            Constants.ERROR,
                            errorCode,
                            errorDescription,
                            response.body()?.asMap()
                        )
                    }
                } ?: run {
                    debugInfo?.append("getCardDetails.onResponse(body = null), ")
                    Log.d(TAG, "getCardDetails.onResponse: null")
                    internalCallback?.onFailure(
                        Constants.ERROR,
                        Error.INTERNAL_ERROR.errorCode,
                        Error.INTERNAL_ERROR.errorDescription,
                        response.body()?.asMap()
                    )
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                internalCallback?.onFailure(
                    Constants.ERROR,
                    Error.INTERNAL_ERROR.errorCode,
                    Error.INTERNAL_ERROR.errorDescription,
                    null
                )
            }
        })
    }


    private fun getLocale(context: Context? = null): String {
        val locale = context?.resources?.configuration?.let { configuration ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                configuration.locales.get(0)
            } else {
                configuration.locale
            }
        } ?: Locale.getDefault()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            locale.toLanguageTag()
        } else {
            locale.toString().replace("_", "-")
        }.takeIf { it.length == 5 && it.contains("-") } ?: "en-US"
    }

    private fun JsonObject.asCustomMap() = Gson().fromJson<HashMap<String, Any>>(this, HashMap::class.java)



    fun <T> tryOrNull(block: () -> T): T? {
        return try {
            block()
        } catch (t: Throwable) {
            null
        }
    }
}
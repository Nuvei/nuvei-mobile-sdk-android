package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class UPOsOutput(
    @SerializedName("paymentMethods") val methods: List<PaymentMethod>,
    @SerializedName("status") val status: String?,
    @SerializedName("errCode") val error: Int?,
    @SerializedName("reason") val reason: String?,
) {
    class PaymentMethod(
        @SerializedName("userPaymentOptionId") val userPaymentOptionId: String,
        @SerializedName("paymentMethodName") val methodType: String,
        @SerializedName("upoStatus") val status: String,
        @SerializedName("upoName") val title: String,

        @SerializedName("upoData") val upoData: UpoData,

        ) : Serializable {
        class UpoData(
            @SerializedName("ccCardNumber") val ccNumber: String,
            @SerializedName("ccExpMonth") val ccExpiryMonth: String,
            @SerializedName("ccExpYear") val ccExpiryYear: String,
            @SerializedName("ccNameOnCard") val ccHolderName: String,
            @SerializedName("brand") val brand: String?,
            @SerializedName("email") val email: String?,
        ) : Serializable
    }
}

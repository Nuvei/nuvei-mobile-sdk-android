package com.nuvei.mobilesdk.core.threeds2sdk.parameters;

import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

public class AuthenticationRequestParameters {
    private final String sdkEphemeralPublicKey;
    private final String deviceData;
    private final String sdkTransactionId;
    private final String sdkAppId;
    private final String sdkReferenceNumber;
    private final String messageVersion;

    public AuthenticationRequestParameters(
            String sdkTransactionID,
            String deviceData,
            String sdkEphemeralPublicKey,
            String sdkAppID,
            String sdkReferenceNumber,
            String messageVersion)
            throws InvalidInputException
    {
        if (sdkTransactionID == null) {
            throw new InvalidInputException("sdkTransactionID cannot be null");
        }
        if (deviceData == null) {
            throw new InvalidInputException("deviceData cannot be null");
        }
        if (sdkEphemeralPublicKey == null) {
            throw new InvalidInputException("sdkEphemeralPublicKey cannot be null");
        }
        if (sdkAppID == null) {
            throw new InvalidInputException("sdkAppID cannot be null");
        }
        if (sdkReferenceNumber == null) {
            throw new InvalidInputException("sdkReferenceNumber cannot be null");
        }
        if (messageVersion == null) {
            throw new InvalidInputException("messageVersion cannot be null");
        }
        this.deviceData = deviceData;
        this.sdkTransactionId = sdkTransactionID;
        this.sdkAppId = sdkAppID;
        this.sdkReferenceNumber = sdkReferenceNumber;
        this.sdkEphemeralPublicKey = sdkEphemeralPublicKey;
        this.messageVersion = messageVersion;
    }

    public String getDeviceData() {
        return deviceData;
    }

    public String getSDKTransactionID() {
        return sdkTransactionId;
    }

    public String getSDKAppID() {
        return sdkAppId;
    }

    public String getSDKReferenceNumber() {
        return sdkReferenceNumber;
    }

    public String getSDKEphemeralPublicKey() {
        return sdkEphemeralPublicKey;
    }

    public String getMessageVersion() {
        return messageVersion;
    }

}

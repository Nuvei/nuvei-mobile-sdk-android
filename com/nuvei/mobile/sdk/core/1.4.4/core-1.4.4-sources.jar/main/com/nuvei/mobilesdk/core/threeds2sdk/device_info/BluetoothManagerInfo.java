package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import com.nuvei.mobilesdk.core.threeds2sdk.device_info.BaseDeviceInfo;

class BluetoothManagerInfo extends BaseDeviceInfo {
    //BluetoothManager
    //Bluetooth Manager is used to conduct overall Bluetooth Management.
    //Through Bluetooth Adapter, it facilitates in performing fundamental Bluetooth tasks, such as initiate device discovery, query a list
    //of bonded (paired) devices, instantiate a BluetoothDevice using a known MAC address, and create a BluetoothServerSocket to listen
    //for connection requests from other devices, and start a scan for Bluetooth LE devices.
    private static final String DI_DD_Android_Address = "A039"; //Hardware address of the local Bluetooth adapter.
    private static final String DI_DD_Android_BondedDevices = "A040"; //Returns the set of BluetoothDevice objects that are bonded (paired) to the local adapter.
    private static final String DI_DD_Android_isEnabled = "A041"; //Determines if this adapter supports Tunnel Directed Link Setup.

    BluetoothManagerInfo(Context context) {
        collectBluetoothManagerInfo(context);
    }

    @SuppressLint("HardwareIds")
    private void collectBluetoothManagerInfo(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADMIN) == PERMISSION_GRANTED) {
            BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
            if (ba != null) {
                putData(DI_DD_Android_Address, ba.getAddress());
                Set<BluetoothDevice> bondedDevicesSet = ba.getBondedDevices();
                ArrayList<String> bondedDevices = new ArrayList<>();

                if (bondedDevicesSet != null) {
                    for (BluetoothDevice bluetoothDevice : bondedDevicesSet) {
                        if (bluetoothDevice.getUuids().length > 0) {
                            bondedDevices.add(bluetoothDevice.getUuids()[0].getUuid().toString());
                        }
                    }
                }

                putData(DI_DD_Android_BondedDevices, bondedDevices);
                putData(DI_DD_Android_isEnabled, String.valueOf(ba.isEnabled()));
            } else {
                dpna.put(DI_DD_Android_Address, DI_DPNA_RE_NullValue);
                dpna.put(DI_DD_Android_BondedDevices, DI_DPNA_RE_NullValue);
                dpna.put(DI_DD_Android_isEnabled, DI_DPNA_RE_NullValue);
            }
        } else {
            dpna.put(DI_DD_Android_Address, DI_DPNA_RE_NullValue);
            dpna.put(DI_DD_Android_BondedDevices, DI_DPNA_RE_NullValue);
            dpna.put(DI_DD_Android_isEnabled, DI_DPNA_RE_NullValue);
        }
    }

    private Map<String, Object> bluetoothDeviceToMap(BluetoothDevice paramBluetoothDevice) {
        Map<String, Object> map = new HashMap<>();
        map.put("name", paramBluetoothDevice.getName());
        map.put("address", paramBluetoothDevice.getAddress());
        map.put("type", paramBluetoothDevice.getType());
        map.put("bondState", paramBluetoothDevice.getBondState());
        return map;
    }
}

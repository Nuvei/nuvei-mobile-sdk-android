package com.nuvei.mobilesdk.core.threeds2sdk.exceptions;

/**
 * This exception shall be thrown if the 3DS SDK instance has not been initialized.
 */
public class SDKNotInitializedException extends RuntimeException {
    public SDKNotInitializedException(String message) {
        super(message);
    }
    public SDKNotInitializedException(String message, Throwable cause) {
        super(message, cause);
    }
}

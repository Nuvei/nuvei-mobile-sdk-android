package com.nuvei.mobilesdk.core.mapper

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.Constants
import com.nuvei.mobilesdk.core.model.NVAuthenticate3dOutput
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.network.NetworkConstants

class ClientPaymentResultToGenericOutput(
        private val additions: Map<String, String?>,
        private val isCreatePayment: Boolean
) : Mapper<JsonObject, NVOutput> {
    override fun map(source: JsonObject): NVOutput {

        val sourceWithAdditions = source.deepCopy().also { source ->
            for (entry in additions.entries) {
                entry.value?.let { value -> source.addProperty(entry.key, value) }
            }
        }

        val paymentOption = sourceWithAdditions[NetworkConstants.paymentOption]?.asJsonObject
        val card = tryOptional { paymentOption?.get(NetworkConstants.card)?.asJsonObject }
        val threeD = tryOptional { card?.get(NetworkConstants.threeD)?.asJsonObject }

        val rawResult = Gson().fromJson<HashMap<String, Any>>(source, HashMap::class.java)

        val status = tryOptional {
            sourceWithAdditions[NetworkConstants.transactionStatus]?.asString
        } ?: Constants.ERROR

        val errorCode = tryOptional {
            sourceWithAdditions[NetworkConstants.gwExtendedErrorCode]?.asInt
                    ?: sourceWithAdditions[NetworkConstants.gwErrorCode]?.asInt
                    ?: sourceWithAdditions[NetworkConstants.paymentMethodErrorCode]?.asInt
                    ?: sourceWithAdditions[NetworkConstants.errCode]?.asInt
        }

        val errorDescription = tryOptional {
            sourceWithAdditions[NetworkConstants.gwErrorReason]?.asString
                    ?: sourceWithAdditions[NetworkConstants.paymentMethodErrorReason]?.asString
                    ?: sourceWithAdditions[NetworkConstants.reason]?.asString
        }

//        return Authenticate3dOutput(threeD?.get(NetworkConstants.cavv)?.asString,
//                threeD?.get(NetworkConstants.eci)?.asString,
//                threeD?.get(NetworkConstants.xid)?.asString,
//                threeD?.get(NetworkConstants.dsTransID)?.asString,
//                rawResult,
//                status,
//                errorCode,
//                errorDescription
//        )

        if (isCreatePayment) {
            return NVCreatePaymentOutput(
                    status,
                    tryOptional { paymentOption?.get(NetworkConstants.userPaymentOptionId)?.asString },
                    tryOptional { card?.get(NetworkConstants.ccCardNumber)?.asString },
                    tryOptional { card?.get(NetworkConstants.bin)?.asString },
                    tryOptional { card?.get(NetworkConstants.last4Digits)?.asString },
                    tryOptional { card?.get(NetworkConstants.ccExpMonth)?.asString },
                    tryOptional { card?.get(NetworkConstants.ccExpYear)?.asString },
                    tryOptional { sourceWithAdditions[NetworkConstants.transactionId]?.asString },
                    tryOptional { threeD?.get(NetworkConstants.threeDReasonId)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.threeDReason)?.asString },// Doesn't exist
                    tryOptional { threeD?.get(NetworkConstants.challengePreferenceReason)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.isLiabilityOnIssuer)?.asBoolean },// Doesn't exist
                    tryOptional { sourceWithAdditions[NetworkConstants.cancelled]?.asBoolean } ?: false,// Doesn't exist
                    tryOptional { threeD?.get(NetworkConstants.challengeCancelReasonId)?.asString },// Doesn't exist
                    tryOptional { threeD?.get(NetworkConstants.challengeCancelReason)?.asString },// Doesn't exist
                    errorCode,
                    errorDescription,
                    rawResult,
                    status,
                    tryOptional { paymentOption?.get(NetworkConstants.isDirect)?.asBoolean },
                    tryOptional { paymentOption?.get(NetworkConstants.redirectUrl)?.asString },
                    tryOptional { sourceWithAdditions?.get(NetworkConstants.transactionStatus)?.asString },
                    tryOptional { sourceWithAdditions?.get(NetworkConstants.gwErrorCode)?.asInt },
                    tryOptional { sourceWithAdditions?.get(NetworkConstants.gwErrorReason)?.asString }
            )
        } else {
            return NVAuthenticate3dOutput(
                    status,
                    tryOptional { paymentOption?.get(NetworkConstants.userPaymentOptionId)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.cavv)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.eci)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.xid)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.dsTransID)?.asString },
                    tryOptional { card?.get(NetworkConstants.ccCardNumber)?.asString },
                    tryOptional { card?.get(NetworkConstants.bin)?.asString },
                    tryOptional { card?.get(NetworkConstants.last4Digits)?.asString },
                    tryOptional { card?.get(NetworkConstants.ccExpMonth)?.asString },
                    tryOptional { card?.get(NetworkConstants.ccExpYear)?.asString },
                    tryOptional { sourceWithAdditions[NetworkConstants.ccTempToken]?.asString },
                    tryOptional { sourceWithAdditions[NetworkConstants.transactionId]?.asString },
                    tryOptional { threeD?.get(NetworkConstants.threeDReasonId)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.threeDReason)?.asString },// Doesn't exist
                    tryOptional { threeD?.get(NetworkConstants.challengePreferenceReason)?.asString },
                    tryOptional { threeD?.get(NetworkConstants.isLiabilityOnIssuer)?.asBoolean },// Doesn't exist
                    tryOptional { sourceWithAdditions[NetworkConstants.cancelled]?.asBoolean } ?: false,// Doesn't exist
                    tryOptional { threeD?.get(NetworkConstants.challengeCancelReasonId)?.asString },// Doesn't exist
                    tryOptional { threeD?.get(NetworkConstants.challengeCancelReason)?.asString },// Doesn't exist
                    errorCode,
                    errorDescription,
                    rawResult
            )
        }
    }
}
package com.nuvei.mobilesdk.core

import com.nuvei.mobilesdk.core.model.NVCardDetailsInput

interface NuveiCardField {
    fun getCardDetailsInput(): NVCardDetailsInput?
}

package com.nuvei.mobilesdk.core.threeds2sdk.crypto;

import android.util.Log;

import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.keys.RsaKeyUtil;
import org.jose4j.lang.JoseException;

import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;

public class RSACrypto {

    private static final String TAG = "[3DSSDK][RSACrypto]";

    public KeyPair generateKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        return kpg.genKeyPair();
    }

    JsonWebKey jwk(Key key) throws JoseException {
        return JsonWebKey.Factory.newJwk(key);
    }

    public PublicKey publicKey(String remotePublicKeyAsPem) throws JoseException, InvalidKeySpecException {
        if (!remotePublicKeyAsPem.startsWith("-----BEGIN PUBLIC KEY-----")) {
            remotePublicKeyAsPem = "-----BEGIN PUBLIC KEY----- " + remotePublicKeyAsPem;
        }
        if (!remotePublicKeyAsPem.endsWith("-----END PUBLIC KEY-----")) {
            remotePublicKeyAsPem = remotePublicKeyAsPem + " -----END PUBLIC KEY-----";
        }
        return new RsaKeyUtil().fromPemEncoded(remotePublicKeyAsPem);
    }

    String encrypt(String plain, String remotePublicKeyAsPem) throws JoseException, InvalidKeySpecException {
        PublicKey publicKey = publicKey(remotePublicKeyAsPem);
        JsonWebKey jwk = jwk(publicKey);
        return encrypt(plain, jwk);
    }

    public String encrypt(String plain, PublicKey remotePublicKey) throws JoseException {
        JsonWebKey jwk = jwk(remotePublicKey);
        return encrypt(plain, jwk);
    }

    String encrypt(String plain, JsonWebKey jwk) throws JoseException {

        // Create a new Json Web Encryption object
        JsonWebEncryption senderJwe = new JsonWebEncryption();

        // The plaintext of the JWE is the message that we want to encrypt.
        senderJwe.setPlaintext(plain);

        // Set the "alg" header, which indicates the key management mode for this JWE.
        senderJwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.RSA_OAEP_256);

        // Set the "enc" header, which indicates the content encryption algorithm to be used.
        // This example is using AES_128_CBC_HMAC_SHA_256 which is a composition of AES CBC
        // and HMAC SHA2 that provides authenticated encryption.
        senderJwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);

        // Set the key on the JWE. In this case, using direct mode, the key will used directly as
        // the content encryption key. AES_128_CBC_HMAC_SHA_256, which is being used to encrypt the
        // content requires a 256 bit key.
        senderJwe.setKey(jwk.getKey());

        // Produce the JWE compact serialization, which is where the actual encryption is done.
        // The JWE compact serialization consists of five base64url encoded parts
        // combined with a dot ('.') character in the general format of
        // <header>.<encrypted key>.<initialization vector>.<ciphertext>.<authentication tag>
        // Direct encryption doesn't use an encrypted key so that field will be an empty string
        // in this case.
        String compactSerialization = senderJwe.getCompactSerialization();

        // Do something with the JWE. Like send it to some other party over the clouds
        // and through the interwebs.
        Log.d(TAG, "encrypt: JWE compact serialization = " + compactSerialization);

        return compactSerialization;
    }

    public String decrypt(String encrypted, PrivateKey privateKey) throws JoseException {
        JsonWebKey jwk = jwk(privateKey);
        return decrypt(encrypted, jwk);
    }

    String decrypt(String encrypted, JsonWebKey jwk) throws JoseException {
        // That other party, the receiver, can then use JsonWebEncryption to decrypt the message.
        JsonWebEncryption receiverJwe = new JsonWebEncryption();

        // Set the algorithm constraints based on what is agreed upon or expected from the sender
        AlgorithmConstraints algConstraints = new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST, KeyManagementAlgorithmIdentifiers.RSA_OAEP_256);
        receiverJwe.setAlgorithmConstraints(algConstraints);
        AlgorithmConstraints encConstraints = new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST, ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
        receiverJwe.setContentEncryptionAlgorithmConstraints(encConstraints);

        // Set the compact serialization on new Json Web Encryption object
        receiverJwe.setCompactSerialization(encrypted);

        // Symmetric encryption, like we are doing here, requires that both parties have the same key.
        // The key will have had to have been securely exchanged out-of-band somehow.
        receiverJwe.setKey(jwk.getKey());

        // Get the message that was encrypted in the JWE. This step performs the actual decryption steps.
        String plaintext = receiverJwe.getPlaintextString();

        // And do whatever you need to do with the clear text message.
        Log.d(TAG, "decrypt: plaintext = " + plaintext);

        return plaintext;
    }

    public String decrypt(String encrypted, Key key) throws JoseException, InvalidInputException {
        Log.d(TAG, "decrypt(" + encrypted + ")");

        // Create a new JsonWebSignature object
        JsonWebSignature jws = new JsonWebSignature();

        // Set the algorithm constraints based on what is agreed upon or expected from the sender
        AlgorithmConstraints algConstraints = new AlgorithmConstraints(
                AlgorithmConstraints.ConstraintType.WHITELIST,
                AlgorithmIdentifiers.RSA_PSS_USING_SHA256,
                AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
        jws.setAlgorithmConstraints(algConstraints);

        // Set the compact serialization on the JWS
        jws.setCompactSerialization(encrypted);

        // The verification key on the JWS is the public key from the JWK we pulled from the JWK Set.
        jws.setKey(key);

        // Check the signature
        if (!jws.verifySignature()) {
            Log.d(TAG, "decrypt: " +
                    "throw new InvalidInputException(\"Wrong ACS data encryption - invalid JWS\")");
            throw new InvalidInputException("Wrong ACS data encryption - invalid JWS");
        }

        // Do something useful with the result of signature verification
        Log.d(TAG, "decrypt: JWS Signature is valid");

        // Get the payload, or signed content, from the JWS
        String payload = jws.getPayload();
        Log.d(TAG, "decrypt: payload = " + payload);

        return payload;
    }

//    public static List<String> parsePublicKeyFromPem() throws NoSuchAlgorithmException, InvalidKeySpecException, JoseException {
//        String pem = //"-----BEGIN RSA PUBLIC KEY----- " +
//                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAr/O0BfXWngO9OJDBsqdR5U2h28jrX6Y+Llbl" +
//                "TBaYeT2tW7+ca3YzTFXA8duVUwdlWxl3JZCOOeL1feVP6g0TNOHVCkCnirVDLkcozod4aSkNvx+929aD" +
//                "r1ithqhruf0skBc2sMZGBBCNpso6XGzyAf2uZ2+9DvXoKIUYgcr7PQmL2Y0awyQN7KCRcusaotYNz2mO" +
//                "PrL/hAv6hTexkNrQKzFcPwCuc6kN6aNjD+p2CJ51/5p02SNS70nPOmwmg63j6f3n7xVykQ56kNc1l5B5" +
//                "xOpeHJmqk3+hyF1dF/47rQmMFicN41QSvZ5AZJKgWlIn2VQROMkEHkF9ZBRLx1nFTwIDAQAB";
//                // + " -----END RSA PUBLIC KEY-----";
//        String pem2 = "-----BEGIN PUBLIC KEY----- " +
//                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAr/O0BfXWngO9OJDBsqdR5U2h28jrX6Y+Llbl" +
//                "TBaYeT2tW7+ca3YzTFXA8duVUwdlWxl3JZCOOeL1feVP6g0TNOHVCkCnirVDLkcozod4aSkNvx+929aD" +
//                "r1ithqhruf0skBc2sMZGBBCNpso6XGzyAf2uZ2+9DvXoKIUYgcr7PQmL2Y0awyQN7KCRcusaotYNz2mO" +
//                "PrL/hAv6hTexkNrQKzFcPwCuc6kN6aNjD+p2CJ51/5p02SNS70nPOmwmg63j6f3n7xVykQ56kNc1l5B5" +
//                "xOpeHJmqk3+hyF1dF/47rQmMFicN41QSvZ5AZJKgWlIn2VQROMkEHkF9ZBRLx1nFTwIDAQAB"
//                + " -----END PUBLIC KEY-----";
//
//        // Parse PEM-encoded key to RSA public / private JWK
//        X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(Base64.decode(pem, Base64.DEFAULT));
//        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//        PublicKey publicKey = keyFactory.generatePublic(pubKeySpec);
//        String key1 = publicKey.toString();
//
//        RsaKeyUtil keyUtil = new RsaKeyUtil();
//        PublicKey publicKey2 = keyUtil.fromPemEncoded(pem2);
//        String key2 = publicKey2.toString();
//
//        ArrayList<String> result = new ArrayList<>();
//        result.add(key1);
//        result.add(key2);
//        return result;
//    }
}

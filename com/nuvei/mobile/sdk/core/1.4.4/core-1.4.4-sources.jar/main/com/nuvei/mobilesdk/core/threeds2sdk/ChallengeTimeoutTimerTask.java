package com.nuvei.mobilesdk.core.threeds2sdk;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeActivity;
import com.nuvei.mobilesdk.core.threeds2sdk.ErrorMessage;
import com.nuvei.mobilesdk.core.threeds2sdk.Transaction;

import java.lang.ref.WeakReference;
import java.util.TimerTask;

class ChallengeTimeoutTimerTask extends TimerTask {

    private final static String TAG = "[3DSSDK][TimeoutTask]";

    private WeakReference<Transaction> weakTransaction = new WeakReference(null);
    private API api = null;

    ChallengeTimeoutTimerTask(Transaction transaction) {
        weakTransaction = new WeakReference(transaction);
    }

    @Override
    public void run() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                handleTimeout();
            }
        });
    }

    private void handleTimeout() {
        Transaction transaction = weakTransaction.get();
        if (transaction == null) {
            Log.d(TAG, "sendTimeoutError: transaction is null");
            return;
        }

        ErrorMessage error = generateErrorMessage(transaction);
        sendTimeoutError(error, transaction);
        protocolError(error, transaction);
        closeActivity();
    }

    private ErrorMessage generateErrorMessage(Transaction transaction) {
        ErrorMessage error = transaction.generateErrorMessage();
        error.setErrorCode("402");
        error.setErrorDescription("Transaction timed-out.");
        error.setErrorDetail("Timeout expiry reached for the transaction.");
        return error;
    }

    private void sendTimeoutError(ErrorMessage error, Transaction transaction) {
        if (api == null) {
            api = new API();
        }

        api.post(transaction.acsURL, error, new API.ErrorCallback() {
            @Override
            public void onResponse(ErrorMessage responseError) {
                Log.d(TAG, "sendTimeoutError.onResponse: responseError = " + responseError);
            }

            @Override
            public void onFailure(Exception e) {
                Log.d(TAG, "sendTimeoutError.onFailure: exception = " + e);
            }
        });
    }

    private void protocolError(ErrorMessage error, Transaction transaction) {
        transaction.protocolError(error);
    }

    private void closeActivity() {
        ChallengeActivity activity = ChallengeActivity.instance.get();
        if (activity != null && !activity.isFinishing()) {
            activity.finish();
        }
    }
}

package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ShippingAddress(
    @SerializedName("addressMatch") val addressMatch: String? = null,
    @SerializedName("city") val city: String? = null,
    @SerializedName("country") val country: String? = null,
    @SerializedName("address") val address: String? = null,
    @SerializedName("zip") val zip: String? = null,
    @SerializedName("state") val state: String? = null,
    @SerializedName("email") val email: String? = null,
    @SerializedName("phone") val phone: String? = null,
    @SerializedName("cell") val cell: String? = null,
    @SerializedName("firstName") val firstName: String? = null,
    @SerializedName("lastName") val lastName: String? = null,
    @SerializedName("shippingCounty") val shippingCounty: String? = null,
    @SerializedName("shipAddressLine2") val shipAddressLine2: String? = null,
    @SerializedName("shipAddressLine3") val shipAddressLine3: String? = null
): Serializable
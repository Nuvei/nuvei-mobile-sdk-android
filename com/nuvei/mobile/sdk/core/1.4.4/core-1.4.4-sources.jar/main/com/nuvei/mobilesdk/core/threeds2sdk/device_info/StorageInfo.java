package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.util.DisplayMetrics;

import com.nuvei.mobilesdk.core.threeds2sdk.device_info.BaseDeviceInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class StorageInfo extends BaseDeviceInfo {

    private static final String ROOT_PACKAGE_NAME = "com.sonerim.a3dsecure";

    //PackageManager
    //Package Manager is used to retrieve various kinds of information related to the application packages that are currently installed on the device.
    private static final String DI_DD_Android_isSafeMode = "A124"; //Returns whether the device has been booted into safe mode.
    private static final String DI_DD_Android_getInstalledApplications = "A125"; //Returns a list of application packages that are installed on the device.
    private static final String DI_DD_Android_getInstallerPackageName = "A126"; //Retrieves the package name of the application that installed a package.
    private static final String DI_DD_Android_getSystemAvailableFeatures = "A127"; //Retrieves a list of features that are available on the device.
    private static final String DI_DD_Android_getSystemSharedLibraryNames = "A128"; //Retrieves a list of shared libraries that are available on the device.

    //Environment
    //Environment provides access to environment variables.
    private static final String DI_DD_Android_getExternalStorageState = "A129"; //Returns the current state of the primary shared/external storage media.

    //Locale
    //Represents a specific geographical, political, or cultural region.
    private static final String DI_DD_Android_getAvailableLocales = "A130"; //Returns the system's installed locales.

    //DisplayMetrics
    //DisplayMetrics describes general information about a display, such as its size, density, and font scaling.
    private static final String DI_DD_Android_density = "A131"; //The logical density of the display.
    private static final String DI_DD_Android_densityDpi = "A132"; //The screen density expressed as dots-per-inch.
    private static final String DI_DD_Android_scaledDensity = "A133"; //A scaling factor for fonts displayed on the display.
    private static final String DI_DD_Android_xdpi = "A134"; //The exact physical pixels per inch of the screen in the X dimension.
    private static final String DI_DD_Android_ydpi = "A135"; //The exact physical pixels per inch of the screen in the Y dimension.

    //StatFs
    //StatFs retrieves overall information about the space on a filesystem.
    private static final String DI_DD_Android_getTotalBytes = "A136"; //The total number of bytes supported by the filesystem.


    StorageInfo(Context context) {
        collectPackageManagerInfo(context);
        collectEnvironmentInfo();
        collectLocaleInfo(context);
        collectDisplayMetricsInfo(context);
        collectStatFsInfo();
    }

    private void collectPackageManagerInfo(Context context) {
        PackageManager packageManager = context.getPackageManager();
        putData(DI_DD_Android_isSafeMode, String.valueOf(packageManager.isSafeMode()));

        List<ApplicationInfo> installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
        ArrayList<Map<String, String>> installedAppsMaps = new ArrayList<>();
        ArrayList<String> installedAppsPackages = new ArrayList<>();
        for (ApplicationInfo appInfo : installedApps) {
            Map<String, String> appInfoMap = new HashMap<>();
            appInfoMap.put("name", appInfo.name);
            appInfoMap.put("packageName", appInfo.packageName);
            installedAppsMaps.add(appInfoMap);
            installedAppsPackages.add(appInfo.packageName);
        }
        putData(DI_DD_Android_getInstalledApplications, installedAppsPackages);

        String installerPackageName = packageManager.getInstallerPackageName(context.getPackageName());
        if (installerPackageName != null) {
            putData(DI_DD_Android_getInstallerPackageName, installerPackageName);
        } else {
            dpna.put(DI_DD_Android_getInstallerPackageName, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }

        FeatureInfo[] features = packageManager.getSystemAvailableFeatures();
        putData(DI_DD_Android_getSystemAvailableFeatures, features.length);

        String[] names = packageManager.getSystemSharedLibraryNames();
        putData(DI_DD_Android_getSystemSharedLibraryNames, names.length);
    }

    private void collectEnvironmentInfo() {
        putData(DI_DD_Android_getExternalStorageState, Environment.getExternalStorageState());
    }

    private void collectLocaleInfo(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            putData(DI_DD_Android_getAvailableLocales, context.getResources().getConfiguration().getLocales().size());
        } else {
            putData(DI_DD_Android_getAvailableLocales, 1);
        }
    }

    private void collectDisplayMetricsInfo(Context context) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        putData(DI_DD_Android_density, String.valueOf(metrics.density));
        putData(DI_DD_Android_densityDpi, String.valueOf(metrics.densityDpi));
        putData(DI_DD_Android_scaledDensity, String.valueOf(metrics.scaledDensity));
        putData(DI_DD_Android_xdpi, String.valueOf(metrics.xdpi));
        putData(DI_DD_Android_ydpi, String.valueOf(metrics.ydpi));
    }

    private void collectStatFsInfo() {
        StatFs statFs = new StatFs(Environment.getRootDirectory().getAbsolutePath());
        putData(DI_DD_Android_getTotalBytes, String.valueOf(statFs.getTotalBytes()));
    }
}

package com.nuvei.mobilesdk.core.threeds2sdk.crypto;

import org.apache.cxf.rs.security.jose.common.JoseConstants;
import org.apache.cxf.rs.security.jose.jwa.ContentAlgorithm;
import org.apache.cxf.rs.security.jose.jwe.JweEncryption;
import org.apache.cxf.rs.security.jose.jwe.JweHeaders;
import org.apache.cxf.rs.security.jose.jwe.JweUtils;
import org.apache.cxf.rs.security.jose.jwk.JsonWebKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;

public class CXFCrypto {
    KeyPair generateKeyPair() throws NoSuchProviderException, NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        Security.addProvider(new BouncyCastleProvider());
        ECGenParameterSpec ecGenSpec = new ECGenParameterSpec(JsonWebKey.EC_CURVE_P256);
        KeyPairGenerator g = KeyPairGenerator.getInstance(JsonWebKey.KEY_TYPE_ELLIPTIC, "BC");
        g.initialize(ecGenSpec, new SecureRandom());
        return g.generateKeyPair();
    }

    /**
     * @param privateKey    Local private key
     * @param publicKey     Remote public key
     * @param partyVInfo    May be SDKReferenceNumber for CReq or DirectoryServerID for DeviceInfo
     * @return
     */
    byte[] generateCEK(ECPrivateKey privateKey, ECPublicKey publicKey, String partyVInfo) {
        return JweUtils.getECDHKey(privateKey, publicKey, null, partyVInfo.getBytes(), "", 256);
    }

    String jwe_CReq(byte[] cek, String contentToEncrypt, String transactionId) {
        ContentAlgorithm contentAlgorithm = ContentAlgorithm.A128GCM;
        JweEncryption jweEncryption = JweUtils.getDirectKeyJweEncryption(cek, contentAlgorithm);
        JweHeaders head = new JweHeaders();
        head.setHeader(JoseConstants.HEADER_KEY_ID, transactionId);
        return jweEncryption.encrypt(contentToEncrypt.getBytes(StandardCharsets.UTF_8), head);
    }

    String jwe_deviceInfo(byte[] cek, String contentToEncrypt) {
        ContentAlgorithm contentAlgorithm = ContentAlgorithm.A128GCM;
        JweEncryption jweEncryption = JweUtils.getDirectKeyJweEncryption(cek, contentAlgorithm);
        JweHeaders head = new JweHeaders();
        return jweEncryption.encrypt(contentToEncrypt.getBytes(StandardCharsets.UTF_8), head);
    }
}

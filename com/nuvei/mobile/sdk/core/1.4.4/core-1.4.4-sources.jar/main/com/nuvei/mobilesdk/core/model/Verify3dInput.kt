package com.nuvei.mobilesdk.core.model

import com.google.gson.JsonObject

public // NUVEI_MOBILE_SDK
class Verify3dInput(
        val clientRequestId: String?,
        val sessionToken: String?,
        val userTokenId: String?,
        val merchantId: String?,
        val merchantSiteId: String?,
        val amount: String?,
        val currency: String?,
        val paymentOption: JsonObject?
)
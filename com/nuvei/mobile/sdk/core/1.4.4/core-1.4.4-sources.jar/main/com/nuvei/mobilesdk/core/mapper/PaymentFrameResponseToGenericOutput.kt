package com.nuvei.mobilesdk.core.mapper

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.Constants
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.model.NVAuthenticate3dOutput
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.network.NetworkConstants

class PaymentFrameResponseToGenericOutput(
        private val additions: Map<String, String?>,
        private val isCreatePayment: Boolean,
        private val isThreeD2: Boolean
) : Mapper<JsonObject, NVOutput> {
    override fun map(source: JsonObject): NVOutput {

        val sourceWithAdditions = source.deepCopy().also { source ->
            for (entry in additions.entries) {
                entry.value?.let { value -> source.addProperty(entry.key, value) }
            }
        }

        val rawResult = Gson().fromJson<HashMap<String, Any>>(source, HashMap::class.java)

        val status = tryOptional { sourceWithAdditions[NetworkConstants.result]?.asString }
                ?: Constants.ERROR

        val errorCode = tryOptional {
            sourceWithAdditions[NetworkConstants.gwExtendedErrorCode]?.asInt
                    ?: sourceWithAdditions[NetworkConstants.gwErrorCode]?.asInt
                    ?: sourceWithAdditions[NetworkConstants.paymentMethodErrorCode]?.asInt
                    ?: sourceWithAdditions[NetworkConstants.errCode]?.asInt
        }

        Nuvei.log("[MKMK] PaymentFrameResponseToGenericOutput.sourceWithAdditions.errorDescription = ${sourceWithAdditions[NetworkConstants.errorDescription]?.asString}")
        val errorDescription = tryOptional {
            sourceWithAdditions[NetworkConstants.errorDescription]?.asString
                    ?: sourceWithAdditions[NetworkConstants.gwErrorReason]?.asString
                    ?: sourceWithAdditions[NetworkConstants.paymentMethodErrorReason]?.asString
                    ?: sourceWithAdditions[NetworkConstants.reason]?.asString
        }
        Nuvei.log("[MKMK] errorDescription = $errorDescription")

//        return Authenticate3dOutput(source[NetworkConstants.cavv]?.asString,
//                source[NetworkConstants.eci]?.asString,
//                source[NetworkConstants.xid]?.asString,
//                source[NetworkConstants.dsTransID]?.asString,
//                rawResult,
//                status,
//                errorCode,
//                errorDescription
//        )

        // in case of challenge (isThreeD2=true) there is an override to the transactionId
        val actualTransactionId = if (isThreeD2 && !isCreatePayment) {
            // auth3d should return the transactionId from clientAuthorize3d which is the call before completeVerify
            additions[NetworkConstants.transactionId] ?: rawResult?.get(NetworkConstants.transactionId) as? String
        } else {
            // createPayment should return the last transactionId
            rawResult?.get(NetworkConstants.transactionId) as? String ?: additions[NetworkConstants.transactionId]
        }

        if (isCreatePayment) {
            return NVCreatePaymentOutput(
                    status,
                    tryOptional { sourceWithAdditions.get(NetworkConstants.userPaymentOptionId)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccCardNumber)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.bin)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.last4Digits)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccExpMonth)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccExpYear)?.asString },
                    transactionId = actualTransactionId,
                    tryOptional { sourceWithAdditions.get(NetworkConstants.threeDReasonId)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.threeDReason)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.challengePreferenceReason)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.isLiabilityOnIssuer)?.asBoolean },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.cancelled)?.asBoolean } ?: false,
                    tryOptional { sourceWithAdditions.get(NetworkConstants.challengeCancelReasonId)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.challengeCancelReason)?.asString },
                    errorCode,
                    errorDescription,
                    rawResult
            )
        } else {
            return NVAuthenticate3dOutput(
                    status,
                    tryOptional { sourceWithAdditions.get(NetworkConstants.userPaymentOptionId)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.cavv)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.eci)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.xid)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.dsTransID)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccCardNumber)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.bin)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.last4Digits)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccExpMonth)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccExpYear)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.ccTempToken)?.asString },
                    transactionId = actualTransactionId,
                    tryOptional { sourceWithAdditions.get(NetworkConstants.threeDReasonId)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.threeDReason)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.challengePreferenceReason)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.isLiabilityOnIssuer)?.asBoolean },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.cancelled)?.asBoolean } ?: false,
                    tryOptional { sourceWithAdditions.get(NetworkConstants.challengeCancelReasonId)?.asString },
                    tryOptional { sourceWithAdditions.get(NetworkConstants.challengeCancelReason)?.asString },
                    errorCode,
                    errorDescription,
                    rawResult
            )
        }
    }
}
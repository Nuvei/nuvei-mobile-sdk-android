package com.nuvei.mobilesdk.core.threeds2sdk.parameters;

import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import java.util.HashMap;

public class ConfigParameters {

    private static final String DEFAULT_GROUP_NAME = "DEFAULT_GROUP_NAME";
    public static final String HOSTING_APP_GROUP_NAME = "HOSTING_APP_GROUP_NAME";

    public static final String HOSTING_APP_IMAGE = "HOSTING_APP_IMAGE";
    public static final String DIRECTORY_SERVER_GROUP = "DS";
    public static final String DIRECTORY_SERVER_ID = "ID";
    public static final String DIRECTORY_SERVER_KEY = "KEY";
    public static final String DIRECTORY_SERVER_ALG_KEY = "ALG";
    public static final String DIRECTORY_SERVER_ALG_RSA = "rsa";
    public static final String DIRECTORY_SERVER_ALG_EC = "ec";
    public static final String DIRECTORY_SERVER_ROOT_CA_KEY = "ROOT_CA";
    public static final String DIRECTORY_SERVER_ROOT_CA_ALG_KEY = "ROOT_CA_ALG";

    private HashMap<String, String> params = new HashMap<>();

    /**
     * Adds a configuration parameter either to the specified group or to the default group.
     *
     * @param group Group to which the configuration parameter is to be added.
     *              Note: If a group is not specified, then the default group shall be used.
     * @param paramName Name of the configuration parameter
     * @param paramValue Value of the configuration parameter
     *
     * @throws InvalidInputException This exception shall be thrown if paramName is null or if the parameter in the group is duplicate
     */
    public void addParam(String group, String paramName, String paramValue) throws InvalidInputException {
        if (paramName == null) {
            throw new InvalidInputException("paramName cannot be null");
        }

        String nonNullGroup = nonNullGroup(group);
        String existingParam = getParamValue(nonNullGroup, paramName);
        if (existingParam != null) {
            throw new InvalidInputException("parameter in the group is duplicate");
        }

        params.put(key(nonNullGroup, paramName), paramValue);
    }

    /**
     * The getParamValue method shall return a configuration parameter’s value either from the
     * specified group or from the default group, if the group is not specified.
     *
     * @param group Group from which the configuration parameter’s value is to be returned
     * @param paramName Name of the configuration parameter
     *
     * @return The value of the specified configuration parameter as a string.
     * If the parameter is not found in the specified group, then this method returns null.
     * Note: If the group is null, then the default group shall be used for lookup.
     *
     * @throws InvalidInputException This exception shall be thrown if paramName is null
     */
    public String getParamValue(String group, String paramName) throws InvalidInputException {
        if (paramName == null) {
            throw new InvalidInputException("paramName cannot be null");
        }
        String nonNullGroup = nonNullGroup(group);
        return params.get(key(nonNullGroup, paramName));
    }

    /**
     * The removeParam method shall remove a configuration parameter either from the specified group or from
     * the default group, if the group is not specified. It should return the value of the parameter that it removes.
     *
     * @param group Group from which the configuration parameter is to be removed.
     * @param paramName Name of the configuration parameter.
     *
     * @return The value of the parameter that it removes.
     * If the parameter is not found in the specified group, then this method returns null.
     * Note: If the group is null, then the default group shall be used for lookup.
     *
     * @throws InvalidInputException This exception shall be thrown if paramName is null
     */
    public String removeParam (String group, String paramName) throws InvalidInputException {
        if (paramName == null) {
            throw new InvalidInputException("paramName cannot be null");
        }
        String nonNullGroup = nonNullGroup(group);
        String existingParam = getParamValue(nonNullGroup, paramName);
        if (existingParam != null) {
            params.remove(key(nonNullGroup, paramName));
        }
        return existingParam;
    }

    private String nonNullGroup(String group) {
        return group != null ? group : DEFAULT_GROUP_NAME;
    }

    private String key(String group, String paramName) {
        return String.format("%s@@@%s", group, paramName);
    }
}

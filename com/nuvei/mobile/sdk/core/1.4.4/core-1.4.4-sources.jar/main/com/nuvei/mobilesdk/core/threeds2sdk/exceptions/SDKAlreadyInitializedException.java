package com.nuvei.mobilesdk.core.threeds2sdk.exceptions;

/**
 * This exception shall be thrown if the 3DS SDK instance has already been initialized.
 */
public class SDKAlreadyInitializedException extends RuntimeException {
    public SDKAlreadyInitializedException (String message) {
        super(message, null);
    }
    public SDKAlreadyInitializedException (String message, Throwable cause) {
        super(message, cause);
    }
}

package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

abstract class BaseDeviceInfo {
    /**
     * Market or regional restriction on the parameter
     */
    protected static final String DI_DPNA_RE_MarketOrRegionalRestriction = "RE01";

    /**
     * Platform version does not support the parameter or the parameter has been deprecated
     */
    protected static final String DI_DPNA_RE_PlatformVersionOrDeprecated = "RE02";

    /**
     * Parameter collection not possible without prompting the user for permission
     */
    protected static final String DI_DPNA_RE_MissingPermission = "RE03";

    /**
     * Parameter value returned is null od blank
     */
    protected static final String DI_DPNA_RE_NullValue = "RE04";

    /**
     * The device is jailbroken
     */
    protected static final String DI_SW_Jailbroken = "SW01";

    /**
     * The integrity of the SDK has been tampered
     */
    protected static final String DI_SW_SdkIntegrityTampered = "SW02";

    /**
     * An emulator is being used to run the App
     */
    protected static final String DI_SW_Emulator = "SW03";

    /**
     * A debugger is attached to the App
     */
    protected static final String DI_SW_DebuggerAttached = "SW04";

    /**
     * The OS or the OS version is not supported
     */
    protected static final String DI_SW_UnsupportedOsVersion = "SW05";


    protected HashMap<String, Object> dd = new HashMap<>();
    protected HashMap<String, String> dpna = new HashMap<>();

    HashMap<String, Object> getDeviceInfo() {
        return dd;
    }

    HashMap<String, String> getNotSupportedInfo() {
        return dpna;
    }

    void putData(String key, Object value) {
        if (value == null) {
            dpna.put(key, DI_DPNA_RE_NullValue);
            return;
        } else if (value instanceof String) {
            if (((String) value).isEmpty()) {
                dpna.put(key, DI_DPNA_RE_NullValue);
                return;
            }
        } else if (value instanceof ArrayList) {
            if (((ArrayList) value).isEmpty()) {
                dpna.put(key, DI_DPNA_RE_NullValue);
                return;
            }
        } else if (value instanceof Map) {
            if (((Map) value).isEmpty()) {
                dpna.put(key, DI_DPNA_RE_NullValue);
                return;
            }
        } else if (value instanceof Integer) {
            value = String.valueOf(value);
        } else if (value instanceof Float) {
            value = String.valueOf(value);
        } else if (value instanceof Double) {
            value = String.valueOf(value);
        } else if (value instanceof Long) {
            value = String.valueOf(value);
        }
        dd.put(key, value);
    }
}

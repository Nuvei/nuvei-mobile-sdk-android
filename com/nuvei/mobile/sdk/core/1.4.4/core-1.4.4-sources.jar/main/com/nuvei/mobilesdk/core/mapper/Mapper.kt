package com.nuvei.mobilesdk.core.mapper

interface Mapper<Source, Destination> {
    fun map(source: Source): Destination

    fun <T> tryOptional(expression: () -> T): T? {
        return try {
            expression()
        } catch (ex: Throwable) {
            null
        }
    }
}
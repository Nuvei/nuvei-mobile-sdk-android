package com.nuvei.mobilesdk.core

interface InternalCallback<SuccessResponse> {
    fun onSuccess(response: SuccessResponse)
    fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?)
}

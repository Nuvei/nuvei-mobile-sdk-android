package com.nuvei.mobilesdk.core.threeds2sdk;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CReq;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CRes;

public class ErrorMessage {

    @SerializedName("threeDSServerTransID")
    @Nullable
    private
    String threeDSServerTransID;

    @SerializedName("acsTransID")
    @Nullable
    private
    String acsTransID;

    @SerializedName("dsTransID")
    @Nullable
    private
    String dsTransID;

    @SerializedName("sdkTransID")
    @Nullable
    private
    String sdkTransID;

    /**
     * E.g. A
     */
    @SerializedName("errorComponent")
    private
    String errorComponent;

    /**
     * E.g. 302
     */
    @SerializedName("errorCode")
    private
    String errorCode;

    /**
     * E.g. Data could not be decrypted by the DS due to technical or other reason.
     */
    @SerializedName("errorDescription")
    private
    String errorDescription;

    /**
     * E.g. sdkCounterStoA not correct, expected 1 received 000
     */
    @SerializedName("errorDetail")
    private
    String errorDetail;

    /**
     * E.g. CReq
     */
    @SerializedName("errorMessageType")
    @Nullable
    private
    String errorMessageType;

    /**
     * E.g. ErrorMessage
     */
    @SerializedName("messageType")
    private
    String messageType;

    /**
     * E.g. 2.1.0
     */
    @SerializedName("messageVersion")
    private
    String messageVersion;

    ErrorMessage(
            @Nullable String acsTransID,
            @Nullable String sdkTransID,
            @Nullable String threeDSServerTransID,
            String messageVersion
    ) {
        setMessageType("Erro");
        setErrorComponent("C");
        setErrorMessageType("CRes");
        setAcsTransID(acsTransID);
        setSdkTransID(sdkTransID);
        setThreeDSServerTransID(threeDSServerTransID);
        setMessageVersion(messageVersion);
    }

    ErrorMessage(CRes cres) {
        this(
                cres.getAcsTransID(),
                cres.getSdkTransID(),
                cres.getThreeDSServerTransID(),
                cres.getMessageVersion()
        );
    }

    ErrorMessage(CReq creq) {
        this(
                creq.getAcsTransID(),
                creq.getSdkTransID(),
                creq.getThreeDSServerTransID(),
                creq.getMessageVersion()
        );
    }

    @Nullable
    public String getThreeDSServerTransID() {
        return threeDSServerTransID;
    }

    @Nullable
    public String getAcsTransID() {
        return acsTransID;
    }

    @Nullable
    public String getDsTransID() {
        return dsTransID;
    }

    @Nullable
    public String getSdkTransID() {
        return sdkTransID;
    }

    public String getErrorComponent() {
        return errorComponent;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    @Nullable
    public String getErrorMessageType() {
        return errorMessageType;
    }

    public String getMessageType() {
        return messageType;
    }

    public String getMessageVersion() {
        return messageVersion;
    }

    void setThreeDSServerTransID(@Nullable String threeDSServerTransID) {
        this.threeDSServerTransID = threeDSServerTransID;
    }

    void setAcsTransID(@Nullable String acsTransID) {
        this.acsTransID = acsTransID;
    }

    void setDsTransID(@Nullable String dsTransID) {
        this.dsTransID = dsTransID;
    }

    void setSdkTransID(@Nullable String sdkTransID) {
        this.sdkTransID = sdkTransID;
    }

    void setErrorComponent(String errorComponent) {
        this.errorComponent = errorComponent;
    }

    void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    void setErrorDetail(String errorDetail) {
        this.errorDetail = errorDetail;
    }

    void setErrorMessageType(@Nullable String errorMessageType) {
        this.errorMessageType = errorMessageType;
    }

    void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    void setMessageVersion(String messageVersion) {
        this.messageVersion = messageVersion;
    }

    public String getTransactionID() {
        return getSdkTransID();
    }

    public String getErrorDetails() {
        return getErrorDetail();
    }
}

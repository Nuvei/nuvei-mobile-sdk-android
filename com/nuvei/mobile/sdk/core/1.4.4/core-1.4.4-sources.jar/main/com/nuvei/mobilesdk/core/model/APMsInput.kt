package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName

class APMsInput(
    @SerializedName("sessionToken") val sessionToken: String,
    @SerializedName("merchantSiteId") val merchantSiteId: String,
    @SerializedName("merchantId") val merchantId: String,
    @SerializedName("languageCode") val languageCode: String,
    @SerializedName("countryCode") val countryCode: String,
    @SerializedName("sourceApplication") val sourceApplication: String? = null
)

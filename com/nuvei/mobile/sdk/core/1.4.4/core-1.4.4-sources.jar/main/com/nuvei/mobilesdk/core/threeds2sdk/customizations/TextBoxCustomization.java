package com.nuvei.mobilesdk.core.threeds2sdk.customizations;

import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

public class TextBoxCustomization extends Customization {
    private int borderWidth;
    private String borderColor;
    private int cornerRadius;

    public void setBorderWidth (int borderWidth) throws InvalidInputException {
        this.borderWidth = borderWidth;
    }

    public int getBorderWidth() {
        return borderWidth;
    }

    public void setBorderColor(String hexColorCode) throws InvalidInputException {
        this.borderColor = hexColorCode;
    }

    public String getBorderColor() {
        return borderColor;
    }

    public void setCornerRadius(int cornerRadius) throws InvalidInputException {
        this.cornerRadius = cornerRadius;
    }

    public int getCornerRadius() {
        return cornerRadius;
    }
}

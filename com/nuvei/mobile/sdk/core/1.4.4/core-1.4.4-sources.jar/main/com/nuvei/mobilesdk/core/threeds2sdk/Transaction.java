package com.nuvei.mobilesdk.core.threeds2sdk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.google.gson.Gson;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.Curve;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.ECKey;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.gen.ECKeyGenerator;
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeActivity;
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeExecutor;
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeKeys;
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeStatusReceiver;
import com.nuvei.mobilesdk.core.threeds2sdk.ChallengeTimeoutTimerTask;
import com.nuvei.mobilesdk.core.threeds2sdk.CompletionEvent;
import com.nuvei.mobilesdk.core.threeds2sdk.CryptoHelper;
import com.nuvei.mobilesdk.core.threeds2sdk.ErrorMessage;
import com.nuvei.mobilesdk.core.threeds2sdk.ProtocolErrorEvent;
import com.nuvei.mobilesdk.core.threeds2sdk.RuntimeErrorEvent;
import com.nuvei.mobilesdk.core.threeds2sdk.customizations.UiCustomization;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.SDKRuntimeException;
import com.nuvei.mobilesdk.core.threeds2sdk.network.AcsSignedContent;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CReq;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CRes;
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.AuthenticationRequestParameters;
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ChallengeParameters;
import com.nuvei.mobilesdk.core.threeds2sdk.parameters.ConfigParameters;

import org.apache.cxf.rs.security.jose.jwk.JsonWebKey;
import org.apache.cxf.rs.security.jose.jwk.JwkUtils;
import org.jose4j.lang.JoseException;

import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Timer;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * An object that implements the Transaction interface shall hold parameters that the 3DS Server
 * requires to create AReq messages and to perform the Challenge Flow.
 */
public class Transaction {

    private final static String TAG = "[3DSSDK][Transaction]";

    final String transactionID;
    private final String directoryServerID;
    private final DSPublicKey dsPublicKey;
    private final String deviceData;
    private final ECKey sdkEphemeralKeyPair;
    private final String sdkEphemeralPublicKey;
    private final String sdkAppID;
    private final String sdkReferenceNumber;
    private final String messageVersion;

    private int counterStoA = 0;

    ChallengeKeys challengeKeys;
    ChallengeParameters challengeParameters;
    String acsURL;
    UiCustomization uiCustomization;
    ConfigParameters configParameters;
    ChallengeStatusReceiver challengeStatusReceiver;

    static Transaction currentTransaction;

    private ChallengeExecutor challengeExecutor = null;
    private Timer timer;

    Transaction(
            String directoryServerID,
            DSPublicKey dsPublicKey,
            String deviceData,
            String sdkAppID,
            String sdkReferenceNumber,
            String messageVersion,
            UiCustomization uiCustomization,
            ConfigParameters configParameters
    ) throws InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchProviderException, JOSEException {
        Log.d(TAG, "Transaction(" +
                "directoryServerID: " + directoryServerID +
                ", dsPublicKey = " + dsPublicKey +
                ", sdkAppID = " + sdkAppID +
                ", sdkReferenceNumber = " + sdkReferenceNumber +
                ", messageVersion = " + messageVersion +
                ")");
        this.transactionID = UUID.randomUUID().toString();
        this.deviceData = deviceData;
        sdkEphemeralKeyPair = new ECKeyGenerator(Curve.P_256).generate();
        Log.d(TAG, "Transaction(), sdkEphemeralKeyPair = " + sdkEphemeralKeyPair.toJSONString());

        JsonWebKey privateJwk = JwkUtils.fromECPrivateKey(sdkEphemeralKeyPair.toECPrivateKey(), "P-256");
        this.sdkEphemeralPublicKey = sdkEphemeralKeyPair.toPublicJWK().toJSONString();
        this.sdkAppID = sdkAppID;
        this.directoryServerID = directoryServerID;
        this.dsPublicKey = dsPublicKey;
        this.sdkReferenceNumber = sdkReferenceNumber;
        this.messageVersion = messageVersion;
        this.uiCustomization = uiCustomization;
        this.configParameters = configParameters;

        challengeKeys = new ChallengeKeys();
        challengeKeys.setSdkJwk(privateJwk);
        challengeKeys.setSdkReferenceNumber(sdkReferenceNumber);
    }

    /**
     * Returns device and 3DS SDK information to the 3DS Requestor App.
     *
     * @return An AuthenticationRequestParameters object that contains device information and 3DS SDK information.
     * @throws SDKRuntimeException This exception shall be thrown if an internal error is encountered by the 3DS SDK.
     */
    public AuthenticationRequestParameters getAuthenticationRequestParameters() throws SDKRuntimeException {
        Log.d(TAG, "getAuthenticationRequestParameters: transactionID = " + transactionID);
        Log.d(TAG, "getAuthenticationRequestParameters: deviceData = " + deviceData);
        Log.d(TAG, "getAuthenticationRequestParameters: sdkEphemeralPublicKey = " + sdkEphemeralPublicKey);
        Log.d(TAG, "getAuthenticationRequestParameters: sdkAppID = " + sdkAppID);
        Log.d(TAG, "getAuthenticationRequestParameters: sdkReferenceNumber = " + sdkReferenceNumber);
        Log.d(TAG, "getAuthenticationRequestParameters: messageVersion = " + messageVersion);
        return new AuthenticationRequestParameters(
                transactionID,
                deviceData,
                sdkEphemeralPublicKey,
                sdkAppID,
                sdkReferenceNumber,
                messageVersion
        );
    }

    /**
     * Initiates the challenge process.
     *
     * @param currentActivity         The Android activity instance that invoked doChallenge.
     * @param challengeParameters     ACS details (contained in the ARes) required by the 3DS SDK to conduct
     *                                the challenge process during the transaction.
     *                                The following details are mandatory:
     *                                • 3DS Server Transaction ID
     *                                • ACS Transaction ID
     *                                • ACS Reference Number
     *                                • ACS Signed Content
     * @param challengeStatusReceiver Callback object for notifying the 3DS Requestor App about the challenge status.
     * @param timeOut                 Timeout interval (in minutes) within which the challenge process must be completed. The minimum timeout interval shall be 5 minutes.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     *                               A timeout interval of less than 5 minutes is also treated as invalid input.
     * @throws SDKRuntimeException   This exception shall be thrown if an internal error is encountered by the 3DS SDK.
     */
    public void doChallenge(
            final Activity currentActivity,
            ChallengeParameters challengeParameters,
            ChallengeStatusReceiver challengeStatusReceiver,
            int timeOut)
            throws InvalidInputException, SDKRuntimeException {

        Log.d(TAG, "doChallenge(" +
                "currentActivity: " + currentActivity +
                ", challengeParameters = " + challengeParameters +
                ", challengeStatusReceiver = " + challengeStatusReceiver +
                ", timeOut = " + timeOut +
                ")");

        validateDoChallengeInput(currentActivity, challengeParameters, challengeStatusReceiver, timeOut);

        handleTimeOut(timeOut);

        String acsDataString = decryptAcsSignedContent(challengeParameters);
        Log.d(TAG, "doChallenge(): acsDataString = " + acsDataString);

        this.challengeParameters = challengeParameters;
        this.challengeStatusReceiver = challengeStatusReceiver;
        currentTransaction = this;

        AcsSignedContent acsSignedContent = parse(acsDataString);
        acsURL = acsSignedContent.getAcsURL();
        challengeKeys.setAcsKey(acsSignedContent.getAcsEphemPubKey());

        challengeExecutor = new ChallengeExecutor(this);
        challengeExecutor.setListener(new ChallengeExecutor.Listener() {
            @Override
            public void onStartedLoading() {
            }

            @Override
            public void onFinishedLoading() {
            }

            @Override
            public void handleCRes(CRes cres) {
                Intent challengeActivityIntent = ChallengeActivity.getIntent(currentActivity, cres);
                challengeActivityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                currentActivity.startActivity(challengeActivityIntent);
                Log.d(TAG, "doChallenge(): did startActivity");
            }

            @Override
            public void finishActivity() {
            }
        });
        challengeExecutor.performInitialChallenge();
    }

    private void validateDoChallengeInput(
            Activity currentActivity,
            ChallengeParameters challengeParameters,
            ChallengeStatusReceiver challengeStatusReceiver,
            int timeOut
    ) {
        if (currentActivity == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(currentActivity cannot be null)");
            throw new InvalidInputException("currentActivity cannot be null");
        }

        if (challengeParameters == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(challengeParameters cannot be null)");
            throw new InvalidInputException("challengeParameters cannot be null");
        }
        if (challengeParameters.get3DSServerTransactionID() == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(challengeParameters.get3DSServerTransactionID() cannot be null)");
            throw new InvalidInputException("challengeParameters.get3DSServerTransactionID() cannot be null");
        }
        if (challengeParameters.getAcsRefNumber() == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(challengeParameters.getAcsRefNumber() cannot be null)");
            throw new InvalidInputException("challengeParameters.getAcsRefNumber() cannot be null");
        }
        if (challengeParameters.getAcsSignedContent() == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(challengeParameters.getAcsSignedContent() cannot be null)");
            throw new InvalidInputException("challengeParameters.getAcsSignedContent() cannot be null");
        }
        if (challengeParameters.getAcsTransactionID() == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(challengeParameters.getAcsTransactionID() cannot be null)");
            throw new InvalidInputException("challengeParameters.getAcsTransactionID() cannot be null");
        }

        if (challengeStatusReceiver == null) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(challengeStatusReceiver cannot be null)");
            throw new InvalidInputException("challengeStatusReceiver cannot be null");
        }

        if (timeOut < 5) {
            Log.d(TAG, "doChallenge(): -> InvalidInputException(timeOut must be at least 5 minutes)");
            throw new InvalidInputException("timeOut must be at least 5 minutes");
        }
    }

    private void handleTimeOut(int timeOut) {
        ChallengeTimeoutTimerTask task = new ChallengeTimeoutTimerTask(this);
        timer = new Timer();
        this.timer.schedule(task, TimeUnit.MINUTES.toMillis(timeOut));
    }

    private String decryptAcsSignedContent(ChallengeParameters challengeParameters) {
        String acsDataString;
        try {
            String signedContent = challengeParameters.getAcsSignedContent();

            Log.d(TAG, "challengeParameters.getAcsSignedContent() = " + signedContent);
//            acsDataString = CryptoHelper.validateJws(challengeParameters.getAcsSignedContent(), dsPublicKey);
            acsDataString = CryptoHelper.validateJwsWithoutRootCA(signedContent);
            //acsDataString = CryptoHelper.validateJws(challengeParameters.getAcsSignedContent());
            //acsDataString = CryptoHelper.validateJwsAsInDocs(challengeParameters.getAcsSignedContent());
        } catch (InvalidInputException e) {
            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
            throw new InvalidInputException("ACS Signed Content is wrong (Code 0)");
        } catch (JoseException e) {
            e.printStackTrace();
            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
            throw new InvalidInputException("ACS Signed Content is wrong (Code 1)");
//        } catch (InvalidKeySpecException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 2)");
//        } catch (CertificateException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 3)");
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 4)");
//        } catch (InvalidKeyException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 5)");
//        } catch (SignatureException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 6)");
//        } catch (NoSuchProviderException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 7)");
//        } catch (RuntimeException e) {
//            e.printStackTrace();
//            Log.d(TAG, "doChallenge(): -> throw new InvalidInputException(\"ACS Signed Content is wrong\")");
//            throw new InvalidInputException("ACS Signed Content is wrong (Code 8)");
        }
        return acsDataString;
    }

    /**
     * Returns an instance of Progress View (processing screen) that the 3DS Requestor App uses.
     *
     * @param currentActivity An Android activity instance.
     * @return A ProgressDialog object.
     * @throws InvalidInputException This exception shall be thrown if an input parameter is invalid.
     * @throws SDKRuntimeException   This exception shall be thrown if an internal error is encountered by the 3DS SDK.
     */
    public Dialog getProgressView(Activity currentActivity) throws InvalidInputException, SDKRuntimeException {

        Log.d(TAG, "getProgressView(" +
                "currentActivity: " + currentActivity +
                ")");

        if (currentActivity == null) {
            Log.d(TAG, "getProgressView(): -> InvalidInputException");
            throw new InvalidInputException("currentActivity cannot be null");
        }

        Dialog dialog = new Dialog(currentActivity);

        if (!(currentActivity instanceof ChallengeActivity)) {
            LinearLayout linearLayout = new LinearLayout(currentActivity);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setPadding(30, 30, 30, 30);

            byte[] decodedString = Base64.decode(configParameters.getParamValue(ConfigParameters.HOSTING_APP_GROUP_NAME, ConfigParameters.HOSTING_APP_IMAGE), Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

            Drawable drawable = new BitmapDrawable(currentActivity.getResources(), bitmap);

            ImageView imageView = new ImageView(currentActivity);
            imageView.setImageDrawable(drawable);
            imageView.setLayoutParams(new LinearLayout.LayoutParams(600, 300));

            linearLayout.addView(imageView);
            linearLayout.addView(new ProgressBar(currentActivity));

            dialog.addContentView(linearLayout,
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

        } else {
            LinearLayout linearLayout = new LinearLayout(currentActivity);
            linearLayout.setBackgroundColor(Color.TRANSPARENT);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setGravity(Gravity.CENTER_VERTICAL);
            linearLayout.setPadding(40, 40, 40, 40);

            linearLayout.addView(new ProgressBar(currentActivity));

            dialog.addContentView(linearLayout,
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        dialog.setCancelable(false);

        return dialog;
    }

    /**
     * Cleans up resources that are held by the Transaction object.
     */
    public void close() {
        Log.d(TAG, "close()");
        timer.cancel();
        challengeStatusReceiver = null;
        challengeExecutor = null;
        currentTransaction = null;
    }

    private AcsSignedContent parse(String acsSignedContentString) {
        return new Gson().fromJson(acsSignedContentString, AcsSignedContent.class);
    }

    @SuppressLint("DefaultLocale")
    CReq generateCReq() {
        CReq creq = new CReq();
        creq.setSdkTransID(transactionID);
        creq.setThreeDSServerTransID(challengeParameters.get3DSServerTransactionID());
        creq.setThreeDSRequestorAppURL(challengeParameters.getThreeDSRequestorAppURL());
        creq.setAcsTransID(challengeParameters.getAcsTransactionID());
        creq.setMessageType("CReq");
        creq.setMessageVersion(messageVersion);
        creq.setChallengeWindowSize("03");// TODO: change according to screen size (01: 250x400, 02: 390x400, 03: 500x600, 04: 600x400, 05: Full screen)
        creq.setSdkCounterStoA(String.format("%03d", counterStoA));
        counterStoA += 1;
        return creq;
    }

    ErrorMessage generateErrorMessage() {
        return new ErrorMessage(
                challengeParameters.getAcsTransactionID(),
                transactionID,
                challengeParameters.get3DSServerTransactionID(),
                messageVersion
        );
    }

    // --------------------------------------------------------------------
    // Inform challengeStatusReceiver
    // --------------------------------------------------------------------

    private boolean isFinalized = false;

    void completed(String sdkTransactionID, String transactionStatus) {
        if (isFinalized) {
            return;
        }
        isFinalized = true;
        challengeStatusReceiver.completed(new CompletionEvent(sdkTransactionID, transactionStatus));
    }

    void cancelled() {
        if (isFinalized) {
            return;
        }
        isFinalized = true;
        challengeStatusReceiver.cancelled();
    }

    void protocolError(ErrorMessage errorMessage) {
        if (isFinalized) {
            return;
        }
        if ("402".equals(errorMessage.getErrorCode())) {
            challengeStatusReceiver.timedout();
            isFinalized = true;
        }

        if (challengeStatusReceiver != null) {
            challengeStatusReceiver.protocolError(new ProtocolErrorEvent(transactionID, errorMessage));
            isFinalized = true;
        }
    }

    void runtimeError(String errorCode, String errorMessage) {
        if (isFinalized) {
            return;
        }
        isFinalized = true;
        challengeStatusReceiver.runtimeError(new RuntimeErrorEvent(errorCode, errorMessage));
    }

    public ChallengeExecutor getChallengeExecutor() {
        return challengeExecutor;
    }

    public String getMessageVersion() {
        return messageVersion;
    }
}

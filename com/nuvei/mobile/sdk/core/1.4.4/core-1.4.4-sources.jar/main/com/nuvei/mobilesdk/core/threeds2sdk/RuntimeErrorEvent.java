package com.nuvei.mobilesdk.core.threeds2sdk;

/**
 * The com.ults.samplesdk.RuntimeErrorEvent class shall hold details of run-time errors that are encountered by the 3DS SDK during authentication.
 * <p>
 * Note: A run-time error is not the same as a protocol error. For information about protocol errors, refer to Class ProtocolErrorEvent.
 * <p>
 * The implementer shall incorporate code that handles run-time errors. The following are examples of run-time errors:
 * <ul>
 * <li>ACS is unreachable.
 * <li>Unparseable message.
 * <li>Network issues.
 * </ul>
 */
public class RuntimeErrorEvent {

    private final String errorCode, errorMessage;

    public RuntimeErrorEvent(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     * The getErrorCode method shall return the implementer-specific error code. As the 3DS SDK implementer, you define this error code.
     *
     * @return This method returns the implementer-specific error code as a string. As the 3DS SDK implementer, you define this error code.
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * The getErrorMessage method shall return the error message.
     *
     * @return This method returns the error message as a string.
     */
    public String getErrorMessage() {
        return errorMessage;
    }

}

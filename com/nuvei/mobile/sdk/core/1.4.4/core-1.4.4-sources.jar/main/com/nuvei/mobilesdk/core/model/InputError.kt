package com.nuvei.mobilesdk.core.model

enum class InputError {
    NumberEmpty, CreditCardInvalid, ExpiryEmpty, ExpiryInvalid, CVVEmpty, CVVInvalid, HolderNameEmpty, HolderNameInvalid, PersonalIDEmpty, PersonalIDInvalid, CreditCardBlocked ;

    companion object {
        val numberErrors get() = arrayOf(NumberEmpty, CreditCardInvalid, CreditCardBlocked)
        val expiryErrors get() = arrayOf(ExpiryEmpty, ExpiryInvalid)
        val cvvErrors get() = arrayOf(CVVEmpty, CVVInvalid)
        val holderNameErrors get() = arrayOf(HolderNameEmpty, HolderNameInvalid)
        val personalIDErrors get() = arrayOf(PersonalIDEmpty, PersonalIDInvalid)
        fun from(value: Int) = values().firstOrNull { it.ordinal == value }
    }
}
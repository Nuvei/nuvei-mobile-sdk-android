package com.nuvei.mobilesdk.core

import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput
import com.nuvei.mobilesdk.core.model.Error

interface CardDetailsCallback {
    fun onComplete(response: NVCardDetailsOutput?, error: Error?)
}

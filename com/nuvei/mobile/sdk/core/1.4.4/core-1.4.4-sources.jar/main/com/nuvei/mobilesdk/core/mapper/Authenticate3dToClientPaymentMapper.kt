package com.nuvei.mobilesdk.core.mapper

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants

class Authenticate3dToClientPaymentMapper : Mapper<NVPayment, JsonObject> {
    override fun map(source: NVPayment): JsonObject {

        val jsonObject = Gson().toJsonTree(source).asJsonObject
        jsonObject.addProperty(NetworkConstants.webMasterId, NetworkConstants.sdkVersionPrefix + Nuvei.sdkVersion)
        jsonObject.remove("countryCode")
        jsonObject.remove("amount")
        jsonObject.remove("currency")
        return jsonObject

//        val map = HashMap<String, Any>()
//        map[NetworkConstants.merchantSiteId] = source.merchantSiteId
//        map[NetworkConstants.merchantId] = source.merchantId
//        map[NetworkConstants.sessionToken] = source.sessionToken
//        source.clientRequestId?.let { map[NetworkConstants.clientRequestId] = it }
//        source.customData?.let { map[NetworkConstants.customData] = it }
//        source.clientUniqueId?.let { map[NetworkConstants.clientUniqueId] = it }
//        source.userTokenId?.let { map[NetworkConstants.userTokenId] = it }
//        source.userDetails?.let { map[NetworkConstants.userDetails] = it }
//        source.shippingAddress?.let { map[NetworkConstants.shippingAddress] = it }
//        source.billingAddress?.let { map[NetworkConstants.billingAddress] = it }
//        source.dynamicDescriptor?.let { map[NetworkConstants.dynamicDescriptor] = it }
//        source.merchantDetails?.let { map[NetworkConstants.merchantDetails] = it }
//        source.notificationUrl?.let { map[NetworkConstants.urlDetails] = it }
//        map[NetworkConstants.webMasterId] = "sdk_android_ver1.0"
//        map[NetworkConstants.paymentOption] = source.paymentOption.toMap()
//
//        return map
    }

}
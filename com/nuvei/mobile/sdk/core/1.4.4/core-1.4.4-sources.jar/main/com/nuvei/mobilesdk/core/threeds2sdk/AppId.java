package com.nuvei.mobilesdk.core.threeds2sdk;

import android.content.Context;
import android.content.SharedPreferences;

import static android.content.Context.MODE_PRIVATE;

class AppId {
    private static final String PREFS_NAME = "3DS";
    private static final String APP_ID_KEY = "3DS-app-id";

    static String get(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String appId = prefs.getString(APP_ID_KEY, null);
        if (appId == null) {
            appId = java.util.UUID.randomUUID().toString();
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(APP_ID_KEY, appId);
            editor.apply();
        }
        return appId;
    }
}

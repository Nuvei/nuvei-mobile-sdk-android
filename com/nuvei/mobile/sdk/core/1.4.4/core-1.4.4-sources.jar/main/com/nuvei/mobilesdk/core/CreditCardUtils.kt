package com.nuvei.mobilesdk.core

import com.nuvei.mobilesdk.core.mapper.CreditCardTypeToIconMapper
import java.util.Calendar

class CreditCardUtils {
    enum class CardType(
        val numberLengths: Array<Int>,
        val regex: Regex,
        val cvvLength: Int? =  null
    ) {
        amex(arrayOf(15), Regex("^3[47][0-9]{5,}\$"), 4),
        visa(arrayOf(13, 16, 19), Regex("^4[0-9]{6,}([0-9]{3})?\$"),3),
        masterCard(arrayOf(16), Regex("^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}\$"),3),
        diners(arrayOf(14,15), Regex("^3(?:0[0-5]|[68][0-9])[0-9]{4,}\$"),3),
        discover(arrayOf(16), Regex("^6(?:011|5[0-9]{2})[0-9]{3,}\$"),3),
        jcb(arrayOf(16), Regex("^(?:2131|1800|35[0-9]{3})[0-9]{3,}\$"),3),
        elo(arrayOf(), Regex("^((((636368)|(438935)|(504175)|(451416)|(636297))[0-9]{0,10})|((5067)|(4576)|(4011))[0-9]{0,12})\$"),3),
        hipercard(arrayOf(), Regex("^(606282|3841)[0-9]{5,}\$"),3),
        unionPay(arrayOf(16, 17, 18, 19), Regex("^(62|88)[0-9]{5,}\$"),3),
        maestro(arrayOf(12, 13, 14, 15, 16, 17, 18, 19), Regex("^(?:50[0-9]{2}|56[0-9]{2}|57[0-9]{2}|58[0-9]{2}|6304|6703|6759|676[1-3])[0-9]{8,15}$"),3);

        companion object {
            fun fromBrandName(brandName: String?) = when (brandName) {
                "amex" -> amex
                "visa" -> visa
                "master_card" -> masterCard
                "diners", "diners_club_international" -> diners
                "discover", "discover_card" -> discover
                "jcb" -> jcb
                "elo" -> elo
                "hiper_card" -> hipercard
                "union_pay", "china_union" -> unionPay
                "maestro" -> maestro
                else -> null
            }
        }
    }

    data class ParsedCard(val number: String, val type: CardType)

    companion object {
        val creditCardIconMapper = CreditCardTypeToIconMapper()

        fun iconForCard(parsedCard: ParsedCard?) =
            parsedCard?.takeUnless { it.number.isEmpty() }?.let { creditCardIconMapper.map(it.type) }

        fun parseCardNumber(rawValue: String): ParsedCard? {
            val value = Regex("[^0-9]").replace(rawValue, "")
            if (value.length <= 7) {
                return null
            }

            CardType.values().forEach { cardType ->
                if (!cardType.regex.matches(value)) {
                    return@forEach
                }

                if (!cardType.numberLengths.contains(value.count())) {
                    return@forEach
                }

                if (!validateUsingLuhnAlgorithm(value)) {
                    return@forEach
                }

                return ParsedCard(value, cardType)
            }

            return null
        }

        fun parseDate(rawValue: String): String? {
            Regex("[^0-9]*([0-9]{2}/[0-9]{2})$").findAll(rawValue).find {
                val values = it.value.split("/")
                if (values.count() < 2) { return@find false }

                val month = values[0].toIntOrNull() ?: return@find false
                val year = values[1].toIntOrNull() ?: return@find false

                if ((month in 1..12).not()) { return@find false }

                if (!isFutureDate(month, year)) { return@find false }

                return it.value
            }

            return null
        }

        private fun validateUsingLuhnAlgorithm(number: String): Boolean {
            var checksum = 0

            for (i in number.length - 1 downTo 0 step 2) {
                checksum += number[i] - '0'
            }
            for (i in number.length - 2 downTo 0 step 2) {
                val n: Int = (number[i] - '0') * 2
                checksum += if (n > 9) n - 9 else n
            }

            return checksum % 10 == 0
        }
    }
}

fun isFutureDate(month: Int,year: Int): Boolean {
    with(Calendar.getInstance()) {
        val currentYearFull = get(Calendar.YEAR);
        val currentMonth = get(Calendar.MONTH)

        val currentYear = currentYearFull % 100

        return year > currentYear || (year == currentYear && month >= currentMonth + 1);
    }
}

fun isValidCvv(rawCvv: String, cardType: CreditCardUtils.CardType?): Boolean {
    val digits = rawCvv.filter(Char::isDigit)
    if (digits.isEmpty()) return false
    return if (cardType != null ){
        if (cardType.name.equals("amex")){
            digits.length.equals(4)
        }else{
            digits.length.equals(3)
        }
    }
    else{
        (digits.length.equals(3) || digits.length.equals(4))
    }
}
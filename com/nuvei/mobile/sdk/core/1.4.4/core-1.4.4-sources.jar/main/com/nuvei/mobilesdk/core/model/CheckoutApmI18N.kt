package com.nuvei.mobilesdk.core.model

data class OptionMsg(val code: String?, val label: String)

data class FieldMsg(
    val key: String,
    val text: String,
    val error: String,
    val options: List<OptionMsg> = emptyList()
)

data class MethodMsg(
    val methodId: String,
    val fields: List<FieldMsg> = emptyList(),
    val title: String? = null                   // optional method title override
)

data class CheckoutApmStrings(
    val saveDetailsText: String = "Save my details for future use",
    val payButtonTitleText: String = "Pay %1.2f%2s",

    val emptyFieldErrorText: String = "This field is required"
)

// Lookup (read-only by SDK)
class CheckoutApmI18N internal constructor(
    private val titles: Map<String, String>,
    private val dict: Map<String, Map<String, String>>,
    val apmUiStrings: CheckoutApmStrings
) {
    fun title(methodId: String): String? = titles[methodId]

    fun text(methodId: String, fieldKey: String): String? =
        dict[methodId]?.get(fieldKey)

    fun error(methodId: String, fieldKey: String): String? =
        dict[methodId]?.get("${fieldKey}_error")

    fun option(methodId: String, fieldKey: String, code: String?): String? {
        val safeCode = code?.takeIf { it.isNotBlank() } ?: "<default>"
        return dict[methodId]?.get("$fieldKey.option.$safeCode")
    }

    companion object {
        private const val DEFAULT_OPTION_KEY = "<default>"

        @JvmStatic
        fun from(
            methods: List<MethodMsg>,
            apmUiStrings: CheckoutApmStrings = CheckoutApmStrings()
        ): CheckoutApmI18N {
            val titles = mutableMapOf<String, String>()
            val dict = methods.associate { m ->
                m.title?.let { titles[m.methodId] = it }
                val inner = LinkedHashMap<String, String>(m.fields.size * 3)
                m.fields.forEach { f ->
                    inner[f.key] = f.text
                    inner["${f.key}_error"] = f.error
                    if (!f.options.isNullOrEmpty()){
                        f.options.forEach { opt ->
                            val safeCode = opt.code?.takeIf { it.isNotBlank() } ?: DEFAULT_OPTION_KEY
                            inner["${f.key}.option.$safeCode"] = opt.label
                        }
                    }

                }
                m.methodId to inner.toMap()
            }
            return CheckoutApmI18N(
                titles = titles.toMap(),
                dict = dict,
                apmUiStrings = apmUiStrings
            )
        }
    }
}
// Simple store the client initializes once
object CheckoutApmI18NStore {
    @Volatile private var instance: CheckoutApmI18N =
        CheckoutApmI18N.from(emptyList())

    @JvmStatic @Synchronized
    fun init(i18n: CheckoutApmI18N) { instance = i18n }

    @JvmStatic
    fun get(): CheckoutApmI18N = instance

    @JvmStatic @Synchronized
    fun clear() {
        instance = CheckoutApmI18N.from(emptyList())
    }
}
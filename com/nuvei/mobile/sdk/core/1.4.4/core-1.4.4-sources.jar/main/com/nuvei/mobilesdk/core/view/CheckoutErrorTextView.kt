package com.nuvei.mobilesdk.core.view

import android.content.Context
import android.content.res.TypedArray
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.annotation.ColorInt
import androidx.appcompat.widget.AppCompatTextView
import com.nuvei.mobilesdk.core.R
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.SimplyConnectUICustomization
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import kotlin.math.max


class CheckoutErrorTextView : AppCompatTextView {
    private var parentId: Int? = null
    private var didAddListener = false
    private var lastText: String? = null

    private var shouldIgnore = false

    var code: InputError? = null
        private set

    var maxLength: Int? = null
        set(value) {
            field = value
            applyFilter()
        }

    private fun applyFilter() {
        val limit = maxLength ?: return
        parentEditText()?.let { et ->
            val currentLen = et.text?.length ?: 0
            val filterLimit = kotlin.math.max(currentLen, limit)
            et.filters = arrayOf(InputFilter.LengthFilter(filterLimit))
        }
    }

    var onValidateInput: ((text: String, hasFocus: Boolean) -> Unit)? = null

    constructor(context: Context) : super(context) {
        init(null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(attrs)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        if (!didAddListener) {
            parentEditText()?.apply {
                val handler = InputTextWatcher()
                addTextChangedListener(handler)
                val existingListener = onFocusChangeListener
                setOnFocusChangeListener { v, hasFocus ->
                    existingListener?.onFocusChange(v, hasFocus)
                    if (!hasFocus) {
                        val text = text?.toString()?.takeIf { it.isNotEmpty() } ?: return@setOnFocusChangeListener
                        onValidateInput?.invoke(text, false)
                    }
                }
                lastText = text.toString()
            }
            didAddListener = true
        }
    }

    fun setInputValue(value: String) {
        shouldIgnore = true
        parentEditText()?.apply {
            setTag(R.id.TAG_PROGRAMMATIC_CHANGE, true)
            val position = selectionEnd
            setText(value)
            setSelection(position.takeIf { it < text.length } ?: (text.length).takeIf { it >= 0 } ?: 0)
            setTag(R.id.TAG_PROGRAMMATIC_CHANGE, null)
        }
        shouldIgnore = false
    }

    fun setErrorMessage(message: Int, errorCode: InputError) {
        code = errorCode
        text = context.getString(message)
        visibility = View.VISIBLE
        parentEditText()?.setBackgroundResource(R.drawable.checkout_method_text_error_background)
    }

    fun setErrorMessage(message: String, errorCode: InputError) {
        code = errorCode
        text = message
        setTextColor(SimplyConnectUICustomization.errorBoxCustomization.textColor)
        textSize = SimplyConnectUICustomization.errorBoxCustomization.textFontSize.toFloat()
        visibility = View.VISIBLE
        applyNuveiFont(SimplyConnectUICustomization.errorBoxCustomization.textFontName)
        applyCustomization(parentEditText()!!, isError = true)
    }

    fun clearErrorMessage() {
        code = null
        text = null
        visibility = View.INVISIBLE
        applyCustomization(parentEditText()!!, isError = false)
    }

    fun applyCustomization(vararg views: EditText, isError: Boolean) {
        val textBoxCustomization = SimplyConnectUICustomization.textBoxCustomization
        val errorTextBoxCustomization = SimplyConnectUICustomization.errorBoxCustomization

        val textColor = textBoxCustomization.textColor
        val textFontSize = textBoxCustomization.textFontSize
        val borderWidth = textBoxCustomization.borderWidth
        val cornerRadius = textBoxCustomization.cornerRadius
        val borderColor = if (isError) errorTextBoxCustomization.borderColor else textBoxCustomization.borderColor

        views.forEach { et ->
            et.post {
                // 0) If something else tinted the background, kill it so our drawable shows
                et.backgroundTintList = null
                et.backgroundTintMode = null

                // 1) Keep padding (setBackground resets it)
                val pL = et.paddingLeft
                val pT = et.paddingTop
                val pR = et.paddingRight
                val pB = et.paddingBottom

                // 2) Text appearance (so you also see *some* change even if bg got replaced)
                et.setTextColor(textColor)
                et.textSize = textFontSize.toFloat()

                val dm = et.resources.displayMetrics
                val strokePx = borderWidth * dm.density
                val radiusPx = cornerRadius * dm.density

                val outer = FloatArray(8) { radiusPx }
                val innerRadius = max(0f, radiusPx - strokePx)
                val inner = FloatArray(8) { innerRadius }

//                val ring = ShapeDrawable(
//                    RoundRectShape(outer, RectF(strokePx, strokePx, strokePx, strokePx), inner)
//                ).apply {
//                    paint.isAntiAlias = true
//                    paint.style = Paint.Style.FILL       // fill the ring
//                    paint.color = borderColor
//                }

                et.backgroundTintList = null
                et.background = makeRingDrawable(
                    borderColor,
                    borderWidth,
                    cornerRadius,
                    et,
                    textBoxCustomization.backgroundColor
                )
                et.setPadding(pL, pT, pR, pB)
                et.invalidate()
            }
        }
    }

    private fun makeRingDrawable(
        @ColorInt strokeColor: Int,
        strokeWidthDp: Int,
        cornerRadiusDp: Int,
        v: View,
        @ColorInt fillColor: Int? = null
    ): Drawable {
        val dm = v.resources.displayMetrics
        val stroke = strokeWidthDp * dm.density
        val r = cornerRadiusDp * dm.density

        val outer = floatArrayOf(r, r, r, r, r, r, r, r)

        if (stroke <= 0f) {
            return ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor ?: android.graphics.Color.TRANSPARENT
            }
        }

        val innerR = (r - stroke).coerceAtLeast(0f)
        val inner = floatArrayOf(innerR, innerR, innerR, innerR, innerR, innerR, innerR, innerR)

        // 1) Border drawn as a *ring* so corners aren’t thicker
        val ring = ShapeDrawable(
            RoundRectShape(outer, RectF(stroke, stroke, stroke, stroke), inner)
        ).apply {
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.color = strokeColor
        }

        // 2) Optional fill under the ring
        return if (fillColor == null) {
            ring
        } else {
            val fill = ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor
            }
            LayerDrawable(arrayOf(fill, ring))
        }
    }

    private fun parentEditText(): EditText? {
        val parentId = parentId ?: return null

        return (parent as? ViewGroup)?.findViewById(parentId) as? EditText
    }

    private fun init(attrs: AttributeSet?) {
        val values: TypedArray = context.obtainStyledAttributes(attrs, R.styleable.CheckoutErrorTextView)
        for (index in 0 until values.indexCount) {
            when (val attr = values.getIndex(index)) {
                R.styleable.CheckoutErrorTextView_parentId -> {
                    parentId = values.getResourceId(attr, -1)
                }
            }
        }

        values.recycle()
    }

    private inner class InputTextWatcher : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        }

        override fun afterTextChanged(newTextValue: Editable?) {
            val newText = newTextValue.toString()
            if (shouldIgnore || lastText == newText) {
                return
            }

            lastText = newText

            applyFilter()
            clearErrorMessage()
            onValidateInput?.invoke(newText, true)
        }
    }
}
package com.nuvei.mobilesdk.core.threeds2sdk.crypto;

import android.text.TextUtils;
import android.util.Log;

import com.nuvei.mobilesdk.core.nimbusds.jose.EncryptionMethod;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEAlgorithm;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEHeader;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWEObject;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWSObject;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWSVerifier;
import com.nuvei.mobilesdk.core.nimbusds.jose.Payload;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.ECDHEncrypter;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.ECDSAVerifier;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.impl.ConcatKDF3DS2;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.ECKey;
import com.nuvei.mobilesdk.core.nimbusds.jose.util.Base64URL;
import com.nuvei.mobilesdk.core.nimbusds.jose.util.X509CertUtils;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.jose4j.base64url.Base64Url;
import org.jose4j.base64url.SimplePEMEncoder;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.keys.EcKeyUtil;
import org.jose4j.lang.JoseException;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECFieldFp;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.EllipticCurve;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.crypto.KeyAgreement;

public class ECDHCrypto {

    private static final String TAG = "[3DSSDK][ECDHCrypto]";


    public static String nimbus_encrypt2(String dd, ECPublicKey publicKey, String dsId) {
        try {

            JWEHeader header = new JWEHeader
                    .Builder(JWEAlgorithm.ECDH_ES, EncryptionMethod.A128CBC_HS256)
                    .build();
            JWEObject jweObject = new JWEObject(header, new Payload(dd));

            jweObject.encrypt(new ECDHEncrypter(publicKey, null, new ConcatKDF3DS2("SHA-256", dsId)));
            return jweObject.serialize();
        } catch (Exception ex) {
            Log.e(TAG, "failed to jweEncrypt", ex);
            throw new RuntimeException();
        }
    }

    public KeyPair generateKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        kpg.initialize(256);
        return kpg.genKeyPair();
    }

    JsonWebKey jwk(Key key) throws JoseException {
        return JsonWebKey.Factory.newJwk(key);
    }

    public static PublicKey publicKey(String remotePublicKeyAsPem) throws JoseException, InvalidKeySpecException {
        if (!remotePublicKeyAsPem.startsWith("-----BEGIN PUBLIC KEY-----")) {
            remotePublicKeyAsPem = "-----BEGIN PUBLIC KEY----- " + remotePublicKeyAsPem;
        }
        if (!remotePublicKeyAsPem.endsWith("-----END PUBLIC KEY-----")) {
            remotePublicKeyAsPem = remotePublicKeyAsPem + " -----END PUBLIC KEY-----";
        }
        return new EcKeyUtil().fromPemEncoded(remotePublicKeyAsPem);
    }

    void performKeyAgreement(KeyPair kp, PublicKey remotePublicKey) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] ourPk = kp.getPublic().getEncoded();
        byte[] otherPk = remotePublicKey.getEncoded();

        // Perform key agreement
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(kp.getPrivate());
        ka.doPhase(remotePublicKey, true);

        // Read shared secret
        byte[] sharedSecret = ka.generateSecret();

        // Derive a key from the shared secret and both public keys
        MessageDigest hash = MessageDigest.getInstance("SHA-256");
        hash.update(sharedSecret);
        // Simple deterministic ordering
        List<ByteBuffer> keys = Arrays.asList(ByteBuffer.wrap(ourPk), ByteBuffer.wrap(otherPk));
        Collections.sort(keys);
        hash.update(keys.get(0));
        hash.update(keys.get(1));

        byte[] derivedKey = hash.digest();
    }

//    String encrypt(String plain, String remotePublicKeyAsPem) throws JoseException, InvalidKeySpecException {
//        PublicKey publicKey = publicKey(remotePublicKeyAsPem);
//        JsonWebKey jwk = jwk(publicKey);
//        return encrypt(plain, jwk);
//    }

//    public String encrypt(String plain, PublicKey remotePublicKey) throws JoseException {
//        JsonWebKey jwk = jwk(remotePublicKey);
//        return encrypt(plain, jwk);
//    }

    //    public static ECKey generateEC() throws JOSEException {
//        return new ECKeyGenerator(Curve.P_256).generate();
//    }
    public static KeyPair generateEC() throws NoSuchProviderException, NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        Security.insertProviderAt(new BouncyCastleProvider(), 1);
//        ECGenParameterSpec ecGenSpec = new ECGenParameterSpec(org.apache.cxf.rs.security.jose.jwk.JsonWebKey.EC_CURVE_P256);
//        ECGenParameterSpec ecGenSpec = new ECGenParameterSpec("prime256v1");
        ECParameterSpec ecGenSpec = new ECParameterSpec(
                new EllipticCurve(
                        new ECFieldFp(new BigInteger("115792089210356248762697446949407573530086143415290314195533631308867097853951")),
                        new BigInteger("115792089210356248762697446949407573530086143415290314195533631308867097853948"),
                        new BigInteger("41058363725152142129326129780047268409114441015993725554835256314039467401291")),
                new ECPoint(
                        new BigInteger("48439561293906451759052585252797914202762949526041747995844080717082404635286"),
                        new BigInteger("36134250956749795798585127919587881956611106672985015071877198253568414405109")),
                new BigInteger("115792089210356248762697446949407573529996955224135760342422259061068512044369"),
                1);;
        KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
        g.initialize(ecGenSpec);
        return g.generateKeyPair();
    }

    public void nimbus_encrypt(String plainJson, ECPublicKey otherPublicKey, String directoryServerId) throws JOSEException {
//        JWSHeader jwsHeader = new JWSHeader(JWSAlgorithm.ES256);
//        SignedJWT signedJWT = new SignedJWT(jwsHeader, Alice);
//        signedJWT.sign(new ECDSASigner(ecJwk));
//        String sdfs = signedJWT.serialize();

//        String paddedPemEncodedCert = "-----BEGIN CERTIFICATE-----" + pemEncodedCert + "-----END CERTIFICATE-----";

        JWEHeader jweHeader = new JWEHeader(
                JWEAlgorithm.ECDH_ES,
                EncryptionMethod.A128CBC_HS256,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                Base64URL.encode(directoryServerId),
                null,
                0,
                null,
                null,
                null,
                null);

//        byte[] encodedPublicKey = SimplePEMEncoder.decode(pemEncodedCert);
//        X509Certificate cert = X509CertUtils.parse(encodedPublicKey);
        JWEObject jwe = new JWEObject(jweHeader, new Payload(plainJson));
//        jwe.encrypt(new ECDHEncrypter(ECKey.parse(cert)));
        jwe.encrypt(new ECDHEncrypter(otherPublicKey));
        String serializedJwe = jwe.serialize();
        Log.d(TAG, "nimbus_encrypt: jwe = " + jwe.getHeader());
        Log.d(TAG, "nimbus_encrypt: serializedJwe = " + serializedJwe);
    }

    public String jose4j_encrypt(String plainJson, PublicKey otherPublicKey, String directoryServerId) throws JoseException {

        // the JWE object
        JsonWebEncryption jwe = new JsonWebEncryption();

        // The output of the ECDH-ES key agreement will be used as the content encryption key
        jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.ECDH_ES);

        // The content encryption key is used to encrypt the payload
        // with a composite AES-CBC / HMAC SHA2 encryption algorithm
        jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);

        // don't think you really need this but you had ""apv":DirectoryServerID" in the question so...
        jwe.setHeader(HeaderParameterNames.KEY_ID, Base64Url.encodeUtf8ByteRepresentation(directoryServerId));

        // We encrypt to the receiver using their public key
        jwe.setKey(otherPublicKey);

        // What is going to be encrypted
        jwe.setPayload(plainJson);

        // Produce the JWE compact serialization, which is a string consisting of five dot ('.') separated
        // base64url-encoded parts in the form Header..IV.Ciphertext.AuthenticationTag
        String serializedJwe = jwe.getCompactSerialization();

        Log.d(TAG, "jose4j_encrypt: jwe = " + jwe);
        Log.d(TAG, "jose4j_encrypt: serializedJwe = " + serializedJwe);

        return serializedJwe;
    }

    public String encrypt(String plain, PublicKey remotePublicKey) throws JoseException {
        JsonWebKey jwk = jwk(remotePublicKey);
        return encrypt(plain, jwk);
    }

    String encrypt(String plain, JsonWebKey jwk) throws JoseException {

        // Create a new Json Web Encryption object
        JsonWebEncryption senderJwe = new JsonWebEncryption();

        // The plaintext of the JWE is the message that we want to encrypt.
        senderJwe.setPlaintext(plain);

        // Set the "alg" header, which indicates the key management mode for this JWE.
        senderJwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.ECDH_ES);

        // Set the "enc" header, which indicates the content encryption algorithm to be used.
        // This example is using AES_128_CBC_HMAC_SHA_256 which is a composition of AES CBC
        // and HMAC SHA2 that provides authenticated encryption.
        senderJwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);

        // Set the key on the JWE. In this case, using direct mode, the key will used directly as
        // the content encryption key. AES_128_CBC_HMAC_SHA_256, which is being used to encrypt the
        // content requires a 256 bit key.
        senderJwe.setKey(jwk.getKey());

        // Produce the JWE compact serialization, which is where the actual encryption is done.
        // The JWE compact serialization consists of five base64url encoded parts
        // combined with a dot ('.') character in the general format of
        // <header>.<encrypted key>.<initialization vector>.<ciphertext>.<authentication tag>
        // Direct encryption doesn't use an encrypted key so that field will be an empty string
        // in this case.
        String compactSerialization = senderJwe.getCompactSerialization();

        // Do something with the JWE. Like send it to some other party over the clouds
        // and through the interwebs.
        Log.d(TAG, "encrypt: JWE compact serialization = " + compactSerialization);

        return compactSerialization;
    }

//    void enc2(PublicKey remotePublicKey, String directoryServerId) throws JoseException {
//        // Generate an EC key pair, which will be used for signing and verification of the JWT, wrapped in a JWK
//        EllipticCurveJsonWebKey senderJwk = EcJwkGenerator.generateJwk(EllipticCurves.P256);
//
//        // Generate an EC key pair, wrapped in a JWK, which will be used for encryption and decryption of the JWT
//        EllipticCurveJsonWebKey receiverJwk = (EllipticCurveJsonWebKey) PublicJsonWebKey.Factory.newPublicJwk(remotePublicKey);
//
//        // The outer JWT is a JWE
//        JsonWebEncryption jwe = new JsonWebEncryption();
//
//        // The output of the ECDH-ES key agreement will encrypt a randomly generated content encryption key
//        jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.ECDH_ES);
//
//        // The content encryption key is used to encrypt the payload
//        // with a composite AES-CBC / HMAC SHA2 encryption algorithm
//        jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
//
//        // We encrypt to the receiver using their public key
//        jwe.setKey(receiverJwk.getPublicKey());
//
//        jwe.setHeader(HeaderParameterNames.AGREEMENT_PARTY_V_INFO, directoryServerId);
////        jwe.setHeader(HeaderParameterNames.EPHEMERAL_PUBLIC_KEY, directoryServerJwk.toJson());
//
//        // A JWT is a JWS and/or a JWE with JSON claims as the payload.
//        // In this example it is a JWS nested inside a JWE
//        // So we first create a JsonWebSignature object.
//        JsonWebSignature jws = new JsonWebSignature();
//
//        // The JWT is signed using the sender's private key
//        jws.setKey(senderJwk.getPrivateKey());
//
//        // Set the Key ID (kid) header because it's just the polite thing to do.
//        // We only have one signing key in this example but a using a Key ID helps
//        // facilitate a smooth key rollover process
//        jws.setKeyIdHeaderValue(senderJwk.getKeyId());
//
//        // Set the signature algorithm on the JWT/JWS that will integrity protect the claims
//        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
//
//        // Sign the JWS and produce the compact serialization, which will be the inner JWT/JWS
//        // representation, which is a string consisting of three dot ('.') separated
//        // base64url-encoded parts in the form Header.Payload.Signature
//        String innerJwt = jws.getCompactSerialization();
//
//
//        // The inner JWT is the payload of the outer JWT
//        jwe.setPayload(innerJwt);
//
//        // Produce the JWE compact serialization, which is the complete JWT/JWE representation,
//        // which is a string consisting of five dot ('.') separated
//        // base64url-encoded parts in the form Header.EncryptedKey.IV.Ciphertext.AuthenticationTag
//        String jwt = jwe.getCompactSerialization();
//
//
//        // Now you can do something with the JWT. Like send it to some other party
//        // over the clouds and through the interwebs.
//        System.out.println("JWT: " + jwt);
//    }

//    void enc(PublicKey remotePublicKey, String directoryServerId) throws JoseException {
//        // Generate an EC key pair, which will be used for signing and verification of the JWT, wrapped in a JWK
//        EllipticCurveJsonWebKey senderJwk = EcJwkGenerator.generateJwk(EllipticCurves.P256);
//
//        // Give the JWK a Key ID (kid), which is just the polite thing to do
//        senderJwk.setKeyId("sender's key");
//
//        // Generate an EC key pair, wrapped in a JWK, which will be used for encryption and decryption of the JWT
//        EllipticCurveJsonWebKey receiverJwk = (EllipticCurveJsonWebKey) PublicJsonWebKey.Factory.newPublicJwk(remotePublicKey);
//
//        // The outer JWT is a JWE
//        JsonWebEncryption jwe = new JsonWebEncryption();
//
//        // The output of the ECDH-ES key agreement will encrypt a randomly generated content encryption key
//        jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.ECDH_ES);
//
//        // The content encryption key is used to encrypt the payload
//        // with a composite AES-CBC / HMAC SHA2 encryption algorithm
//        jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
//
//        // We encrypt to the receiver using their public key
//        jwe.setKey(receiverJwk.getPublicKey());
//        jwe.setKeyIdHeaderValue(receiverJwk.getKeyId());
//
//        // A nested JWT requires that the cty (Content Type) header be set to "JWT" in the outer JWT
//        jwe.setContentTypeHeaderValue("JWT");
//        jwe.setHeader(HeaderParameterNames.AGREEMENT_PARTY_V_INFO, directoryServerId);
// //        jwe.setHeader(HeaderParameterNames.EPHEMERAL_PUBLIC_KEY, directoryServerJwk.toJson());
//
//        // A JWT is a JWS and/or a JWE with JSON claims as the payload.
//        // In this example it is a JWS nested inside a JWE
//        // So we first create a JsonWebSignature object.
//        JsonWebSignature jws = new JsonWebSignature();
//
//        // The JWT is signed using the sender's private key
//        jws.setKey(senderJwk.getPrivateKey());
//
//        // Set the Key ID (kid) header because it's just the polite thing to do.
//        // We only have one signing key in this example but a using a Key ID helps
//        // facilitate a smooth key rollover process
//        jws.setKeyIdHeaderValue(senderJwk.getKeyId());
//
//        // Set the signature algorithm on the JWT/JWS that will integrity protect the claims
//        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
//
//        // Sign the JWS and produce the compact serialization, which will be the inner JWT/JWS
//        // representation, which is a string consisting of three dot ('.') separated
//        // base64url-encoded parts in the form Header.Payload.Signature
//        String innerJwt = jws.getCompactSerialization();
//
//
//        // The inner JWT is the payload of the outer JWT
//        jwe.setPayload(innerJwt);
//
//        // Produce the JWE compact serialization, which is the complete JWT/JWE representation,
//        // which is a string consisting of five dot ('.') separated
//        // base64url-encoded parts in the form Header.EncryptedKey.IV.Ciphertext.AuthenticationTag
//        String jwt = jwe.getCompactSerialization();
//
//
//        // Now you can do something with the JWT. Like send it to some other party
//        // over the clouds and through the interwebs.
//        System.out.println("JWT: " + jwt);
//    }

//    String encrypt(String plain, JsonWebKey dsJwk, String dsId) throws JoseException {
//
//        // Create a new Json Web Encryption object
//        JsonWebEncryption jwe = new JsonWebEncryption();
//
//        // The plaintext of the JWE is the message that we want to encrypt.
////        senderJwe.setPlaintext(plain);
//
//        // Set the "alg" header, which indicates the key management mode for this JWE.
//        jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.ECDH_ES);
//
//        jwe.setHeader(HeaderParameterNames.AGREEMENT_PARTY_V_INFO, dsId);
//        jwe.setHeader(HeaderParameterNames.EPHEMERAL_PUBLIC_KEY, dsJwk.toJson());
//
//        // Set the "enc" header, which indicates the content encryption algorithm to be used.
//        // This example is using AES_128_CBC_HMAC_SHA_256 which is a composition of AES CBC
//        // and HMAC SHA2 that provides authenticated encryption.
//        jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
//
//        // Set the key on the JWE. In this case, using direct mode, the key will used directly as
//        // the content encryption key. AES_128_CBC_HMAC_SHA_256, which is being used to encrypt the
//        // content requires a 256 bit key.
//        jwe.setKey(dsJwk.getKey());
//
//        // Produce the JWE compact serialization, which is where the actual encryption is done.
//        // The JWE compact serialization consists of five base64url encoded parts
//        // combined with a dot ('.') character in the general format of
//        // <header>.<encrypted key>.<initialization vector>.<ciphertext>.<authentication tag>
//        // Direct encryption doesn't use an encrypted key so that field will be an empty string
//        // in this case.
//        String compactSerialization = senderJwe.getCompactSerialization();
//
//        // Do something with the JWE. Like send it to some other party over the clouds
//        // and through the interwebs.
//        System.out.println("[3dsSdkCrypto] JWE compact serialization: " + compactSerialization);
//
//        return compactSerialization;
//    }

    public String decrypt_numbus(String encrypted, String ecPublicKeyPem)
            throws ParseException, JOSEException, InvalidInputException
    {

//        ecPublicKeyPem = "-----BEGIN CERTIFICATE----- " + ecPublicKeyPem + " -----END CERTIFICATE-----";
//        JWK ecPublicJWK = ECKey.parseFromPEMEncodedX509Cert(ecPublicKeyPem);

        String[] components = encrypted.split("\\.");
        if (components.length != 3) {
            Log.d(TAG, "decrypt() -> " +
                    "throw new InvalidInputException(\"Wrong ACS data encryption\"), " +
                    "encrypted data contains "+components.length+" components instead of 3");
            throw new InvalidInputException("Wrong ACS data encryption 1");
        }
        JWSObject jwsObject = new JWSObject(
                new Base64URL(components[0]),
                new Base64URL(components[1]),
                new Base64URL(components[2])
        );

        byte[] decode = SimplePEMEncoder.decode(ecPublicKeyPem);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(decode);

        ecPublicKeyPem = "-----BEGIN CERTIFICATE----- " + ecPublicKeyPem + " -----END CERTIFICATE-----";
        X509Certificate cert = X509CertUtils.parse(ecPublicKeyPem);
        ECKey key = ECKey.parse(cert);

        // The recipient creates a verifier with the public EC key
        JWSVerifier verifier = new ECDSAVerifier(key);

        // Verify the EC signature
        if (!jwsObject.verify(verifier)) {
            Log.d(TAG, "decrypt() -> " +
                    "throw new InvalidInputException(\"Wrong ACS data encryption - invalid JWS\")");
            throw new InvalidInputException("Wrong ACS data encryption - invalid JWS");
        }

        return jwsObject.getPayload().toString();
    }

    public String decrypt(String encrypted, Key key) throws JoseException, InvalidInputException {
        Log.d(TAG, "decrypt(" + encrypted + ")");

        // Create a new JsonWebSignature object
        JsonWebSignature jws = new JsonWebSignature();

        // Set the algorithm constraints based on what is agreed upon or expected from the sender
        AlgorithmConstraints algConstraints = new AlgorithmConstraints(
                AlgorithmConstraints.ConstraintType.WHITELIST,
                AlgorithmIdentifiers.RSA_PSS_USING_SHA256,
                AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
        jws.setAlgorithmConstraints(algConstraints);

        // Set the compact serialization on the JWS
        jws.setCompactSerialization(encrypted);

        // The verification key on the JWS is the public key from the JWK we pulled from the JWK Set.
        jws.setKey(key);

        // Check the signature
        if (!jws.verifySignature()) {
            Log.d(TAG, "decrypt() -> " +
                    "throw new InvalidInputException(\"Wrong ACS data encryption - invalid JWS\")");
            throw new InvalidInputException("Wrong ACS data encryption - invalid JWS");
        }

        // Do something useful with the result of signature verification
        Log.d(TAG, "decrypt() -> JWS Signature is valid");

        // Get the payload, or signed content, from the JWS
        String payload = jws.getPayload();
        Log.d(TAG, "decrypt() -> payload = " + payload);

        return payload;
    }

//    public String decrypt(String encrypted, Key key) throws JoseException, InvalidInputException {
//        // That other party, the receiver, can then use JsonWebEncryption to decrypt the message.
//        JsonWebEncryption receiverJwe = new JsonWebEncryption();
//
//        // Set the algorithm constraints based on what is agreed upon or expected from the sender
//        AlgorithmConstraints algConstraints = new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST, KeyManagementAlgorithmIdentifiers.RSA_OAEP_256);
//        receiverJwe.setAlgorithmConstraints(algConstraints);
//        AlgorithmConstraints encConstraints = new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST, ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
//        receiverJwe.setContentEncryptionAlgorithmConstraints(encConstraints);
//
//        String[] components = encrypted.split("\\.");
//        if (components.length != 3) {
//            Log.d(TAG, "decrypt() -> " +
//                    "throw new InvalidInputException(\"Wrong ACS data encryption\"), " +
//                    "encrypted data contains "+components.length+" components instead of 3");
//            throw new InvalidInputException("Wrong ACS data encryption 1");
//        }
//
//        Gson gson = new Gson();
//
//        String decodedProtectedHeader = Base64Url.decodeToUtf8String(components[0]);
//        Log.d(TAG, "decrypt() -> decodedProtectedHeader = " + decodedProtectedHeader);
//        AcsJwsProtectedHeader protectedHeader = gson.fromJson(decodedProtectedHeader, AcsJwsProtectedHeader.class);
//        if (protectedHeader == null || !protectedHeader.isValid()) {
//            Log.d(TAG, "decrypt() -> " +
//                    "throw new InvalidInputException(\"Wrong ACS data encryption\")");
//            throw new InvalidInputException("Wrong ACS data encryption 2");
//        }
//
//        X509Util xu = X509Util.getX509Util(null);
//
//        X509Certificate leaf = xu.fromBase64Der(protectedHeader.x5c.get(0));
//        X509Certificate root = xu.fromBase64Der(protectedHeader.x5c.get(1));
//
//        String decodedPayload = Base64Url.decodeToUtf8String(components[1]);
//        Log.d(TAG, "decrypt() -> decodedProtectedHeader = " + decodedProtectedHeader);
//        AcsPayload payload = gson.fromJson(decodedPayload, AcsPayload.class);
//        if (payload == null || !payload.isValid()) {
//            Log.d(TAG, "decrypt() -> throw new InvalidInputException(\"Wrong ACS data encryption\")");
//            throw new InvalidInputException("Wrong ACS data encryption 3");
//        }
//
//        receiverJwe.setCertificateChainHeaderValue(leaf, root);
//
////        // Set the compact serialization on new Json Web Encryption object
////        receiverJwe.setCompactSerialization(encrypted);
//
//        // Symmetric encryption, like we are doing here, requires that both parties have the same key.
//        // The key will have had to have been securely exchanged out-of-band somehow.
//        receiverJwe.setKey(jwk.getKey());
//
//        // Get the message that was encrypted in the JWE. This step performs the actual decryption steps.
//        String plaintext = receiverJwe.getPlaintextString();
//
//        // And do whatever you need to do with the clear text message.
//        Log.d(TAG, "plaintext: " + plaintext);
//
//        return plaintext;
//    }
}

class AcsJwsProtectedHeader {
    List<String> x5c;
    String alg;

    Boolean isValid() {
        return !TextUtils.isEmpty(alg) && x5c != null && x5c.size() == 2;
    }
}

class AcsPayload {
    String acsURL;
    EphemPubKey acsEphemPubKey;
    EphemPubKey sdkEphemPubKey;

    Boolean isValid() {
        return !TextUtils.isEmpty(acsURL) &&
                acsEphemPubKey != null && acsEphemPubKey.isValid() &&
                sdkEphemPubKey != null && sdkEphemPubKey.isValid();
    }
}

class EphemPubKey {
    String kty;
    String crv;
    String x;
    String y;

    Boolean isValid() {
        return !TextUtils.isEmpty(kty) &&
                !TextUtils.isEmpty(crv) &&
                !TextUtils.isEmpty(x) &&
                !TextUtils.isEmpty(y);
    }
}
package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

public // NUVEI_MOBILE_SDK
class CardDetails: Serializable {
    public constructor(
            cardNumber: String?,
            cardHolderName: String?,
            cvv: String?,
            expirationMonth: String,
            expirationYear: String
    ): this(cardNumber?.replace(" ", ""), cardHolderName, cvv, expirationMonth, expirationYear, null)

    constructor(
            cardNumber: String?,
            cardHolderName: String?,
            cvv: String?,
            expirationMonth: String,
            expirationYear: String,
            threeD: ThreeD?
    ) {
        this.cardNumber = if (cardNumber != "") cardNumber?.replace(" ", "") else null
        this.cardHolderName = if (cardHolderName != "") cardHolderName else null
        this.CVV = if (cvv != "") cvv else null
        this.expirationMonth = expirationMonth
        this.expirationYear = expirationYear
        this.threeD = threeD
    }
    public constructor(
        externalToken: ExternalToken
    ) {
        this.externalToken = externalToken
        this.cardNumber = null
        this.cardHolderName = null
        this.CVV = null
        this.expirationMonth = null
        this.expirationYear = null
        this.threeD = null
    }

    public constructor(ccTempToken: String, cardHolderName: String? = null) {
        this.ccTempToken = ccTempToken
        this.externalToken = null
        this.cardNumber = null
        this.cardHolderName = cardHolderName
        this.CVV = null
        this.expirationMonth = null
        this.expirationYear = null
        this.threeD = null
    }

    @SerializedName("cardNumber") val cardNumber: String?
    @SerializedName("cardHolderName") val cardHolderName: String?
    @SerializedName("CVV") val CVV: String?
    @SerializedName("expirationMonth") val expirationMonth: String?
    @SerializedName("expirationYear") val expirationYear: String?

    @SerializedName("threeD") var threeD: ThreeD? = null
    @SerializedName("externalToken") var externalToken: ExternalToken? = null
    @SerializedName("ccTempToken") var ccTempToken: String? = null

    class ExternalToken(
        @SerializedName("externalTokenProvider") var externalTokenProvider: String,
        @SerializedName("mobileToken") var mobileToken: String
    ): Serializable
}

public // NUVEI_MOBILE_SDK
class ThreeD (
        @SerializedName("sdk") val sdk: Sdk
): Serializable

public // NUVEI_MOBILE_SDK
class Sdk(
        @SerializedName("transID") var transID: String? = null,
        @SerializedName("encData") var encData: String? = null,
        @SerializedName("ephemPubKey") var ephemPubKey: String? = null,
        @SerializedName("referenceNumber") var referenceNumber: String? = null,
        @SerializedName("appID") var appID: String? = null,
        @SerializedName("messageVersion") var messageVersion: String? = null,
        @SerializedName("maxTimeout") var maxTimeout: String? = null,
        @SerializedName("appSdkInterface") val appSdkInterface: String = "02",
        @SerializedName("appSdkUIType") val appSdkUIType: String = "05"// TODO: Change to "01,02,03,04,05"
): Serializable

public // NUVEI_MOBILE_SDK
class V2AdditionalParams(
        @SerializedName("appSdkInterface") val appSdkInterface: String = "02",
        @SerializedName("appSdkUIType") val appSdkUIType: String = "05",// TODO: Change to "01,02,03,04,05"
        @SerializedName("challengeWindowSize") var challengeWindowSize: String = "05"
)

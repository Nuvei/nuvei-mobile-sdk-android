package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName

data class UPOsInput(
    @SerializedName("sessionToken") val sessionToken: String,
    @SerializedName("merchantSiteId") val merchantSiteId: String,
    @SerializedName("merchantId") val merchantId: String,
    @SerializedName("currencyCode") val currencyCode: String,
    @SerializedName("countryCode") val countryCode: String?,
    @SerializedName("sourceApplication") val sourceApplication: String? = null
)

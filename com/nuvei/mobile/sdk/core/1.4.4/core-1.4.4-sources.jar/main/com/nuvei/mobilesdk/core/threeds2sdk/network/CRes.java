package com.nuvei.mobilesdk.core.threeds2sdk.network;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class CRes implements Serializable {

    @SerializedName("threeDSServerTransID")
    private
    String threeDSServerTransID;

    @SerializedName("acsCounterAtoS")
    private
    String acsCounterAtoS;

    @SerializedName("acsTransID")
    private
    String acsTransID;

    @SerializedName("acsHTML")
    private
    String acsHTML;

    @SerializedName("acsHTMLRefresh")
    private
    String acsHTMLRefresh;

    @SerializedName("acsUiType")
    private
    String acsUiType;

    @SerializedName("challengeCompletionInd")
    private
    String challengeCompletionInd;

    @SerializedName("challengeInfoHeader")
    private
    String challengeInfoHeader;

    @SerializedName("challengeInfoLabel")
    private
    String challengeInfoLabel;

    @SerializedName("challengeAddInfo")
    private
    String challengeAddInfo;

    @SerializedName("challengeInfoText")
    private
    String challengeInfoText;

    @SerializedName("challengeInfoTextIndicator")
    private
    String challengeInfoTextIndicator;

    @SerializedName("challengeSelectInfo")
    private
    List<Map<String, String>> challengeSelectInfo;

    @SerializedName("expandInfoLabel")
    private
    String expandInfoLabel;

    @SerializedName("expandInfoText")
    private
    String expandInfoText;

    @SerializedName("issuerImage")
    private
    Image issuerImage;

    @SerializedName("messageExtension")
    private
    List<MessageExtension> messageExtension;

    @SerializedName("messageType")
    private
    String messageType;

    @SerializedName("messageVersion")
    private
    String messageVersion;

    @SerializedName("oobAppURL")
    private
    String oobAppURL;

    @SerializedName("oobAppLabel")
    private
    String oobAppLabel;

    @SerializedName("oobContinueLabel")
    private
    String oobContinueLabel;

    @SerializedName("psImage")
    private
    Image psImage;

    @SerializedName("resendInformationLabel")
    private
    String resendInformationLabel;

    @SerializedName("sdkTransID")
    private
    String sdkTransID;

    @SerializedName("submitAuthenticationLabel")
    private
    String submitAuthenticationLabel;

    @SerializedName("whitelistingInfoText")
    private
    String whitelistingInfoText;

    @SerializedName("whyInfoLabel")
    private
    String whyInfoLabel;

    @SerializedName("whyInfoText")
    private
    String whyInfoText;

    /**
     * Transaction Status
     */
    @SerializedName("transStatus")
    private
    String transStatus;

    /**
     * 3DS Server Transaction ID
     */
    public String getThreeDSServerTransID() {
        return threeDSServerTransID;
    }

    /**
     * ACS Counter ACS to SDK
     * Counter used as a security measure in the ACS to 3DS SDK secure channel.
     * Length: 3 characters
     */
    public String getAcsCounterAtoS() {
        return acsCounterAtoS;
    }

    /**
     * ACS Transaction ID
     */
    public String getAcsTransID() {
        return acsTransID;
    }

    /**
     * ACS HTML
     */
    public String getAcsHTML() {
        return acsHTML;
    }

    /**
     * ACS UI Type
     */
    public String getAcsUiType() {
        return acsUiType;
    }

    /**
     * Challenge Completion Indicator
     */
    public String getChallengeCompletionInd() {
        return challengeCompletionInd;
    }

    /**
     * Challenge Information Header
     */
    public String getChallengeInfoHeader() {
        return challengeInfoHeader;
    }

    /**
     * Challenge Information Label
     */
    public String getChallengeInfoLabel() {
        return challengeInfoLabel;
    }

    /**
     * Challenge Information Text
     */
    public String getChallengeInfoText() {
        return challengeInfoText;
    }

    public String getAcsHTMLRefresh() {
        return acsHTMLRefresh;
    }

    /**
     * Challenge Information Text Indicator
     */
    public String getChallengeInfoTextIndicator() {
        return challengeInfoTextIndicator;
    }

    /**
     * Challenge Selection Information
     */
    public List<Map<String, String>> getChallengeSelectInfo() {
        return challengeSelectInfo;
    }

    /**
     * Expandable Information Label
     */
    public String getExpandInfoLabel() {
        return expandInfoLabel;
    }

    /**
     * Expandable Information Text
     */
    public String getExpandInfoText() {
        return expandInfoText;
    }

    /**
     * Issuer Image
     */
    public Image getIssuerImage() {
        return issuerImage;
    }

    /**
     * Message Extension
     */
    public List<MessageExtension> getMessageExtension() {
        return messageExtension;
    }

    /**
     * Message Type
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * Message Version Number
     */
    public String getMessageVersion() {
        return messageVersion;
    }

    /**
     * OOB App URL
     */
    public String getOobAppURL() {
        return oobAppURL;
    }

    /**
     * OOB App Label
     */
    public String getOobAppLabel() {
        return oobAppLabel;
    }

    /**
     * OOB Continuation Label
     */
    public String getOobContinueLabel() {
        return oobContinueLabel;
    }

    /**
     * Payment System Image
     */
    public Image getPsImage() {
        return psImage;
    }

    /**
     * Resend Information Label
     */
    public String getResendInformationLabel() {
        return resendInformationLabel;
    }

    /**
     * SDK Transaction ID
     */
    public String getSdkTransID() {
        return sdkTransID;
    }

    /**
     * Submit Authentication Label
     */
    public String getSubmitAuthenticationLabel() {
        return submitAuthenticationLabel;
    }

    /**
     * Challenge Additional Information
     */

    public String getChallengeAddInfo() {
        return challengeAddInfo;
    }

    /**
     * Whitelisting Information Text
     */
    public String getWhitelistingInfoText() {
        return whitelistingInfoText;
    }

    /**
     * Why Information Label
     */
    public String getWhyInfoLabel() {
        return whyInfoLabel;
    }

    /**
     * Why Information Text
     */
    public String getWhyInfoText() {
        return whyInfoText;
    }

    public String getTransStatus() {
        return transStatus;
    }

    public class Image implements Serializable {
        @SerializedName("medium")
        private
        String medium;

        @SerializedName("high")
        private
        String high;

        @SerializedName("extraHigh")
        private
        String extraHigh;

        public String getMedium() {
            return medium;
        }

        public String getHigh() {
            if (high != null){
                return high;
            } else{
                return medium;
            }
        }

        public String getExtraHigh() {
            if (extraHigh != null) {
                return extraHigh;
            } else {
                return getHigh();
            }
        }
    }

    public class MessageExtension implements Serializable {
        @SerializedName("name")
        private
        String name;

        @SerializedName("id")
        private
        String id;

        @SerializedName("criticalityIndicator")
        private
        Boolean criticalityIndicator;

        @SerializedName("data")
        private
        Map<String,Object> data;

        public String getName() {
            return name;
        }

        public String getId() {
            return id;
        }

        public Boolean getCriticalityIndicator() {
            return criticalityIndicator;
        }

        public Map<String,Object> getData() {
            return data;
        }
    }
}

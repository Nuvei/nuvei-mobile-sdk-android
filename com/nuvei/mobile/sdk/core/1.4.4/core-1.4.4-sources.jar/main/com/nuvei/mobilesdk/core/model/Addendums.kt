package com.nuvei.mobilesdk.core.model

class Addendums {
    var localPayment: LocalPayment? = null
}

class LocalPayment(
    var nationalId: String? = null,
    val installmentType: String? = null,
    val numberOfInstallments: String? = null
)
package com.nuvei.mobilesdk.core.threeds2sdk.network;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

/**
 *
 *  {
 *      "acsURL":"https:\/\/simulator-3ds.selftestplatform.com\/v2.1.0\/acs\/1598\/",
 *      "acsEphemPubKey":{
 *          "kty":"EC",
 *          "crv":"P-256",
 *          "x":"ebckjjDtRkD0Gh6ihXhcn1IwkyceYXHUVkkixoInZ1A",
 *          "y":"54pAn_HcMYNimZv96XIsMVKrkzjVaX8Bjm587E_YS48"
 *      },
 *      "sdkEphemPubKey":{
 *          "kty":"EC",
 *          "crv":"P-256",
 *          "x":"TvZ7HaNESc_fBgW_yUQnxFNcmgaNcSyoNi67yoLgsnc",
 *          "y":"aQEI4RKzJnCkTwibI0Rnm-N9-5YVLvqIBJc89NzkhrU"
 *      }
 *  }
 */

public class AcsSignedContent {
    @SerializedName("acsEphemPubKey")
    private Map<String, Object> acsEphemPubKey;

    @SerializedName("sdkEphemPubKey")
    private Map<String, Object> sdkEphemPubKey;

    @SerializedName("acsURL")
    private String acsURL;

    public Map<String, Object> getAcsEphemPubKey() {
        return acsEphemPubKey;
    }

    public Map<String, Object> getSdkEphemPubKey() {
        return sdkEphemPubKey;
    }

    public String getAcsURL() {
        return acsURL;
    }
}

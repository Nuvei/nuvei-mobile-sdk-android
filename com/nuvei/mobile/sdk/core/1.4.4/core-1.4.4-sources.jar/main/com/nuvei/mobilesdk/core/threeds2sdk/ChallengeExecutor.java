package com.nuvei.mobilesdk.core.threeds2sdk;

import androidx.annotation.Nullable;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.threeds2sdk.ErrorMessage;
import com.nuvei.mobilesdk.core.threeds2sdk.Transaction;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CReq;
import com.nuvei.mobilesdk.core.threeds2sdk.network.CRes;

import java.lang.ref.WeakReference;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class ChallengeExecutor {

    interface Listener {
        void onStartedLoading();
        void onFinishedLoading();
        void handleCRes(final CRes cres);
        void finishActivity();
    }

    private interface SendErrorListener {
        void completed(boolean success);
    }

    private final static String TAG = "[3DSSDK][Ch.Executor]";

    private WeakReference<Transaction> transaction;
    private API api = new API();

    private Listener listener = null;

    private CRes lastCres = null;

    ChallengeExecutor(Transaction transaction) {
        this.transaction = new WeakReference<>(transaction);
    }

    void setListener(Listener listener) {
        this.listener = listener;
    }

    CRes getLastCres() {
        return lastCres;
    }

    void setLastCres(CRes lastCres) {
        this.lastCres = lastCres;
    }

    void performInitialChallenge() {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        CReq creq = transaction.generateCReq();

        executeChallenge(creq);
    }

    void performChallengeWithHtml(String challengeHTMLDataEntry) {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        CReq creq = transaction.generateCReq();

        creq.setChallengeHTMLDataEntry(challengeHTMLDataEntry);

        executeChallenge(creq);
    }

    void performChallengeWithData(String challengeDataEntry, Boolean whitelisting) {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        CReq creq = transaction.generateCReq();

        if (challengeDataEntry != null && !challengeDataEntry.isEmpty()) {
            creq.setChallengeDataEntry(challengeDataEntry);
        } else {
            creq.setChallengeNoEntry("Y");
        }
        if (whitelisting != null) {
            creq.setWhitelistingDataEntry(whitelisting ? "Y" : "N");
        }

        executeChallenge(creq);
    }

    void performChallengeResendCode() {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        CReq creq = transaction.generateCReq();
        creq.setResendChallenge("Y");

        executeChallenge(creq);
    }

    void performChallengeCancel() {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        CReq creq = transaction.generateCReq();
        creq.setChallengeCancel("01");

        executeChallenge(creq);
    }

    void performChallengeOobContinue(Boolean whitelisting) {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        CReq creq = transaction.generateCReq();
        creq.setOobContinue(true);
        if (whitelisting != null) {
            creq.setWhitelistingDataEntry(whitelisting ? "Y" : "N");
        }

        executeChallenge(creq);
    }

    private void executeChallenge(CReq creq) {
        final Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        onStartedLoading();

        Gson gson = new Gson();
        String requestJson = gson.toJson(creq, CReq.class);
        Log.d(TAG, "executeChallenge(): will send request, requestJson = " + requestJson);

        String url = transaction.acsURL;
        Log.d(TAG, "executeChallenge(): will send request, url = " + url);

        String encryptedRequest = null;
        byte[] cek = transaction.challengeKeys.getCek();

        // TODO: Remove in prod
//        ChallengeCrypto crypto = url.contains("13.93.90.79") ? new DebugChallengeCrypto(cek) : new ChallengeCrypto(cek);
        ChallengeCrypto crypto = new ChallengeCrypto(cek);

        try {
            encryptedRequest = crypto.encrypt(requestJson, transaction.challengeParameters.getAcsTransactionID());
        } catch (JOSEException e) {
            Log.d(TAG, "executeChallenge(): JOSEException: " + e);
            e.printStackTrace();
        } catch (ParseException e) {
            Log.d(TAG, "executeChallenge(): ParseException: " + e);
            e.printStackTrace();
        }
        Log.d(TAG, "executeChallenge(): will send request, encryptedRequest = " + encryptedRequest);

        try {
            api.post(url, creq, encryptedRequest, crypto, new API.Callback() {
                @Override
                public void onResponse(CReq creq, CRes cres) {
                    Log.d(TAG, "executeChallenge.onResponse: CRes = " + cres);
                    onFinishedLoading();

                    ErrorMessage error = validateCRes(cres, creq);
                    if (error != null) {
                        Log.d(TAG, "executeChallenge.onResponse.protocolError");
                        sendError(error);
                    } else if (isFinal(cres)) {
                        Log.d(TAG, "executeChallenge.onResponse.isFinal");
                        transaction.completed(cres.getSdkTransID(), cres.getTransStatus());
                        finish();
                    } else {
                        Log.d(TAG, "executeChallenge.onResponse.handleCRes");
                        handleCRes(cres);
                    }
                }

                @Override
                public void onFailure(CReq creq, Exception e) {
                    Log.d(TAG, "executeChallenge.onFailure: exception = " + e);
                    onFinishedLoading();

                    ErrorMessage error = validateCResException(creq, e);

                    if (error != null) {
                        Log.d(TAG, "executeChallenge.onResponse.protocolError");
                        sendError(error);
                    } else {
                        Log.d(TAG, "executeChallenge.onResponse.runtimeError");
                        ErrorMessage errorMessage = new ErrorMessage(creq);
                        errorMessage.setErrorCode("402");
                        errorMessage.setErrorDescription("Transaction timed-out.");
                        errorMessage.setErrorDetail("Timeout expiry reached for the transaction as defined in Section 5.5.");
                        sendError(errorMessage, new SendErrorListener() {
                            @Override
                            public void completed(boolean success) {
                                transaction.runtimeError("-1032", "Timeout");
                            }
                        });
                    }
                }

                @Override
                public void onProtocolError(CReq creq, ErrorMessage error) {
                    Log.d(TAG, "executeChallenge.onProtocolError: error = " + error);
                    onFinishedLoading();

                    transaction.protocolError(error);
                    finish();
                }
            });
        } catch (Exception ex) {
            Log.d(TAG, "executeChallenge.catch: exception = " + ex);
            onFinishedLoading();
            transaction.runtimeError("-1010", "Failed to send CReq message, ex = " + ex.getLocalizedMessage());
        }
    }

    @Nullable
    private ErrorMessage validateCResException(CReq cReq, Exception e) {
        if (e instanceof JsonSyntaxException || e instanceof IllegalStateException || e instanceof NullPointerException || e instanceof InvalidInputException) {
            ErrorMessage errorMessage = new ErrorMessage(cReq);
            errorMessage.setErrorCode("101");
            errorMessage.setErrorDescription("Message not recognised");
            errorMessage.setErrorDetail("Invalid Formatted Message");
            return errorMessage;
        }

        return null;
    }

    private void sendError(final ErrorMessage error) {
        sendError(error, new SendErrorListener() {
            @Override
            public void completed(boolean success) {
                Transaction transaction = ChallengeExecutor.this.transaction.get();
                if (transaction == null) {
                    return;
                }

                transaction.protocolError(error);
            }
        });
    }

    private void sendError(final ErrorMessage error, @Nullable final SendErrorListener listener) {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            return;
        }

        api.post(transaction.acsURL, error, new API.ErrorCallback() {
            @Override
            public void onResponse(ErrorMessage responseError) {
                Log.d(TAG, "sendError.onResponse: responseError = " + responseError);

                if (listener != null) {
                    listener.completed(true);
                }

                finish();
            }

            @Override
            public void onFailure(Exception e) {
                Log.d(TAG, "sendError.onFailure: exception = " + e);

                if (listener != null) {
                    listener.completed(true);
                }

                finish();
            }
        });
    }

    private boolean isFinal(CRes cres) {
        String challengeCompletionInd = cres.getChallengeCompletionInd();
        return "Y".equals(challengeCompletionInd);
    }

    private ErrorMessage validateCRes(CRes cres, CReq cReq) {
        Transaction transaction = this.transaction.get();
        if (transaction == null) {
            ErrorMessage error = new ErrorMessage(cReq);
            error.setMessageVersion("2.2.0");
            error.setErrorCode("102");
            error.setErrorDescription("Message Version Number received is not valid for the receiving component");
            error.setErrorDetail("2.2.0");
            return error;
        }

        String missingRequiredElements = "|";

        // Required
        String threeDSServerTransID = cres.getThreeDSServerTransID();
        String acsCounterAtoS = cres.getAcsCounterAtoS();
        String acsTransID = cres.getAcsTransID();
        String challengeCompletionInd = cres.getChallengeCompletionInd();
        String messageType = cres.getMessageType();
        String messageVersion = cres.getMessageVersion();
        String sdkTransID = cres.getSdkTransID();
        if (isNullOrEmpty(threeDSServerTransID)) {
            missingRequiredElements += ",threeDSServerTransID";
        } else {
            if (!threeDSServerTransID.equals(cReq.getThreeDSServerTransID())) {
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("301");
                error.setErrorDescription("Transaction ID received is not valid for the receiving component.");
                error.setErrorDetail("The Transaction ID received was invalid.");
                return error;
            }
        }
        if (isNullOrEmpty(acsCounterAtoS)) {
            missingRequiredElements += ",acsCounterAtoS";
        } else {
            if (lastCres != null) {
                Log.d(TAG, "validateCRes: [AtoS] acsCounterAtoS = |" + acsCounterAtoS + "|");
                Log.d(TAG, "validateCRes: [AtoS] lastAcsCounterAtoS = |" + lastCres.getAcsCounterAtoS() + "|");
                if (Integer.valueOf(acsCounterAtoS) <= Integer.valueOf(lastCres.getAcsCounterAtoS())) {
                    Log.d(TAG, "validateCRes: [AtoS] ErrorMessage 302");
                    ErrorMessage error = new ErrorMessage(cReq);
                    error.setErrorCode("302");
                    error.setErrorDescription("Data could not be decrypted by the receiving system due to technical or other reason.");
                    error.setErrorDetail("Mismatch between the SDK Counter ACS to SDK and the ACS Counter ACS to SDK is detected by the 3DS SDK.");
                    return error;
                }
            } else {
                Log.d(TAG, "validateCRes: [AtoS] lastCres = |nil|");
            }
        }
        if (isNullOrEmpty(acsTransID)) {
            missingRequiredElements += ",acsTransID";
        } else {
            Log.d(TAG, "acsTransID = " + acsTransID);
            if (!acsTransID.equals(cReq.getAcsTransID())) {
                Log.d(TAG, "acsTransID not equal to " + cReq.getAcsTransID());
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("301");
                error.setErrorDescription("Transaction ID received is not valid for the receiving component.");
                error.setErrorDetail("The Transaction ID received was invalid.");
                return error;
            }
            Log.d(TAG, "acsTransID is equal to " + cReq.getAcsTransID());

            if (!Pattern.matches("[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}", acsTransID)) {
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("301");
                error.setErrorDescription("Transaction ID received is not valid for the receiving component.");
                error.setErrorDetail("The Transaction ID received was invalid.");
                return error;
            }
        }
        if (isNullOrEmpty(challengeCompletionInd)) {
            missingRequiredElements += ",challengeCompletionInd";
        }
        if (isNullOrEmpty(messageType)) {
            missingRequiredElements += ",messageType";
        }
        if (isNullOrEmpty(messageVersion)) {
            missingRequiredElements += ",messageVersion";
        }
        if (isNullOrEmpty(sdkTransID)) {
            missingRequiredElements += ",sdkTransID";
        } else {
            if (!sdkTransID.equals(cReq.getSdkTransID())) {
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("301");
                error.setErrorDescription("Transaction ID received is not valid for the receiving component.");
                error.setErrorDetail("The Transaction ID received was invalid.");
                return error;
            }
        }
        if (missingRequiredElements.length() > 1) {
            missingRequiredElements = missingRequiredElements.replace("|,", "");
            ErrorMessage error = new ErrorMessage(cReq);
            error.setErrorCode("201");
            error.setErrorDescription("A message element required as defined in Table A.1 is missing from the message");
            error.setErrorDetail(missingRequiredElements);
            error.setMessageVersion(transaction.getMessageVersion());
            return error;
        }

        if (!"CRes".equals(messageType)) {
            ErrorMessage error = new ErrorMessage(cReq);
            error.setErrorCode("101");
            error.setErrorDescription("Message is not CRes");
            error.setErrorDetail("Invalid message type");
            return error;
        }

        if (!transaction.getMessageVersion().equals(messageVersion)) {
            ErrorMessage error = new ErrorMessage(cReq);
            error.setMessageVersion(transaction.getMessageVersion());
            error.setErrorCode("102");
            error.setErrorDescription("Message Version Number received is not valid for the receiving component");
            error.setErrorDetail(transaction.getMessageVersion());
            return error;
        }

        // Conditional
        String invalidElements = "|";
        if (threeDSServerTransID.length() > 36) {
            invalidElements += ",threeDSServerTransID";
        }

        if (acsCounterAtoS.length() > 3) {
            Log.d(TAG, "validateCRes: [AtoS] acsCounterAtoS.count > 3");
            invalidElements += ",acsCounterAtoS";
        }

        if (acsTransID.length() > 36) {
            invalidElements += ",acsTransID";
        }

        if (challengeCompletionInd.length() != 1) {
            invalidElements += ",challengeCompletionInd";
        } else {
            if (!challengeCompletionInd.equals("Y") && !challengeCompletionInd.equals("N")) {
                invalidElements += ",challengeCompletionInd";
            }
        }

        if (messageType.length() > 4) {
            invalidElements += ",messageType";
        }

        if (messageVersion.length() < 5 && messageVersion.length() > 8) {
            invalidElements += ",messageVersion";
        }

        if (sdkTransID.length() > 36) {
            invalidElements += ",sdkTransID";
        }

        if (cres.getChallengeInfoTextIndicator() != null && cres.getChallengeInfoTextIndicator().equals("")) {
            invalidElements += ",challengeInfoTextIndicator";
        }

        if (cres.getResendInformationLabel() != null && cres.getResendInformationLabel().equals("")) {
            invalidElements += ",resendInformationLabel";
        }

        if (cres.getWhitelistingInfoText() != null && cres.getWhitelistingInfoText().length() > 64) {
            invalidElements += ",whitelistingInfoText";
        }

        if (cres.getAcsHTML() != null) {
            String acsHTML = cres.getAcsHTML();
            if (acsHTML.endsWith("=") || acsHTML.contains("/") || acsHTML.contains(" ") || acsHTML.contains("+") || acsHTML.contains("\n")) {
                invalidElements += ",acsHTML";
            }
        }

        if (cres.getAcsHTMLRefresh() != null) {
            String acsHTML = cres.getAcsHTMLRefresh();
            if (acsHTML.endsWith("=") || acsHTML.contains("/") || acsHTML.contains(" ") || acsHTML.contains("+") || acsHTML.contains("\n")) {
                invalidElements += ",acsHTMLRefresh";
            }
        }

        if (invalidElements.length() > 1) {
            invalidElements = invalidElements.replace("|,", "");
            ErrorMessage error = new ErrorMessage(cReq);
            error.setErrorCode("203");
            error.setErrorDescription("Data element not in the required format or value is invalid as defined in Table A.1");
            error.setErrorDetail(invalidElements);
            return error;
        }

        if (cres.getMessageExtension() != null && !cres.getMessageExtension().isEmpty()) {
            ErrorMessage error = new ErrorMessage(cReq);
            error.setErrorCode("203");
            error.setErrorDescription("Data element not in the required format or value is invalid as defined in Table A.1");
            error.setErrorDetail("name");

            if (cres.getMessageExtension().size() > 10) {
                return error;
            } else {
                String invalidMessagesIds = "|";
                for (int i = 0; i < cres.getMessageExtension().size(); i++) {
                    CRes.MessageExtension messageExtension = cres.getMessageExtension().get(i);

                    if (messageExtension.getCriticalityIndicator()) {
                        invalidMessagesIds += "," + messageExtension.getId();
                    }

                    if (messageExtension.getName().length() > 64) {
                        return error;
                    }

                    if (messageExtension.getId().length() > 64) {
                        return error;
                    }

                    if (messageExtension.getData() != null) {
                        Object messageExtensionText = messageExtension.getData().get("text");
                        if (messageExtensionText instanceof String && ((String) messageExtensionText).length() > 8059) {
                            return error;
                        }
                    }
                }

                if (invalidMessagesIds.length() > 1) {
                    invalidMessagesIds = invalidMessagesIds.replace("|,", "");
                    ErrorMessage notRecognizedError = new ErrorMessage(cReq);
                    notRecognizedError.setErrorCode("202");
                    notRecognizedError.setErrorDescription("Critical message extension not recognised.");
                    notRecognizedError.setErrorDetail(invalidMessagesIds);
                    return notRecognizedError;
                }
            }
        }

        if (challengeCompletionInd.equals("Y")) {
            String transStatus = cres.getTransStatus();// Required for final CRes
            if (isNullOrEmpty(transStatus)) {
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("201");
                error.setErrorDescription("A message element required as defined in Table A.1 is missing from the message");
                error.setErrorDetail("transStatus");
                return error;
            } else {
                if (!acsTransID.equals(lastCres.getAcsTransID())) {
                    ErrorMessage error = new ErrorMessage(cReq);
                    error.setErrorCode("301");
                    error.setErrorDescription("Transaction ID received is not valid for the receiving component.");
                    error.setErrorDetail("The Transaction ID received was invalid.");
                    return error;
                }
            }
        } else {
            String acsUiTypeString = cres.getAcsUiType();
            if (isNullOrEmpty(acsUiTypeString)) {
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("201");
                error.setErrorDescription("A message element required as defined in Table A.1 is missing from the message");
                error.setErrorDetail("acsUiType");
                return error;
            }
            int acsUiType;
            try {
                acsUiType = Integer.parseInt(acsUiTypeString);
            } catch (NumberFormatException e) {
                acsUiType = 0;
            }
            if (acsUiTypeString.length() != 2 || acsUiType < 1 || acsUiType > 5) {
                ErrorMessage error = new ErrorMessage(cReq);
                error.setErrorCode("203");
                error.setErrorDescription("Data element not in the required format or value is invalid as defined in Table A.1");
                error.setErrorDetail("acsUiType");
                return error;
            }

            if (acsUiType == 5) {
                String acsHTML = cres.getAcsHTML();// Required for UI type 01, 02 and 03
                if (isNullOrEmpty(acsHTML)) {
                    ErrorMessage error = new ErrorMessage(cReq);
                    error.setErrorCode("201");
                    error.setErrorDescription("A message element required as defined in Table A.1 is missing from the message");
                    error.setErrorDetail("acsHTML");
                    return error;
                }
            }

            String missingElements = "|";

            if (acsUiType <= 4) {
                if (acsUiType <= 3) {
                    String submitAuthenticationLabel = cres.getSubmitAuthenticationLabel();// Required for UI type 01, 02 and 03
                    if (isNullOrEmpty(submitAuthenticationLabel)) {
                        missingElements += ",submitAuthenticationLabel";
                    }

                    if (isNullOrEmpty(cres.getChallengeInfoLabel())) {
                        missingElements += ",challengeInfoLabel";
                    }
                }

                String challengeInfoHeader = cres.getChallengeInfoHeader();
                String challengeInfoText = cres.getChallengeInfoText();
                List<Map<String, String>> challengeSelectInfo = cres.getChallengeSelectInfo();

                if (isNullOrEmpty(challengeInfoHeader)) {
                    missingElements += ",challengeInfoHeader";
                }

                if (isNullOrEmpty(challengeInfoText)) {
                    missingElements += ",challengeInfoText";

                }

                if (acsUiType == 2 || acsUiType == 3) {
                    if (challengeSelectInfo == null || challengeSelectInfo.isEmpty()) {
                        missingElements += ",challengeSelectInfo";
                    }
                }

                if (missingElements.length() > 1) {
                    missingElements = missingElements.replace("|,", "");
                    ErrorMessage error = new ErrorMessage(cReq);
                    error.setErrorCode("201");
                    error.setErrorDescription("A message element required as defined in Table A.1 is missing from the message");
                    error.setErrorDetail(missingElements);
                    error.setMessageVersion(transaction.getMessageVersion());
                    return error;
                }

                if (acsUiType == 4) {
                    String oobContinueLabel = cres.getOobContinueLabel();
                    if (isNullOrEmpty(oobContinueLabel)) {
                        ErrorMessage error = new ErrorMessage(cReq);
                        error.setErrorCode("201");
                        error.setErrorDescription("A message element required as defined in Table A.1 is missing from the message");
                        error.setErrorDetail("oobContinueLabel");
                        error.setMessageVersion(transaction.getMessageVersion());
                        return error;
                    }
                }
            }
        }

        return null;
    }

    private boolean isNullOrEmpty(String string) {
        return string == null || string.isEmpty();
    }

    private void onStartedLoading() {
        Listener listener = this.listener;
        if (listener != null) {
            listener.onStartedLoading();
        }
    }

    private void onFinishedLoading() {
        Listener listener = this.listener;
        if (listener != null) {
            listener.onFinishedLoading();
        }
    }

    private void handleCRes(final CRes cres) {
        lastCres = cres;

        Listener listener = this.listener;
        if (listener != null) {
            listener.handleCRes(cres);
        } else {
            Log.d(TAG, "listener is null - handleCRes() didn't executed");
        }
    }

    private void finish() {
        Listener listener = this.listener;
        if (listener != null) {
            listener.finishActivity();
        }
    }

    // TODO: Remove in prod
//    private class DebugChallengeCrypto extends ChallengeCrypto {
//
//        DebugChallengeCrypto(byte[] sdkCek) {
//            super(sdkCek);
//        }
//
//        @Override
//        public String decrypt(String encrypted) {
//            return encrypted;
//        }
//
//        @Override
//        String encrypt(String creq, String transactionId) throws JOSEException, ParseException {
//            return creq;
//        }
//    }
}

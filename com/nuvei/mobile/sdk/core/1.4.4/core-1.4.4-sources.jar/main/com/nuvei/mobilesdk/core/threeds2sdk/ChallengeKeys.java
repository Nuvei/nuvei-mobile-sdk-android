package com.nuvei.mobilesdk.core.threeds2sdk;

import android.util.Log;

import org.apache.cxf.rs.security.jose.jwe.JweUtils;
import org.apache.cxf.rs.security.jose.jwk.JsonWebKey;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public class ChallengeKeys {

    private final static String TAG = "[3DSSDK][ChallengeKeys]";

    private JsonWebKey sdkJwk = null;
    private Map<String, Object> acsKey = null;
    private String sdkReferenceNumber = null;
    private byte[] cek = null;

    void setSdkJwk(JsonWebKey sdkJwk) {
        Log.d(TAG, "setSdkJwk(): sdkJwk = " + sdkJwk.asMap());
        this.sdkJwk = sdkJwk;
        cek = null;
    }

    void setAcsKey(Map<String, Object> acsKey) {
        Log.d(TAG, "setAcsKey(): acsKey = " + acsKey);
        this.acsKey = acsKey;
        cek = null;
    }

    void setSdkReferenceNumber(String sdkReferenceNumber) {
        Log.d(TAG, "setSdkReferenceNumber(): sdkReferenceNumber = " + sdkReferenceNumber);
        this.sdkReferenceNumber = sdkReferenceNumber;
        cek = null;
    }

    private void generateEncryptionCek() {
        JsonWebKey acsJwk = new JsonWebKey(acsKey);
        cek = JweUtils.getECDHKey(sdkJwk, acsJwk, null, sdkReferenceNumber.getBytes(StandardCharsets.UTF_8), "", 256);
    }

    byte[] getCek() {
        if (cek == null) {
            try {
                generateEncryptionCek();
            } catch (Exception e) {
                Log.e(TAG, "getCek(): e = " + e);
                throw e;
            }
        }
        return cek;
    }
}

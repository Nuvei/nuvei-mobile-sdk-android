package com.nuvei.mobilesdk.core.threeds2sdk;

import com.nuvei.mobilesdk.core.threeds2sdk.enums.Severity;

/**
 * The Warning class shall represent a warning that is produced by the 3DS SDK while performing security checks during initialization.
 */
public class Warning {
    private final String id;
    private final String message;
    private final Severity severity;

    Warning(String id, String message, Severity severity) {
        this.id = id;
        this.message = message;
        this.severity = severity;
    }

    /**
     * The getID method shall return the warning ID.
     * @return This method returns the warning ID as a string.
     */
    public String getID() {
        return id;
    }

    /**
     * The getMessage method shall return the warning message.
     * @return This method returns the warning message as a string.
     */
    public String getMessage() {
        return message;
    }

    /**
     * The getSeverity method shall return the severity level of the warning produced by the 3DS SDK.
     * @return This method returns the severity level of the warning as a Severity enum type.
     */
    public Severity getSeverity() {
        return severity;
    }
}

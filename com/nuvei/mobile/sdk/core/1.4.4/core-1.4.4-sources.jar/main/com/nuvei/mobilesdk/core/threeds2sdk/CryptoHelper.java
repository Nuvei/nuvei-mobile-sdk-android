package com.nuvei.mobilesdk.core.threeds2sdk;

import android.util.Log;
import android.util.Pair;

import com.nuvei.mobilesdk.core.nimbusds.jose.JOSEException;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWSAlgorithm;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWSObject;
import com.nuvei.mobilesdk.core.nimbusds.jose.JWSVerifier;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.ECDSAVerifier;
import com.nuvei.mobilesdk.core.nimbusds.jose.crypto.RSASSAVerifier;
import com.nuvei.mobilesdk.core.nimbusds.jose.jwk.ECKey;
import com.nuvei.mobilesdk.core.nimbusds.jose.util.X509CertUtils;
import com.nuvei.mobilesdk.core.threeds2sdk.DSPublicKey;
import com.nuvei.mobilesdk.core.threeds2sdk.crypto.ECDHCrypto;
import com.nuvei.mobilesdk.core.threeds2sdk.crypto.RSACrypto;
import com.nuvei.mobilesdk.core.threeds2sdk.exceptions.InvalidInputException;

import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

class CryptoHelper {

    private static final String TAG = "[3DSSDK][CryptoHelper]";

    static Pair<String, PublicKey> encrypt(String plain, DSPublicKey dsPublicKey, String dsId) throws JoseException, InvalidKeySpecException {
        Log.d(TAG, "encrypt("+plain+")");

        PublicKey otherPublicKey;
        switch (dsPublicKey.algorithm) {
            case EC:
                Log.d(TAG, "encrypt(...): handle EC");
                otherPublicKey = ECDHCrypto.publicKey(dsPublicKey.publicKey);
                Log.d(TAG, "encrypt(...): otherPublicKey = " + otherPublicKey);
//                return new Pair<>(new ECDHCrypto().jose4j_encrypt(plain, otherPublicKey, dsId), otherPublicKey);
                if (otherPublicKey instanceof ECPublicKey) {
                    String jwe = ECDHCrypto.nimbus_encrypt2(plain, ((ECPublicKey)otherPublicKey), dsId);
                    return new Pair<>(jwe, otherPublicKey);
                }
                return new Pair<>(new ECDHCrypto().encrypt(plain, otherPublicKey), otherPublicKey);
//                break;

            case RSA:
                Log.d(TAG, "encrypt(...): handle RSA");
                RSACrypto rsaCrypto = new RSACrypto();
                otherPublicKey = rsaCrypto.publicKey(dsPublicKey.publicKey);
                Log.d(TAG, "encrypt(...): otherPublicKey = " + otherPublicKey);
                String encrypted = rsaCrypto.encrypt(plain, otherPublicKey);
                Log.d(TAG, "MKMK: plain = " + plain);
                Log.d(TAG, "MKMK: publicKey = " + dsPublicKey.publicKey);
                Log.d(TAG, "MKMK: encrypted = " + encrypted);

                return new Pair<>(encrypted, otherPublicKey);
//                RSACrypto crypto = new RSACrypto();
//                KeyPair pair = crypto.generateKeyPair();
//                PublicKey publicKey = pair.getPublic();
//                Log.d("[MK]", "publicKey: " + publicKey);
//                PrivateKey privateKey = pair.getPrivate();
//                Log.d("[MK]", "privateKey: " + privateKey);
//
//                String encrypted = crypto.encrypt(plain, publicKey);
//                String decrypted = crypto.decrypt(encrypted, privateKey);
//                Log.d("[MK]", "plain: " + plain);
//                Log.d("[MK]", "encrypted: " + encrypted);
//                Log.d("[MK]", "decrypted: " + decrypted);
//                break;

            default:
                return null;
        }
    }

    static String decrypt(String signedContent, DSPublicKey dsPublicKey) throws JOSEException, JoseException, InvalidInputException, InvalidKeySpecException {
        Log.d(TAG, "decrypt("+signedContent+")");

        PublicKey otherPublicKey;
        switch (dsPublicKey.rootCaAlgorithm) {
            case EC:
                Log.d(TAG, "decrypt: handle EC");
                otherPublicKey = ECDHCrypto.publicKey(dsPublicKey.rootCA);
                Log.d(TAG, "decrypt: otherPublicKey = " + otherPublicKey);
                return new ECDHCrypto().decrypt(signedContent, otherPublicKey);

            case RSA:
                Log.d(TAG, "decrypt: handle RSA");
                RSACrypto rsaCrypto = new RSACrypto();
                otherPublicKey = rsaCrypto.publicKey(dsPublicKey.rootCA);
                Log.d(TAG, "decrypt: otherPublicKey = " + otherPublicKey);
                return rsaCrypto.decrypt(signedContent, otherPublicKey);

            default:
                return null;
        }
    }

    static String decrypt(String signedContent, String dsPublicKeyId, String dsPublicKeyPem) throws JOSEException, JoseException, InvalidInputException, InvalidKeySpecException {
        Log.d(TAG, "decrypt("+signedContent+")");

        PublicKey otherPublicKey;
        try {
            Log.d(TAG, "decrypt: handle EC");
            otherPublicKey = ECDHCrypto.publicKey(dsPublicKeyPem);
            Log.d(TAG, "decrypt: otherPublicKey = " + otherPublicKey);
            return new ECDHCrypto().decrypt(signedContent, otherPublicKey);
        } catch (Throwable e) {
            Log.d(TAG, "decrypt: handle RSA");
            RSACrypto rsaCrypto = new RSACrypto();
            otherPublicKey = rsaCrypto.publicKey(dsPublicKeyPem);
            Log.d(TAG, "decrypt: otherPublicKey = " + otherPublicKey);
            return rsaCrypto.decrypt(signedContent, otherPublicKey);
        }
    }

    static String decrypt(String signedContent, ECKey sdkEphemeralKeyPair) throws JOSEException, JoseException, InvalidInputException {
        Log.d(TAG, "decrypt("+signedContent+")");
        return new ECDHCrypto().decrypt(signedContent, sdkEphemeralKeyPair.toPublicKey());
    }

    static String decrypt_nimbus(String signedContent, String publicKeyPem) throws JOSEException, JoseException, InvalidInputException, ParseException {
        Log.d(TAG, "decrypt("+signedContent+")");

        return new ECDHCrypto().decrypt_numbus(signedContent, publicKeyPem);
    }

    static String validateJwsAsInDocs(String jws) {
        JWSObject jwsObject;
        try {
            jwsObject = JWSObject.parse(jws);
        } catch (ParseException e) {
            throw new RuntimeException("JWS parsing failed");
        }
        try {
            JWSVerifier verifier = null;
            JWSAlgorithm alg = jwsObject.getHeader().getAlgorithm();
            if (alg.equals(JWSAlgorithm.PS256) || alg.equals(JWSAlgorithm.RS256)) {
                List<com.nuvei.mobilesdk.core.nimbusds.jose.util.Base64> x509CertChain = jwsObject.getHeader().getX509CertChain();
                verifier = new RSASSAVerifier((RSAPublicKey)X509CertUtils.parse(x509CertChain.get(0).decode()).getPublicKey());
            } else if (alg.equals(JWSAlgorithm.ES256)) {
                verifier = new ECDSAVerifier(ECKey.parse(jwsObject.getHeader().getJWK().toJSONString()));
            } else {
                // unsupported algorithm
                throw new RuntimeException("JWS validation failed due to unsupported algorithm ("+alg+")");
            }
            if (!jwsObject.verify(verifier)) {
                throw new RuntimeException("JWS validation failed.");
            }
        } catch (Exception e) {
            throw new RuntimeException("JWS validation failed.", e);
        }
        return jwsObject.getPayload().toString();
    }

    static String validateJwsWithoutRootCA(String jws) throws JoseException, InvalidInputException {
        if (jws.startsWith("\"") && jws.endsWith("\"")) {
            jws = jws.substring(1);
            jws = jws.substring(0, jws.length() - 1);
        }

        if (jws.endsWith("=")) {
            throw new InvalidInputException("ACS Signed Content is wrong (Code 0.1)");
        }
        if (jws.contains("+")) {
            throw new InvalidInputException("ACS Signed Content is wrong (Code 0.2)");
        }
        if (jws.contains("/")) {
            throw new InvalidInputException("ACS Signed Content is wrong (Code 0.3)");
        }
        if (jws.contains(" ")) {
            throw new InvalidInputException("ACS Signed Content is wrong (Code 0.4)");
        }
        if (jws.contains("\n")) {
            throw new InvalidInputException("ACS Signed Content is wrong (Code 0.5)");
        }

//        if (jws.substring(0, 4).contains("0000")) { // TODO: Remove in prod
//            return new String(Base64.decode(jws.substring(4), Base64.DEFAULT), StandardCharsets.UTF_8);
//        } else {
            JsonWebSignature signature = new JsonWebSignature();
            signature.setCompactSerialization(jws);
            List<X509Certificate> certificateChain = signature.getCertificateChainHeaderValue();
            Certificate acsCertificate = certificateChain.get(0);
            signature.setKey(acsCertificate.getPublicKey());
            signature.verifySignature();
            return signature.getPayload();
//        }
    }

    static String validateJws(String jws, DSPublicKey dsPublicKey) throws JoseException, InvalidKeySpecException, CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException {
        PublicKey rootCaPublicKey = null;
        switch (dsPublicKey.rootCaAlgorithm) {
            case EC:
                Log.d(TAG, "validateJws: handle EC");
                rootCaPublicKey = ECDHCrypto.publicKey(dsPublicKey.rootCA);
                break;
            case RSA:
                Log.d(TAG, "validateJws: handle RSA");
                RSACrypto rsaCrypto = new RSACrypto();
                rootCaPublicKey = rsaCrypto.publicKey(dsPublicKey.rootCA);
                break;
        }
        String payload = verifySignature(jws, rootCaPublicKey);
        Log.d(TAG, "validateJws: payload = " + payload);
        return payload;
    }

    private static String verifySignature(String compactSerialization, PublicKey rootCaPublicKey) throws JoseException, NoSuchAlgorithmException, CertificateException, NoSuchProviderException, InvalidKeyException, SignatureException {
        JsonWebSignature signature = new JsonWebSignature();
        signature.setCompactSerialization(compactSerialization);
        List<X509Certificate> certificateChain = signature.getCertificateChainHeaderValue();
        Certificate acsCertificate = verifyCertificateChain(certificateChain, rootCaPublicKey);
        signature.setKey(acsCertificate.getPublicKey());
        signature.verifySignature();
        return signature.getPayload();
    }

    private static Certificate verifyCertificateChain(List<X509Certificate> certificateChain, PublicKey rootCaPublicKey) throws NoSuchProviderException, CertificateException, NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        if (certificateChain == null || certificateChain.size() == 0) {
            throw new InvalidInputException("certificateChain must be not empty");
        }
        if (rootCaPublicKey == null) {
            throw new InvalidInputException("rootCaPublicKey must be not null");
        }

        List<X509Certificate> reversedCertificateChain = new ArrayList<>();
        for (X509Certificate cert : certificateChain) {
            reversedCertificateChain.add(0, cert);
        }

        X509Certificate previousCert = null;
        PublicKey previousCertPublicKey = rootCaPublicKey;
        for (X509Certificate cert : reversedCertificateChain) {
            if (!cert.equals(previousCert)) {
                cert.verify(previousCertPublicKey);
            }
            cert.checkValidity();
            previousCert = cert;
            previousCertPublicKey = cert.getPublicKey();
        }

        return previousCert;
    }

}

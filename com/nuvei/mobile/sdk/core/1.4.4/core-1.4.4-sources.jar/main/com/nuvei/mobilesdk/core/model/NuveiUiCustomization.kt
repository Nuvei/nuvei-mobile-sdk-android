package com.nuvei.mobilesdk.core.model

import android.graphics.Color
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.res.ResourcesCompat
import java.io.Serializable
import java.util.*

public // NUVEI_MOBILE_SDK
class NuveiUiCustomization(
    @DrawableRes val logo: Int? = null,
    val toolbarCustomization: NuveiToolbarCustomization? = null,
    val labelCustomization: NuveiLabelCustomization? = null,
    val textBoxCustomization: NuveiTextBoxCustomization? = null
) {
    private val buttons: TreeMap<String, NuveiButtonCustomization> = TreeMap()
    private fun setButtonCustomization(customization: NuveiButtonCustomization, type: String) {
        buttons[type] = customization
    }
    public fun setButtonCustomization(customization: NuveiButtonCustomization, type: NuveiButtonCustomization.Type) {
        setButtonCustomization(customization, type.toString())
    }
    private fun getButtonCustomization(type: String): NuveiButtonCustomization? = buttons[type]
    public fun getButtonCustomization(type: NuveiButtonCustomization.Type): NuveiButtonCustomization? {
        return getButtonCustomization(type.toString())
    }
}

open class NuveiBaseCustomization(
    var textFontName: Int? = null,
    var textColor: Int = Color.BLACK,
    var textFontSize: Int = 0
) : Serializable

public // NUVEI_MOBILE_SDK
class NuveiButtonCustomization(
    textFontName: Int? = null,
    textColor: Int = Color.BLACK,
    textFontSize: Int = 0,
    var backgroundColor: Int = Color.TRANSPARENT,
    var cornerRadius: Int = 0
): NuveiBaseCustomization(textFontName, textColor, textFontSize) {
    public enum class Type {
        SUBMIT, CONTINUE, NEXT, CANCEL, RESEND, VERIFY
    }
}

class NuveiRecyclerViewCustomization(
    var backgroundColor: Int = Color.parseColor("#F3F5F7"),
    var sectionTextFontName: Int? = null,
    var sectionTextFontSize: Int = 0,
    var sectionTextColor: Int = Color.BLACK,
    var cellBackgroundColor: Int = Color.WHITE,
    var cellTextColor : Int = Color.parseColor("#4A5568"),
    var cellTextFontSize : Int = 14,
    var cellTextFontName : Int? = null
)

public // NUVEI_MOBILE_SDK
class NuveiToolbarCustomization(
        var headerText: String? = null,
        textFontName: Int? = null,
        textFontSize: Int = 0,
        textColor: Int = Color.BLACK,
        var backgroundColor: Int = Color.BLACK,
        var closeButtonBackgroundColor: Int = Color.WHITE,
        @DrawableRes var logoResId: Int? = null
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

public // NUVEI_MOBILE_SDK
class NuveiLabelCustomization(
        textFontName: Int? = null,
        textFontSize: Int = 0,
        textColor: Int = Color.BLACK,
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

public // NUVEI_MOBILE_SDK
class NuveiTextBoxCustomization(
    textFontName: Int? = null,
    textFontSize: Int = 0,
    textColor: Int = Color.BLACK,
    var headingTextFontSize: Int = 0,
    var headingTextFontColor: Int = 0,
    var headingTextFontName: Int? = null,
    var placeholderTextFontSize: Int = 0,
    var placeholderFontColor: Int = 0,
    var borderColor: Int = Color.BLACK,
    var cornerRadius: Int = 0,
    var borderWidth: Int = 0,
    var backgroundColor: Int = Color.WHITE
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

class NuveiErrorTextBoxCustomization(
    textFontName: Int? = null,
    textFontSize: Int = 0,
    textColor: Int = Color.BLACK,
    var borderColor: Int = Color.RED
): NuveiBaseCustomization(textFontName, textColor, textFontSize)

data class NuveiFieldCustomization(
    val backgroundColor: Int = Color.WHITE,
    val borderColor: Int = Color.BLACK,
    val cornerRadius: Int = 1,
    val borderWidth: Int = 1,
    val labelCustomization: NuveiLabelCustomization = NuveiLabelCustomization(),
    val textBoxCustomization: NuveiTextBoxCustomization = NuveiTextBoxCustomization(),
    val errorBoxCustomization: NuveiErrorTextBoxCustomization = NuveiErrorTextBoxCustomization(),
) : Serializable

data class SimplyConnectFontSpec(
    @androidx.annotation.FontRes val fontResId: Int? = null,
    val familyName: String? = null,
    val typeface: android.graphics.Typeface? = null
)

// In your SDK
object TypefaceResolver {
    fun resolve(context: android.content.Context, spec: SimplyConnectFontSpec?): android.graphics.Typeface? {
        spec ?: return null

        // Explicit Typeface wins
        spec.typeface?.let { return it }

        // Then @font resource
        spec.fontResId?.takeIf { it != 0 }?.let {
            return androidx.core.content.res.ResourcesCompat.getFont(context, it)
        }

        // Then family name ("inter", "sans-serif-medium", etc.)
        spec.familyName?.takeIf { it.isNotBlank() }?.let {
            return android.graphics.Typeface.create(it, android.graphics.Typeface.NORMAL)
        }

        return null
    }
}

// In your SDK
object TypefaceApplier {

    fun applyToViewTree(root: android.view.View, typeface: android.graphics.Typeface) {
        when (root) {
            is android.widget.TextView -> {
                // keep style/weight; set the family
                val style = root.typeface?.style ?: android.graphics.Typeface.NORMAL
                root.typeface = android.graphics.Typeface.create(typeface, style)
            }
        }
        if (root is android.view.ViewGroup) {
            for (i in 0 until root.childCount) {
                applyToViewTree(root.getChildAt(i), typeface)
            }
        }
    }

    /** Call this after setContentView() in your SDK Activity */
    fun installInActivity(activity: androidx.appcompat.app.AppCompatActivity) {
//        val tf = TypefaceResolver.resolve(activity, SimplyConnectUICustomization.fontSpec) ?: return
//        val content = activity.findViewById<android.view.View>(android.R.id.content) ?: return
//
//        // Apply immediately
//        (content as? android.view.ViewGroup)?.let { vg ->
//            // The actual root is the first child of content
//            val root = if (vg.childCount > 0) vg.getChildAt(0) else vg
//            applyToViewTree(root, tf)
//        }
//
//        // Also re-apply when the view tree changes (e.g., Fragment transactions)
//        content.viewTreeObserver.addOnGlobalLayoutListener(
//            object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
//                override fun onGlobalLayout() {
//                    val root = (content as? android.view.ViewGroup)?.getChildAt(0) ?: content
//                    applyToViewTree(root, tf)
//                }
//            }
//        )
    }
}

object FieldsUICustomization{
    var backgroundColor: Int = Color.WHITE
    var borderColor: Int = Color.parseColor("#95AAC1")
    var cornerRadius: Int = 3
    var borderWidth: Int = 1

    var textBoxCustomization: NuveiTextBoxCustomization = NuveiTextBoxCustomization(
        headingTextFontSize     = 16,
        headingTextFontColor    = Color.parseColor("#4A5568"),
        backgroundColor         = Color.WHITE,
        placeholderFontColor    = Color.GRAY,
        placeholderTextFontSize = 14,
        textFontSize            = 14,
        textColor               = Color.BLACK,
        borderWidth             = 1,
        cornerRadius            = 5,
        borderColor             = Color.parseColor("#95AAC1")

    )
    var errorBoxCustomization: NuveiErrorTextBoxCustomization = NuveiErrorTextBoxCustomization(
        textFontSize = 10,
        textColor = Color.RED,
        borderColor = Color.RED
    )
}


object SimplyConnectUICustomization{

    var recyclerViewCustomization: NuveiRecyclerViewCustomization = NuveiRecyclerViewCustomization(
        backgroundColor =  Color.parseColor("#F3F5F7"),
        sectionTextFontSize = 16,
        sectionTextColor = Color.BLACK,
        cellBackgroundColor = Color.WHITE,
        cellTextColor = Color.parseColor("#4A5568"),
        cellTextFontSize = 14
    )
    var toolbarCustomization: NuveiToolbarCustomization = NuveiToolbarCustomization(
        backgroundColor = Color.parseColor("#081F2B"),
        textColor = Color.parseColor("#C7CCCF"),
        headerText = "Checkout",
        textFontSize = 16,
        closeButtonBackgroundColor  = Color.WHITE

    )
    var textBoxCustomization: NuveiTextBoxCustomization = NuveiTextBoxCustomization(
        headingTextFontSize = 16,
        headingTextFontColor = Color.BLACK,
        placeholderTextFontSize = 14,
        placeholderFontColor = Color.GRAY,
        textFontSize = 14,
        textColor = Color.BLACK,
        borderColor = Color.parseColor("#95AAC1"),
        cornerRadius = 5,
        borderWidth = 1,
        backgroundColor = Color.WHITE
    )
    var errorBoxCustomization: NuveiErrorTextBoxCustomization = NuveiErrorTextBoxCustomization(
        textFontSize = 12,
        textColor = Color.RED,
        borderColor = Color.RED
    )
    var payButtonCustomization: NuveiButtonCustomization = NuveiButtonCustomization(
        textFontSize = 14,
        textColor = Color.WHITE,
        backgroundColor = Color.parseColor("#493DAA"),
        cornerRadius = 10
    )
    var checkboxButtonCustomization: NuveiButtonCustomization = NuveiButtonCustomization(
        textFontSize    = 14,
        textColor       = Color.parseColor("#D3DCE6"),
        backgroundColor = Color.parseColor("#493DAA")
    )
}

fun TextView.applyNuveiFont(font: Int?) {
    val tf = font?.let { ResourcesCompat.getFont(context, it) }
    if (tf != null) {
        typeface = tf
    }
}
package com.nuvei.mobilesdk.core.threeds2sdk.device_info;

import android.content.ContentResolver;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.ContextCompat;

import java.lang.reflect.Field;

import static android.Manifest.permission.REQUEST_INSTALL_PACKAGES;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import com.nuvei.mobilesdk.core.threeds2sdk.device_info.BaseDeviceInfo;

class SettingsInfo extends BaseDeviceInfo {
    //SettingsSecure
    //Secure system settings, containing system preferences that applications can read but are not allowed to write.
    private static final String DI_DD_Android_ACCESSIBILITY_DISPLAY_INVERSION_ENABLED = "A065"; //Specifies whether display color inversion is enabled.
    private static final String DI_DD_Android_ACCESSIBILITY_ENABLED = "A066"; //Specifies whether accessibility is enabled.
    private static final String DI_DD_Android_ACCESSIBILITY_SPEAK_PASSWORD = "A067"; //Specifies whether to speak passwords while in accessibility mode.
    private static final String DI_DD_Android_ALLOWED_GEOLOCATION_ORIGINS = "A068"; //Origins for which browsers should allow geolocation by default. The value is a space-separated list of origins.
    private static final String DI_DD_Android_ANDROID_ID = "A069"; //64-bit number (as a hex string) that is randomly generated when the end user first sets up the device.
    private static final String DI_DD_Android_DATA_ROAMING = "A070"; //Determines whether or not data roaming is enabled.
    private static final String DI_DD_Android_DEFAULT_INPUT_METHOD = "A071"; //Setting to record the input method used by default.
    private static final String DI_DD_Android_DEVICE_PROVISIONED = "A072"; //Determines whether the device has been provisioned.
    private static final String DI_DD_Android_ENABLED_ACCESSIBILITY_SERVICES = "A073"; //List of enabled accessibility providers.
    private static final String DI_DD_Android_ENABLED_INPUT_METHODS = "A074"; //List of input methods that are currently enabled.
    private static final String DI_DD_Android_INPUT_METHOD_SELECTOR_VISIBILITY = "A075"; //Setting to record the visibility of the input method selector.
    private static final String DI_DD_Android_INSTALL_NON_MARKET_APPS = "A076"; //Specifies whether applications can be installed for this user via the system's ACTION_IN STALL_PACKAGE mechanism.
    private static final String DI_DD_Android_LOCATION_MODE = "A077"; //Degree of location access enabled by the end user.
    private static final String DI_DD_Android_SKIP_FIRST_USE_HINTS = "A078"; //If enabled, apps should try to skip any introductory hints on first launch.
    private static final String DI_DD_Android_SYS_PROP_SETTING_VERSION = "A079"; //Secure system settings, containing system preferences that applications can read but are not allowed to write.
    private static final String DI_DD_Android_TTS_DEFAULT_PITCH = "A080"; //Default text-to-speech engine pitch.
    private static final String DI_DD_Android_TTS_DEFAULT_RATE = "A081"; //Default text-to-speech engine speech rate.
    private static final String DI_DD_Android_TTS_DEFAULT_SYNTH = "A082"; //Default text-to-speech engine.
    private static final String DI_DD_Android_TTS_ENABLED_PLUGINS = "A083"; //Space delimited list of plugin packages that are enabled.

    //SettingsGlobal
    //Global system settings, containing preferences that always apply identically to all defined users.
    private static final String DI_DD_Android_ADB_ENABLED = "A084"; //Specifies whether ADB is enabled.
    private static final String DI_DD_Android_AIRPLANE_MODE_RADIOS = "A085"; //Comma-separated list of radios that need to be disabled when airplane mode is on.
    private static final String DI_DD_Android_ALWAYS_FINISH_ACTIVITIES = "A086"; //If 1, the activity manager will aggressively finish activities and processes as soon as they are no longer needed.
    private static final String DI_DD_Android_ANIMATOR_DURATION_SCALE = "A087"; //Scaling factor for animator-based animations.
    private static final String DI_DD_Android_AUTO_TIME = "A088"; //Value to specify whether the user prefers the date, time and time zone to be automatically fetched from the network (NITZ).
    private static final String DI_DD_Android_AUTO_TIME_ZONE = "A089"; //Value to specify whether the user prefers the time zone to be automatically fetched from the network (NITZ).
    private static final String DI_DD_Android_DEVELOPMENT_SETTINGS_ENABLED = "A090"; //Determines whether the end user has enabled development settings.
    private static final String DI_DD_Android_HTTP_PROXY = "A091"; //Host name and port for global http proxy.
    private static final String DI_DD_Android_NETWORK_PREFERENCE = "A092"; //User preference for which networks should be used.
    private static final String DI_DD_Android_STAY_ON_WHILE_PLUGGED_IN = "A093"; //Determines whether the device must remain switched on while it is plugged in.
    private static final String DI_DD_Android_TRANSITION_ANIMATION_SCALE = "A094"; //Scaling factor for activity transition animations.
    private static final String DI_DD_Android_USB_MASS_STORAGE_ENABLED = "A095"; //Indicates whether USB mass storage is enabled.
    private static final String DI_DD_Android_USE_GOOGLE_MAIL = "A096"; //If this setting is set (to anything), then all references to Gmail on the device must change to Google Mail.
    private static final String DI_DD_Android_WAIT_FOR_DEBUGGER = "A097"; //If 1, when launching DEBUG_APP it will wait for the debugger before starting user code.
    private static final String DI_DD_Android_WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON = "A098"; //Determines whether the end user should be notified of open networks.

    //SettingsSystem
    //System settings, containing miscellaneous system preferences.
    private static final String DI_DD_Android_ACCELEROMETER_ROTATION = "A099"; //Control whether the accelerometer will be used to change screen orientation.
    private static final String DI_DD_Android_BLUETOOTH_DISCOVERABILITY = "A100"; //Determines whether remote devices may discover and/or connect to this device.
    private static final String DI_DD_Android_BLUETOOTH_DISCOVERABILITY_TIMEOUT = "A101"; //Bluetooth discoverability timeout.
    private static final String DI_DD_Android_DATE_FORMAT = "A102"; //Date format string mm/dd/yyyy dd/mm/yyyy yyyy/mm/dd.
    private static final String DI_DD_Android_DTMF_TONE_TYPE_WHEN_DIALING = "A103"; //CDMA only settings + DTMF tone type played by the dialer when dialing
    private static final String DI_DD_Android_DTMF_TONE_WHEN_DIALING = "A104"; //Whether the audible DTMF tones are played by the dialer when dialing.
    private static final String DI_DD_Android_END_BUTTON_BEHAVIOR = "A105"; //The behavior when the user presses the end call button if they're not on a call.
    private static final String DI_DD_Android_FONT_SCALE = "A106"; //Scaling factor for fonts, float.
    private static final String DI_DD_Android_HAPTIC_FEEDBACK_ENABLED = "A107"; //Whether the haptic feedback (long presses) is enabled.
    private static final String DI_DD_Android_MODE_RINGER_STREAMS_AFFECTED = "A108"; //Determines which streams are affected by ringer mode changes.
    private static final String DI_DD_Android_NOTIFICATION_SOUND = "A109"; //Persistent store for the system-wide default notification sound.
    private static final String DI_DD_Android_MUTE_STREAMS_AFFECTED = "A110"; //Determines which streams are affected by mute.
    private static final String DI_DD_Android_RINGTONE = "A111"; //Persistent store for the system-wide default ringtone URI.
    private static final String DI_DD_Android_SCREEN_BRIGHTNESS = "A112"; //The screen back light brightness between 0 and 255.
    private static final String DI_DD_Android_SCREEN_BRIGHTNESS_MODE = "A113"; //Control whether to enable automatic brightness mode.
    private static final String DI_DD_Android_SCREEN_OFF_TIMEOUT = "A114"; //The amount of time in milliseconds before the device goes to sleep or begins to dream after a period of inactivity.
    private static final String DI_DD_Android_SOUND_EFFECTS_ENABLED = "A115"; //Whether sounds effects (key clicks, lid open) are enabled.
    private static final String DI_DD_Android_TEXT_AUTO_CAPS = "A116"; //Setting to enable AutoCaps in text editors.
    private static final String DI_DD_Android_TEXT_AUTO_PUNCTUATE = "A117"; //Setting to enable Auto Punctuate in text editors
    private static final String DI_DD_Android_TEXT_AUTO_REPLACE = "A118"; //Setting to enable Auto Replace (AutoText) in text editors.
    private static final String DI_DD_Android_TEXT_SHOW_PASSWORD = "A119"; //Setting to showing password characters in text editors.
    private static final String DI_DD_Android_TIME_12_24 = "A120"; //Display time in the 12-hour format or the 24-hour format.
    private static final String DI_DD_Android_USER_ROTATION = "A121"; //Default screen rotation when no other policy applies.
    private static final String DI_DD_Android_VIBRATE_ON = "A122"; //Whether vibrate is on for different events.
    private static final String DI_DD_Android_VIBRATE_WHEN_RINGING = "A123"; //Whether the phone vibrates when it is ringing during an incoming call.

    SettingsInfo(Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        collectSettingsSecureInfo(context, contentResolver);
        collectSettingsGlobalInfo(context, contentResolver);
        collectSettingsSystemInfo(contentResolver);
    }

    private void collectSettingsSecureInfo(Context context, ContentResolver contentResolver) {
        collectSecureInfo(DI_DD_Android_ACCESSIBILITY_ENABLED, Settings.Secure.ACCESSIBILITY_ENABLED, Type.INT, contentResolver);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.N_MR1) {
            collectSecureInfo(DI_DD_Android_ACCESSIBILITY_SPEAK_PASSWORD, Settings.Secure.ACCESSIBILITY_SPEAK_PASSWORD, Type.INT, contentResolver);
        } else {
            dpna.put(DI_DD_Android_ACCESSIBILITY_SPEAK_PASSWORD, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
        collectSecureInfo(DI_DD_Android_ALLOWED_GEOLOCATION_ORIGINS, Settings.Secure.ALLOWED_GEOLOCATION_ORIGINS, Type.STRING, contentResolver);
        collectSecureInfo(DI_DD_Android_ANDROID_ID, Settings.Secure.ANDROID_ID, Type.STRING, contentResolver);
        collectSecureInfo(DI_DD_Android_DEFAULT_INPUT_METHOD, Settings.Secure.DEFAULT_INPUT_METHOD, Type.STRING, contentResolver);// TODO: Make sure the value is string
        collectSecureInfo(DI_DD_Android_ENABLED_ACCESSIBILITY_SERVICES, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, Type.STRING, contentResolver);// TODO: Make sure the value is string
        collectSecureInfo(DI_DD_Android_ENABLED_INPUT_METHODS, Settings.Secure.ENABLED_INPUT_METHODS, Type.STRING, contentResolver);
        collectSecureInfo(DI_DD_Android_INPUT_METHOD_SELECTOR_VISIBILITY, Settings.Secure.INPUT_METHOD_SELECTOR_VISIBILITY, Type.INT, contentResolver);
        collectSecureInfo(DI_DD_Android_TTS_DEFAULT_RATE, Settings.Secure.TTS_DEFAULT_RATE, Type.INT, contentResolver);// TODO: Make sure the value is int
        collectSecureInfo(DI_DD_Android_TTS_DEFAULT_PITCH, Settings.Secure.TTS_DEFAULT_PITCH, Type.INT, contentResolver);// TODO: Make sure the value is int
        collectSecureInfo(DI_DD_Android_TTS_DEFAULT_SYNTH, Settings.Secure.TTS_DEFAULT_SYNTH, Type.STRING, contentResolver);// TODO: Make sure the value is string
        collectSecureInfo(DI_DD_Android_TTS_ENABLED_PLUGINS, Settings.Secure.TTS_ENABLED_PLUGINS, Type.STRING, contentResolver);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.M) {
            try {
                Field field = Settings.Secure.class.getField("SYS_PROP_SETTING_VERSION");
                String key = (String) field.get(null);
                String value = Settings.Secure.getString(context.getContentResolver(), key);
                putData(DI_DD_Android_SYS_PROP_SETTING_VERSION, value);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                dpna.put(DI_DD_Android_SYS_PROP_SETTING_VERSION, DI_DPNA_RE_PlatformVersionOrDeprecated);
            }
        } else {
            dpna.put(DI_DD_Android_SYS_PROP_SETTING_VERSION, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }

        collectSecureInfo(DI_DD_Android_LOCATION_MODE, Settings.Secure.LOCATION_MODE, Type.INT, contentResolver);
//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
//            collectSecureInfo(DI_DD_Android_LOCATION_MODE, Settings.Secure.LOCATION_MODE, Type.INT, contentResolver);
//        } else {
//            dpna.put(DI_DD_Android_LOCATION_MODE, DI_DPNA_RE_PlatformVersionOrDeprecated);
//        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            collectSecureInfo(DI_DD_Android_ACCESSIBILITY_DISPLAY_INVERSION_ENABLED, Settings.Secure.ACCESSIBILITY_DISPLAY_INVERSION_ENABLED, Type.INT, contentResolver);
            collectSecureInfo(DI_DD_Android_SKIP_FIRST_USE_HINTS, Settings.Secure.SKIP_FIRST_USE_HINTS, Type.INT, contentResolver);
        } else {
            dpna.put(DI_DD_Android_ACCESSIBILITY_DISPLAY_INVERSION_ENABLED, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_SKIP_FIRST_USE_HINTS, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private void collectSettingsGlobalInfo(Context context, ContentResolver contentResolver) {
        collectGlobalInfo(DI_DD_Android_DATA_ROAMING, Settings.Global.DATA_ROAMING, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_DEVICE_PROVISIONED, Settings.Global.DEVICE_PROVISIONED, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_ADB_ENABLED, Settings.Global.ADB_ENABLED, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_AIRPLANE_MODE_RADIOS, Settings.Global.AIRPLANE_MODE_RADIOS, Type.STRING, contentResolver);
        collectGlobalInfo(DI_DD_Android_ALWAYS_FINISH_ACTIVITIES, Settings.Global.ALWAYS_FINISH_ACTIVITIES, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_ANIMATOR_DURATION_SCALE, Settings.Global.ANIMATOR_DURATION_SCALE, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_AUTO_TIME, Settings.Global.AUTO_TIME, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_AUTO_TIME_ZONE, Settings.Global.AUTO_TIME_ZONE, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_DEVELOPMENT_SETTINGS_ENABLED, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_HTTP_PROXY, Settings.Global.HTTP_PROXY, Type.STRING, contentResolver);
        collectGlobalInfo(DI_DD_Android_NETWORK_PREFERENCE, Settings.Global.NETWORK_PREFERENCE, Type.STRING, contentResolver);// TODO: Make sure the value is string
        collectGlobalInfo(DI_DD_Android_STAY_ON_WHILE_PLUGGED_IN, Settings.Global.STAY_ON_WHILE_PLUGGED_IN, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_TRANSITION_ANIMATION_SCALE, Settings.Global.TRANSITION_ANIMATION_SCALE, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_USB_MASS_STORAGE_ENABLED, Settings.Global.USB_MASS_STORAGE_ENABLED, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_USE_GOOGLE_MAIL, Settings.Global.USE_GOOGLE_MAIL, Type.INT, contentResolver);
        collectGlobalInfo(DI_DD_Android_WAIT_FOR_DEBUGGER, Settings.Global.WAIT_FOR_DEBUGGER, Type.INT, contentResolver);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            collectGlobalInfo(DI_DD_Android_WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON, Settings.Global.WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON, Type.INT, contentResolver);
        } else {
            dpna.put(DI_DD_Android_WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            putData(DI_DD_Android_INSTALL_NON_MARKET_APPS, Settings.Global.INSTALL_NON_MARKET_APPS);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (ContextCompat.checkSelfPermission(context, REQUEST_INSTALL_PACKAGES) == PERMISSION_GRANTED) {
                putData(DI_DD_Android_INSTALL_NON_MARKET_APPS, context.getPackageManager().canRequestPackageInstalls());
            } else {
                dpna.put(DI_DD_Android_INSTALL_NON_MARKET_APPS, DI_DPNA_RE_PlatformVersionOrDeprecated);
            }
        } else {
            dpna.put(DI_DD_Android_INSTALL_NON_MARKET_APPS, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private void collectSettingsSystemInfo(ContentResolver contentResolver) {
        collectSystemInfo(DI_DD_Android_ACCELEROMETER_ROTATION, Settings.System.ACCELEROMETER_ROTATION, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_BLUETOOTH_DISCOVERABILITY, Settings.System.BLUETOOTH_DISCOVERABILITY, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_BLUETOOTH_DISCOVERABILITY_TIMEOUT, Settings.System.BLUETOOTH_DISCOVERABILITY_TIMEOUT, Type.LONG, contentResolver);
        collectSystemInfo(DI_DD_Android_DATE_FORMAT, Settings.System.DATE_FORMAT, Type.STRING, contentResolver);
        collectSystemInfo(DI_DD_Android_DTMF_TONE_WHEN_DIALING, Settings.System.DTMF_TONE_WHEN_DIALING, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_END_BUTTON_BEHAVIOR, Settings.System.END_BUTTON_BEHAVIOR, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_FONT_SCALE, Settings.System.FONT_SCALE, Type.FLOAT, contentResolver);
        collectSystemInfo(DI_DD_Android_HAPTIC_FEEDBACK_ENABLED, Settings.System.HAPTIC_FEEDBACK_ENABLED, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_MODE_RINGER_STREAMS_AFFECTED, Settings.System.MODE_RINGER_STREAMS_AFFECTED, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_NOTIFICATION_SOUND, Settings.System.NOTIFICATION_SOUND, Type.STRING, contentResolver);
        collectSystemInfo(DI_DD_Android_MUTE_STREAMS_AFFECTED, Settings.System.MUTE_STREAMS_AFFECTED, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_RINGTONE, Settings.System.RINGTONE, Type.STRING, contentResolver);
        collectSystemInfo(DI_DD_Android_SCREEN_BRIGHTNESS, Settings.System.SCREEN_BRIGHTNESS, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_SCREEN_OFF_TIMEOUT, Settings.System.SCREEN_OFF_TIMEOUT, Type.LONG, contentResolver);
        collectSystemInfo(DI_DD_Android_SOUND_EFFECTS_ENABLED, Settings.System.SOUND_EFFECTS_ENABLED, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_TEXT_AUTO_CAPS, Settings.System.TEXT_AUTO_CAPS, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_TEXT_AUTO_PUNCTUATE, Settings.System.TEXT_AUTO_PUNCTUATE, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_TEXT_AUTO_REPLACE, Settings.System.TEXT_AUTO_REPLACE, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_TEXT_SHOW_PASSWORD, Settings.System.TEXT_SHOW_PASSWORD, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_TIME_12_24, Settings.System.TIME_12_24, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_USER_ROTATION, Settings.System.USER_ROTATION, Type.INT, contentResolver);
        collectSystemInfo(DI_DD_Android_VIBRATE_ON, Settings.System.VIBRATE_ON, Type.INT, contentResolver);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            collectSystemInfo(DI_DD_Android_DTMF_TONE_TYPE_WHEN_DIALING, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, Type.INT, contentResolver);
            collectSystemInfo(DI_DD_Android_VIBRATE_WHEN_RINGING, Settings.System.VIBRATE_WHEN_RINGING, Type.INT, contentResolver);
        } else {
            dpna.put(DI_DD_Android_DTMF_TONE_TYPE_WHEN_DIALING, DI_DPNA_RE_PlatformVersionOrDeprecated);
            dpna.put(DI_DD_Android_VIBRATE_WHEN_RINGING, DI_DPNA_RE_PlatformVersionOrDeprecated);
        }
    }

    private void collectSecureInfo(String deviceInfoKey, String settingsKey, Type type, ContentResolver contentResolver) {
        Object value = null;
        try {
            switch (type) {
                case INT:
                    value = Settings.Secure.getInt(contentResolver, settingsKey);
                    break;
                case FLOAT:
                    value = Settings.Secure.getFloat(contentResolver, settingsKey);
                    break;
                case LONG:
                    value = Settings.Secure.getLong(contentResolver, settingsKey);
                    break;
                default:
                    value = Settings.Secure.getString(contentResolver, settingsKey);
                    break;
            }
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        putData(deviceInfoKey, value);
    }

    private void collectSystemInfo(String deviceInfoKey, String settingsKey, Type type, ContentResolver contentResolver) {
        Object value = null;
        try {
            switch (type) {
                case INT:
                    value = Settings.System.getInt(contentResolver, settingsKey);
                    break;
                case FLOAT:
                    value = Settings.System.getFloat(contentResolver, settingsKey);
                    break;
                case LONG:
                    value = Settings.System.getLong(contentResolver, settingsKey);
                    break;
                default:
                    value = Settings.System.getString(contentResolver, settingsKey);
                    break;
            }
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        putData(deviceInfoKey, value);
    }

    private void collectGlobalInfo(String deviceInfoKey, String settingsKey, Type type, ContentResolver contentResolver) {
        Object value = null;
        try {
            switch (type) {
                case INT:
                    value = Settings.Global.getInt(contentResolver, settingsKey);
                    break;
                case FLOAT:
                    value = Settings.Global.getFloat(contentResolver, settingsKey);
                    break;
                case LONG:
                    value = Settings.Global.getLong(contentResolver, settingsKey);
                    break;
                default:
                    value = Settings.Global.getString(contentResolver, settingsKey);
                    break;
            }
        } catch (SecurityException e) {
            e.printStackTrace();
            value = DI_DPNA_RE_MissingPermission;
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        putData(deviceInfoKey, value);
    }

    enum Type {
        INT, FLOAT, LONG, STRING
    }
}

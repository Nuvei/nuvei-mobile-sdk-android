package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import com.nuvei.mobilesdk.core.Constants
import com.nuvei.mobilesdk.core.network.NetworkConstants

open class NVOutput(
    @SerializedName("result") val result: String,
    @SerializedName("userPaymentOptionId") val userPaymentOptionId: String? = null,
    @SerializedName("ccCardNumber") val ccCardNumber: String? = null,
    @SerializedName("bin") val bin: String? = null,
    @SerializedName("last4Digits") val last4Digits: String? = null,
    @SerializedName("ccExpMonth") val ccExpMonth: String? = null,
    @SerializedName("ccExpYear") val ccExpYear: String? = null,
    @SerializedName("transactionId") val transactionId: String? = null,
    @SerializedName("threeDReasonId") val threeDReasonId: String? = null,
    @SerializedName("threeDReason") val threeDReason: String? = null,
    @SerializedName("challengePreferenceReason") val challengePreferenceReason: String? = null,
    @SerializedName("isLiabilityOnIssuer") val isLiabilityOnIssuer: Boolean? = null,
    @SerializedName("cancelled") val cancelled: Boolean = false,
    @SerializedName("challengeCancelReasonId") val challengeCancelReasonId: String? = null,
    @SerializedName("challengeCancelReason") val challengeCancelReason: String? = null,
    @SerializedName("errorCode") val errorCode: Int? = null,
    @SerializedName("errorDescription") val errorDescription: String? = null,
    @SerializedName("rawResult") val rawResult: Map<String, Any>? = null,
    @SerializedName("status") val status: String = ""
) {
    companion object {
        const val APPROVED = "APPROVED"
        const val CANCELLED = "CANCELLED"
        const val DECLINED = "DECLINED"
        const val ERROR = Constants.ERROR

        fun create(
            isCreatePayment: Boolean,
            result: String,
            userPaymentOptionId: String? = null,
            ccCardNumber: String? = null,
            bin: String? = null,
            last4Digits: String? = null,
            ccExpMonth: String? = null,
            ccExpYear: String? = null,
            transactionId: String? = null,
            threeDReasonId: String? = null,
            threeDReason: String? = null,
            challengePreferenceReason: String? = null,
            isLiabilityOnIssuer: Boolean? = null,
            challengeCancelReasonId: String? = null,
            challengeCancelReason: String? = null,
            errorCode: Int? = null,
            errorDescription: String? = null,
            rawResult: Map<String, Any>? = null
        ): NVOutput {
            val output: NVOutput

            val actualTransactionId = transactionId ?: rawResult?.get(NetworkConstants.transactionId) as? String

            if (isCreatePayment) {
                output = NVCreatePaymentOutput(
                    result = result,
                    userPaymentOptionId = userPaymentOptionId,
                    ccCardNumber = ccCardNumber,
                    bin = bin,
                    last4Digits = last4Digits,
                    ccExpMonth = ccExpMonth,
                    ccExpYear = ccExpYear,
                    transactionId = actualTransactionId,
                    threeDReasonId = threeDReasonId,
                    threeDReason = threeDReason,
                    challengePreferenceReason = challengePreferenceReason,
                    isLiabilityOnIssuer = isLiabilityOnIssuer,
                    cancelled = (result == Constants.CANCELLED),
                    challengeCancelReasonId = challengeCancelReasonId,
                    challengeCancelReason = challengeCancelReason,
                    errorCode = errorCode,
                    errorDescription = errorDescription,
                    rawResult = rawResult
                )
            } else {
                output = NVAuthenticate3dOutput(
                    result = result,
                    userPaymentOptionId = userPaymentOptionId,
                    ccCardNumber = ccCardNumber,
                    bin = bin,
                    last4Digits = last4Digits,
                    ccExpMonth = ccExpMonth,
                    ccExpYear = ccExpYear,
                    transactionId = actualTransactionId,
                    threeDReasonId = threeDReasonId,
                    threeDReason = threeDReason,
                    challengePreferenceReason = challengePreferenceReason,
                    isLiabilityOnIssuer = isLiabilityOnIssuer,
                    cancelled = (result == Constants.CANCELLED),
                    challengeCancelReasonId = challengeCancelReasonId,
                    challengeCancelReason = challengeCancelReason,
                    errorCode = errorCode,
                    errorDescription = errorDescription,
                    rawResult = rawResult
                )
            }
            return output
        }
    }
}
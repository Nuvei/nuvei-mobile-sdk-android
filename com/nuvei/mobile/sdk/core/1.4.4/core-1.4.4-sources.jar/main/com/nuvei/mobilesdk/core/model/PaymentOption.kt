package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

public // NUVEI_MOBILE_SDK
class PaymentOption(
    userPaymentOptionId: String? = null,
    @SerializedName("card") val card: CardDetails? = null,
    @SerializedName("savePm") val saveMethod: Boolean? = null,
    @SerializedName("alternativePaymentMethod") val alternativePaymentMethod: AlternativePaymentMethod? = null,
) : Serializable {
    class AlternativePaymentMethod private constructor(
        @Transient val fields: MutableMap<String, Any?> = HashMap(),
    ) : Serializable, Map<String, Any?> by fields {
        constructor(
            paymentMethod: String,
            fields: MutableMap<String, Any?>,
        ) : this(fields) {
            this.paymentMethod = paymentMethod
        }

        var paymentMethod: String?
            get() = fields["paymentMethod"] as? String
            set(value) {
                fields["paymentMethod"] = value
            }
    }

    @SerializedName("userPaymentOptionId")
    val userPaymentOptionId: String? = if (userPaymentOptionId != "") userPaymentOptionId else null
}
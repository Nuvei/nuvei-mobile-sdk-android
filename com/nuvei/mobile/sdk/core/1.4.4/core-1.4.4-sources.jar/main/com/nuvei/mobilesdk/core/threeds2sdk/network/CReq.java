package com.nuvei.mobilesdk.core.threeds2sdk.network;

import com.google.gson.annotations.SerializedName;

public class CReq {

    @SerializedName("threeDSRequestorAppURL")
    private
    String threeDSRequestorAppURL;

    @SerializedName("threeDSServerTransID")
    private
    String threeDSServerTransID;

    @SerializedName("acsTransID")
    private
    String acsTransID;

    @SerializedName("challengeCancel")
    private
    String challengeCancel;

    @SerializedName("challengeDataEntry")
    private
    String challengeDataEntry;

    @SerializedName("challengeHTMLDataEntry")
    private
    String challengeHTMLDataEntry;

    @SerializedName("challengeNoEntry")
    private
    String challengeNoEntry;

    @SerializedName("challengeWindowSize")
    private
    String challengeWindowSize;

    @SerializedName("messageExtension")
    private
    String messageExtension;

    @SerializedName("messageType")
    private
    String messageType;

    @SerializedName("messageVersion")
    private
    String messageVersion;

    @SerializedName("oobContinue")
    private
    Boolean oobContinue;

    @SerializedName("resendChallenge")
    private
    String resendChallenge;

    @SerializedName("sdkTransID")
    private
    String sdkTransID;

    @SerializedName("sdkCounterStoA")
    private
    String sdkCounterStoA;

    @SerializedName("whitelistingDataEntry")
    private
    String whitelistingDataEntry;

    /**
     * 3DS Requestor App URL
     * E.g. merchantScheme://appName?transID=b2385523-a66c-4907-ac3c-91848e8c0067
     */
    public String getThreeDSRequestorAppURL() {
        return threeDSRequestorAppURL;
    }

    public void setThreeDSRequestorAppURL(String threeDSRequestorAppURL) {
        this.threeDSRequestorAppURL = threeDSRequestorAppURL;
    }

    /**
     * 3DS Server Transaction ID
     * From ChallengeParameters.get3DSServerTransactionID()
     */
    public String getThreeDSServerTransID() {
        return threeDSServerTransID;
    }

    public void setThreeDSServerTransID(String threeDSServerTransID) {
        this.threeDSServerTransID = threeDSServerTransID;
    }

    /**
     * ACS Transaction ID
     * From ChallengeParameters.getAcsTransactionID()
     */
    public String getAcsTransID() {
        return acsTransID;
    }

    public void setAcsTransID(String acsTransID) {
        this.acsTransID = acsTransID;
    }

    /**
     * Challenge Cancelation Indicator
     */
    public String getChallengeCancel() {
        return challengeCancel;
    }

    public void setChallengeCancel(String challengeCancel) {
        this.challengeCancel = challengeCancel;
    }

    /**
     * Challenge Data Entry
     */
    public String getChallengeDataEntry() {
        return challengeDataEntry;
    }

    public void setChallengeDataEntry(String challengeDataEntry) {
        this.challengeDataEntry = challengeDataEntry;
    }

    /**
     * Challenge HTML Data Entry
     */
    public String getChallengeHTMLDataEntry() {
        return challengeHTMLDataEntry;
    }

    public void setChallengeHTMLDataEntry(String challengeHTMLDataEntry) {
        this.challengeHTMLDataEntry = challengeHTMLDataEntry;
    }

    /**
     * Challenge No Entry
     */
    public String getChallengeNoEntry() {
        return challengeNoEntry;
    }

    public void setChallengeNoEntry(String challengeNoEntry) {
        this.challengeNoEntry = challengeNoEntry;
    }

    /**
     * Challenge Window Size
     */
    public String getChallengeWindowSize() {
        return challengeWindowSize;
    }

    public void setChallengeWindowSize(String challengeWindowSize) {
        this.challengeWindowSize = challengeWindowSize;
    }

    /**
     * Message Extension
     */
    public String getMessageExtension() {
        return messageExtension;
    }

    public void setMessageExtension(String messageExtension) {
        this.messageExtension = messageExtension;
    }

    /**
     * Message Type
     */
    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    /**
     * Message Version Number
     */
    public String getMessageVersion() {
        return messageVersion;
    }

    public void setMessageVersion(String messageVersion) {
        this.messageVersion = messageVersion;
    }

    /**
     * OOB Continuation Indicator
     */
    public Boolean getOobContinue() {
        return oobContinue;
    }

    public void setOobContinue(Boolean oobContinue) {
        this.oobContinue = oobContinue;
    }

    /**
     * Resend Challenge Information Code
     */
    public String getResendChallenge() {
        return resendChallenge;
    }

    public void setResendChallenge(String resendChallenge) {
        this.resendChallenge = resendChallenge;
    }

    /**
     * SDK Transaction ID
     */
    public String getSdkTransID() {
        return sdkTransID;
    }

    public void setSdkTransID(String sdkTransID) {
        this.sdkTransID = sdkTransID;
    }

    /**
     * SDK Counter SDK to ACS
     */
    public String getSdkCounterStoA() {
        return sdkCounterStoA;
    }

    public void setSdkCounterStoA(String sdkCounterStoA) {
        this.sdkCounterStoA = sdkCounterStoA;
    }

    /**
     * Whitelisting Data Entry
     */
    public String getWhitelistingDataEntry() {
        return whitelistingDataEntry;
    }

    public void setWhitelistingDataEntry(String whitelistingDataEntry) {
        this.whitelistingDataEntry = whitelistingDataEntry;
    }
}

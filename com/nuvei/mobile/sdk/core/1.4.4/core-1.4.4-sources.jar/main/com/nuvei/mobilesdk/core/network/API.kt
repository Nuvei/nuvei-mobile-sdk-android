package com.nuvei.mobilesdk.core.network

import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface API {

    @POST("websdk/initPaymentWithCardTokenization.do")
    fun initPayment(
            @Body initPaymentBody: JsonObject
    ): Call<JsonObject>

    //@POST("clientPayment.do")
    @POST("clientAuthorize3d.do")
    fun clientAuthorize3d(@Body body: JsonObject): Call<JsonObject>

    @POST("clientPayment.do")
    fun clientPayment(@Body body: JsonObject): Call<JsonObject>

    @POST("verify3d")
    fun verify3d(
            @Body initPaymentBody: JsonObject
    ): Call<JsonObject>

    @POST("websdk/clientGetUserUPOs.do")
    fun userUPOs(@Body body: JsonObject): Call<JsonObject>

    @POST("getPaymentStatus")
    fun getPaymentStatus(@Body body: JsonObject): Call<JsonObject>

    @POST("getMerchantPaymentMethods.do")
    fun getMerchantPaymentMethods(@Body body: JsonObject): Call<JsonObject>

    @POST("websdk/clientDeleteUPO.do")
    fun deleteSavedUPO(@Body body: JsonObject): Call<JsonObject>

    @POST("cardTokenization.do")
    fun cardTokenization(@Body body: JsonObject): Call<JsonObject>

    @POST("getCardDetails.do")
    fun getCardDetails(@Body body: JsonObject): Call<JsonObject>
}
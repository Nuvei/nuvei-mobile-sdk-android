package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName

class NVAuthenticate3dOutput(
    result: String,
    userPaymentOptionId: String? = null,
    @SerializedName("cavv") val cavv: String? = null,
    @SerializedName("eci") val eci: String? = null,
    @SerializedName("xid") val xid: String? = null,
    @SerializedName("dsTransID") val dsTransID: String? = null,
    ccCardNumber: String? = null,
    bin: String? = null,
    last4Digits: String? = null,
    ccExpMonth: String? = null,
    ccExpYear: String? = null,
    @SerializedName("ccTempToken") val ccTempToken: String? = null,
    transactionId: String? = null,
    threeDReasonId: String? = null,
    threeDReason: String? = null,
    challengePreferenceReason: String? = null,
    isLiabilityOnIssuer: Boolean? = null,
    cancelled: Boolean = false,
    challengeCancelReasonId: String? = null,
    challengeCancelReason: String? = null,
    errorCode: Int? = null,
    errorDescription: String? = null,
    rawResult: Map<String, Any>? = null
) : NVOutput(
    result = result,
    userPaymentOptionId = userPaymentOptionId,
    ccCardNumber = ccCardNumber,
    bin = bin,
    last4Digits = last4Digits,
    ccExpMonth = ccExpMonth,
    ccExpYear = ccExpYear,
    transactionId = transactionId,
    threeDReasonId = threeDReasonId,
    threeDReason = threeDReason,
    challengePreferenceReason = challengePreferenceReason,
    isLiabilityOnIssuer = isLiabilityOnIssuer,
    cancelled = cancelled,
    challengeCancelReasonId = challengeCancelReasonId,
    challengeCancelReason = challengeCancelReason,
    errorCode = errorCode,
    errorDescription = errorDescription,
    rawResult = rawResult
)
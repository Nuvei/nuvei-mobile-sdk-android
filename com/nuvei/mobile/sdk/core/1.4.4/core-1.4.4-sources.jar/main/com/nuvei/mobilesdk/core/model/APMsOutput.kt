package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName

class APMsOutput (
    @SerializedName("paymentMethods") val paymentMethods: List<APM>,
    @SerializedName("status") val status: String?,
    @SerializedName("errCode") val error: Int?,
    @SerializedName("reason") val reason: String?,
) {
    class APM(
        @SerializedName("paymentMethod") val methodType: String,
        @SerializedName("paymentMethodDisplayName") val title: List<Caption>,
        @SerializedName("logoURL") val logoURL: String?,
        @SerializedName("fields") val fields: List<Field>,
    )

    class Field(
        @SerializedName("name") val name: String,
        @SerializedName("type") val type: String,
        @SerializedName("caption") val caption: List<Caption>,
        @SerializedName("listValues") val values: List<ListValue>?,
    )

    class Caption(
        @SerializedName("language") val language: String,
        @SerializedName("message") val message: String,
    )

    class ListValue(
        @SerializedName("code") val code: String,
        @SerializedName("caption") val caption: String,
    )
}
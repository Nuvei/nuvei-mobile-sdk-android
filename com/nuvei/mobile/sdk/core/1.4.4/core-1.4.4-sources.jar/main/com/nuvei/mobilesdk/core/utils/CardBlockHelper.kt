package com.nuvei.mobilesdk.core.utils

import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput

object CardBlockHelper {

    private const val TOKEN_PREPAID = "isprepaid"
    private const val TOKEN_NOT_RELOADABLE = "isnotreloadable"

    fun isConfigured(blockCards: List<List<String>>?): Boolean =
        !blockCards.isNullOrEmpty() && blockCards.any { !it.isNullOrEmpty() }

    fun isCardBlocked(cardDetails: NVCardDetailsOutput, blockCards: List<List<String>>?): Boolean {
        return getMatchingRule(cardDetails, blockCards) != null
    }

    fun getMatchingRule(cardDetails: NVCardDetailsOutput, blockCards: List<List<String>>?): List<String>? {
        if (!isConfigured(blockCards)) {
            return null
        }

        return blockCards.orEmpty().firstOrNull { ruleMatches(cardDetails, it) }
    }

    private fun ruleMatches(cardDetails: NVCardDetailsOutput, rule: List<String>): Boolean {
        val normalizedTokens = rule
            .mapNotNull { it.trim().takeIf(String::isNotEmpty) }
            .map(::normalizeToken)

        if (normalizedTokens.isEmpty()) {
            return false
        }

        return normalizedTokens.all { tokenMatches(cardDetails, it) }
    }

    private fun tokenMatches(cardDetails: NVCardDetailsOutput, token: String): Boolean {
        return when (token) {
            TOKEN_PREPAID -> cardDetails.isPrepaid == true
            TOKEN_NOT_RELOADABLE -> cardDetails.isNotReloadableCard == true
            else -> responseFieldValues(cardDetails).any { field ->
                field == token || field.matches(Regex("\\b${Regex.escape(token)}\\b"))
            }
        }
    }

    private fun responseFieldValues(cardDetails: NVCardDetailsOutput): List<String> {
        return listOf(
            cardDetails.brand,
            cardDetails.cardType,
            cardDetails.cardProduct,
            cardDetails.issuerCountry
        ).mapNotNull { it?.trim()?.takeIf(String::isNotEmpty)?.lowercase() }
    }

    private fun normalizeToken(rawToken: String): String {
        return rawToken
            .trim()
            .lowercase()
    }

    fun getBlockedCardMessageFromRules(cardDetails: NVCardDetailsOutput, blockCards: List<List<String>>?): String {
        val matchingRule = getMatchingRule(cardDetails, blockCards) ?: emptyList()
        return getBlockedCardMessage(cardDetails, matchingRule)
    }

    fun getBlockedCardMessage(cardDetails: NVCardDetailsOutput, matchingRule: List<String>): String {
        val parts = mutableListOf<String>()
        val ruleTokens = matchingRule.map { normalizeToken(it) }.filter { it.isNotEmpty() }

        // Follow the 6-part order: {Country} {Brand} {Product} {Type} {Prepaid} {Gift}
        // 1. Country — all capitals (e.g. "US", "GB")
        cardDetails.issuerCountry?.takeIf { it.isNotBlank() }?.let { field ->
            if (ruleTokens.any { token -> fieldMatches(field, token) }) {
                parts.add(field.uppercase())
            }
        }
        
        // 2. Brand — first letter capital (e.g. "Visa", "Mastercard")
        cardDetails.brand?.takeIf { it.isNotBlank() }?.let { field ->
            if (ruleTokens.any { token -> fieldMatches(field, token) }) {
                parts.add(field.lowercase().replaceFirstChar { it.uppercase() })
            }
        }
        
        // 3. Product — lowercase (e.g. "corporate")
        cardDetails.cardProduct?.takeIf { it.isNotBlank() }?.let { field ->
            if (ruleTokens.any { token -> fieldMatches(field, token) }) {
                parts.add(field.lowercase())
            }
        }
        
        // 4. Type — lowercase (e.g. "credit", "debit")
        cardDetails.cardType?.takeIf { it.isNotBlank() }?.let { field ->
            if (ruleTokens.any { token -> fieldMatches(field, token) }) {
                parts.add(field.lowercase())
            }
        }

        // 5. Prepaid — lowercase
        if (cardDetails.isPrepaid == true && ruleTokens.contains(TOKEN_PREPAID)) {
            parts.add("prepaid")
        }

        // 6. Gift — lowercase
        if (cardDetails.isNotReloadableCard == true && ruleTokens.contains(TOKEN_NOT_RELOADABLE)) {
            parts.add("gift")
        }

        // Join all parts; ensure the very first character of the result is always capitalised
        val prefix = parts.joinToString(" ").ifBlank { "These" }
        return "${prefix.replaceFirstChar { it.uppercase() }} cards are not accepted."
    }

    private fun fieldMatches(field: String, token: String): Boolean {
        val f = field.lowercase().trim()
        return f == token || f.matches(Regex("\\b${Regex.escape(token)}\\b"))
    }
}

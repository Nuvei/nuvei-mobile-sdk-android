package com.nuvei.mobilesdk.core.listeners;

public class SDKChallengeDataListener {
    private static SDKChallengeDataListener instance;

    public static SDKChallengeDataListener getInstance() {
        if (instance == null) {
            instance = new SDKChallengeDataListener();
        }
        return instance;
    }

    public void handleChallenge() {

    }
}

package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

public // NUVEI_MOBILE_SDK
class NVPayment(
    @SerializedName("sessionToken") val sessionToken: String,
    @SerializedName("merchantId") val merchantId: String,
    @SerializedName("merchantSiteId") val merchantSiteId: String,
    @SerializedName("googlePayMerchantId") val googlePayMerchantId: String? = null,
    @SerializedName("googlePayMerchantName") val googlePayMerchantName: String? = null,
    @SerializedName("googlePayGateway") val googlePayGateway: String? = null,
    @SerializedName("googlePayGatewayMerchantId") val googlePayGatewayMerchantId: String? = null,
    @SerializedName("currency") val currency: String? = null,
    @SerializedName("amount") val amount: String? = null,
    @SerializedName("paymentOption") var paymentOption: PaymentOption,
    @SerializedName("clientUniqueId") val clientUniqueId: String? = null,
    @SerializedName("clientRequestId") val clientRequestId: String? = null,
    @SerializedName("customData") val customData: String? = null,
    @SerializedName("billingAddress") val billingAddress: BillingAddress? = null,
    @SerializedName("shippingAddress") val shippingAddress: ShippingAddress? = null,
    @SerializedName("notificationUrl") val notificationUrl: String? = null,
    @SerializedName("userDetails") val userDetails: UserDetails? = null,
    @SerializedName("merchantDetails") val merchantDetails: MerchantDetails? = null,
    @SerializedName("dynamicDescriptor") val dynamicDescriptor: DynamicDescriptor? = null,
    @SerializedName("timeout") val timeout: Int = 10, // minutes (min. 5)
    @SerializedName("requestTimeout") val requestTimeout: Int = 10, // seconds
    @SerializedName("sourceApplication") val sourceApplication: String? = null,
    @SerializedName("addendums") val addendums: Addendums? = null,
    @SerializedName("cardData") val cardData: CardDetails? = null,
    @SerializedName("blockCards") val blockCards: List<List<String>>? = null
) : Serializable

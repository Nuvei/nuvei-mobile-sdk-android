package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class NVCardDetailsOutput (
    @SerializedName("brand") val brand: String?,
    @SerializedName("secondaryBrand") val secondaryBrand: String?,
    @SerializedName("cardType") val cardType: String?,
    @SerializedName("program") val program: String?,
    @SerializedName("visaDirectSupport") val visaDirectSupport: String?,
    @SerializedName("mastercardSendSupport") val mastercardSendSupport: String?,
    @SerializedName("isPrepaid") val isPrepaid: Boolean?,
    @SerializedName("issuerCountry") val issuerCountry: String?,
    @SerializedName("currency") val currency: String?,
    @SerializedName("dccAllowed") val dccAllowed: Boolean?,
    @SerializedName("sessionToken") val sessionToken: String?,
    @SerializedName("internalRequestId") val internalRequestId: Int?,
    @SerializedName("status") val status: String?,
    @SerializedName("reason") val reason: String?,
    @SerializedName("errCode") val errCode: Int?,
    @SerializedName("merchantId") val merchantId: String?,
    @SerializedName("merchantSiteId") val merchantSiteId: String?,
    @SerializedName("version") val version: String?,
    @SerializedName("clientRequestId") val clientRequestId: String?,
    @SerializedName("issuerBankName") val issuerBankName: String?,
    @SerializedName("clientUniqueId") val clientUniqueId: String?,
    @SerializedName("bin") var bin: String?,
    @SerializedName("last4Digits") var last4Digits: String?,
    @SerializedName("ccExpMonth") var ccExpMonth: String?,
    @SerializedName("ccExpYear") var ccExpYear: String?,
    @SerializedName(value = "isNotReloadable", alternate = ["isNotReloadableCard"]) val isNotReloadableCard: Boolean?,
    @SerializedName("cardProduct") val cardProduct: String?
): Serializable

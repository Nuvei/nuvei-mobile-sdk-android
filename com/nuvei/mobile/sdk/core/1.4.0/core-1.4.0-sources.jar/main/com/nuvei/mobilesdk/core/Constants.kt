package com.nuvei.mobilesdk.core

class Constants {
    companion object {
        const val APPROVED = "APPROVED"
        const val REDIRECT = "REDIRECT"
        const val DECLINED = "DECLINED"
        const val ERROR = "ERROR"
        const val CANCELLED = "CANCELLED"

        const val VERIFY_3D_NOTIF_URL_FORMAT = "/threeDSecure/completeVerify3d.do?sessionToken="
        const val PAYMENT_NOTIF_URL_FORMAT = "/threeDSecure/completePayment.do?sessionToken="

        //HTML
        const val ADD_CARD_3DS_HTML_ACS_URL_ = "_acsUrl_"
        const val ADD_CARD_3DS_HTML_PA_REQ = "_paReq_"
        const val ADD_CARD_3DS_HTML_CREQ = "_ceq_"
        const val ADD_CARD_3DS_HTML_TERM_URL = "_termUrl_"

        const val ADD_CARD_3DS_HTML = "<!DOCTYPE html>" +
                "<html>" +
                "<body onload=\"OnLoadEvent()\">" +
                "<form id=\"mainform\" novalidate action=\"$ADD_CARD_3DS_HTML_ACS_URL_\" method=\"POST\">" +
                "    <input type=\"hidden\" name=\"PaReq\" value=\"$ADD_CARD_3DS_HTML_PA_REQ\"/>" +
                "    <input type=\"hidden\" name=\"TermUrl\" value=\"$ADD_CARD_3DS_HTML_TERM_URL\"/>" +
                "</form>" +
                "<script>" +
                "function OnLoadEvent() {" +
                "  document.getElementById(\"mainform\").submit();" +
                "}" +
                "</script>" +
                "</body>" +
                "</html>"
        const val FORCE_WEB_3DS2_HTML = "<!DOCTYPE html>" +
                "<html>" +
                "<body onload=\"OnLoadEvent()\">" +
                "<form id=\"mainform\" novalidate action=\"$ADD_CARD_3DS_HTML_ACS_URL_\" method=\"POST\">" +
                "  <input type=\"hidden\" name=\"creq\" value=\"$ADD_CARD_3DS_HTML_CREQ\"/>" +
                "</form>" +
                "<script>" +
                "function OnLoadEvent() {" +
                "  document.getElementById(\"mainform\").submit();" +
                "}" +
                "</script>" +
                "</body>" +
                "</html>"
    }
}

public
object Keys {
    const val checkoutTransactionDetails = "checkoutTransactionDetails"
    const val checkoutNVPayment = "checkoutNVPayment"
    const val checkoutPaymentMethodUrl = "checkoutPaymentMethodUrl"
    const val checkoutResponse = "checkoutResponse"
    const val webCheckoutResponse = "webCheckoutResponse"
    const val googlePayRequestCode = 1000
    const val checkoutRequestCode = 1001

    const val TRANSACTION_ID = "TRANSACTION"
    const val ERROR_CODE = "ERROR_CODE"
    const val RESULT = "RESULT"
    const val RAW_RESULT = "RAW_RESULT"
    const val BIN = "BIN"
    const val LAST_4_DIGITS = "LAST_4_DIGITS"
    const val CC_EXP_MONTH = "CC_EXP_MONTH"
    const val CC_EXP_YEAR = "CC_EXP_YEAR"
    const val CC_CARD_NUMBER = "CC_CARD_NUMBER"
    const val USER_PAYMENT_OPTION_ID = "USER_PAYMENT_OPTION_ID"
    const val ERROR_DESCRIPTION = "ERROR_DESCRIPTION"
    const val IC_CREATE_PAYMENT = "IC_CREATE_PAYMENT"
}
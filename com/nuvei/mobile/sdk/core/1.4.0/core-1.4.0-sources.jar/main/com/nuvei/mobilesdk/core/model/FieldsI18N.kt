package com.nuvei.mobilesdk.core.model

object FieldsI18N {
    var cardHolderNameTitle: String = "Cardholder Name"
    var cardHolderNamePlaceholder: String = "John Smith"
    var cardNumberTitle: String = "Card Number"
    var cardNumberPlaceholder: String = "1234-5678-1234-5678"
    var expirationDateTitle: String = "Expiry Date"
    var expirationDatePlaceholder: String = "12/23"
    var cvvTitle: String = "CVV"
    var cvvPlaceholder: String = "123"
    var cvvPlaceholderAmex: String = "1234"

    var numberEmpty: String = "Please fill the credit card number"
    var cardBlocked: String = ""
    var creditCardInvalid: String = "Please enter a valid card number"
    var expiryEmpty: String = "Please fill the expiry date"
    var expiryInvalid: String = "Invalid expiration date"
    var cvvEmpty: String = "Please fill the CVV"
    var cvvInvalid: String = "CVV is invalid"
    var holderNameEmpty: String = "Please fill the card holder name"
    var holderNameInvalid: String = "Invalid cardholder name"


    var cardBrand: String = ""
    var brandError: String = ""
    var internalError: String = ""
}
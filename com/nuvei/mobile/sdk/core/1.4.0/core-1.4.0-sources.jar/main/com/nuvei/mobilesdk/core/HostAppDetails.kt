package com.nuvei.mobilesdk.core

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.telephony.TelephonyManager
import com.google.gson.annotations.SerializedName
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

class HostAppDetails(
    @SerializedName("deviceType") val deviceType: String? = null,
    @SerializedName("deviceName") val deviceName: String? = null,
    @SerializedName("deviceOS") val deviceOS: String? = null,
    @SerializedName("browser") val browser: String? = null,
    @SerializedName("ipAddress") val ipAddress: String? = null,
    @Transient val packageName: String? = null,
    @Transient val isTestApp: Boolean? = null,
    @Transient var simCountryCode: String? = null
    ) {

    companion object {

        fun setup(context: Context) {
            val xlarge = context.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK == Configuration.SCREENLAYOUT_SIZE_XLARGE
            val large = context.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK == Configuration.SCREENLAYOUT_SIZE_LARGE
            val deviceType = if (xlarge || large) "TABLET" else "SMARTPHONE"

            Nuvei.hostAppDetails = HostAppDetails(
                deviceType = deviceType,
                deviceName = Build.MODEL,
                deviceOS = Build.VERSION.RELEASE,
                ipAddress = getIPAddress(true) ,
                packageName = context.applicationContext.packageName,
                isTestApp =  context.applicationContext.packageName.startsWith("com.nuvei."),
                simCountryCode = (context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager)?.networkCountryIso?.uppercase()
            )
        }

        private fun getIPAddress(useIPv4: Boolean): String {
            try {
                val interfaces: List<NetworkInterface> = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (intf in interfaces) {
                    val addrs: List<InetAddress> = Collections.list(intf.inetAddresses)
                    for (addr in addrs) {
                        if (!addr.isLoopbackAddress) {
                            val sAddr = addr.hostAddress
                            //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                            val isIPv4 = sAddr.indexOf(':') < 0
                            if (useIPv4) {
                                if (isIPv4) return sAddr
                            } else {
                                if (!isIPv4) {
                                    val delim = sAddr.indexOf('%') // drop ip6 zone suffix
                                    return if (delim < 0) sAddr.uppercase() else sAddr.substring(0, delim).uppercase()
                                }
                            }
                        }
                    }
                }
            } catch (ignored: java.lang.Exception) {
            }
            return ""
        }
    }
}
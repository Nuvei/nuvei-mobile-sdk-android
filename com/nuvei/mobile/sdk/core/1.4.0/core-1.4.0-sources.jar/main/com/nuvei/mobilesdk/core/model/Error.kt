package com.nuvei.mobilesdk.core.model

enum class Error(val errorCode: Int, val errorDescription: String) {
    IS_PROCESSING(10000, "Previous transaction still processing"),
    INVALID_INPUT(10001, "Invalid input"),
    INTERNAL_ERROR(10002, "Internal error"),
    USER_CANCELLED(10003, "User cancelled"),
    PROTOCOL_ERROR(10004, "PROTOCOL_ERROR"),
    TIMED_OUT(10005, "TIMED_OUT"),
    MISSING_TRANSACTION_ID(10006, "Internal Error"),
    MISSING_THREE_D(10007, "Internal Error"),
    NOT_SET_UP(10008, "SDK not initialized, please call Nuvei.setup(..) function"),
    FORCE_WEB_CHALLENGE(10009, "forceWebChallenge must be true in this version"),
    GENERAL_3D_ERROR(-5, "General 3D error")
    ;
}
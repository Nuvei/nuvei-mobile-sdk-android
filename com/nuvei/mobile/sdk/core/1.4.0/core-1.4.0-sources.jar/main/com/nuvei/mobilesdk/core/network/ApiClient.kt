package com.nuvei.mobilesdk.core.network

import com.nuvei.mobilesdk.core.BuildConfig
import com.nuvei.mobilesdk.core.Constants
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.Nuvei.Environment
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okio.Buffer
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


class ApiClient {
    companion object {
        private val TAG = "Nuvei.ApiClient"

        private var retrofit: Retrofit? = null
        var service: API? = null
        var baseUrl = "https://secure.safecharge.com/ppp/api/v1/"
            private set
        private var termBaseUrl = "https://secure.safecharge.com/ppp/api"
        private var sourceApplication = "Unknown"

        fun setup(url: String) {
            baseUrl = "$url/v1/"
            termBaseUrl = url

            service = createService()
        }

        fun setSourceApplication(sourceApplication: String) {
            Companion.sourceApplication = sourceApplication
        }

        fun notificationURL(sessionToken: String, isCreatePayment: Boolean): String {
            val notifyUrlFormat = if (isCreatePayment) Constants.PAYMENT_NOTIF_URL_FORMAT else Constants.VERIFY_3D_NOTIF_URL_FORMAT
            return termBaseUrl + notifyUrlFormat + sessionToken
        }

        private val timeout: Long = if (BuildConfig.DEBUG) 60 else 30

        private fun createService(): API? {
            val okHttpClient = OkHttpClient.Builder()
                .cache(null)
                .connectTimeout(timeout, TimeUnit.SECONDS)
                .writeTimeout(timeout, TimeUnit.SECONDS)
                .readTimeout(timeout, TimeUnit.SECONDS)

            okHttpClient.addInterceptor(CustomInterceptor().apply {
                level = CustomInterceptor.Level.BODY
            })

            okHttpClient.addInterceptor {
                val request = it.request()

                val buffer = Buffer()
                request.body?.writeTo(buffer)

                val newBody = JSONObject(buffer.readUtf8()).put("sourceApplication", sourceApplication)
                buffer.clear()
                buffer.close()

                return@addInterceptor it.proceed(
                    request.newBuilder().method(
                        request.method,
                        RequestBody.create(request.body?.contentType(), newBody.toString())
                    ).build()
                )
            }

            retrofit = Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(okHttpClient.build())
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit?.create(API::class.java)
        }

//        fun service(): API? {
//            val okHttpClient = OkHttpClient.Builder()
//                    .cache(null)
//                    .connectTimeout(timeout, TimeUnit.SECONDS)
//                    .writeTimeout(timeout, TimeUnit.SECONDS)
//                    .readTimeout(timeout, TimeUnit.SECONDS)
//
//            okHttpClient.addInterceptor(CustomInterceptor().apply {
//                level = CustomInterceptor.Level.BODY
//            })
//
//            okHttpClient.addInterceptor {
//                val request = it.request()
//
//                val buffer = Buffer()
//                request.body?.writeTo(buffer)
//
//                val newBody = JSONObject(buffer.readUtf8()).put("sourceApplication", sourceApplication)
//                buffer.clear()
//                buffer.close()
//
//                return@addInterceptor it.proceed(
//                    request.newBuilder().method(
//                        request.method,
//                        RequestBody.create(request.body?.contentType(), newBody.toString())
//                    ).build()
//                )
//            }
//
//            retrofit = Retrofit.Builder()
//                    .baseUrl(baseUrl)
//                    .client(okHttpClient.build())
//                    .addConverterFactory(GsonConverterFactory.create())
//                    .build()
//
//            return retrofit?.create<API>(API::class.java)
//        }
    }
}

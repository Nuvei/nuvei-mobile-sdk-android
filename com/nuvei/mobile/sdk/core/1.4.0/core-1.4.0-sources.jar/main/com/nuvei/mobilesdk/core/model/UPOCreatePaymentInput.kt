package com.nuvei.mobilesdk.core.model

import com.google.gson.annotations.SerializedName
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.network.NetworkConstants

class UPOCreatePaymentInput(
    @SerializedName("sessionToken") val sessionToken: String,
    @SerializedName("merchantSiteId") val merchantSiteId: String,
    @SerializedName("merchantId") val merchantId: String,
    @SerializedName("currencyCode") val currencyCode: String,
    @SerializedName("userTokenId") val userTokenId: String? = null,
    @SerializedName("clientUniqueId") val clientUniqueId: String? = null,
    @SerializedName("userDetails") val userDetails: UserDetails? = null,
    @SerializedName("paymentOption") val paymentOption: PaymentOption,
    @SerializedName(NetworkConstants.webMasterId) val webMasterId: String = NetworkConstants.sdkVersionPrefix + Nuvei.sdkVersion
)

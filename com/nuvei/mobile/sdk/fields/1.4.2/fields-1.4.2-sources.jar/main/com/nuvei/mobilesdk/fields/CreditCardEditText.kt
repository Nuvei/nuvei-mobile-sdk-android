package com.nuvei.mobilesdk.fields

import android.content.Context
import androidx.appcompat.widget.AppCompatEditText
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.DigitsKeyListener
import android.util.AttributeSet

class CreditCardEditText : AppCompatEditText {
    var groupSeparator = " "
        private set

    var numberOfGroups = 5
        private set

    var groupLength = 4
        private set

    var maxLength = numberOfGroups * (groupLength + 1) - 1
        private set

    private val digitsKeyListener = DigitsKeyListener.getInstance("0123456789")

    private var initCompleted = false

    constructor(context: Context) : super(context) {
        init(null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(attrs)
    }

    private fun init(attrs: AttributeSet?) {
        maxLength = numberOfGroups * (groupLength + 1) - 1

        setSelection(text!!.length)
        inputType = InputType.TYPE_CLASS_NUMBER
        keyListener = digitsKeyListener
        addTextChangedListener(TextChangeListener())

        initCompleted = true
    }

    override fun onSelectionChanged(start: Int, end: Int) {
        if (!initCompleted) {
            return
        }

        super.onSelectionChanged(start, end)
    }

    private inner class TextChangeListener : TextWatcher {
        var listenerEnabled = true
        private var deletePosition: Int? = null

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            if (!listenerEnabled) return

            deletePosition = null

            if (!hasSelection() && count == 1 && selectionStart > 0 && after < count) {
                val value = text?.substring(selectionStart - 1, selectionStart)
                if (value == groupSeparator) {
                    deletePosition = selectionStart
                }
            }
        }

        override fun onTextChanged(text: CharSequence?, start: Int, lengthBefore: Int, lengthAfter: Int) {
        }

        override fun afterTextChanged(buffer: Editable?) {
            if (!listenerEnabled || buffer == null) return

            listenerEnabled = false

            var bufferCopy = buffer.toString()
            deletePosition?.takeIf { it > 1 && it <= bufferCopy.length }?.let {
                bufferCopy = bufferCopy.removeRange(it - 2, it - 1)
            }

            val currentFilters = buffer.filters
            buffer.filters = emptyArray()
            buffer.replace(0, buffer.length, formattedText(bufferCopy));
            buffer.filters = currentFilters

            listenerEnabled = true
        }

        fun formattedText(text: String): String {
            return text
                .filter { it.isDigit() }
                .take(maxLength)
                .chunked(groupLength)
                .joinToString(separator = groupSeparator)
        }
    }
}
package com.nuvei.mobilesdk.fields

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.fragment.app.FragmentActivity
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.InternalCallback
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.TokenizeCallback
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.fields.databinding.NuveiFieldsCardBinding
import com.nuvei.mobilesdk.fields.viewmodel.CreditCardFieldViewModel
import com.nuvei.mobilesdk.fields.viewmodel.CreditCardFieldViewModelListener
import com.nuvei.mobilesdk.fields.viewmodel.CreditCardInput
import com.nuvei.mobilesdk.core.model.FieldsI18N
import com.nuvei.mobilesdk.core.model.FieldsUICustomization
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.core.utils.CardBlockHelper
import com.nuvei.mobilesdk.core.view.FieldsErrorTextView


class NuveiCreditCardField : NuveiField {
    private lateinit var binding: NuveiFieldsCardBinding
    private val viewModel = CreditCardFieldViewModel()
    var input: CreditCardInput = CreditCardInput()
    var transactionDetails: CheckoutTransactionDetails? = null

    var onInputUpdated: ((hasFocus: Boolean, ccExpMonth: String?, ccExpYear: String? ) -> (Unit))? = null
    var onInputValidated: ((errors: Array<InputError>?) -> (Unit))? = null
    var onCardDetailsUpdate: ((output: NVCardDetailsOutput?, additionalInfo: Map<String, Any>?) -> (Unit))? = null

    constructor(context: Context) : super(context) {
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        binding = NuveiFieldsCardBinding.inflate(LayoutInflater.from(context), this, true)

        configureView()
        applyCustomization()
    }

    fun validate() {
        viewModel.parseCreditCardInfo(input, ignoreEmpty = false)
    }

    fun tokenize(
        activity: AppCompatActivity,
        transactionDetails: CheckoutTransactionDetails,
        callback: TokenizeCallback
    ) {
        viewModel.tokenize(activity, input, transactionDetails, callback)
    }

    fun createPayment(
        activity: AppCompatActivity,
        transactionDetails: CheckoutTransactionDetails,
        callback: Callback<NVCreatePaymentOutput>,
        declineFallbackDecision: ((NVCreatePaymentOutput, FragmentActivity, ((Nuvei.CheckoutCompletionAction) -> Unit)) -> Unit)?,
    ) {
        viewModel.submitCreditCardInput(
            activity,
            input,
            transactionDetails,
            callback = object : Callback<NVCreatePaymentOutput> {
                override fun onComplete(response: NVCreatePaymentOutput) {
                    if (declineFallbackDecision == null) {
                        callback.onComplete(response)
                    } else {
                        declineFallbackDecision(response, activity) { _ ->
                            callback.onComplete(
                                response
                            )
                        }
                    }
                }
            })
    }

    fun applyCustomization() {
        val customization = FieldsUICustomization

        val borderColor = customization.borderColor
        val backgroundColor = customization.backgroundColor
        val borderWidth = customization.borderWidth
        val cornerRadius = customization.cornerRadius



        with(binding) {
            ViewCompat.setBackgroundTintList(root, null)
            ViewCompat.setBackgroundTintMode(root, null)

            val pL = root.paddingLeft;
            val pT = root.paddingTop
            val pR = root.paddingRight;
            val pB = root.paddingBottom

            // closed-state border
            root.background = makeRingDrawable(
                borderColor,
                borderWidth,
                cornerRadius,
                root,
                backgroundColor
            ).mutate()

            root.setPadding(pL, pT, pR, pB)
            root.invalidate()

            allLabels().forEach {
                it.apply {
                    setTextColor(customization.textBoxCustomization.headingTextFontColor)
                    textSize = customization.textBoxCustomization.headingTextFontSize.toFloat()
                    applyNuveiFont(customization.textBoxCustomization.headingTextFontName)
                }
            }
            allInputFields().forEach { v ->
                v.apply {
                    // remove tints that can override our backgrounds
                    ViewCompat.setBackgroundTintList(v, null)
                    ViewCompat.setBackgroundTintMode(v, null)

                    val pL = v.paddingLeft;
                    val pT = v.paddingTop
                    val pR = v.paddingRight;
                    val pB = v.paddingBottom
                    // text appearance
                    v.setTextColor(customization.textBoxCustomization.textColor)
                    v.textSize = customization.textBoxCustomization.textFontSize.toFloat()
                    v.setHintWithSizeAndColor(v.hint.toString())
                    // closed-state border
                    v.background = makeRingDrawable(
                        customization.textBoxCustomization.borderColor,
                        customization.textBoxCustomization.borderWidth,
                        customization.textBoxCustomization.cornerRadius,
                        v,
                        customization.textBoxCustomization.backgroundColor
                    ).mutate()

                    v.setPadding(pL, pT, pR, pB)
                    v.invalidate()
                    applyNuveiFont(customization.textBoxCustomization.textFontName)
                }
            }
            allErrorFields().forEach {
                it.apply {
                    setTextColor(customization.errorBoxCustomization.textColor)
                    textSize = customization.errorBoxCustomization.textFontSize.toFloat()
                    applyNuveiFont(customization.errorBoxCustomization.textFontName)
                }
            }
        }
    }

    private fun makeRingDrawable(
        @ColorInt strokeColor: Int,
        strokeWidthDp: Int,
        cornerRadiusDp: Int,
        v: View,
        @ColorInt fillColor: Int? = null
    ): Drawable {
        val dm = v.resources.displayMetrics
        val stroke = strokeWidthDp * dm.density
        val r = cornerRadiusDp * dm.density

        val outer = floatArrayOf(r, r, r, r, r, r, r, r)
        val innerR = (r - stroke).coerceAtLeast(0f)
        val inner = floatArrayOf(innerR, innerR, innerR, innerR, innerR, innerR, innerR, innerR)

        // 1) Border drawn as a *ring* so corners aren’t thicker
        val ring = ShapeDrawable(
            RoundRectShape(outer, RectF(stroke, stroke, stroke, stroke), inner)
        ).apply {
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.color = strokeColor
        }

        // 2) Optional fill under the ring
        return if (fillColor == null) {
            ring
        } else {
            val fill = ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor
            }
            LayerDrawable(arrayOf(fill, ring))
        }
    }

    fun TextView.setHintWithSizeAndColor(hintText: String?) {
        if (!hintText.isNullOrEmpty()){
            val s = SpannableString(hintText).apply {
                setSpan(AbsoluteSizeSpan(FieldsUICustomization.textBoxCustomization.placeholderTextFontSize, /* dip = */ true), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(ForegroundColorSpan(FieldsUICustomization.textBoxCustomization.placeholderFontColor), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            hint = s
        }
    }

    private fun configureView() {
        val inputErrors = InputError

        with(FieldsI18N){
            binding.holderNameTitleTextView.text = cardHolderNameTitle
            binding.holderNameEditText.hint = cardHolderNamePlaceholder
            binding.numberTitleTextView.text = cardNumberTitle
            binding.numberEditText.hint = cardNumberPlaceholder
            binding.expiryTitleTextView.text = expirationDateTitle
            binding.expiryEditText.hint = expirationDatePlaceholder
            binding.cvvTitleTextView.text = cvvTitle
            binding.cvvEditText.setHintWithSizeAndColor(cvvPlaceholderAmex)

        }

        fun performInputUpdate(validate: Boolean = false, hasFocus: Boolean = false, transactionDetails: CheckoutTransactionDetails? = null, shouldGetCardDetails: Boolean = false, isExpiryEditText: Boolean = false) {
            val newInput = filledInput()
            if (input.parsedInfo != null) {
                newInput.parsedInfo = input.parsedInfo
            }

            if (validate) {
                viewModel.parseCreditCardInfo(newInput, hasFocus, ignoreEmpty = true, transactionDetails = transactionDetails, shouldGetCardDetails = shouldGetCardDetails , callback =  object : InternalCallback<NVCardDetailsOutput> {
                    override fun onSuccess(response: NVCardDetailsOutput) {
                        val digitsOnly = newInput.number.replace(" ", "")

                        if (digitsOnly.length >= 10){
                            response.bin = digitsOnly.take(6)
                            response.last4Digits = digitsOnly.takeLast(4)
                        }

                        val parsedDate = CreditCardUtils.parseDate(newInput.expiry)
                        if (parsedDate != null){
                            val (monthStr, yearStr) = parsedDate.split("/")
                            response.ccExpMonth = monthStr
                            response.ccExpYear = yearStr
                        }

                        val blockCards = transactionDetails?.blockCards
                        val matchingRule = CardBlockHelper.getMatchingRule(response, blockCards)
                        if (matchingRule != null) {
                            val msg = CardBlockHelper.getBlockedCardMessage(response, matchingRule)
                            showCardNumberError(msg)
                        }

                        onCardDetailsUpdate?.invoke(response, null)
                    }

                    override fun onFailure(
                        result: String,
                        errorCode: Int?,
                        errorDescription: String?,
                        rawResult: Map<String, Any>?
                    ) {
                        onCardDetailsUpdate?.invoke(null, mapOf(
                            "result" to result,
                            "errorCode" to (errorCode ?: 0),
                            "errorDescription" to (errorDescription ?: ""),
                            "rawResult" to (rawResult ?: emptyMap())
                        ))
                    }
                })
            }

            input = newInput
            if (isExpiryEditText){
                val parsedDate = CreditCardUtils.parseDate(newInput.expiry)
                if (parsedDate != null){
                    val (monthStr, yearStr) = parsedDate.split("/")
                    onInputUpdated?.invoke(hasFocus, monthStr, yearStr)
                }
            }else
                onInputUpdated?.invoke(hasFocus, null, null)
        }

        binding.numberErrorTextView.onValidateInput = { _, hasFocus ->
            if (hasFocus){
                clearInputErrors(inputErrors.numberErrors)
            }

            performInputUpdate(validate = true, hasFocus = hasFocus, shouldGetCardDetails = true, transactionDetails = transactionDetails)
        }

        binding.holderNameErrorTextView.onValidateInput = { _, hasFocus ->
            clearInputErrors(inputErrors.holderNameErrors)
            performInputUpdate(validate = !hasFocus, hasFocus = hasFocus)
        }

        binding.expiryErrorTextView.onValidateInput = { _, hasFocus ->
            clearInputErrors(inputErrors.expiryErrors)
            performInputUpdate(validate = !hasFocus, hasFocus = hasFocus, isExpiryEditText = true)
        }

        binding.cvvErrorTextView.onValidateInput = { _, hasFocus ->
            clearInputErrors(inputErrors.cvvErrors)
            performInputUpdate(validate = !hasFocus, hasFocus = hasFocus)
        }

        viewModel.listener = object : CreditCardFieldViewModelListener {
            override fun onLoadingChanged() {
                binding.loadingIndicator.visibility =
                    if (viewModel.isLoading) View.VISIBLE else View.GONE
            }

            override fun onInputParsed(input: CreditCardInput) {
                val fields = allErrorFields()

                input.apply {
                    with(binding) {
                        holderNameErrorTextView.setInputValue(cardHolderName)
                        numberErrorTextView.setInputValue(number)
                        expiryErrorTextView.setInputValue(expiry)
                        cvvErrorTextView.setInputValue(cvv)

                        cvvErrorTextView.maxLength = input.parsedInfo?.cvvLength ?: 4
                        cvvEditText.setHintWithSizeAndColor(if (input.parsedInfo?.cvvLength == 4) FieldsI18N.cvvPlaceholderAmex else FieldsI18N.cvvPlaceholder)
                        if (input.parsedInfo?.icon == null) {
                            cardIcon.setImageDrawable(null)
                        } else {
                            cardIcon.setImageResource(input.parsedInfo?.icon!!)
                        }
                    }

                    parsedInfo?.errors?.forEach {
                        setError(fields, it)
                    }

                    onInputValidated?.invoke(parsedInfo?.errors)
                }

                fields.forEach {
                    it.clearErrorMessage()
                }
            }

            override fun onSubmitResponse(response: NVCreatePaymentOutput) {
            }

            override fun onWebCheckoutRequired(url: String) {
            }
        }
    }

    private fun allErrorFields(): ArrayList<FieldsErrorTextView> {
        return with(binding) {
            arrayListOf(
                numberErrorTextView,
                holderNameErrorTextView,
                expiryErrorTextView,
                cvvErrorTextView
            )
        }
    }

    private fun allInputFields(): ArrayList<EditText> {
        return with(binding) {
            arrayListOf(
                numberEditText,
                holderNameEditText,
                expiryEditText,
                cvvEditText
            )
        }
    }

    private fun allLabels(): ArrayList<TextView> {
        return with(binding) {
            arrayListOf(
                numberTitleTextView,
                holderNameTitleTextView,
                expiryTitleTextView,
                cvvTitleTextView
            )
        }
    }

    private fun filledInput(): CreditCardInput {
        return with(binding) {
            CreditCardInput(
                index = 0,
                cardHolderName = holderNameEditText.text.toString(),
                number = numberEditText.text.toString(),
                expiry = expiryEditText.getFullDate(),
                cvv = cvvEditText.text.toString()
            )
        }
    }

    private fun clearInputErrors(clearedErrors: Array<InputError>) {
        input.parsedInfo?.let { parsedInfo ->
            val existingErrors = parsedInfo.errors ?: return

            val newErrors = ArrayList<InputError>()

            existingErrors.forEach { existingError ->
                var shouldKeep = true
                for (clearedError in clearedErrors) {
                    if (clearedError == existingError) {
                        shouldKeep = false
                        break
                    }
                }
                if (shouldKeep) {
                    newErrors.add(existingError)
                }
            }

            parsedInfo.errors = newErrors.toTypedArray()
        }
    }

    private fun setError(fields: ArrayList<FieldsErrorTextView>, checkoutInputError: InputError) {
        with(binding) {
            when (checkoutInputError) {
                InputError.CreditCardBlocked -> {
                    numberErrorTextView.setErrorMessage(
                        FieldsI18N.cardBlocked.takeUnless { it.isBlank() } ?: FieldsI18N.cardBlockedConstructed,
                        checkoutInputError
                    )

                    fields.removeAll { it == numberErrorTextView }
                }

                InputError.CreditCardInvalid -> {
                    numberErrorTextView.setErrorMessage(
                        FieldsI18N.creditCardInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == numberErrorTextView }
                }

                InputError.NumberEmpty -> {
                    numberErrorTextView.setErrorMessage(
                        FieldsI18N.numberEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == numberErrorTextView }
                }

                InputError.CVVEmpty -> {
                    cvvErrorTextView.setErrorMessage(
                        FieldsI18N.cvvEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == cvvErrorTextView }
                }

                InputError.CVVInvalid -> {
                    cvvErrorTextView.setErrorMessage(
                        FieldsI18N.cvvInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == cvvErrorTextView }
                }

                InputError.ExpiryEmpty -> {
                    expiryErrorTextView.setErrorMessage(
                        FieldsI18N.expiryEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == expiryErrorTextView }
                }

                InputError.ExpiryInvalid -> {
                    expiryErrorTextView.setErrorMessage(
                        FieldsI18N.expiryInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == expiryErrorTextView }
                }

                InputError.HolderNameEmpty -> {
                    holderNameErrorTextView.setErrorMessage(
                        FieldsI18N.holderNameEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == holderNameErrorTextView }
                }

                InputError.HolderNameInvalid -> {
                    holderNameErrorTextView.setErrorMessage(
                        FieldsI18N.holderNameInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == holderNameErrorTextView }
                }

                else -> { }
            }
        }
    }

    fun showCardNumberError(message: String) {
        // Always write to cardBlockedConstructed; never overwrite the client-provided cardBlocked
        FieldsI18N.cardBlockedConstructed = message

        input.parsedInfo?.let {
            it.errors = (it.errors?.toMutableList() ?: mutableListOf()).apply {
                add(InputError.CreditCardBlocked)
            }.toTypedArray()
            it.errors?.forEach {
            setError(allErrorFields(), it)
            }
        }
    }

    private fun TextView.customizeTypeFace(fontName: String?) {
        @Suppress("NAME_SHADOWING")
        val fontName = fontName ?: return
        typeface = try {
            Typeface.createFromAsset(context.assets, "fonts/$fontName")
        } catch (e: RuntimeException) {
            Log.e("[3DSSDK]", "Can't load custom typeface. Failed with exception: $e")
            typeface // fallback to default
        }
    }
}

package com.nuvei.mobilesdk.fields

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.text.Editable
import android.text.TextWatcher
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.fragment.app.FragmentActivity
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.InternalCallback
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.TokenizeCallback
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.fields.databinding.NuveiFieldsCardBinding
import com.nuvei.mobilesdk.fields.viewmodel.CreditCardFieldViewModel
import com.nuvei.mobilesdk.fields.viewmodel.CreditCardFieldViewModelListener
import com.nuvei.mobilesdk.fields.viewmodel.CreditCardInput
import com.nuvei.mobilesdk.core.model.FieldsI18N
import com.nuvei.mobilesdk.core.model.FieldsUICustomization
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.core.utils.CardBlockHelper
import com.nuvei.mobilesdk.core.view.FieldsErrorTextView


import com.nuvei.mobilesdk.core.NuveiCardField
import com.nuvei.mobilesdk.core.model.NVCardDetailsInput


class NuveiCreditCardField : NuveiField, NuveiCardField {
    private lateinit var binding: NuveiFieldsCardBinding
    private val viewModel = CreditCardFieldViewModel()
    var input: CreditCardInput = CreditCardInput()
    var transactionDetails: CheckoutTransactionDetails? = null

    var onInputUpdated: ((hasFocus: Boolean, ccExpMonth: String?, ccExpYear: String? ) -> (Unit))? = null
    var onInputValidated: ((errors: Array<InputError>?) -> (Unit))? = null
    var onCardDetailsUpdate: ((output: NVCardDetailsOutput?, additionalInfo: Map<String, Any>?) -> (Unit))? = null

    var onPaymentFormChange: ((pm: String, label: String, action: String, oldValue: String, newValue: String, validation: String, paste: Boolean) -> Unit)? = null
    var onFormValidated: ((isFormValid: Boolean, invalidFields: List<String>) -> Unit)? = null

    private var lastIsFormValid: Boolean? = null
    private var lastInvalidFields: List<String>? = null
    private val fieldFocusSessionStartValues = mutableMapOf<String, String>()
    private val fieldFocusSessionPasted = mutableMapOf<String, Boolean>()
    private val focusStateMap = mutableMapOf<String, Boolean>()
    private val enteredFields = HashSet<String>()

    constructor(context: Context) : super(context) {
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        binding = NuveiFieldsCardBinding.inflate(LayoutInflater.from(context), this, true)

        configureView()
        applyCustomization()
    }

    fun validate() {
        viewModel.parseCreditCardInfo(input, ignoreEmpty = false)
    }

    fun tokenize(
        activity: AppCompatActivity,
        transactionDetails: CheckoutTransactionDetails,
        callback: TokenizeCallback
    ) {
        viewModel.tokenize(activity, input, transactionDetails, callback)
    }

    fun createPayment(
        activity: AppCompatActivity,
        transactionDetails: CheckoutTransactionDetails,
        callback: Callback<NVCreatePaymentOutput>,
        declineFallbackDecision: ((NVCreatePaymentOutput, FragmentActivity, ((Nuvei.CheckoutCompletionAction) -> Unit)) -> Unit)?,
    ) {
        viewModel.submitCreditCardInput(
            activity,
            input,
            transactionDetails,
            callback = object : Callback<NVCreatePaymentOutput> {
                override fun onComplete(response: NVCreatePaymentOutput) {
                    if (declineFallbackDecision == null) {
                        callback.onComplete(response)
                    } else {
                        declineFallbackDecision(response, activity) { _ ->
                            callback.onComplete(
                                response
                            )
                        }
                    }
                }
            })
    }

    fun applyCustomization() {
        val customization = FieldsUICustomization

        val borderColor = customization.borderColor
        val backgroundColor = customization.backgroundColor
        val borderWidth = customization.borderWidth
        val cornerRadius = customization.cornerRadius



        with(binding) {
            ViewCompat.setBackgroundTintList(root, null)
            ViewCompat.setBackgroundTintMode(root, null)

            val pL = root.paddingLeft;
            val pT = root.paddingTop
            val pR = root.paddingRight;
            val pB = root.paddingBottom

            // closed-state border
            root.background = makeRingDrawable(
                borderColor,
                borderWidth,
                cornerRadius,
                root,
                backgroundColor
            ).mutate()

            root.setPadding(pL, pT, pR, pB)
            root.invalidate()

            allLabels().forEach {
                it.apply {
                    setTextColor(customization.textBoxCustomization.headingTextFontColor)
                    textSize = customization.textBoxCustomization.headingTextFontSize.toFloat()
                    applyNuveiFont(customization.textBoxCustomization.headingTextFontName)
                }
            }
            allInputFields().forEach { v ->
                v.apply {
                    // remove tints that can override our backgrounds
                    ViewCompat.setBackgroundTintList(v, null)
                    ViewCompat.setBackgroundTintMode(v, null)

                    val pL = v.paddingLeft;
                    val pT = v.paddingTop
                    val pR = v.paddingRight;
                    val pB = v.paddingBottom
                    // text appearance
                    v.setTextColor(customization.textBoxCustomization.textColor)
                    v.textSize = customization.textBoxCustomization.textFontSize.toFloat()
                    v.setHintWithSizeAndColor(v.hint.toString())
                    // closed-state border
                    v.background = makeRingDrawable(
                        customization.textBoxCustomization.borderColor,
                        customization.textBoxCustomization.borderWidth,
                        customization.textBoxCustomization.cornerRadius,
                        v,
                        customization.textBoxCustomization.backgroundColor
                    ).mutate()

                    v.setPadding(pL, pT, pR, pB)
                    v.invalidate()
                    applyNuveiFont(customization.textBoxCustomization.textFontName)
                }
            }
            allErrorFields().forEach {
                it.apply {
                    setTextColor(customization.errorBoxCustomization.textColor)
                    textSize = customization.errorBoxCustomization.textFontSize.toFloat()
                    applyNuveiFont(customization.errorBoxCustomization.textFontName)
                }
            }
        }
    }

    private fun makeRingDrawable(
        @ColorInt strokeColor: Int,
        strokeWidthDp: Int,
        cornerRadiusDp: Int,
        v: View,
        @ColorInt fillColor: Int? = null
    ): Drawable {
        val dm = v.resources.displayMetrics
        val stroke = strokeWidthDp * dm.density
        val r = cornerRadiusDp * dm.density

        val outer = floatArrayOf(r, r, r, r, r, r, r, r)

        if (stroke <= 0f) {
            return ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor ?: android.graphics.Color.TRANSPARENT
            }
        }

        val innerR = (r - stroke).coerceAtLeast(0f)
        val inner = floatArrayOf(innerR, innerR, innerR, innerR, innerR, innerR, innerR, innerR)

        // 1) Border drawn as a *ring* so corners aren’t thicker
        val ring = ShapeDrawable(
            RoundRectShape(outer, RectF(stroke, stroke, stroke, stroke), inner)
        ).apply {
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.color = strokeColor
        }

        // 2) Optional fill under the ring
        return if (fillColor == null) {
            ring
        } else {
            val fill = ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor
            }
            LayerDrawable(arrayOf(fill, ring))
        }
    }

    fun TextView.setHintWithSizeAndColor(hintText: String?) {
        if (!hintText.isNullOrEmpty()){
            val s = SpannableString(hintText).apply {
                setSpan(AbsoluteSizeSpan(FieldsUICustomization.textBoxCustomization.placeholderTextFontSize, /* dip = */ true), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(ForegroundColorSpan(FieldsUICustomization.textBoxCustomization.placeholderFontColor), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            hint = s
        }
    }

    private fun configureView() {
        val inputErrors = InputError

        with(FieldsI18N){
            binding.holderNameTitleTextView.text = cardHolderNameTitle
            binding.holderNameEditText.hint = cardHolderNamePlaceholder
            binding.numberTitleTextView.text = cardNumberTitle
            binding.numberEditText.hint = cardNumberPlaceholder
            binding.expiryTitleTextView.text = expirationDateTitle
            binding.expiryEditText.hint = expirationDatePlaceholder
            binding.cvvTitleTextView.text = cvvTitle
            binding.cvvEditText.setHintWithSizeAndColor(cvvPlaceholderAmex)

        }

        fun performInputUpdate(validate: Boolean = false, hasFocus: Boolean = false, transactionDetails: CheckoutTransactionDetails? = null, shouldGetCardDetails: Boolean = false, isExpiryEditText: Boolean = false) {
            val newInput = filledInput()
            if (input.parsedInfo != null) {
                newInput.parsedInfo = input.parsedInfo
            }

            if (validate) {
                viewModel.parseCreditCardInfo(newInput, hasFocus, ignoreEmpty = true, transactionDetails = transactionDetails, shouldGetCardDetails = shouldGetCardDetails , callback =  object : InternalCallback<NVCardDetailsOutput> {
                    override fun onSuccess(response: NVCardDetailsOutput) {


                        val blockCards = transactionDetails?.blockCards
                        val matchingRule = CardBlockHelper.getMatchingRule(response, blockCards)
                        if (matchingRule != null) {
                            val msg = CardBlockHelper.getBlockedCardMessage(response, matchingRule)
                            showCardNumberError(msg)
                        }

                        onCardDetailsUpdate?.invoke(response, null)
                    }

                    override fun onFailure(
                        result: String,
                        errorCode: Int?,
                        errorDescription: String?,
                        rawResult: Map<String, Any>?
                    ) {
                        onCardDetailsUpdate?.invoke(null, mapOf(
                            "result" to result,
                            "errorCode" to (errorCode ?: 0),
                            "errorDescription" to (errorDescription ?: ""),
                            "rawResult" to (rawResult ?: emptyMap())
                        ))
                    }
                })
            }

            input = newInput
            if (isExpiryEditText){
                val parsedDate = CreditCardUtils.parseDate(newInput.expiry)
                if (parsedDate != null){
                    val (monthStr, yearStr) = parsedDate.split("/")
                    onInputUpdated?.invoke(hasFocus, monthStr, yearStr)
                }
            }else
                onInputUpdated?.invoke(hasFocus, null, null)
        }

        binding.numberErrorTextView.onValidateInput = { _, hasFocus ->
            if (hasFocus){
                clearInputErrors(inputErrors.numberErrors)
            }

            performInputUpdate(validate = true, hasFocus = hasFocus, shouldGetCardDetails = true, transactionDetails = transactionDetails)
        }

        binding.holderNameErrorTextView.onValidateInput = { _, hasFocus ->
            clearInputErrors(inputErrors.holderNameErrors)
            performInputUpdate(validate = !hasFocus, hasFocus = hasFocus)
        }

        binding.expiryErrorTextView.onValidateInput = { _, hasFocus ->
            clearInputErrors(inputErrors.expiryErrors)
            performInputUpdate(validate = !hasFocus, hasFocus = hasFocus, isExpiryEditText = true)
        }

        binding.cvvErrorTextView.onValidateInput = { _, hasFocus ->
            clearInputErrors(inputErrors.cvvErrors)
            performInputUpdate(validate = !hasFocus, hasFocus = hasFocus)
        }

        viewModel.listener = object : CreditCardFieldViewModelListener {
            override fun onLoadingChanged() {
                binding.loadingIndicator.visibility =
                    if (viewModel.isLoading) View.VISIBLE else View.GONE
            }

            override fun onInputParsed(input: CreditCardInput) {
                val fields = allErrorFields()

                input.apply {
                    with(binding) {
                        holderNameErrorTextView.setInputValue(cardHolderName)
                        numberErrorTextView.setInputValue(number)
                        expiryErrorTextView.setInputValue(expiry)
                        cvvErrorTextView.setInputValue(cvv)

                        cvvErrorTextView.maxLength = input.parsedInfo?.cvvLength ?: 4
                        cvvEditText.setHintWithSizeAndColor(if (input.parsedInfo?.cvvLength == 4) FieldsI18N.cvvPlaceholderAmex else FieldsI18N.cvvPlaceholder)
                        if (input.parsedInfo?.icon == null) {
                            cardIcon.setImageDrawable(null)
                        } else {
                            cardIcon.setImageResource(input.parsedInfo?.icon!!)
                        }
                    }

                    parsedInfo?.errors?.forEach {
                        setError(fields, it)
                    }

                    onInputValidated?.invoke(parsedInfo?.errors)
                }

                fields.forEach {
                    it.clearErrorMessage()
                }

                evaluateAndTriggerFormValidationTransition()
            }

            override fun onSubmitResponse(response: NVCreatePaymentOutput) {
            }

            override fun onWebCheckoutRequired(url: String) {
            }
        }
        setupEventParityListeners()
    }

    private fun setupEventParityListeners() {
        val fields = listOf(
            Triple(binding.numberEditText, "cc_num", binding.numberErrorTextView),
            Triple(binding.holderNameEditText, "card_holder", binding.holderNameErrorTextView),
            Triple(binding.expiryEditText, "cc_exp", binding.expiryErrorTextView),
            Triple(binding.cvvEditText, "cc_cvv", binding.cvvErrorTextView)
        )

        for ((editText, label, errorView) in fields) {
            val initialVal = getFieldText(editText)
            fieldFocusSessionStartValues[label] = initialVal
            fieldFocusSessionPasted[label] = false
            focusStateMap[label] = editText.hasFocus()

            editText.addTextChangedListener(object : TextWatcher {
                private var beforeText = ""
                private var changeDepth = 0

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                    val isFormatting = (editText as? com.nuvei.mobilesdk.fields.CreditCardEditText)?.isFormatting == true
                    if (isFormatting) return

                    changeDepth++
                    if (changeDepth > 1) return
                    beforeText = s?.toString() ?: ""
                }
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (editText.getTag(com.nuvei.mobilesdk.core.R.id.TAG_PROGRAMMATIC_CHANGE) == true) return
                    val isFormatting = (editText as? com.nuvei.mobilesdk.fields.CreditCardEditText)?.isFormatting == true
                    if (isFormatting) return

                    if (changeDepth > 1) return
                    if (count > 0) {
                        val inserted = s?.subSequence(start, start + count)?.toString()
                        if (inserted != null) {
                            var matched = false
                            try {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                val clip = clipboard?.primaryClip
                                if (clip != null && clip.itemCount > 0) {
                                    val clipText = clip.getItemAt(0).text?.toString()
                                    if (clipText != null) {
                                        val normInserted = inserted.filter { it.isLetterOrDigit() }
                                        val normClip = clipText.filter { it.isLetterOrDigit() }
                                        if (normInserted.isNotEmpty() && normInserted == normClip) {
                                            fieldFocusSessionPasted[label] = true
                                            matched = true
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                // Handled via fallback below
                            }
                            if (!matched) {
                                val isNumericField = label == "cc_num" || label == "cc_exp" || label == "cc_cvv"
                                val fallbackThreshold = if (isNumericField) 1 else 3
                                if (inserted.length > fallbackThreshold && (count - before) > 1) {
                                    fieldFocusSessionPasted[label] = true
                                }
                            }
                        }
                    }
                }
                override fun afterTextChanged(s: Editable?) {
                    val isFormatting = (editText as? com.nuvei.mobilesdk.fields.CreditCardEditText)?.isFormatting == true
                    if (isFormatting) return

                    changeDepth--
                    if (changeDepth > 0) return
                    evaluateAndTriggerFormValidationTransition()
                }
            })

            val existingListener = editText.onFocusChangeListener
            editText.setOnFocusChangeListener { v, hasFocus ->
                existingListener?.onFocusChange(v, hasFocus)

                val currentText = getFieldText(editText)
                val wasFocused = focusStateMap[label] ?: false
                if (hasFocus != wasFocused) {
                    val newInput = filledInput()
                    if (input.parsedInfo != null) {
                        newInput.parsedInfo = input.parsedInfo
                    }
                    input = newInput

                    focusStateMap[label] = hasFocus
                    val action = if (hasFocus) "focus" else "blur"
                    
                    val rawOldValue = if (hasFocus) currentText else (fieldFocusSessionStartValues[label] ?: "")
                    val rawNewValue = currentText

                    val oldValue = when (label) {
                        "cc_num" -> maskCardNumber(rawOldValue)
                        "cc_exp", "cc_cvv" -> if (rawOldValue.isNotEmpty()) "****" else ""
                        else -> rawOldValue
                    }
                    val newValue = when (label) {
                        "cc_num" -> maskCardNumber(rawNewValue)
                        "cc_exp", "cc_cvv" -> if (rawNewValue.isNotEmpty()) "****" else ""
                        else -> rawNewValue
                    }

                    val hasBeenEntered = enteredFields.contains(label)
                    if (hasFocus) {
                        enteredFields.add(label)
                    }
                    val validationError = if (action == "focus" && !hasBeenEntered) "" else (getFieldError(label) ?: "")
                    val paste = if (hasFocus) false else (fieldFocusSessionPasted[label] ?: false)

                    val displayLabel = when (label) {
                        "cc_num" -> binding.numberTitleTextView.text?.toString()?.trim()
                        "card_holder" -> binding.holderNameTitleTextView.text?.toString()?.trim()
                        "cc_exp" -> binding.expiryTitleTextView.text?.toString()?.trim()
                        "cc_cvv" -> binding.cvvTitleTextView.text?.toString()?.trim()
                        else -> null
                    } ?: label

                    onPaymentFormChange?.invoke(
                        "cc_card",
                        displayLabel,
                        action,
                        oldValue,
                        newValue,
                        validationError,
                        paste
                    )

                    if (hasFocus) {
                        fieldFocusSessionStartValues[label] = currentText
                        fieldFocusSessionPasted[label] = false
                    } else {
                        fieldFocusSessionStartValues[label] = currentText
                    }

                    evaluateAndTriggerFormValidationTransition()
                }
            }
        }

        val tempInput = filledInput()
        viewModel.parseAndValidateCreditCardInput(tempInput, ignoreEmpty = false)
        lastInvalidFields = getInvalidFields(tempInput.parsedInfo?.errors)
        lastIsFormValid = lastInvalidFields?.isEmpty() == true
    }

    private fun evaluateAndTriggerFormValidationTransition() {
        val tempInput = filledInput()
        viewModel.parseAndValidateCreditCardInput(tempInput, ignoreEmpty = false)
        val errors = tempInput.parsedInfo?.errors
        val invalidFields = getInvalidFields(errors)
        val isFormValid = invalidFields.isEmpty()

        if (isFormValid != lastIsFormValid || invalidFields != lastInvalidFields) {
            lastIsFormValid = isFormValid
            lastInvalidFields = invalidFields
            onFormValidated?.invoke(isFormValid, invalidFields)
        }
    }

    private fun getFieldError(label: String): String? {
        val tempInput = filledInput()
        viewModel.parseAndValidateCreditCardInput(tempInput, ignoreEmpty = false)
        val errors = tempInput.parsedInfo?.errors ?: return null

        for (error in errors) {
            when (error) {
                InputError.CreditCardBlocked -> {
                    if (label == "cc_num") {
                        return FieldsI18N.cardBlocked.takeUnless { it.isBlank() } ?: FieldsI18N.cardBlockedConstructed
                    }
                }
                InputError.CreditCardInvalid -> {
                    if (label == "cc_num") return FieldsI18N.creditCardInvalid
                }
                InputError.NumberEmpty -> {
                    if (label == "cc_num") return FieldsI18N.numberEmpty
                }
                InputError.CVVEmpty -> {
                    if (label == "cc_cvv") return FieldsI18N.cvvEmpty
                }
                InputError.CVVInvalid -> {
                    if (label == "cc_cvv") return FieldsI18N.cvvInvalid
                }
                InputError.ExpiryEmpty -> {
                    if (label == "cc_exp") return FieldsI18N.expiryEmpty
                }
                InputError.ExpiryInvalid -> {
                    if (label == "cc_exp") return FieldsI18N.expiryInvalid
                }
                InputError.HolderNameEmpty -> {
                    if (label == "card_holder") return FieldsI18N.holderNameEmpty
                }
                InputError.HolderNameInvalid -> {
                    if (label == "card_holder") return FieldsI18N.holderNameInvalid
                }
                else -> { }
            }
        }
        return null
    }

    private fun getInvalidFields(errors: Array<InputError>?): List<String> {
        val invalid = mutableSetOf<String>()
        errors?.forEach { error ->
            when (error) {
                InputError.NumberEmpty, InputError.CreditCardInvalid, InputError.CreditCardBlocked -> invalid.add("cc_num")
                InputError.ExpiryEmpty, InputError.ExpiryInvalid -> invalid.add("cc_exp")
                InputError.CVVEmpty, InputError.CVVInvalid -> invalid.add("cc_cvv")
                InputError.HolderNameEmpty, InputError.HolderNameInvalid -> invalid.add("card_holder")
                else -> { }
            }
        }
        return invalid.toList()
    }

    private fun detectCardBrand(number: String): String? {
        val cleanNumber = number.replace("[^0-9]".toRegex(), "")
        if (cleanNumber.isEmpty()) return null

        if (cleanNumber.startsWith("4")) return "visa"
        if (cleanNumber.startsWith("34") || cleanNumber.startsWith("37")) return "amex"
        
        if (cleanNumber.length >= 2) {
            val prefix2 = cleanNumber.substring(0, 2).toIntOrNull()
            if (prefix2 != null && prefix2 in 51..55) {
                return "mastercard"
            }
        }
        if (cleanNumber.length >= 4) {
            val prefix4 = cleanNumber.substring(0, 4).toIntOrNull()
            if (prefix4 != null && prefix4 in 2221..2720) {
                return "mastercard"
            }
        }

        if (cleanNumber.startsWith("36") || cleanNumber.startsWith("38")) return "diners"
        if (cleanNumber.length >= 3) {
            val prefix3 = cleanNumber.substring(0, 3).toIntOrNull()
            if (prefix3 != null && prefix3 in 300..305) {
                return "diners"
            }
        }

        if (cleanNumber.startsWith("65")) return "discover"
        if (cleanNumber.length >= 3) {
            val prefix3 = cleanNumber.substring(0, 3).toIntOrNull()
            if (prefix3 != null && prefix3 in 644..649) {
                return "discover"
            }
        }
        if (cleanNumber.startsWith("6011")) return "discover"

        if (cleanNumber.startsWith("35") || cleanNumber.startsWith("2131") || cleanNumber.startsWith("1800")) return "jcb"

        if (cleanNumber.startsWith("62") || cleanNumber.startsWith("88")) return "unionpay"

        val maestroPrefixes = listOf("5018", "5020", "5038", "5893", "6304", "6759", "6761", "6762", "6763")
        for (pref in maestroPrefixes) {
            if (cleanNumber.startsWith(pref)) return "maestro"
        }

        val eloPrefixes = listOf("636368", "438935", "504175", "451416", "636297", "5067", "4576", "4011")
        for (pref in eloPrefixes) {
            if (cleanNumber.startsWith(pref)) return "elo"
        }

        if (cleanNumber.startsWith("606282") || cleanNumber.startsWith("3841")) return "hipercard"

        return null
    }

    private fun maskCardNumber(number: String): String {
        val cleanNumber = number.replace("[^0-9]".toRegex(), "")
        if (cleanNumber.isEmpty()) return ""
        
        val parsedCard = CreditCardUtils.parseCardNumber(cleanNumber)
        return if (parsedCard != null) {
            val brand = (detectCardBrand(cleanNumber) ?: "unknown").lowercase()
            val last4 = if (cleanNumber.length >= 4) {
                cleanNumber.substring(cleanNumber.length - 4)
            } else {
                cleanNumber
            }
            brand + last4
        } else {
            ""
        }
    }

    private fun getFieldText(editText: EditText): String {
        return if (editText is ExpiryEditText) {
            editText.getFullDate()
        } else {
            editText.text.toString()
        }
    }

    private fun allErrorFields(): ArrayList<FieldsErrorTextView> {
        return with(binding) {
            arrayListOf(
                numberErrorTextView,
                holderNameErrorTextView,
                expiryErrorTextView,
                cvvErrorTextView
            )
        }
    }

    private fun allInputFields(): ArrayList<EditText> {
        return with(binding) {
            arrayListOf(
                numberEditText,
                holderNameEditText,
                expiryEditText,
                cvvEditText
            )
        }
    }

    private fun allLabels(): ArrayList<TextView> {
        return with(binding) {
            arrayListOf(
                numberTitleTextView,
                holderNameTitleTextView,
                expiryTitleTextView,
                cvvTitleTextView
            )
        }
    }

    private fun filledInput(): CreditCardInput {
        return with(binding) {
            CreditCardInput(
                index = 0,
                cardHolderName = holderNameEditText.text.toString(),
                number = numberEditText.text.toString(),
                expiry = expiryEditText.getFullDate(),
                cvv = cvvEditText.text.toString()
            )
        }
    }

    private fun clearInputErrors(clearedErrors: Array<InputError>) {
        input.parsedInfo?.let { parsedInfo ->
            val existingErrors = parsedInfo.errors ?: return

            val newErrors = ArrayList<InputError>()

            existingErrors.forEach { existingError ->
                var shouldKeep = true
                for (clearedError in clearedErrors) {
                    if (clearedError == existingError) {
                        shouldKeep = false
                        break
                    }
                }
                if (shouldKeep) {
                    newErrors.add(existingError)
                }
            }

            parsedInfo.errors = newErrors.toTypedArray()
        }
    }

    private fun setError(fields: ArrayList<FieldsErrorTextView>, checkoutInputError: InputError) {
        with(binding) {
            when (checkoutInputError) {
                InputError.CreditCardBlocked -> {
                    numberErrorTextView.setErrorMessage(
                        FieldsI18N.cardBlocked.takeUnless { it.isBlank() } ?: FieldsI18N.cardBlockedConstructed,
                        checkoutInputError
                    )

                    fields.removeAll { it == numberErrorTextView }
                }

                InputError.CreditCardInvalid -> {
                    numberErrorTextView.setErrorMessage(
                        FieldsI18N.creditCardInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == numberErrorTextView }
                }

                InputError.NumberEmpty -> {
                    numberErrorTextView.setErrorMessage(
                        FieldsI18N.numberEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == numberErrorTextView }
                }

                InputError.CVVEmpty -> {
                    cvvErrorTextView.setErrorMessage(
                        FieldsI18N.cvvEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == cvvErrorTextView }
                }

                InputError.CVVInvalid -> {
                    cvvErrorTextView.setErrorMessage(
                        FieldsI18N.cvvInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == cvvErrorTextView }
                }

                InputError.ExpiryEmpty -> {
                    expiryErrorTextView.setErrorMessage(
                        FieldsI18N.expiryEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == expiryErrorTextView }
                }

                InputError.ExpiryInvalid -> {
                    expiryErrorTextView.setErrorMessage(
                        FieldsI18N.expiryInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == expiryErrorTextView }
                }

                InputError.HolderNameEmpty -> {
                    holderNameErrorTextView.setErrorMessage(
                        FieldsI18N.holderNameEmpty,
                        checkoutInputError
                    )
                    fields.removeAll { it == holderNameErrorTextView }
                }

                InputError.HolderNameInvalid -> {
                    holderNameErrorTextView.setErrorMessage(
                        FieldsI18N.holderNameInvalid,
                        checkoutInputError
                    )
                    fields.removeAll { it == holderNameErrorTextView }
                }

                else -> { }
            }
        }
    }

    fun showCardNumberError(message: String) {
        // Always write to cardBlockedConstructed; never overwrite the client-provided cardBlocked
        FieldsI18N.cardBlockedConstructed = message

        input.parsedInfo?.let {
            it.errors = (it.errors?.toMutableList() ?: mutableListOf()).apply {
                add(InputError.CreditCardBlocked)
            }.toTypedArray()
            it.errors?.forEach {
            setError(allErrorFields(), it)
            }
        }
    }

    private fun TextView.customizeTypeFace(fontName: String?) {
        @Suppress("NAME_SHADOWING")
        val fontName = fontName ?: return
        typeface = try {
            Typeface.createFromAsset(context.assets, "fonts/$fontName")
        } catch (e: RuntimeException) {
            Log.e("[3DSSDK]", "Can't load custom typeface. Failed with exception: $e")
            typeface // fallback to default
        }
    }

    override fun getCardDetailsInput(): NVCardDetailsInput? {
        val newInput = filledInput()
        if (input.parsedInfo != null) {
            newInput.parsedInfo = input.parsedInfo
        }
        input = newInput

        val digitsOnly = input.number.replace(" ", "")
        val parsedCard = com.nuvei.mobilesdk.core.CreditCardUtils.parseCardNumber(input.number)
        
        val error = when {
            digitsOnly.isEmpty() -> com.nuvei.mobilesdk.core.model.InputError.NumberEmpty
            parsedCard == null -> com.nuvei.mobilesdk.core.model.InputError.CreditCardInvalid
            else -> null
        }

        if (error != null) {
            input.parsedInfo = CreditCardInput.ParsedInfo(
                arrayOf(error),
                com.nuvei.mobilesdk.core.CreditCardUtils.iconForCard(parsedCard),
                parsedCard?.type?.cvvLength ?: 4
            )
            viewModel.listener?.onInputParsed(input)
            return null
        } else {
            clearInputErrors(arrayOf(com.nuvei.mobilesdk.core.model.InputError.NumberEmpty, com.nuvei.mobilesdk.core.model.InputError.CreditCardInvalid))
            viewModel.listener?.onInputParsed(input)
        }

        val transaction = transactionDetails
        val sessionToken = transaction?.sessionToken ?: ""
        val merchantId = transaction?.merchantId ?: ""
        val merchantSiteId = transaction?.merchantSiteId ?: ""
        val clientRequestId = transaction?.clientRequestId ?: ""
        val clientUniqueId = transaction?.clientUniqueId

        return NVCardDetailsInput(
            sessionToken = sessionToken,
            merchantId = merchantId,
            merchantSiteId = merchantSiteId,
            clientRequestId = clientRequestId,
            clientUniqueId = clientUniqueId,
            cardNumber = digitsOnly
        )
    }
}

package com.nuvei.mobilesdk.fields.viewmodel

import android.app.Activity
import android.os.Handler
import android.os.Looper
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.InternalCallback
import com.nuvei.mobilesdk.core.TokenizeCallback
import com.nuvei.mobilesdk.core.model.CardDetails
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.model.PaymentOption
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.isValidCvv
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.Error
import com.nuvei.mobilesdk.core.model.NVCardDetailsInput
import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput
import java.io.Serializable

interface CreditCardFieldViewModelListener {
    fun onLoadingChanged()
    fun onInputParsed(input: CreditCardInput)
    fun onSubmitResponse(response: NVCreatePaymentOutput)
    fun onWebCheckoutRequired(url: String)
}

class CreditCardFieldViewModel {
    var isLoading = false
    var listener: CreditCardFieldViewModelListener? = null

    fun parseCreditCardInfo(input: CreditCardInput, hasFocus: Boolean = false, ignoreEmpty: Boolean = true, transactionDetails: CheckoutTransactionDetails? = null,shouldGetCardDetails: Boolean = false, callback: InternalCallback<NVCardDetailsOutput> ? = null) {
        if (hasFocus) { // Only parse the card type, while the user is typing
            val parsedCard = CreditCardUtils.parseCardNumber(input.number)
            input.parsedInfo = CreditCardInput.ParsedInfo(
                input.parsedInfo?.errors,
                CreditCardUtils.iconForCard(parsedCard),
                parsedCard?.type?.cvvLength ?: 4
            )
            if (parsedCard != null && shouldGetCardDetails && transactionDetails != null){
                Nuvei.getCardDetails(NVCardDetailsInput(
                    sessionToken = transactionDetails.sessionToken,
                    merchantId = transactionDetails.merchantId,
                    merchantSiteId = transactionDetails.merchantSiteId,
                    clientRequestId = transactionDetails.clientRequestId,
                    clientUniqueId = transactionDetails.clientUniqueId,
                    cardNumber = input.number
                ), callback)
            }
        } else {
            parseAndValidateCreditCardInput(input, ignoreEmpty)
        }

        listener?.onInputParsed(input)
    }

    fun tokenize(activity: Activity, input: CreditCardInput, transactionDetails: CheckoutTransactionDetails, callback: TokenizeCallback) {
        if (!parseAndValidateCreditCardInput(input, ignoreEmpty = false)) {
            listener?.onInputParsed(input)
            return
        }

        isLoading = true
        listener?.onLoadingChanged()

       Nuvei.internalTokenize(
            activity,
            getTokenizeObject(input, transactionDetails),
            NetworkConstants.Values.SourceApplication.fields,
            object : TokenizeCallback {
                override fun onComplete(token: String?, error: Error?, additionalInfo: Map<String, Any>?) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        isLoading = false
                        listener?.onLoadingChanged()

                        callback.onComplete(token, error, additionalInfo)
                    }, 100)
                }
            }
        )
    }

    fun submitCreditCardInput(
        activity: Activity,
        input: CreditCardInput,
        transactionDetails: CheckoutTransactionDetails,
        source: String? = null,
        callback: Callback<NVCreatePaymentOutput>? = null
    ) {
        if (!parseAndValidateCreditCardInput(input, ignoreEmpty = false)) {
            listener?.onInputParsed(input)
            return
        }

        isLoading = true
        listener?.onLoadingChanged()

        Nuvei.internalCreatePayment(
            activity,
            getInputObject(input, transactionDetails),
            null,
            transactionDetails.forceWebChallenge,
            source = NetworkConstants.Values.SourceApplication.fields,
            object : Callback<NVCreatePaymentOutput> {
                override fun onComplete(response: NVCreatePaymentOutput) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        isLoading = false
                        listener?.onLoadingChanged()

                        listener?.onSubmitResponse(response)
                        callback?.onComplete(response)
                    }, 100)
                }
            }
        )
    }

    private fun getInputObject(input: CreditCardInput, transactionDetails: CheckoutTransactionDetails): NVPayment {
        val expiryParts = input.expiry.split("/")

        val paymentOption = PaymentOption(
            card = CardDetails(
                input.number,
                input.cardHolderName,
                input.cvv,
                expiryParts[0],
                expiryParts[1]
            ),
            saveMethod = input.shouldSaveCard
        )

        return with(transactionDetails) {
            NVPayment(
                sessionToken,
                merchantId,
                merchantSiteId,
                googlePayMerchantId,
                googlePayMerchantName,
                googlePayGateway,
                googlePayGatewayMerchantId,
                currency,
                amount,
                paymentOption,
                userTokenId,
                clientUniqueId,
                clientRequestId,
                customData,
                billingAddress,
                shippingAddress,
                notificationUrl,
                userDetails,
                merchantDetails,
                transactionDetails.countryCode,
                dynamicDescriptor
            )
        }
    }

    private fun getTokenizeObject(input: CreditCardInput, transactionDetails: CheckoutTransactionDetails): NVPayment {
        val expiryParts = input.expiry.split("/")

        val paymentOption = PaymentOption(
            card = CardDetails(
                input.number,
                input.cardHolderName,
                input.cvv,
                expiryParts[0],
                expiryParts[1]
            ),
            saveMethod = input.shouldSaveCard
        )

        val cardData = CardDetails(
            input.number,
            input.cardHolderName,
            input.cvv,
            expiryParts[0],
            expiryParts[1]
        )

        return with(transactionDetails) {
            NVPayment(
                sessionToken,
                merchantId,
                merchantSiteId,
                googlePayMerchantId,
                googlePayMerchantName,
                googlePayGateway,
                googlePayGatewayMerchantId,
                currency,
                amount,
                paymentOption,
                userTokenId,
                clientUniqueId,
                clientRequestId,
                customData,
                billingAddress,
                shippingAddress,
                notificationUrl,
                userDetails,
                merchantDetails,
                transactionDetails.countryCode,
                dynamicDescriptor,
                cardData = cardData
            )
        }
    }

    fun parseAndValidateCreditCardInput(input: CreditCardInput, ignoreEmpty: Boolean): Boolean {
        val inputErrors = ArrayList<InputError>()
        var parsedCard: CreditCardUtils.ParsedCard? = null

        if (input.expiry.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.ExpiryEmpty)
            }
        } else if (CreditCardUtils.parseDate(input.expiry) == null) {
            inputErrors.add(InputError.ExpiryInvalid)
        }

        if (input.number.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.NumberEmpty)
            }
        } else {
            parsedCard = CreditCardUtils.parseCardNumber(input.number)
            if (parsedCard == null) {
                inputErrors.add(InputError.CreditCardInvalid)
            }
            else if (input.parsedInfo?.errors?.contains(InputError.CreditCardBlocked) == true){
                inputErrors.add(InputError.CreditCardBlocked)
            }
        }

        if (input.cardHolderName.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.HolderNameEmpty)
            }
        } else if (input.cardHolderName.first().isDigit()) {
            inputErrors.add(InputError.HolderNameInvalid)
        }

        if (input.cvv.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.CVVEmpty)
            }
        } else if (!isValidCvv(input.cvv, parsedCard?.type)) {
            inputErrors.add(InputError.CVVInvalid)
        }

        input.parsedInfo = CreditCardInput.ParsedInfo(
            inputErrors.toTypedArray(),
            CreditCardUtils.iconForCard(parsedCard),
            parsedCard?.type?.cvvLength ?: 4
        )

        if (inputErrors.size > 0) {
            return false
        }

        return true
    }
}

data class CreditCardInput(
    val index: Int? = null,
    var number: String = "",
    var expiry: String = "",
    var cvv: String = "",
    var cardHolderName: String = "",
    var shouldSaveCard: Boolean = false,
    var parsedInfo: ParsedInfo? = null,
) : Serializable {
    data class ParsedInfo(
        var errors: Array<InputError>? = null,
        var icon: Int? = null,
        var cvvLength: Int? = null
    ) : Serializable
}

fun String.formatAsCreditCardNumber(): String {
    return this
        .filter { it.isDigit() }
        .take(20)
        .chunked(4)
        .joinToString(separator = " ")
}

fun String.formatAsExpiry(): String {
    return this
        .filter { it.isDigit() }
        .take(4)
        .chunked(2)
        .mapIndexed { index, s ->
            var result = s
            if (index == 0)  {
                val first = s.first()
                if (first != '0' && first != '1') {
                    result = "0${first}"
                }
            }
            return@mapIndexed result
        }
        .joinToString(separator = "/")
}

fun String.formatAsCVV(length: Int): String {
    return this
        .filter { it.isDigit() }
        .take(length)
}
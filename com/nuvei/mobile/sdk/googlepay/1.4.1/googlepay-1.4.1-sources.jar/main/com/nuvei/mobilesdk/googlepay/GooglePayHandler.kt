package com.nuvei.mobilesdk.googlepay

import android.app.Activity
import android.os.Handler
import android.os.Looper
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.gms.wallet.PaymentData
import com.google.android.gms.wallet.PaymentsClient
import com.google.android.gms.wallet.Wallet
import com.google.android.gms.wallet.WalletConstants
import com.google.android.gms.wallet.button.ButtonOptions
import com.google.android.gms.wallet.button.PayButton
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.Nuvei.tryOrNull
import com.nuvei.mobilesdk.core.model.CardDetails
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.model.PaymentOption
import com.nuvei.mobilesdk.core.model.UPOCreatePaymentInput
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.googlePayToken
import com.nuvei.mobilesdk.core.network.ApiClient
import org.json.JSONArray
import org.json.JSONObject

class GooglePayHandler {
    private val googlePayActivityResultHandler: ActivityResultLauncher<IntentSenderRequest>
    private val googlePaymentsClient: PaymentsClient
    private lateinit var nvPayment: NVPayment
    private lateinit var transactionDetails: CheckoutTransactionDetails
    private lateinit var result: (result: NVCreatePaymentOutput?) -> Unit
    private lateinit var activity: Activity

    private val activityResultCallback = ActivityResultCallback<ActivityResult> { activityResult ->
        val token = activityResult.data?.let { tokenFromData(PaymentData.getFromIntent(it)) }
        if (token != null) {
            nvPayment.paymentOption = PaymentOption(
                card = CardDetails(
                    externalToken = CardDetails.ExternalToken(
                        externalTokenProvider = googlePayToken,
                        mobileToken = token
                    )
                )
            )

            if (auth3DSupport) {
                val authInput = with(transactionDetails) {
                    NVPayment(
                        sessionToken,
                        merchantId,
                        merchantSiteId,
                        googlePayMerchantId,
                        googlePayMerchantName,
                        googlePayGateway,
                        googlePayGatewayMerchantId,
                        currency,
                        amount,
                        nvPayment.paymentOption,
                        clientUniqueId,
                        clientRequestId,
                        customData,
                        billingAddress,
                        shippingAddress,
                        notificationUrl,
                        userDetails,
                        merchantDetails,
                        countryCode ?: "US",
                        dynamicDescriptor
                    )
                }

                Nuvei.internalCreatePayment(
                    activity,
                    authInput,
                    null,
                    transactionDetails.forceWebChallenge,
                    source = NetworkConstants.Values.SourceApplication.checkout,
                    object : Callback<NVCreatePaymentOutput> {
                        override fun onComplete(response: NVCreatePaymentOutput) {
                            result.invoke(response)
                        }
                    }
                )
            } else {
                submitGooglePayPayment(nvPayment) {
                    response -> result.invoke(response)
                }
            }
        } else {
            Nuvei.getPaymentStatus(transactionDetails.sessionToken) {
                response -> result.invoke(response)
            }
        }
    }

    constructor(activity: AppCompatActivity) {
        this.activity = activity
        googlePayActivityResultHandler = activity.registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult(), activityResultCallback)
        googlePaymentsClient = createPaymentsClient(activity)
    }

    constructor(fragment: Fragment) {
        this.activity = fragment.requireActivity()
        googlePayActivityResultHandler = fragment.registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult(), activityResultCallback)
        googlePaymentsClient = createPaymentsClient(activity)

    }

    companion object {
        var auth3DSupport = false
        fun initializeButton(button: PayButton) {
            val baseCardPaymentMethod =
                JSONObject()
                    .put("type", "CARD")
                    .put(
                        "parameters", JSONObject()
                            .put(
                                "allowedAuthMethods", JSONArray(
                                    listOf(
                                        "PAN_ONLY",
                                        "CRYPTOGRAM_3DS"
                                    )
                                )
                            )
                            .put(
                                "allowedCardNetworks", JSONArray(
                                    listOf(
                                        "AMEX",
                                        "DISCOVER",
                                        "INTERAC",
                                        "JCB",
                                        "MASTERCARD",
                                        "VISA"
                                    )
                                )
                            )
                            .put("billingAddressRequired", true)
                            .put(
                                "billingAddressParameters", JSONObject()
                                    .put("format", "FULL")
                            )
                    )

            val allowedPaymentMethods: JSONArray = JSONArray().put(baseCardPaymentMethod)

            button.initialize(
                ButtonOptions.newBuilder()
                    .setAllowedPaymentMethods(allowedPaymentMethods.toString()).build()
            )
        }
    }

    fun openGooglePay(nvPayment: NVPayment, forceWebChallenge: Boolean, result: (result: NVCreatePaymentOutput?) -> Unit) {
        this.result = result
        val transactionDetails = CheckoutTransactionDetails(nvPayment, forceWebChallenge = forceWebChallenge)

        val input = mapOf(
            "apiVersion" to 2,
            "apiVersionMinor" to 0,
//            "existingPaymentMethodRequired" to false,
            "transactionInfo" to mapOf(
                "checkoutOption" to "COMPLETE_IMMEDIATE_PURCHASE",
                "countryCode" to transactionDetails.countryCode,
                "currencyCode" to transactionDetails.currency.uppercase(),
                "totalPriceStatus" to "FINAL",
                "totalPrice" to transactionDetails.amount
            ),
            "shippingAddressParameters" to mapOf(
                "phoneNumberRequired" to true
            ),
            "merchantInfo" to mapOf(
                "merchantId" to transactionDetails.googlePayMerchantId,
                "merchantName" to transactionDetails.googlePayMerchantName
            ),
            "allowedPaymentMethods" to listOf(
                mapOf(
                    "type" to "CARD",
                    "parameters" to mapOf(
                        "allowedAuthMethods" to listOf(
                            "PAN_ONLY",
                            "CRYPTOGRAM_3DS"
                        ),
                        "allowedCardNetworks" to listOf(
                            "AMEX",
                            "DISCOVER",
                            "INTERAC",
                            "JCB",
                            "MASTERCARD",
                            "VISA"
                        ),
                        "allowCreditCards" to true,
                        "allowPrepaidCards" to false,
                        "assuranceDetailsRequired" to true,
                        "billingAddressRequired" to true,
                        "billingAddressParameters" to mapOf(
                            "format" to "FULL",
                            "phoneNumberRequired" to true
                        )
                    ),
                    "tokenizationSpecification" to mapOf(
                        "type" to "PAYMENT_GATEWAY",
                        "parameters" to mapOf(
                            "gateway" to transactionDetails.googlePayGateway,
                            "gatewayMerchantId" to transactionDetails.googlePayGatewayMerchantId
                        )
                    )
                )
            )
        )

        this.transactionDetails = transactionDetails
        this.nvPayment = nvPayment
        val json = JSONObject(input)
        val request = com.google.android.gms.wallet.PaymentDataRequest.fromJson(json.toString())

        googlePaymentsClient
            .loadPaymentData(request)
            .addOnCompleteListener { completedTask ->
                when (val exception = completedTask.exception) {
                    is com.google.android.gms.common.api.ResolvableApiException -> {
                        googlePayActivityResultHandler.launch(
                            IntentSenderRequest.Builder(exception.resolution).build()
                        )
                    }
                }
            }
    }

    private fun createPaymentsClient(activity: Activity): PaymentsClient {
        val walletEnvironment: Int = when (Nuvei.environment) {
            Nuvei.Environment.STAGING -> WalletConstants.ENVIRONMENT_TEST
            Nuvei.Environment.PROD -> WalletConstants.ENVIRONMENT_PRODUCTION
            else -> throw RuntimeException("Nuvei Core Environment not set.")
        }

        val walletOptions = Wallet.WalletOptions.Builder()
            .setEnvironment(walletEnvironment)
            .build()

        return Wallet.getPaymentsClient(activity, walletOptions)
    }

    private fun submitGooglePayPayment(nvPayment: NVPayment, result: (NVCreatePaymentOutput?) -> Unit) {
        ApiClient.setSourceApplication(NetworkConstants.Values.SourceApplication.checkout)

        val upo = UPOCreatePaymentInput(
            sessionToken = nvPayment.sessionToken,
            merchantSiteId = nvPayment.merchantSiteId,
            merchantId = nvPayment.merchantId,
            currencyCode = requireNotNull(nvPayment.currency){ "Currency must not be null" },
            clientUniqueId = nvPayment.clientUniqueId,
            userDetails = nvPayment.userDetails,
            paymentOption = nvPayment.paymentOption
        )

        Nuvei.createUPOPayment(upo, result)
    }
    private fun tokenFromData(paymentData: PaymentData?): String? {
        return tryOrNull {
            paymentData
                ?.toJson()
                ?.let { JSONObject(it) }
                ?.getJSONObject("paymentMethodData")
                ?.toString()
        }
    }
}
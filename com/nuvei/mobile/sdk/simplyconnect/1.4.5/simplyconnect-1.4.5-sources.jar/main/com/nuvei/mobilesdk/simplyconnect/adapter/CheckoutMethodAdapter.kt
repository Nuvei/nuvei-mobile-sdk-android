package com.nuvei.mobilesdk.simplyconnect.adapter

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import android.content.Context
import com.nuvei.mobilesdk.core.CreditCardUtils
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.children
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.Nuvei.tryOrNull
import com.nuvei.mobilesdk.core.model.LocalPayment
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.idealType
import com.nuvei.mobilesdk.googlepay.GooglePayHandler
import com.nuvei.mobilesdk.core.isFutureDate
import com.nuvei.mobilesdk.core.model.APMsOutput
import com.nuvei.mobilesdk.core.CheckoutApmI18NStore
import com.nuvei.mobilesdk.core.CheckoutI18N
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.SimplyConnectUICustomization
import com.nuvei.mobilesdk.core.model.UPOsOutput
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.core.view.CheckoutErrorTextView
import com.nuvei.mobilesdk.simplyconnect.KeyboardUtils
import com.nuvei.mobilesdk.simplyconnect.R
import com.nuvei.mobilesdk.simplyconnect.SimplyConnect
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutApmDynamicBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutCardBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutGenericBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutGooglePayBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutSectionBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutUpoCardBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutUpoGenericBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ViewCheckoutTextFieldBinding
import com.nuvei.mobilesdk.simplyconnect.model.Installments
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CreditCardInput
import com.nuvei.mobilesdk.simplyconnect.views.PickerDialog
import com.nuvei.mobilesdk.simplyconnect.views.PickerDialogAdapter
import java.io.Serializable

class CheckoutMethodAdapter(
    val activity: AppCompatActivity,
    val nvPayment: NVPayment
) : RecyclerView.Adapter<CheckoutMethodAdapter.BaseViewHolder>() {
    var onPayButtonClicked: ((CheckoutMethodListItem, input: Any?) -> (Unit))? = null
    var onDeleteButtonClicked: ((CheckoutMethodListItem) -> (Unit))? = null
    var onInputUpdated: ((CheckoutMethodListItem, input: Any?, hasFocus: Boolean) -> (Unit))? = null
    var onShowPicker: ((PickerDialog) -> (Unit))? = null
    var onItemExpanded: ((CheckoutMethodListItem, index: Int) -> (Unit))? = null
    val apmI18n = CheckoutApmI18NStore.get()

    private val viewTypeMapper = arrayOf(
        R.layout.list_item_checkout_generic,
        R.layout.list_item_checkout_card,
        R.layout.list_item_checkout_google_pay,
        R.layout.list_item_checkout_upo_card,
        R.layout.list_item_checkout_upo_generic,
        R.layout.list_item_checkout_section,
    )

    private var items: List<CheckoutMethodBaseListItem> = emptyList()

    fun getItems(): List<CheckoutMethodBaseListItem> = items

    private val fieldFocusSessionStartValues = HashMap<String, String>()
    private val fieldFocusSessionPasted = HashMap<String, Boolean>()
    private val focusStateMap = HashMap<String, Boolean>()
    private val enteredFields = HashSet<String>()

    private var lastSelectedPosition = -1
    private var lastIsFormValid: Boolean? = null
    private var lastInvalidFields = emptyList<String>()

    private var recyclerView: RecyclerView? = null

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        this.recyclerView = recyclerView
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        this.recyclerView = null
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): BaseViewHolder {
        val viewHolder = when (viewType) {
            R.layout.list_item_checkout_section -> SectionViewHolder(ListItemCheckoutSectionBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_card -> CardViewHolder(ListItemCheckoutCardBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_google_pay -> GooglePayViewHolder(
                ListItemCheckoutGooglePayBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_upo_card -> UPOCardViewHolder(ListItemCheckoutUpoCardBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_upo_generic -> UPOGenericViewHolder(ListItemCheckoutUpoGenericBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_generic -> DefaultViewHolder(ListItemCheckoutGenericBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            else -> DynamicFieldsViewHolder(ListItemCheckoutApmDynamicBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
        }

        return viewHolder
    }

    override fun onBindViewHolder(viewHolder: BaseViewHolder, position: Int) {
        val item = items[position]

        viewHolder.bind(item, position)
        viewHolder.updateWithSelectedState(item)

        if (item is CheckoutMethodListItem) {
            viewHolder.updateWithInput(item.input)
        }
    }

    override fun onBindViewHolder(viewHolder: BaseViewHolder, position: Int, payloads: MutableList<Any>) {
        if (viewHolder !is CardViewHolder) {
            onBindViewHolder(viewHolder, position)
        } else if (payloads.isEmpty()) {
            onBindViewHolder(viewHolder, position)
        } else {
            val item = items[position] as? CheckoutMethodListItem ?: run { onBindViewHolder(viewHolder, position); return }

            payloads.forEach {
                if (it == PayloadKeys.inputUpdated) {
                    viewHolder.updateWithInput(item.input)
                } else if (it == PayloadKeys.selectedStateUpdated) {
                    viewHolder.updateWithSelectedState(item)
                }
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val item = items[position]
        return if (item.layoutId == R.layout.list_item_checkout_apm_dynamic) {
            viewTypeMapper.size + position
        } else {
            viewTypeMapper.find { it == item.layoutId } ?: 0
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun setItems(newItems: List<CheckoutMethodBaseListItem>) {
        val allItems = ArrayList<CheckoutMethodBaseListItem>()

        newItems.forEach {
            allItems.add(it)

            if (it is CheckoutMethodsSection) {
                allItems.addAll(it.items)
            }
        }

        items = allItems

        notifyDataSetChanged()

        recyclerView?.post {
            evaluateAndTriggerFormValidationTransition()
        }
    }

    fun handleItemInputUpdate(input: Any) {
        val index = when (input) {
            is CreditCardInput -> { input.index }
            is UPOCardInput -> { input.index }
            else -> { -1 }
        }

        if (index != null && index >= 0 && index < items.size) {
            val item = items[index] as? CheckoutMethodListItem
            if (item != null) {
                // Merge parsedInfo (errors/icon) into the current input to avoid losing 
                // recent text changes in other fields while the async request was in flight.
                if (input is CreditCardInput && item.input is CreditCardInput) {
                    (item.input as CreditCardInput).parsedInfo = input.parsedInfo
                } else if (input is UPOCardInput && item.input is UPOCardInput) {
                    (item.input as UPOCardInput).parsedInfo = input.parsedInfo
                } else {
                    item.input = input
                }
            }
        }

        notifyItemChanged(index!!, PayloadKeys.inputUpdated)
        recyclerView?.post {
            evaluateAndTriggerFormValidationTransition()
        }
    }

    abstract inner class BaseViewHolder(view: ViewGroup) : RecyclerView.ViewHolder(view) {
        abstract fun bind(item: CheckoutMethodBaseListItem, position: Int)
        abstract fun updateWithSelectedState(item: CheckoutMethodBaseListItem)
        abstract fun updateWithInput(input: Any?)

        internal fun toggleSelected(newIndex: Int) {
            for (index in items.indices) {
                val item = items[index] as? CheckoutMethodListItem ?: continue

                if (newIndex == index) {
                    item.isSelected = !item.isSelected
                    notifyItemChanged(newIndex, PayloadKeys.selectedStateUpdated)
                    if (item.isSelected) {
                        onItemExpanded?.invoke(item, index)
                    }
                } else if (item.isSelected) {
                    item.isSelected = false
                    notifyItemChanged(index, PayloadKeys.selectedStateUpdated)
                }
            }
            recyclerView?.post {
                evaluateAndTriggerFormValidationTransition()
            }
        }

        internal fun updateIcon(item: CheckoutMethodListItem, iconImageView: ImageView) {
            if (item.iconUrl == null) {
                iconImageView.setImageResource(item.iconId ?: R.drawable.ic_credit_card)
            } else {
                Glide
                    .with(itemView)
                    .load(alignedImageUrl(item.iconUrl))
                    .centerCrop()
                    .placeholder(R.drawable.ic_credit_card)
                    .into(iconImageView)
            }
        }
    }

    private inner class DefaultViewHolder(val binding: ListItemCheckoutGenericBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            val apm = item.data as? APMsOutput.APM
            val isAPM = apm != null

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            // --- title ---
            binding.titleTextView.text = if (isAPM) {
                apmI18n.title(apm!!.methodType) ?: item.title
            } else {
                item.title
            }

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            // --- icon ---
            updateIcon(item, binding.iconImageView)

            // --- item click ---
            itemView.setOnClickListener { toggleSelected(position) }

            // --- pay button ---
            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)
                    item.input = APMInput(position, emptyList(), binding.saveCheckBox.isChecked)
                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = if (isAPM) {
                    String.format(
                        apmI18n.apmUiStrings.payButtonTitleText,
                        item.amount,
                        item.currency
                    )
                } else {
                    String.format(
                        CheckoutI18N.payButtonTitle,
                        item.amount,
                        item.currency
                    )
                }

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            if (isAPM){
                binding.saveCheckBox.text = apmI18n.apmUiStrings.saveDetailsText
            }

            binding.saveCheckBox.setTextColor(SimplyConnectUICustomization.checkboxButtonCustomization.textColor)
            binding.saveCheckBox.applyNuveiFont(SimplyConnectUICustomization.checkboxButtonCustomization.textFontName)
            binding.saveCheckBox.buttonTintList = ColorStateList.valueOf(SimplyConnectUICustomization.checkboxButtonCustomization.backgroundColor)
            binding.saveCheckBox.textSize = SimplyConnectUICustomization.checkboxButtonCustomization.textFontSize.toFloat()

        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class SectionViewHolder(val binding: ListItemCheckoutSectionBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodsSection) return

            binding.titleTextView.apply {
                text = item.title
                with(SimplyConnectUICustomization.recyclerViewCustomization){
                    textSize = sectionTextFontSize.toFloat()
                    setTextColor(sectionTextColor)
                    applyNuveiFont(sectionTextFontName)
                }
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class UPOCardViewHolder(val binding: ListItemCheckoutUpoCardBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = item.title
            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            binding.tvExpiryDate.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvExpiryDate.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvExpiryDate.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvCVV.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvCVV.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvCVV.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvInstallmentProgram.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvInstallmentProgram.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvInstallmentProgram.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvNumberOfInstallments.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvNumberOfInstallments.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvNumberOfInstallments.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvPersonalId.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvPersonalId.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvPersonalId.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)

            applyCustomization(
                binding.expiryEditText,
                binding.cvvEditText,
                binding.personalIdEditText,
                binding.ddlInstallmentsProgram,
                binding.ddlNumberOfInstallments
            )

            binding.ddlInstallmentsProgram
            binding.ddlNumberOfInstallments


            with(CheckoutI18N){
                binding.tvExpiryDate.text = expirationDateTitle
                binding.expiryEditText.setHintWithSizeAndColor(expirationDatePlaceholder)
                binding.tvCVV.text = cvvTitle
                binding.cvvEditText.setHintWithSizeAndColor(cvvPlaceholder)
                binding.tvInstallmentProgram.text = installmentsProgramTitle
                binding.tvNumberOfInstallments.text = numberOfInstallmentsTitle
                binding.tvPersonalId.text = personalIdTitle
                binding.personalIdEditText.setHintWithSizeAndColor(personalIdPlaceholder)
                binding.payButton.text = payButtonTitle
            }

            updateIcon(item, binding.iconImageView)

            val inputErrors = InputError

            fun performInputUpdate(hasFocus: Boolean = false) {
                val newInput = filledInput(position)

                item.input = newInput
                onInputUpdated?.invoke(item, newInput, hasFocus)
            }

            var hasExpiry = false

            (item.data as? UPOsOutput.PaymentMethod)?.upoData?.let {
                val month = it.ccExpiryMonth.toIntOrNull() ?: return
                val year = it.ccExpiryYear.toIntOrNull() ?: return

                if (!isFutureDate(month, year)) {
                    hasExpiry = true
                    binding.expiryTextInputLayout.visibility = View.VISIBLE
                }
            }

            (item.initialParsedInfo as? UPOCardInput.InitialParsedInfo)?.let { parsedInfo ->
                binding.cvvErrorTextView.maxLength = parsedInfo.cvvLength
                binding.cvvEditText.setHintWithSizeAndColor(if (parsedInfo.cvvLength == 4) CheckoutI18N.cvvPlaceholderAMEX else CheckoutI18N.cvvPlaceholder)
            }

            if (!hasExpiry) {
                binding.expiryTextInputLayout.visibility = View.GONE
            }

            setupEventParityListeners(binding.expiryEditText, "upo", "cc_exp", binding.tvExpiryDate, position, { performInputUpdate(binding.expiryEditText.hasFocus()) }) { getFieldErrorForUpo(item, "cc_exp") }
            setupEventParityListeners(binding.cvvEditText, "upo", "cc_cvv", binding.tvCVV, position, { performInputUpdate(binding.cvvEditText.hasFocus()) }) { getFieldErrorForUpo(item, "cc_cvv") }

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            binding.deleteImageView.setOnClickListener {
                onDeleteButtonClicked?.invoke(item)
            }

            if (SimplyConnect.installments.options.isNotEmpty()) {
                binding.installmentsProgramInputLayout.visibility = View.VISIBLE
                binding.ddlInstallmentsProgram.items = SimplyConnect.installments.descriptionStrings()
                showInstallments(binding.ddlInstallmentsProgram.selectedItemId)

                binding.ddlInstallmentsProgram.onSelectedItem = {
                        selectedItemId ->
                    showInstallments(selectedItemId)
                }
                setupDropdownEventParityListeners(binding.ddlInstallmentsProgram, "upo", "cc_installments_program", binding.tvInstallmentProgram, position)
                setupDropdownEventParityListeners(binding.ddlNumberOfInstallments, "upo", "cc_installments_number", binding.tvNumberOfInstallments, position)

                binding.ddlInstallmentsProgram.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }

                binding.ddlNumberOfInstallments.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }
            }

            if (SimplyConnect.installments.requirePersonalID) {
                binding.personalIdTextInputLayout.visibility = View.VISIBLE

                binding.personalIdEditText.setHintWithSizeAndColor(CheckoutI18N.personalIdPlaceholder + " (" + (Nuvei.hostAppDetails?.simCountryCode ?: "") +")")
                if (Nuvei.hostAppDetails?.simCountryCode == "MX"
                    || Nuvei.hostAppDetails?.simCountryCode == "BR") {
                    binding.personalIdEditText.inputType = InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                }
                setupEventParityListeners(binding.personalIdEditText, "upo", "personal_id", binding.tvPersonalId, position, { performInputUpdate(binding.personalIdEditText.hasFocus()) }) { getFieldErrorForUpo(item, "personal_id") }
            }

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    allErrorFields().forEach {
                        it.clearErrorMessage()
                    }

                    item.input = filledInput(position)

                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = String.format(
                    CheckoutI18N.payButtonTitle,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }



            binding.expiryErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.expiryErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.cvvErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.cvvErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.personalIDErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.personalIDErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {
            val fields = allErrorFields()

            (input as? UPOCardInput)?.apply {
                with(binding) {
                    expiryErrorTextView.setInputValue(expiry ?: "")
                    cvvErrorTextView.setInputValue(cvv)
                }

                parsedInfo?.errors?.forEach {
                    setError(fields, it)
                }
            }

            fields.forEach {
                it.clearErrorMessage()
            }
        }

        private fun showInstallments(selectedItemId: Int) {
            if (SimplyConnect.installments.options[selectedItemId].isSinglePayment) {
                binding.ddlNumberOfInstallments.items.clear()
                binding.installmentsNumberInputLayout.visibility = View.GONE
            } else {
                binding.ddlNumberOfInstallments.items = Installments.options[selectedItemId].installmentStrings
                binding.installmentsNumberInputLayout.visibility = View.VISIBLE
            }
        }

        fun allErrorFields(): ArrayList<CheckoutErrorTextView> {
            return with(binding) {
                arrayListOf(
                    personalIDErrorTextView,
                    expiryErrorTextView,
                    cvvErrorTextView
                )
            }
        }

        fun filledInput(position: Int): UPOCardInput {
            return with(binding) {
                var localPayment: LocalPayment? = null
                if (SimplyConnect.installments.options.isNotEmpty()) {
                    val selectedOption = SimplyConnect.installments.options[binding.ddlInstallmentsProgram.selectedItemId]

                    var selectedInstallmentsCount: String? = null
                    if (selectedOption.installments.isNotEmpty()) {
                        selectedInstallmentsCount = selectedOption.installments[binding.ddlNumberOfInstallments.selectedItemId].toString()
                    }

                    localPayment = LocalPayment(
                        null,
                        selectedOption.type.ordinal.toString(),
                        selectedInstallmentsCount
                    )
                }

                if (SimplyConnect.installments.requirePersonalID) {
                    val personalID = binding.personalIdEditText.text.toString().trim()
                    if (localPayment != null) {
                        localPayment.nationalId = personalID
                    } else {
                        localPayment = LocalPayment(nationalId= personalID)
                    }
                }

                UPOCardInput(
                    index = position,
                    expiry = if (expiryTextInputLayout.visibility == View.VISIBLE) expiryEditText.getFullDate() else null,
                    cvv = cvvEditText.text.toString(),
                    localPayment = localPayment
                )
            }
        }

        fun clearInputErrors(item: CheckoutMethodListItem, clearedErrors: Array<InputError>) {
            (item.input as? UPOCardInput)?.parsedInfo?.let { parsedInfo ->
                val existingErrors = parsedInfo.errors ?: return

                val newErrors = ArrayList<Int>()

                existingErrors.forEach { existingError ->
                    var shouldKeep = true
                    for (clearedError in clearedErrors) {
                        if (clearedError.ordinal == existingError) {
                            shouldKeep = false
                            break
                        }
                    }
                    if (shouldKeep) {
                        newErrors.add(existingError)
                    }
                }

                parsedInfo.errors = newErrors.toTypedArray()
            }
        }

        fun setError(fields: ArrayList<CheckoutErrorTextView>, error: Int) {
            with(binding) {
                when (val checkoutInputError = InputError.values()[error]) {
                    InputError.CVVInvalid -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvInvalid, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.CVVEmpty -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvEmpty, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.ExpiryEmpty -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryEmpty, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.ExpiryInvalid -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryInvalid, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.PersonalIDEmpty -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDEmpty, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }
                    InputError.PersonalIDInvalid -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDInvalid, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }
                    InputError.CreditCardBlocked -> {
                        binding.cvvErrorTextView.setErrorMessage(CheckoutI18N.cardBlocked.takeUnless { it.isBlank() } ?: CheckoutI18N.cardBlockedConstructed  , checkoutInputError)
                        fields.removeAll { it == binding.cvvErrorTextView }
                    }
                    else -> {}
                }
            }
        }
    }

    private inner class UPOGenericViewHolder(val binding: ListItemCheckoutUpoGenericBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = item.title
            updateIcon(item, binding.iconImageView)

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            binding.deleteImageView.setOnClickListener {
                onDeleteButtonClicked?.invoke(item)
            }

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    onPayButtonClicked?.invoke(item, null)
                }

                text = String.format(
                    CheckoutI18N.payButtonTitle,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class GooglePayViewHolder(val binding: ListItemCheckoutGooglePayBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = item.title

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            GooglePayHandler.initializeButton(binding.googlePayButton)

            binding.googlePayButton.setOnClickListener {
                onPayButtonClicked?.invoke(item, null)
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class DynamicFieldsViewHolder(val binding: ListItemCheckoutApmDynamicBinding) : BaseViewHolder(binding.root) {
        private var boundItem: CheckoutMethodListItem? = null
        private var boundApm: APMsOutput.APM? = null
        private var boundPosition: Int = -1

        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            val apm = item.data as? APMsOutput.APM ?: return
            this.boundItem = item
            this.boundApm = apm
            this.boundPosition = position

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = apmI18n.title(apm.methodType) ?: item.title
            updateIcon(item, binding.iconImageView)

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    val (valid, firstErrorView) = validateFields(apm.methodType)
                    if (!valid) {
                        firstErrorView?.requestFocus()
                        return@setOnClickListener
                    }

                    item.input = filledInput(position, apm)
                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = String.format(
                    apmI18n.apmUiStrings.payButtonTitleText,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            binding.saveCheckBox.text = apmI18n.apmUiStrings.saveDetailsText
            binding.saveCheckBox.setTextColor(SimplyConnectUICustomization.checkboxButtonCustomization.textColor)
            binding.saveCheckBox.applyNuveiFont(SimplyConnectUICustomization.checkboxButtonCustomization.textFontName)
            binding.saveCheckBox.buttonTintList = ColorStateList.valueOf(SimplyConnectUICustomization.checkboxButtonCustomization.backgroundColor)
            binding.saveCheckBox.textSize = SimplyConnectUICustomization.checkboxButtonCustomization.textFontSize.toFloat()

            if (binding.containerView.childCount == 0) {
                createFields(apm, apm.fields)
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected
                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}

        fun createFields(apm: APMsOutput.APM, fields: List<APMsOutput.Field>) {
            val updatedFields = fields.toMutableList()

            when (apm.methodType) {
                idealType -> {
                    createTextField(
                        itemView.context.getString(R.string.checkout_method_ideal_first_name),
                        NetworkConstants.Values.Fields.idealPayerName
                    )
                    createTextField(
                        itemView.context.getString(R.string.checkout_method_ideal_last_name),
                        NetworkConstants.Values.Fields.idealPayerName
                    )
                    createTextField(
                        itemView.context.getString(R.string.checkout_method_ideal_email),
                        NetworkConstants.Values.Fields.idealEmail
                    )
                    updatedFields.removeAll { it.name.compareTo(NetworkConstants.Values.Fields.idealPayerName, true) == 0 }
                }
            }

            updatedFields.forEach {
                when (it.type) {
                    "text" -> createTextField(
                        apmI18n.text(apm.methodType, it.name) ?: it.caption.firstOrNull()?.message,
                        it.name,
                        it.values,
                        methodId = apm.methodType
                    )
                }
            }
        }

        fun createTextField(
            title: String?,
            fieldName: String,
            values: List<APMsOutput.ListValue>? = null,
            methodId: String? = null
        ) {
            val item = boundItem!!
            val apm = boundApm!!

            ViewCheckoutTextFieldBinding.inflate(
                LayoutInflater.from(binding.containerView.context),
                binding.containerView,
                true
            ).also { tf ->
                applyCustomization(tf.editText)
                tf.root.setTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME, fieldName)
                tf.titleTextView.text = title
                tf.titleTextView.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
                tf.titleTextView.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
                tf.titleTextView.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
                tf.editText.setHintWithSizeAndColor(title)
                tf.editText.setTextColor(SimplyConnectUICustomization.textBoxCustomization.textColor)
                tf.editText.textSize = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                tf.editText.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)
                tf.clearError()

                if (values?.isNotEmpty() == true) {
                    // Picker mode
                    tf.editText.inputType = InputType.TYPE_NULL
                    tf.editText.isFocusable = false
                    val key = "apm_${position}_$fieldName"
                    tf.editText.setOnClickListener {
                        // Clear focus from any active field to ensure its blur event fires
                        tf.editText.rootView?.findFocus()?.clearFocus()

                        var hasSelectedValue = false
                        val oldValueOnFocus = tf.editText.text?.toString().orEmpty()

                        fieldFocusSessionStartValues[key] = oldValueOnFocus
                        focusStateMap[key] = true

                        val maskedOldValueOnFocus = maskValue(fieldName, oldValueOnFocus)
                        android.util.Log.d("NuveiDebug", "[APMPicker] focus: key=$key, value=$maskedOldValueOnFocus")
                        SimplyConnect.onPaymentFormChange?.invoke(
                            "apm",
                            tf.titleTextView.text?.toString()?.trim() ?: fieldName,
                            "focus",
                            maskedOldValueOnFocus,
                            maskedOldValueOnFocus,
                            "",
                            false
                        )

                        val displayOptions = values.map { value ->
                            val code = value.code
                            val overridden = methodId?.let { apmI18n.option(it, fieldName, code) }
                            overridden ?: value.caption
                        }
                        val pickerDialogAdapter = PickerDialogAdapter(displayOptions)
                        val dialog = PickerDialog(tf.titleTextView.text.toString(), pickerDialogAdapter)

                        pickerDialogAdapter.onValueSelected = { index ->
                            hasSelectedValue = true
                            val selectedText = displayOptions[index]
                            tf.editText.setText(selectedText)
                            tf.editText.setTag(R.id.TAG_APM_TEXT_FIELD_CODE, values[index].code)
                            tf.clearError() // clear error on selection
                            dialog.dismiss()

                            item.input = filledInput(position, apm)

                            val startVal = fieldFocusSessionStartValues[key] ?: oldValueOnFocus
                            focusStateMap[key] = false

                            val maskedOld = maskValue(fieldName, startVal)
                            val maskedNew = maskValue(fieldName, selectedText)
                            android.util.Log.d("NuveiDebug", "[APMPicker] blur (selected): key=$key, oldValue=$maskedOld, newValue=$maskedNew")
                            SimplyConnect.onPaymentFormChange?.invoke(
                                "apm",
                                tf.titleTextView.text?.toString()?.trim() ?: fieldName,
                                "blur",
                                maskedOld,
                                maskedNew,
                                "",
                                false
                            )

                            evaluateAndTriggerFormValidationTransition()
                        }

                        dialog.onDismissListener = {
                            if (!hasSelectedValue) {
                                val currentVal = tf.editText.text?.toString().orEmpty()
                                val startVal = fieldFocusSessionStartValues[key] ?: oldValueOnFocus
                                focusStateMap[key] = false

                                val validationError = if (currentVal.isBlank()) {
                                    methodId?.let { apmI18n.error(it, fieldName) } ?: apmI18n.apmUiStrings.emptyFieldErrorText
                                } else ""

                                val maskedOld = maskValue(fieldName, startVal)
                                val maskedNew = maskValue(fieldName, currentVal)
                                android.util.Log.d("NuveiDebug", "[APMPicker] blur (dismissed): key=$key, oldValue=$maskedOld, newValue=$maskedNew, validationError=$validationError")
                                SimplyConnect.onPaymentFormChange?.invoke(
                                    "apm",
                                    tf.titleTextView.text?.toString()?.trim() ?: fieldName,
                                    "blur",
                                    maskedOld,
                                    maskedNew,
                                    validationError,
                                    false
                                )

                                evaluateAndTriggerFormValidationTransition()
                            }
                        }

                        onShowPicker?.invoke(dialog)
                    }
                } else {
                    setupEventParityListeners(
                        tf.editText,
                        "apm",
                        fieldName,
                        tf.titleTextView,
                        position,
                        onFocusChanged = {
                            tf.clearError()
                            item.input = filledInput(position, apm)
                        },
                        getFieldError = {
                            val text = tf.editText.text?.toString()
                            if (text.isNullOrBlank()) {
                                methodId?.let { apmI18n.error(it, fieldName) } ?: apmI18n.apmUiStrings.emptyFieldErrorText
                            } else null
                        }
                    )

                    // Text input: clear error as user types
                    tf.editText.doAfterTextChanged {
                        tf.clearError()
                        item.input = filledInput(position, apm)
                        evaluateAndTriggerFormValidationTransition()
                    }
                }
            }
        }


        fun filledInput(position: Int, apm: APMsOutput.APM): APMInput {
            val valueForCombinedFields = fun(fieldName: String, isPicker: Boolean): APMInput.Field {
                var result: String? = ""
                val views = binding.containerView.children
                for (view in views) {
                    val textFieldBinding = tryOrNull { ViewCheckoutTextFieldBinding.bind(view) } ?: continue
                    if (textFieldBinding.root.getTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME) == fieldName) {
                        if (isPicker) {
                            result = textFieldBinding.editText.getTag(R.id.TAG_APM_TEXT_FIELD_CODE) as? String
                        } else {
                            result += textFieldBinding.editText.text.toString()
                        }
                    }
                }
                return APMInput.Field(
                    fieldName,
                    result ?: ""
                )
            }

            val baseFields = apm.fields.map { field ->
                valueForCombinedFields(
                    field.name,
                    field.values?.isNotEmpty() == true
                )
            }

            val additionalFields = when (apm.methodType) {
                idealType -> listOf(
                    valueForCombinedFields(NetworkConstants.Values.Fields.idealEmail, false)
                )
                else -> null
            }

            return APMInput(
                index = position,
                fields = buildList {
                    addAll(baseFields)
                    additionalFields?.let { addAll(it) }
                },
                shouldSave = binding.saveCheckBox.isChecked
            )
        }

        private fun ViewCheckoutTextFieldBinding.showError(text: String) {
            errorTextView.text = text
            errorTextView.textSize = SimplyConnectUICustomization.errorBoxCustomization.textFontSize.toFloat()
            errorTextView.setTextColor(SimplyConnectUICustomization.errorBoxCustomization.textColor)
            errorTextView.applyNuveiFont(SimplyConnectUICustomization.errorBoxCustomization.textFontName)
            errorTextView.visibility = View.VISIBLE
        }

        private fun ViewCheckoutTextFieldBinding.clearError() {
            errorTextView.text = null
            errorTextView.visibility = View.GONE
        }

        /** Try to bind; returns null if this child isn't a text field layout */
        private fun bindChildOrNull(view: View): ViewCheckoutTextFieldBinding? =
            try {
                ViewCheckoutTextFieldBinding.bind(view)
            } catch (_: Throwable) {
                null
            }

        fun getInvalidFields(methodId: String): List<String> {
            val invalid = ArrayList<String>()
            binding.containerView.children.forEach { child ->
                val tf = bindChildOrNull(child) ?: return@forEach
                val fieldName = tf.root.getTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME) as? String ?: return@forEach
                val pickedCode = tf.editText.getTag(R.id.TAG_APM_TEXT_FIELD_CODE) as? String
                val value = pickedCode ?: tf.editText.text?.toString()
                if (value.isNullOrBlank()) {
                    invalid.add(fieldName)
                }
            }
            return invalid
        }

        /** Returns (isValid, firstErrorViewForFocusOrNull) */
        private fun validateFields(methodId: String): Pair<Boolean, View?> {
            var firstErrorView: View? = null
            var allValid = true

            binding.containerView.children.forEach { child ->
                val tf = bindChildOrNull(child) ?: return@forEach

                val fieldName = tf.root.getTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME) as? String ?: return@forEach
                // Picker fields set a code tag; text fields keep plain text
                val pickedCode = tf.editText.getTag(R.id.TAG_APM_TEXT_FIELD_CODE) as? String
                val value = pickedCode ?: tf.editText.text?.toString()
                val empty = value.isNullOrBlank()

                if (empty) {
                    allValid = false
                    // Prefer client-provided error; fallback to a generic one
                    val msg = apmI18n.error(methodId, fieldName) ?: apmI18n.apmUiStrings.emptyFieldErrorText
                    tf.showError(msg)
                    if (firstErrorView == null) firstErrorView = tf.editText
                } else {
                    tf.clearError()
                }
            }

            return allValid to firstErrorView
        }
    }

    private inner class CardViewHolder(val binding: ListItemCheckoutCardBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            itemView.setOnClickListener {
                toggleSelected(position)
                KeyboardUtils.hideKeyboard(itemView)
            }
            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)

            with(CheckoutI18N){
                binding.tvCardholderName.text = cardHolderNameTitle
                binding.holderNameEditText.setHintWithSizeAndColor(cardHolderNamePlaceholder)
                binding.tvCardNumber.text = cardNumberTitle
                binding.numberEditText.setHintWithSizeAndColor(cardNumberPlaceholder)
                binding.tvExpiryDate.text = expirationDateTitle
                binding.expiryEditText.setHintWithSizeAndColor(expirationDatePlaceholder)
                binding.tvCVV.text = cvvTitle
                binding.cvvEditText.setHintWithSizeAndColor(cvvPlaceholder)
                binding.tvInstallmentProgram.text = installmentsProgramTitle
                binding.tvNumberOfInstallments.text = numberOfInstallmentsTitle
                binding.tvPersonalId.text = personalIdTitle
                binding.personalIdEditText.setHintWithSizeAndColor(personalIdPlaceholder)
                binding.saveCheckBox.text = saveDetailsText
                binding.payButton.text = payButtonTitle
            }

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            with(SimplyConnectUICustomization.textBoxCustomization){
                binding.tvCardholderName.textSize = headingTextFontSize.toFloat()
                binding.tvCardholderName.setTextColor(headingTextFontColor)
                binding.tvCardholderName.applyNuveiFont(headingTextFontName)
                binding.tvCardNumber.textSize = headingTextFontSize.toFloat()
                binding.tvCardNumber.setTextColor(headingTextFontColor)
                binding.tvCardNumber.applyNuveiFont(headingTextFontName)
                binding.tvExpiryDate.textSize = headingTextFontSize.toFloat()
                binding.tvExpiryDate.setTextColor(headingTextFontColor)
                binding.tvExpiryDate.applyNuveiFont(headingTextFontName)
                binding.tvCVV.textSize = headingTextFontSize.toFloat()
                binding.tvCVV.setTextColor(headingTextFontColor)
                binding.tvCVV.applyNuveiFont(headingTextFontName)
                binding.tvInstallmentProgram.textSize = headingTextFontSize.toFloat()
                binding.tvInstallmentProgram.setTextColor(headingTextFontColor)
                binding.tvInstallmentProgram.applyNuveiFont(headingTextFontName)
                binding.tvNumberOfInstallments.textSize = headingTextFontSize.toFloat()
                binding.tvNumberOfInstallments.setTextColor(headingTextFontColor)
                binding.tvNumberOfInstallments.applyNuveiFont(headingTextFontName)
                binding.tvPersonalId.textSize = headingTextFontSize.toFloat()
                binding.tvPersonalId.setTextColor(headingTextFontColor)
                binding.tvPersonalId.applyNuveiFont(headingTextFontName)
                binding.saveCheckBox.setTextColor(SimplyConnectUICustomization.checkboxButtonCustomization.textColor)
                binding.saveCheckBox.applyNuveiFont(SimplyConnectUICustomization.checkboxButtonCustomization.textFontName)
                binding.saveCheckBox.buttonTintList = ColorStateList.valueOf(SimplyConnectUICustomization.checkboxButtonCustomization.backgroundColor)
                binding.saveCheckBox.textSize = SimplyConnectUICustomization.checkboxButtonCustomization.textFontSize.toFloat()

                applyCustomization(
                    binding.holderNameEditText,
                    binding.numberEditText,
                    binding.expiryEditText,
                    binding.cvvEditText,
                    binding.personalIdEditText,
                    binding.ddlInstallmentsProgram,
                    binding.ddlNumberOfInstallments
                )

            }

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    allErrorFields().forEach {
                        it.clearErrorMessage()
                    }

                    val newInput = filledInput(position)
                    if (item.creditCardInput?.parsedInfo != null) {
                        newInput.parsedInfo = item.creditCardInput?.parsedInfo
                    }
                    item.input = newInput
                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = String.format(
                    CheckoutI18N.payButtonTitle,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            val inputErrors = InputError

            fun performInputUpdate(hasFocus: Boolean = false) {
                val newInput = filledInput(position)
                if (item.creditCardInput?.parsedInfo != null) {
                    newInput.parsedInfo = item.creditCardInput?.parsedInfo
                }

                item.input = newInput
                onInputUpdated?.invoke(item, newInput, hasFocus)
            }

            binding.numberErrorTextView.onValidateInput = { _, hasFocus ->
                if (hasFocus){
                    clearInputErrors(item, inputErrors.numberErrors)
                    // Clear the stale constructed message so the previous card's error doesn't bleed through
                    CheckoutI18N.cardBlockedConstructed = ""
                }
                performInputUpdate(hasFocus)
            }

            binding.holderNameErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.holderNameErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.expiryErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.expiryErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.cvvErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.cvvErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.personalIDErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.personalIDErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            if (SimplyConnect.installments.options.isNotEmpty()) {
                binding.installmentsProgramInputLayout.visibility = View.VISIBLE
                binding.ddlInstallmentsProgram.items = SimplyConnect.installments.descriptionStrings()
                showInstallments(binding.ddlInstallmentsProgram.selectedItemId)

                binding.ddlInstallmentsProgram.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }

                binding.ddlNumberOfInstallments.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }

                binding.ddlInstallmentsProgram.onSelectedItem = {
                        selectedItemId ->
                    showInstallments(selectedItemId)
                }
                setupDropdownEventParityListeners(binding.ddlInstallmentsProgram, "cc_card", "cc_installments_program", binding.tvInstallmentProgram, position)
                setupDropdownEventParityListeners(binding.ddlNumberOfInstallments, "cc_card", "cc_installments_number", binding.tvNumberOfInstallments, position)
            }

             if (SimplyConnect.installments.requirePersonalID) {
                binding.personalIdTextInputLayout.visibility = View.VISIBLE
                binding.personalIdEditText.setHintWithSizeAndColor(binding.personalIdEditText.hint.toString() + " (" + (Nuvei.hostAppDetails?.simCountryCode
                    ?: "") +")")
                if (Nuvei.hostAppDetails?.simCountryCode == "MX"
                    || Nuvei.hostAppDetails?.simCountryCode == "BR") {
                    binding.personalIdEditText.inputType = InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                }
                setupEventParityListeners(binding.personalIdEditText, "cc_card", "personal_id", binding.tvPersonalId, position, { performInputUpdate(binding.numberEditText.hasFocus()) }) { getFieldErrorForCc(item, "personal_id") }
            }

            setupEventParityListeners(binding.numberEditText, "cc_card", "cc_num", binding.tvCardNumber, position, { performInputUpdate(binding.numberEditText.hasFocus()) }) { getFieldErrorForCc(item, "cc_num") }
            setupEventParityListeners(binding.holderNameEditText, "cc_card", "card_holder", binding.tvCardholderName, position, { performInputUpdate(binding.numberEditText.hasFocus()) }) { getFieldErrorForCc(item, "card_holder") }
            setupEventParityListeners(binding.expiryEditText, "cc_card", "cc_exp", binding.tvExpiryDate, position, { performInputUpdate(binding.numberEditText.hasFocus()) }) { getFieldErrorForCc(item, "cc_exp") }
            setupEventParityListeners(binding.cvvEditText, "cc_card", "cc_cvv", binding.tvCVV, position, { performInputUpdate(binding.numberEditText.hasFocus()) }) { getFieldErrorForCc(item, "cc_cvv") }
        }

        private fun showInstallments(selectedItemId: Int) {
            if (SimplyConnect.installments.options[selectedItemId].isSinglePayment) {
                binding.ddlNumberOfInstallments.items.clear()
                binding.installmentsNumberInputLayout.visibility = View.GONE
            } else {
                binding.ddlNumberOfInstallments.items = Installments.options[selectedItemId].installmentStrings
                binding.installmentsNumberInputLayout.visibility = View.VISIBLE
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {
            val fields = allErrorFields()

            (input as? CreditCardInput)?.apply {
                with(binding) {
                    holderNameErrorTextView.setInputValue(cardHolderName)
                    numberErrorTextView.setInputValue(number)
                    expiryErrorTextView.setInputValue(expiry)
                    cvvErrorTextView.setInputValue(cvv)

                    cvvErrorTextView.maxLength = input.parsedInfo?.cvvLength ?: 4
                    cvvEditText.setHintWithSizeAndColor(if (input.parsedInfo?.cvvLength == 4) CheckoutI18N.cvvPlaceholderAMEX else CheckoutI18N.cvvPlaceholder)
                    if (input.parsedInfo?.icon == null) {
                        cardIcon.setImageDrawable(null)
                    } else {
                        cardIcon.setImageResource(input.parsedInfo?.icon!!)
                    }
                }

                parsedInfo?.errors?.forEach {
                    setError(fields, it)
                }
            }

            fields.forEach {
                it.clearErrorMessage()
            }
        }

        fun allErrorFields(): ArrayList<CheckoutErrorTextView> {
            return with(binding) {
                arrayListOf(
                    numberErrorTextView,
                    holderNameErrorTextView,
                    expiryErrorTextView,
                    cvvErrorTextView
                )
            }
        }

        fun filledInput(position: Int): CreditCardInput {
            var localPayment: LocalPayment? = null
            if (SimplyConnect.installments.options.isNotEmpty()) {
                val selectedOption = SimplyConnect.installments.options[binding.ddlInstallmentsProgram.selectedItemId]

                var selectedInstallmentsCount: String? = null
                if (selectedOption.installments.isNotEmpty()) {
                    selectedInstallmentsCount = selectedOption.installments[binding.ddlNumberOfInstallments.selectedItemId].toString()
                }

                localPayment = LocalPayment(
                    null,
                    selectedOption.type.ordinal.toString(),
                    selectedInstallmentsCount
                )
            }

            if (SimplyConnect.installments.requirePersonalID) {
                val personalID = binding.personalIdEditText.text.toString().trim()
                if (localPayment != null) {
                    localPayment.nationalId = personalID
                } else {
                    localPayment = LocalPayment(nationalId = personalID)
                }
            }

            return with(binding) {
                CreditCardInput(
                    index = position,
                    cardHolderName = holderNameEditText.text.toString(),
                    number = numberEditText.text.toString(),
                    expiry = expiryEditText.getFullDate(),
                    cvv = cvvEditText.text.toString(),
                    shouldSaveCard = saveCheckBox.isChecked,
                    localPayment = localPayment
                )
            }
        }

        fun clearInputErrors(item: CheckoutMethodListItem, clearedErrors: Array<InputError>) {
            item.creditCardInput?.parsedInfo?.let { parsedInfo ->
                val existingErrors = parsedInfo.errors ?: return

                val newErrors = ArrayList<InputError>()

                existingErrors.forEach { existingError ->
                    var shouldKeep = true
                    for (clearedError in clearedErrors) {
                        if (clearedError == existingError) {
                            shouldKeep = false
                            break
                        }
                    }
                    if (shouldKeep) {
                        newErrors.add(existingError)
                    }
                }

                parsedInfo.errors = newErrors.toTypedArray()
            }
        }

        fun setError(fields: ArrayList<CheckoutErrorTextView>, checkoutInputError: InputError) {
            with(binding) {
                when (checkoutInputError) {
                    InputError.CreditCardBlocked ->{
                        binding.numberErrorTextView.setErrorMessage(
                            CheckoutI18N.cardBlocked.takeUnless { it.isBlank() } ?: CheckoutI18N.cardBlockedConstructed,
                            checkoutInputError
                        )
                        fields.removeAll { it == binding.numberErrorTextView }
                    }
                    InputError.CreditCardInvalid -> {
                        numberErrorTextView.setErrorMessage(CheckoutI18N.creditCardInvalid, checkoutInputError)
                        fields.removeAll { it == numberErrorTextView }
                    }
                    InputError.NumberEmpty -> {
                        numberErrorTextView.setErrorMessage(CheckoutI18N.numberEmpty, checkoutInputError)
                        fields.removeAll { it == numberErrorTextView }
                    }
                    InputError.CVVEmpty -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvEmpty, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.CVVInvalid -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvInvalid, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.ExpiryEmpty -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryEmpty, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.ExpiryInvalid -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryInvalid, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.HolderNameEmpty -> {
                        holderNameErrorTextView.setErrorMessage(CheckoutI18N.holderNameEmpty, checkoutInputError)
                        fields.removeAll { it == holderNameErrorTextView }
                    }
                    InputError.HolderNameInvalid -> {
                        holderNameErrorTextView.setErrorMessage(CheckoutI18N.holderNameInvalid, checkoutInputError)
                        fields.removeAll { it == holderNameErrorTextView }
                    }
                    InputError.PersonalIDEmpty -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDEmpty, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }
                    InputError.PersonalIDInvalid -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDInvalid, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }

                }
            }
        }
    }

    private fun makeRingDrawable(
        @ColorInt strokeColor: Int,
        strokeWidthDp: Int,
        cornerRadiusDp: Int,
        v: View,
        @ColorInt fillColor: Int? = null
    ): Drawable {
        val dm = v.resources.displayMetrics
        val stroke = strokeWidthDp * dm.density
        val r = cornerRadiusDp * dm.density

        val outer = floatArrayOf(r, r, r, r, r, r, r, r)

        if (stroke <= 0f) {
            return ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor ?: android.graphics.Color.TRANSPARENT
            }
        }

        val innerR = (r - stroke).coerceAtLeast(0f)
        val inner = floatArrayOf(innerR, innerR, innerR, innerR, innerR, innerR, innerR, innerR)

        // 1) Border drawn as a *ring* so corners aren’t thicker
        val ring = ShapeDrawable(
            RoundRectShape(outer, RectF(stroke, stroke, stroke, stroke), inner)
        ).apply {
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.color = strokeColor
        }

        // 2) Optional fill under the ring
        return if (fillColor == null) {
            ring
        } else {
            val fill = ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor
            }
            LayerDrawable(arrayOf(fill, ring))
        }
    }


    fun applyCustomization(vararg views: View) {
        val cfg = SimplyConnectUICustomization.textBoxCustomization

        views.forEach { v ->
            v.post {
                // remove tints that can override our backgrounds
                ViewCompat.setBackgroundTintList(v, null)
                ViewCompat.setBackgroundTintMode(v, null)

                val pL = v.paddingLeft;
                val pT = v.paddingTop
                val pR = v.paddingRight;
                val pB = v.paddingBottom

                when (v) {
                    is EditText -> {
                        // text appearance
                        v.setTextColor(cfg.textColor)
                        v.textSize = cfg.textFontSize.toFloat()

                        // closed-state border
                        v.background = makeRingDrawable(
                            cfg.borderColor,
                            cfg.borderWidth,
                            cfg.cornerRadius,
                            v,
                            cfg.backgroundColor
                        ).mutate()
                        v.applyNuveiFont(cfg.textFontName)
                        v.setPadding(pL, pT, pR, pB)
                        v.invalidate()
                    }

                    is Spinner -> {
                        // ONLY style the closed view. Do not touch popup background.
                        v.background = makeRingDrawable(
                            cfg.borderColor,
                            cfg.borderWidth,
                            cfg.cornerRadius,
                            v,
                            cfg.backgroundColor
                        ).mutate()
                        v.setPadding(pL, pT, pR, pB)

                        // color/size for the *selected* row (the text shown when closed)
                        val styleSelected: () -> Unit = {
                            (v.selectedView as? TextView)?.apply {
                                setTextColor(cfg.textColor)
                                textSize = cfg.textFontSize.toFloat()
                                applyNuveiFont(cfg.textFontName)
                            }
                        }
                        // apply now and whenever selection changes
                        styleSelected()
                        v.viewTreeObserver?.addOnGlobalLayoutListener { styleSelected() }
                        v.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(
                                parent: android.widget.AdapterView<*>?,
                                view: View?,
                                position: Int,
                                id: Long
                            ) = styleSelected()
                            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                        })
                    }

                    is TextView -> {
                        // in case you pass labels here too
                        v.setTextColor(cfg.headingTextFontColor)
                        v.textSize = cfg.headingTextFontSize.toFloat()
                        v.applyNuveiFont(cfg.textFontName)
                    }

                    else -> {
                        // for any other view just keep padding if we ever set a bg later
                        v.setPadding(pL, pT, pR, pB)
                    }
                }
            }
        }
    }


    fun TextView.setHintWithSizeAndColor(hintText: String?) {
        if (!hintText.isNullOrEmpty()){
            val s = SpannableString(hintText).apply {
                setSpan(AbsoluteSizeSpan(SimplyConnectUICustomization.textBoxCustomization.placeholderTextFontSize, /* dip = */ true), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(ForegroundColorSpan(SimplyConnectUICustomization.textBoxCustomization.placeholderFontColor), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)
            }
            hint = s
        }
    }

    private fun detectCardBrand(number: String): String? {
        val cleanNumber = number.replace("[^0-9]".toRegex(), "")
        if (cleanNumber.isEmpty()) return null

        if (cleanNumber.startsWith("4")) return "visa"
        if (cleanNumber.startsWith("34") || cleanNumber.startsWith("37")) return "amex"
        
        if (cleanNumber.length >= 2) {
            val prefix2 = cleanNumber.substring(0, 2).toIntOrNull()
            if (prefix2 != null && prefix2 in 51..55) {
                return "mastercard"
            }
        }
        if (cleanNumber.length >= 4) {
            val prefix4 = cleanNumber.substring(0, 4).toIntOrNull()
            if (prefix4 != null && prefix4 in 2221..2720) {
                return "mastercard"
            }
        }

        if (cleanNumber.startsWith("36") || cleanNumber.startsWith("38")) return "diners"
        if (cleanNumber.length >= 3) {
            val prefix3 = cleanNumber.substring(0, 3).toIntOrNull()
            if (prefix3 != null && prefix3 in 300..305) {
                return "diners"
            }
        }

        if (cleanNumber.startsWith("65")) return "discover"
        if (cleanNumber.length >= 3) {
            val prefix3 = cleanNumber.substring(0, 3).toIntOrNull()
            if (prefix3 != null && prefix3 in 644..649) {
                return "discover"
            }
        }
        if (cleanNumber.startsWith("6011")) return "discover"

        if (cleanNumber.startsWith("35") || cleanNumber.startsWith("2131") || cleanNumber.startsWith("1800")) return "jcb"

        if (cleanNumber.startsWith("62") || cleanNumber.startsWith("88")) return "unionpay"

        val maestroPrefixes = listOf("5018", "5020", "5038", "5893", "6304", "6759", "6761", "6762", "6763")
        for (pref in maestroPrefixes) {
            if (cleanNumber.startsWith(pref)) return "maestro"
        }

        val eloPrefixes = listOf("636368", "438935", "504175", "451416", "636297", "5067", "4576", "4011")
        for (pref in eloPrefixes) {
            if (cleanNumber.startsWith(pref)) return "elo"
        }

        return null
    }

    private fun maskCardNumber(number: String): String {
        val cleanNumber = number.replace("[^0-9]".toRegex(), "")
        if (cleanNumber.isEmpty()) return ""
        
        val parsedCard = CreditCardUtils.parseCardNumber(cleanNumber)
        return if (parsedCard != null) {
            val brand = (detectCardBrand(cleanNumber) ?: "unknown").lowercase()
            val last4 = if (cleanNumber.length >= 4) {
                cleanNumber.substring(cleanNumber.length - 4)
            } else {
                cleanNumber
            }
            brand + last4
        } else {
            ""
        }
    }

    private fun getFieldErrorForCc(item: CheckoutMethodListItem, label: String): String? {
        val input = item.input as? CreditCardInput ?: return null
        
        val tempInput = CreditCardInput(
            number = input.number,
            expiry = input.expiry,
            cvv = input.cvv,
            cardHolderName = input.cardHolderName,
            localPayment = input.localPayment
        )
        
        val validator = com.nuvei.mobilesdk.simplyconnect.viewmodel.CreditCardFieldViewModel()
        validator.parseAndValidateCreditCardInput(tempInput, ignoreEmpty = false)
        
        val errors = tempInput.parsedInfo?.errors ?: return null
        for (error in errors) {
            when (error) {
                InputError.NumberEmpty -> if (label == "cc_num") return CheckoutI18N.numberEmpty
                InputError.CreditCardInvalid -> if (label == "cc_num") return CheckoutI18N.creditCardInvalid
                InputError.CreditCardBlocked -> if (label == "cc_num") return CheckoutI18N.cardBlocked.takeUnless { it.isBlank() } ?: CheckoutI18N.cardBlockedConstructed
                InputError.ExpiryEmpty -> if (label == "cc_exp") return CheckoutI18N.expiryEmpty
                InputError.ExpiryInvalid -> if (label == "cc_exp") return CheckoutI18N.expiryInvalid
                InputError.CVVEmpty -> if (label == "cc_cvv") return CheckoutI18N.cvvEmpty
                InputError.CVVInvalid -> if (label == "cc_cvv") return CheckoutI18N.cvvInvalid
                InputError.HolderNameEmpty -> if (label == "card_holder") return CheckoutI18N.holderNameEmpty
                InputError.HolderNameInvalid -> if (label == "card_holder") return CheckoutI18N.holderNameInvalid
                InputError.PersonalIDEmpty -> if (label == "personal_id") return CheckoutI18N.personalIDEmpty
                InputError.PersonalIDInvalid -> if (label == "personal_id") return CheckoutI18N.personalIDInvalid
                else -> { }
            }
        }
        return null
    }

    private fun getFieldErrorForUpo(item: CheckoutMethodListItem, label: String): String? {
        val input = item.input as? UPOCardInput ?: return null
        
        val cardBrand = (item.data as? UPOsOutput.PaymentMethod)?.upoData?.brand
        val inputErrors = ArrayList<InputError>()
        input.expiry?.let { expiry ->
            if (expiry.isEmpty()) {
                inputErrors.add(InputError.ExpiryEmpty)
            } else if (CreditCardUtils.parseDate(expiry) == null) {
                inputErrors.add(InputError.ExpiryInvalid)
            }
            Unit
        }
        if (input.cvv.isEmpty()) {
            inputErrors.add(InputError.CVVEmpty)
        } else if (input.cvv.length < 3) {
            inputErrors.add(InputError.CVVInvalid)
        } else if (!cardBrand.isNullOrBlank()) {
            if (!com.nuvei.mobilesdk.core.isValidCvv(input.cvv, CreditCardUtils.CardType.fromBrandName(cardBrand))) {
                inputErrors.add(InputError.CVVInvalid)
            }
        }
        if (SimplyConnect.installments.requirePersonalID) {
            val number = input.localPayment?.nationalId ?: ""
            if (number.isEmpty()) {
                inputErrors.add(InputError.PersonalIDEmpty)
            } else if (!com.nuvei.mobilesdk.simplyconnect.viewmodel.PersonalIDValidator.isValid(number, Nuvei.hostAppDetails?.simCountryCode)) {
                inputErrors.add(InputError.PersonalIDInvalid)
            }
        }
        
        for (error in inputErrors) {
            when (error) {
                InputError.ExpiryEmpty, InputError.ExpiryInvalid -> if (label == "cc_exp") return error.name
                InputError.CVVEmpty, InputError.CVVInvalid -> if (label == "cc_cvv") return error.name
                InputError.PersonalIDEmpty, InputError.PersonalIDInvalid -> if (label == "personal_id") return error.name
                else -> { }
            }
        }
        return null
    }

    private fun getInvalidFieldsFromEnums(errors: Array<InputError>?): List<String> {
        val invalid = mutableSetOf<String>()
        errors?.forEach { error ->
            when (error) {
                InputError.NumberEmpty, InputError.CreditCardInvalid, InputError.CreditCardBlocked -> invalid.add("cc_num")
                InputError.ExpiryEmpty, InputError.ExpiryInvalid -> invalid.add("cc_exp")
                InputError.CVVEmpty, InputError.CVVInvalid -> invalid.add("cc_cvv")
                InputError.HolderNameEmpty, InputError.HolderNameInvalid -> invalid.add("card_holder")
                InputError.PersonalIDEmpty, InputError.PersonalIDInvalid -> invalid.add("personal_id")
                else -> { }
            }
        }
        return invalid.toList()
    }



    private fun getAPMInvalidFields(item: CheckoutMethodListItem): List<String> {
        val apm = item.data as? APMsOutput.APM ?: return emptyList()
        val index = items.indexOf(item)
        val holder = recyclerView?.findViewHolderForAdapterPosition(index) as? DynamicFieldsViewHolder
        return if (holder != null) {
            holder.getInvalidFields(apm.methodType)
        } else {
            val apmInput = item.input as? APMInput
            val filledFieldNames = apmInput?.fields?.map { it.fieldName } ?: emptyList()
            apm.fields.map { it.name }.filter { !filledFieldNames.contains(it) }
        }
    }

    private fun requiresFields(item: CheckoutMethodListItem): Boolean {
        return when (item.layoutId) {
            R.layout.list_item_checkout_card -> true
            R.layout.list_item_checkout_upo_card -> true
            R.layout.list_item_checkout_apm_dynamic -> {
                val apm = item.data as? APMsOutput.APM
                apm != null && apm.fields.isNotEmpty()
            }
            else -> false
        }
    }

    private fun evaluateAndTriggerFormValidationTransition() {
        android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] Started")
        val selectedItem = items.filterIsInstance<CheckoutMethodListItem>().firstOrNull { it.isSelected }
        if (selectedItem == null) {
            android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] selectedItem is null")
            if (lastIsFormValid != false || lastInvalidFields.isNotEmpty()) {
                android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] Resetting state since no item selected")
                lastIsFormValid = false
                lastInvalidFields = emptyList()
                SimplyConnect.onFormValidated?.invoke(false, emptyList())
            }
            return
        }

        val position = items.indexOf(selectedItem)
        val pm = when (selectedItem.layoutId) {
            R.layout.list_item_checkout_card -> "cc_card"
            R.layout.list_item_checkout_upo_card -> "upo"
            R.layout.list_item_checkout_apm_dynamic -> "apm"
            else -> "other"
        }
        android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] selected PM: $pm")

        val invalidFields = if (!requiresFields(selectedItem)) {
            emptyList()
        } else {
            when (pm) {
                "cc_card" -> {
                    val holder = recyclerView?.findViewHolderForAdapterPosition(position) as? CardViewHolder
                    android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] holder is null? ${holder == null}")
                    val tempInput = holder?.filledInput(position) ?: run {
                        android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] holder is null, using fallback input")
                        val cardItem = items[position] as? CheckoutMethodListItem
                        val input = cardItem?.input as? CreditCardInput ?: CreditCardInput()
                        CreditCardInput(
                            number = input.number,
                            expiry = input.expiry,
                            cvv = input.cvv,
                            cardHolderName = input.cardHolderName,
                            localPayment = input.localPayment
                        )
                    }

                    val validator = com.nuvei.mobilesdk.simplyconnect.viewmodel.CreditCardFieldViewModel()
                    validator.parseAndValidateCreditCardInput(tempInput, ignoreEmpty = false)

                    val errors = tempInput.parsedInfo?.errors
                    getInvalidFieldsFromEnums(errors)
                }
                "upo" -> {
                    val holder = recyclerView?.findViewHolderForAdapterPosition(position) as? UPOCardViewHolder
                    val tempInput = holder?.filledInput(position) ?: run {
                        val input = selectedItem.input as? UPOCardInput ?: UPOCardInput(position, null, "")
                        UPOCardInput(
                            index = input.index,
                            expiry = input.expiry,
                            cvv = input.cvv,
                            localPayment = input.localPayment
                        )
                    }

                    val cardBrand = (selectedItem.data as? UPOsOutput.PaymentMethod)?.upoData?.brand
                    val inputErrors = ArrayList<InputError>()
                    tempInput.expiry?.let { expiry ->
                        if (expiry.isEmpty()) {
                            inputErrors.add(InputError.ExpiryEmpty)
                        } else if (CreditCardUtils.parseDate(expiry) == null) {
                            inputErrors.add(InputError.ExpiryInvalid)
                        }
                        Unit
                    }
                    if (tempInput.cvv.isEmpty()) {
                        inputErrors.add(InputError.CVVEmpty)
                    } else if (tempInput.cvv.length < 3) {
                        inputErrors.add(InputError.CVVInvalid)
                    } else if (!cardBrand.isNullOrBlank()) {
                        if (!com.nuvei.mobilesdk.core.isValidCvv(tempInput.cvv, CreditCardUtils.CardType.fromBrandName(cardBrand))) {
                            inputErrors.add(InputError.CVVInvalid)
                        }
                    }
                    if (SimplyConnect.installments.requirePersonalID) {
                        val number = tempInput.localPayment?.nationalId ?: ""
                        if (number.isEmpty()) {
                            inputErrors.add(InputError.PersonalIDEmpty)
                        } else if (!com.nuvei.mobilesdk.simplyconnect.viewmodel.PersonalIDValidator.isValid(number, Nuvei.hostAppDetails?.simCountryCode)) {
                            inputErrors.add(InputError.PersonalIDInvalid)
                        }
                    }

                    getInvalidFieldsFromEnums(inputErrors.toTypedArray())
                }
                "apm" -> {
                    getAPMInvalidFields(selectedItem)
                }
                else -> {
                    emptyList()
                }
            }
        }

        val isFormValid = invalidFields.isEmpty()

        android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] PM evaluation: isFormValid=$isFormValid, invalidFields=$invalidFields")
        android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] Cache state: lastIsFormValid=$lastIsFormValid, lastInvalidFields=$lastInvalidFields")

        if (isFormValid != lastIsFormValid || invalidFields != lastInvalidFields) {
            android.util.Log.d("NuveiDebug", "[evaluateAndTriggerFormValidationTransition] validation state changed! Invoking onFormValidated")
            lastIsFormValid = isFormValid
            lastInvalidFields = invalidFields
            SimplyConnect.onFormValidated?.invoke(isFormValid, invalidFields)
        }
    }

    private fun setupDropdownEventParityListeners(
        dropDownList: com.nuvei.mobilesdk.simplyconnect.views.DropDownList,
        pm: String,
        label: String,
        fieldTitleView: TextView?,
        position: Int
    ) {
        val previousPosition = dropDownList.getTag(R.id.TAG_EVENT_PARITY_POSITION) as? Int
        if (previousPosition == position) {
            return
        }
        dropDownList.setTag(R.id.TAG_EVENT_PARITY_POSITION, position)

        val key = "${pm}_${position}_${label}"
        val getVal = {
            if (dropDownList.items.isNotEmpty() && dropDownList.selectedItemId >= 0 && dropDownList.selectedItemId < dropDownList.items.size) {
                dropDownList.items[dropDownList.selectedItemId]
            } else {
                ""
            }
        }

        val existingOnSelectedItem = dropDownList.onSelectedItem
        dropDownList.onSelectedItem = { selPosition ->
            existingOnSelectedItem?.invoke(selPosition)

            val wasFocused = focusStateMap[key] ?: false
            if (wasFocused) {
                focusStateMap[key] = false
                val currentText = if (dropDownList.items.isNotEmpty() && selPosition >= 0 && selPosition < dropDownList.items.size) {
                    dropDownList.items[selPosition]
                } else {
                    ""
                }
                val rawOldValue = fieldFocusSessionStartValues[key] ?: ""
                val rawNewValue = currentText

                SimplyConnect.onPaymentFormChange?.invoke(
                    pm,
                    fieldTitleView?.text?.toString()?.trim() ?: label,
                    "blur",
                    rawOldValue,
                    rawNewValue,
                    "",
                    false
                )

                fieldFocusSessionStartValues[key] = currentText
            }
        }

        fieldFocusSessionStartValues[key] = getVal()
        fieldFocusSessionPasted[key] = false
        focusStateMap[key] = false

        val existingListener = dropDownList.onFocusChangeListener
        dropDownList.setOnFocusChangeListener { v, hasFocus ->
            existingListener?.onFocusChange(v, hasFocus)
            
            val wasFocused = focusStateMap[key] ?: false
            android.util.Log.d("NuveiDebug", "[setupDropdownEventParityListeners] onFocusChange: key=$key, hasFocus=$hasFocus, wasFocused=$wasFocused")
            if (hasFocus != wasFocused) {
                focusStateMap[key] = hasFocus
                val action = if (hasFocus) "focus" else "blur"
                val currentText = getVal()

                val rawOldValue = if (hasFocus) currentText else (fieldFocusSessionStartValues[key] ?: "")
                val rawNewValue = currentText

                android.util.Log.d("NuveiDebug", "[setupDropdownEventParityListeners] Triggering onPaymentFormChange: action=$action, oldValue=$rawOldValue, newValue=$rawNewValue")
                SimplyConnect.onPaymentFormChange?.invoke(
                    pm,
                    fieldTitleView?.text?.toString()?.trim() ?: label,
                    action,
                    rawOldValue,
                    rawNewValue,
                    "",
                    false
                )

                fieldFocusSessionStartValues[key] = currentText
            }
        }

        dropDownList.setOnTouchListener { v, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP) {
                // Clear focus from any active field to ensure its blur event fires
                dropDownList.rootView?.findFocus()?.clearFocus()

                val wasFocused = focusStateMap[key] ?: false
                if (!wasFocused) {
                    focusStateMap[key] = true
                    val currentText = getVal()
                    fieldFocusSessionStartValues[key] = currentText

                    SimplyConnect.onPaymentFormChange?.invoke(
                        pm,
                        fieldTitleView?.text?.toString()?.trim() ?: label,
                        "focus",
                        currentText,
                        currentText,
                        "",
                        false
                    )
                }
            }
            false
        }
    }

    private fun isSensitiveField(label: String): Boolean {
        val lower = label.lowercase()
        return when {
            lower.contains("cc_num") || lower.contains("cardnumber") || lower.contains("card_number") -> true
            lower.contains("cvv") || lower.contains("securitycode") || lower.contains("security_code") -> true
            lower.contains("cc_exp") || lower.contains("expiry") -> true
            lower.contains("iban") -> true
            lower.contains("account") && !lower.contains("routing") -> true
            lower.contains("ssn") || lower.contains("identification") || lower.contains("nationalid") || lower.contains("national_id") || lower.contains("personalid") || lower.contains("personal_id") -> true
            else -> false
        }
    }

    private fun maskValue(label: String, rawValue: String): String {
        return when {
            label == "cc_num" -> maskCardNumber(rawValue)
            isSensitiveField(label) -> if (rawValue.isNotEmpty()) "****" else ""
            else -> rawValue
        }
    }

    private fun setupEventParityListeners(
        editText: EditText,
        pm: String,
        label: String,
        fieldTitleView: TextView? = null,
        position: Int,
        onFocusChanged: (() -> Unit)? = null,
        getFieldError: () -> String?
    ) {
        // 1. Update dynamic tags on every bind
        editText.setTag(R.id.TAG_EVENT_PARITY_POSITION, position)
        editText.setTag(R.id.TAG_EVENT_PARITY_PM, pm)
        editText.setTag(R.id.TAG_EVENT_PARITY_LABEL, label)
        editText.setTag(R.id.TAG_EVENT_PARITY_TITLE_VIEW, fieldTitleView)
        editText.setTag(R.id.TAG_EVENT_PARITY_ON_FOCUS_CHANGED, onFocusChanged)
        editText.setTag(R.id.TAG_EVENT_PARITY_GET_FIELD_ERROR, getFieldError)

        // 2. Initialize focus state and starting value for this key if it hasn't been set yet
        val initialKey = "${pm}_${position}_${label}"
        if (fieldFocusSessionStartValues[initialKey] == null) {
            fieldFocusSessionStartValues[initialKey] = editText.text?.toString().orEmpty()
        }
        if (fieldFocusSessionPasted[initialKey] == null) {
            fieldFocusSessionPasted[initialKey] = false
        }
        if (focusStateMap[initialKey] == null) {
            focusStateMap[initialKey] = editText.hasFocus()
        }

        // 3. Return early if listeners are already registered on this view instance
        if (editText.getTag(R.id.TAG_EVENT_PARITY_LISTENERS) == "setup_done") {
            return
        }
        editText.setTag(R.id.TAG_EVENT_PARITY_LISTENERS, "setup_done")

        val watcher = object : android.text.TextWatcher {
            private var beforeText = ""
            private var changeDepth = 0

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                val isFormatting = (editText as? com.nuvei.mobilesdk.simplyconnect.views.CreditCardEditText)?.isFormatting == true
                if (isFormatting) return

                changeDepth++
                if (changeDepth > 1) return
                beforeText = s?.toString() ?: ""
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (editText.getTag(com.nuvei.mobilesdk.core.R.id.TAG_PROGRAMMATIC_CHANGE) == true) return
                val isFormatting = (editText as? com.nuvei.mobilesdk.simplyconnect.views.CreditCardEditText)?.isFormatting == true
                if (isFormatting) return

                if (changeDepth > 1) return
                if (count > 0) {
                    val inserted = s?.subSequence(start, start + count)?.toString()
                    if (inserted != null) {
                        val currentPosition = editText.getTag(R.id.TAG_EVENT_PARITY_POSITION) as Int
                        val currentPm = editText.getTag(R.id.TAG_EVENT_PARITY_PM) as String
                        val currentLabel = editText.getTag(R.id.TAG_EVENT_PARITY_LABEL) as String
                        val key = "${currentPm}_${currentPosition}_${currentLabel}"

                        var matched = false
                        try {
                            val clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                            val clip = clipboard?.primaryClip
                            if (clip != null && clip.itemCount > 0) {
                                val clipText = clip.getItemAt(0).text?.toString()
                                if (clipText != null) {
                                    val normInserted = inserted.filter { it.isLetterOrDigit() }
                                    val normClip = clipText.filter { it.isLetterOrDigit() }
                                    if (normInserted.isNotEmpty() && normInserted == normClip) {
                                        fieldFocusSessionPasted[key] = true
                                        matched = true
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            // Handled via fallback below
                        }
                        if (!matched) {
                            val isNumericField = currentLabel == "cc_num" || currentLabel == "cc_exp" || currentLabel == "cc_cvv"
                            val fallbackThreshold = if (isNumericField) 1 else 3
                            if (inserted.length > fallbackThreshold && (count - before) > 1) {
                                fieldFocusSessionPasted[key] = true
                            }
                        }
                    }
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {
                val isFormatting = (editText as? com.nuvei.mobilesdk.simplyconnect.views.CreditCardEditText)?.isFormatting == true
                if (isFormatting) return

                changeDepth--
                if (changeDepth > 0) return
                evaluateAndTriggerFormValidationTransition()
            }
        }

        editText.addTextChangedListener(watcher)

        val existingListener = editText.onFocusChangeListener
        editText.setOnFocusChangeListener { v, hasFocus ->
            existingListener?.onFocusChange(v, hasFocus)

            val currentPosition = editText.getTag(R.id.TAG_EVENT_PARITY_POSITION) as Int
            val currentPm = editText.getTag(R.id.TAG_EVENT_PARITY_PM) as String
            val currentLabel = editText.getTag(R.id.TAG_EVENT_PARITY_LABEL) as String
            val currentTitleView = editText.getTag(R.id.TAG_EVENT_PARITY_TITLE_VIEW) as? TextView
            @Suppress("UNCHECKED_CAST")
            val currentOnFocusChanged = editText.getTag(R.id.TAG_EVENT_PARITY_ON_FOCUS_CHANGED) as? (() -> Unit)
            @Suppress("UNCHECKED_CAST")
            val currentGetFieldError = editText.getTag(R.id.TAG_EVENT_PARITY_GET_FIELD_ERROR) as (() -> String?)

            val key = "${currentPm}_${currentPosition}_${currentLabel}"

            val currentText = editText.text?.toString().orEmpty()
            val wasFocused = focusStateMap[key] ?: false
            android.util.Log.d("NuveiDebug", "[setupEventParityListeners] onFocusChange: key=$key, hasFocus=$hasFocus, wasFocused=$wasFocused")
            if (hasFocus != wasFocused) {
                currentOnFocusChanged?.invoke()
                focusStateMap[key] = hasFocus
                val action = if (hasFocus) "focus" else "blur"

                val rawOldValue = if (hasFocus) currentText else (fieldFocusSessionStartValues[key] ?: "")
                val rawNewValue = currentText

                val oldValue = maskValue(currentLabel, rawOldValue)
                val newValue = maskValue(currentLabel, rawNewValue)

                val hasBeenEntered = enteredFields.contains(key)
                if (hasFocus) {
                    enteredFields.add(key)
                }
                val validationError = if (action == "focus" && !hasBeenEntered) "" else (currentGetFieldError() ?: "")
                val paste = if (hasFocus) false else (fieldFocusSessionPasted[key] ?: false)

                val displayLabel = currentTitleView?.text?.toString()?.trim() ?: currentLabel

                android.util.Log.d("NuveiDebug", "[setupEventParityListeners] calling evaluateAndTriggerFormValidationTransition")
                evaluateAndTriggerFormValidationTransition()

                android.util.Log.d("NuveiDebug", "[setupEventParityListeners] Triggering onPaymentFormChange: pm=$currentPm, label=$displayLabel, action=$action, oldValue=$oldValue, newValue=$newValue, validation=$validationError, paste=$paste")
                SimplyConnect.onPaymentFormChange?.invoke(
                    currentPm,
                    displayLabel,
                    action,
                    oldValue,
                    newValue,
                    validationError,
                    paste
                )

                if (hasFocus) {
                    fieldFocusSessionStartValues[key] = currentText
                    fieldFocusSessionPasted[key] = false
                } else {
                    fieldFocusSessionStartValues[key] = currentText
                }
            }
        }
    }

    companion object {
        object PayloadKeys {
            const val inputUpdated = "payload_inputUpdated"
            const val selectedStateUpdated = "payload_selectedUpdated"
        }
    }
}

interface CheckoutMethodBaseListItem {
    val title: String
    val layoutId: Int?
}

data class CheckoutMethodsSection(
    override val title: String,
    override val layoutId: Int = R.layout.list_item_checkout_section,
    val items: List<CheckoutMethodListItem>,
) : CheckoutMethodBaseListItem

data class CheckoutMethodListItem(
    override val title: String,
    override val layoutId: Int?,
    val iconId: Int? = null,
    val iconUrl: String? = null,
    val amount: Float? = null,
    val currency: String? = null,
    val upoId: String? = null,
    var isSelected: Boolean = false,
    var input: Any? = null,
    var data: Any? = null,
    var initialParsedInfo: Any? = null
) : CheckoutMethodBaseListItem {
    val creditCardInput: CreditCardInput?
        get() = input as? CreditCardInput
}

data class APMInput(
    val index: Int,
    val fields: List<Field>,
    var shouldSave: Boolean,
) {
    data class Field(
        val fieldName: String,
        val fieldValue: Any,
    )
}

data class UPOCardInput(
    val index: Int,
    var expiry: String?,
    var cvv: String,
    var localPayment: LocalPayment? = null,
    var parsedInfo: ParsedInfo? = null
) : Serializable {
    data class ParsedInfo(
        var errors: Array<Int>? = null
    ) : Serializable{

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is ParsedInfo) return false

            val e1 = this.errors
            val e2 = other.errors

            return when {
                e1 === e2 -> true
                e1 == null || e2 == null -> false
                else -> e1.contentEquals(e2)
            }
        }

        override fun hashCode(): Int {
            return errors?.contentHashCode() ?: 0
        }
    }
    data class InitialParsedInfo(
        val cvvLength: Int
    )
}

private fun alignedImageUrl(url: String): String {
    return url
        .replace("default_cc_card.svg", "default_cc_new.png")
        .replace("solid_white/", "")
        .replace("/svg/", "/png/")
        .replace(".svg", ".png")
}



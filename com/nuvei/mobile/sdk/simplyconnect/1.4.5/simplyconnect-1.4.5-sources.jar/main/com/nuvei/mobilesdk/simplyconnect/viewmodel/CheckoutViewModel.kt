package com.nuvei.mobilesdk.simplyconnect.viewmodel

import android.R.attr.handle
import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.model.Addendums
import com.nuvei.mobilesdk.core.model.CardDetails
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.model.PaymentOption
import com.nuvei.mobilesdk.core.model.UPOCreatePaymentInput
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.creditCardType
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.Keys
import com.nuvei.mobilesdk.core.isValidCvv
import com.nuvei.mobilesdk.core.model.APMsInput
import com.nuvei.mobilesdk.core.model.APMsOutput
import com.nuvei.mobilesdk.core.CheckoutI18N
import com.nuvei.mobilesdk.core.model.UPOsInput
import com.nuvei.mobilesdk.core.model.UPOsOutput
import com.nuvei.mobilesdk.core.model.UPODeleteInput
import com.nuvei.mobilesdk.core.utils.CardBlockHelper
import com.nuvei.mobilesdk.simplyconnect.adapter.APMInput
import com.nuvei.mobilesdk.simplyconnect.adapter.UPOCardInput
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.simplyconnect.SimplyConnect
import java.util.Locale

interface CheckoutViewModelListener {
    fun onLoadingChanged()
    fun onInputParsed(input: Any)
    fun onCheckoutMethodsResponse(uposResponse: UPOsOutput?, apmsResponse: APMsOutput?, error: NVOutput?)
    fun onSubmitResponse(response: NVCreatePaymentOutput)
    fun onWebCheckoutRequired(url: String)
}

class CheckoutViewModel(private val handle: SavedStateHandle): ViewModel(), CreditCardFieldViewModelListener {
    var isLoading = false
    var apmLogoCache = HashMap<String, String>()

    var listener: CheckoutViewModelListener? = null
    private val creditCardFieldViewModel = CreditCardFieldViewModel()
    lateinit var apm: APMsOutput
    val countryCode: String? = handle[Keys.checkoutCountryCode]

    init {
        creditCardFieldViewModel.listener = object : CreditCardFieldViewModelListener {
            override fun onLoadingChanged() {
                isLoading = creditCardFieldViewModel.isLoading
                listener?.onLoadingChanged()
            }

            override fun onInputParsed(input: CreditCardInput) {
                listener?.onInputParsed(input)
            }

            override fun onSubmitResponse(response: NVCreatePaymentOutput) {
                listener?.onSubmitResponse(response)
            }

            override fun onWebCheckoutRequired(url: String) {
                listener?.onWebCheckoutRequired(url)
            }
        }
    }

    fun getCheckoutMethods(transactionDetails: CheckoutTransactionDetails, context: Context, shouldGetAPM: Boolean) {
        isLoading = true
        listener?.onLoadingChanged()

        val uposInput = with(transactionDetails) {
            UPOsInput(
                sessionToken,
                merchantSiteId,
                merchantId,
                currency,
                countryCode
            )
        }

        Nuvei.getUPOs(uposInput) { uposOutput, upoError ->
            val apmsInput = with(transactionDetails) {
                APMsInput(
                    sessionToken,
                    merchantSiteId,
                    merchantId,
                    Locale.getDefault().language,
                    countryCode ?: "US"
                )
            }

            if (uposOutput == null) {
                isLoading = false
                listener?.onLoadingChanged()

                listener?.onCheckoutMethodsResponse(null, null, upoError)
                return@getUPOs
            }

            if (shouldGetAPM){
                Nuvei.getAPMs(apmsInput) { apmsOutput, apmError ->
                    isLoading = false
                    listener?.onLoadingChanged()

                    if (apmsOutput == null) {
                        listener?.onCheckoutMethodsResponse(null, null, apmError)
                    } else {
                        apm = apmsOutput
                        listener?.onCheckoutMethodsResponse(uposOutput, apm, null)
                    }
                }
            }else{
                isLoading = false
                listener?.onLoadingChanged()
                listener?.onCheckoutMethodsResponse(uposOutput, apm, null)
            }
        }
    }

    fun parseCreditCardInfo(input: CreditCardInput, hasFocus: Boolean = false, transactionDetails: CheckoutTransactionDetails? = null) {
        creditCardFieldViewModel.parseCreditCardInfo(input, hasFocus, transactionDetails = transactionDetails)
    }

    fun parseUPOCardInfo(input: UPOCardInput, hasFocus: Boolean = false) {
        if (!hasFocus) {
            parseAndValidateUPOCardInput(input, ignoreEmpty = true)
        }

        listener?.onInputParsed(input)
    }

    fun submitCreditCardInput(activity: Activity, input: CreditCardInput, transactionDetails: CheckoutTransactionDetails) {
        creditCardFieldViewModel.submitCreditCardInput(activity, input, transactionDetails)
    }

    fun onMethodExpanded(
        item: com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodListItem,
        index: Int,
        transactionDetails: CheckoutTransactionDetails
    ) {
        val data = item.data as? com.nuvei.mobilesdk.core.model.UPOsOutput.PaymentMethod ?: return
        if (data.methodType != creditCardType) return

        if (CardBlockHelper.isConfigured(transactionDetails.blockCards)) {
            val getCardDetailsInput = com.nuvei.mobilesdk.core.model.NVCardDetailsInput(
                sessionToken = transactionDetails.sessionToken ?: "",
                merchantId = transactionDetails.merchantId ?: "",
                merchantSiteId = transactionDetails.merchantSiteId ?: "",
                clientRequestId = transactionDetails.clientRequestId,
                clientUniqueId = transactionDetails.clientUniqueId,
                cardNumber = null,
                userPaymentOptionId = data.userPaymentOptionId
            )

            Nuvei.getCardDetails(getCardDetailsInput, object : com.nuvei.mobilesdk.core.InternalCallback<com.nuvei.mobilesdk.core.model.NVCardDetailsOutput> {
                override fun onSuccess(response: com.nuvei.mobilesdk.core.model.NVCardDetailsOutput) {
                    if (CardBlockHelper.isCardBlocked(response, transactionDetails.blockCards)) {
                        var input = item.input as? com.nuvei.mobilesdk.simplyconnect.adapter.UPOCardInput
                        if (input == null) {
                            input = com.nuvei.mobilesdk.simplyconnect.adapter.UPOCardInput(
                                index = index,
                                expiry = null,
                                cvv = ""
                            )
                            item.input = input
                        }
                        
                        input.parsedInfo = input.parsedInfo ?: com.nuvei.mobilesdk.simplyconnect.adapter.UPOCardInput.ParsedInfo()
                        input.parsedInfo?.errors = (input.parsedInfo?.errors?.toList() ?: emptyList()).toMutableList().apply {
                            if (!contains(InputError.CreditCardBlocked.ordinal)) add(InputError.CreditCardBlocked.ordinal)
                        }.toTypedArray()

                        CheckoutI18N.cardBlockedConstructed = CardBlockHelper.getBlockedCardMessageFromRules(response, transactionDetails.blockCards)
                        listener?.onInputParsed(input)
                    }
                }

                override fun onFailure(
                    result: String,
                    errorCode: Int?,
                    errorDescription: String?,
                    rawResult: Map<String, Any>?
                ) {}
            }, true)
        }
    }

    fun submitUPOInput(
        activity: Activity,
        input: Any?,
        data: UPOsOutput.PaymentMethod,
        transactionDetails: CheckoutTransactionDetails,
    ) {
        if (data.methodType == creditCardType) {
            if (input !is UPOCardInput) return

            if (!parseAndValidateUPOCardInput(input, data.upoData.brand, ignoreEmpty = false)) {
                listener?.onInputParsed(input)
                return
            }

            val expiryParts = input.expiry?.split("/")

            val doPayment = {
                val paymentOption = PaymentOption(
                    data.userPaymentOptionId,
                    card = CardDetails(
                        cardNumber = null,
                        cardHolderName = null,
                        cvv = input.cvv,
                        expirationMonth = expiryParts?.get(0) ?: "",
                        expirationYear = expiryParts?.get(1) ?: ""
                    )
                )

                var addendums: Addendums? = null

                if (input.localPayment != null) {
                    addendums = Addendums()
                    addendums.localPayment = input.localPayment
                }

                val authInput = with(transactionDetails) {
                    NVPayment(
                        sessionToken,
                        merchantId,
                        merchantSiteId,
                        googlePayMerchantId,
                        googlePayMerchantName,
                        googlePayGateway,
                        googlePayGatewayMerchantId,
                        currency,
                        amount,
                        paymentOption,
                        clientUniqueId,
                        clientRequestId,
                        customData,
                        billingAddress,
                        shippingAddress,
                        notificationUrl,
                        userDetails,
                        merchantDetails,
                        dynamicDescriptor,
                        addendums = addendums
                    )
                }

                Nuvei.sourceApplication = NetworkConstants.Values.SourceApplication.checkout
                Nuvei.internalCreatePayment(
                    activity,
                    authInput,
                    null,
                    transactionDetails.forceWebChallenge,
                    object : Callback<NVCreatePaymentOutput> {
                        override fun onComplete(response: NVCreatePaymentOutput) {
                            Handler(Looper.getMainLooper()).postDelayed({
                                isLoading = false
                                listener?.onLoadingChanged()

                                listener?.onSubmitResponse(response)
                            }, 100)
                        }
                    })
            }

            if (CardBlockHelper.isConfigured(transactionDetails.blockCards)) {
                isLoading = true
                listener?.onLoadingChanged()

                val getCardDetailsInput = com.nuvei.mobilesdk.core.model.NVCardDetailsInput(
                    sessionToken = transactionDetails.sessionToken ?: "",
                    merchantId = transactionDetails.merchantId ?: "",
                    merchantSiteId = transactionDetails.merchantSiteId ?: "",
                    clientRequestId = transactionDetails.clientRequestId,
                    clientUniqueId = transactionDetails.clientUniqueId,
                    cardNumber = null,
                    userPaymentOptionId = data.userPaymentOptionId
                )
                Nuvei.getCardDetails(getCardDetailsInput, object : com.nuvei.mobilesdk.core.InternalCallback<com.nuvei.mobilesdk.core.model.NVCardDetailsOutput> {
                    override fun onSuccess(response: com.nuvei.mobilesdk.core.model.NVCardDetailsOutput) {
                        if (CardBlockHelper.isCardBlocked(response, transactionDetails.blockCards)) {
                            input.parsedInfo = input.parsedInfo ?: UPOCardInput.ParsedInfo()
                            input.parsedInfo?.errors = (input.parsedInfo?.errors?.toList() ?: emptyList()).toMutableList().apply {
                                if (!contains(InputError.CreditCardBlocked.ordinal)) add(InputError.CreditCardBlocked.ordinal)
                            }.toTypedArray()
                            
                            CheckoutI18N.cardBlockedConstructed = CardBlockHelper.getBlockedCardMessageFromRules(response, transactionDetails.blockCards)
                            listener?.onInputParsed(input)

                            isLoading = false
                            listener?.onLoadingChanged()
                        } else {
                            doPayment()
                        }
                    }

                    override fun onFailure(
                        result: String,
                        errorCode: Int?,
                        errorDescription: String?,
                        rawResult: Map<String, Any>?
                    ) {
                        doPayment()
                    }
                }, true)
            } else {
                isLoading = true
                listener?.onLoadingChanged()
                doPayment()
            }

        } else {
            isLoading = true
            listener?.onLoadingChanged()

            val paymentOption = PaymentOption(
                data.userPaymentOptionId
            )

            val createPaymentInput = with(transactionDetails) {
                UPOCreatePaymentInput(
                    sessionToken,
                    merchantSiteId,
                    merchantId,
                    currency,
                    clientUniqueId,
                    billingAddress = billingAddress,
                    shippingAddress = shippingAddress,
                    userDetails = userDetails,
                    paymentOption= paymentOption
                )
            }

            Nuvei.sourceApplication = NetworkConstants.Values.SourceApplication.checkout
            Nuvei.createUPOPayment(createPaymentInput) { response ->
                Handler(Looper.getMainLooper()).postDelayed({
                    if (response == null) {
                        isLoading = false
                        listener?.onLoadingChanged()

                        return@postDelayed
                    }

                    if (response.redirectUrl == null) {
                        isLoading = false
                        listener?.onLoadingChanged()

                        listener?.onSubmitResponse(response)
                    } else {
                        listener?.onWebCheckoutRequired(response.redirectUrl!!)
                    }
                }, 100)
            }
        }
    }

    fun submitAPMInput(
        activity: Activity,
        input: APMInput,
        data: APMsOutput.APM,
        transactionDetails: CheckoutTransactionDetails,
    ) {
        val paymentOption = PaymentOption(
            alternativePaymentMethod = PaymentOption.AlternativePaymentMethod(
                paymentMethod = data.methodType,
                fields = input.fields.associateBy({ it.fieldName }, { it.fieldValue }).toMutableMap()
            ),
            saveMethod = input.shouldSave
        )

        val createPaymentInput = with(transactionDetails) {
            UPOCreatePaymentInput(
                sessionToken,
                merchantSiteId,
                merchantId,
                currency,
                clientUniqueId,
                billingAddress = billingAddress,
                shippingAddress = shippingAddress,
                userDetails = userDetails,
                paymentOption = paymentOption
            )
        }

        isLoading = true
        listener?.onLoadingChanged()

        Nuvei.sourceApplication = NetworkConstants.Values.SourceApplication.checkout
        Nuvei.createUPOPayment(createPaymentInput) { response ->
            Handler(Looper.getMainLooper()).postDelayed({
                if (response == null) {
                    isLoading = false
                    listener?.onLoadingChanged()

                    return@postDelayed
                }

                if (response.redirectUrl == null) {
                    isLoading = false
                    listener?.onLoadingChanged()

                    listener?.onSubmitResponse(response)
                } else {
                    listener?.onWebCheckoutRequired(response.redirectUrl!!)
                }
            }, 100)
        }
    }

    fun verifyRedirectedPaymentCompleted(transactionDetails: CheckoutTransactionDetails) {
        Nuvei.getPaymentStatus(transactionDetails.sessionToken) { response ->
            Handler(Looper.getMainLooper()).postDelayed({
                isLoading = false
                listener?.onLoadingChanged()

                if (response == null) {
                    return@postDelayed
                }

                if (response.errorCode != NetworkConstants.Values.Codes.paymentStillInProgress) {
                    listener?.onSubmitResponse(response)
                }
            }, 100)
        }
    }

    fun externalPaymentStarted() {
        isLoading = true
        listener?.onLoadingChanged()
    }



    fun deleteUPO(upoId: String, transactionDetails: CheckoutTransactionDetails, context: Context) {
        isLoading = true
        listener?.onLoadingChanged()

        val input = with(transactionDetails) {
            UPODeleteInput(
                sessionToken,
                merchantSiteId,
                merchantId,
                upoId
            )
        }

        Nuvei.deleteUPO(input) {
            Handler(Looper.getMainLooper()).postDelayed({
                getCheckoutMethods(transactionDetails, context, false)
            }, 100)
        }
    }

    private fun parseAndValidateUPOCardInput(input: UPOCardInput, cardType: String? = null, ignoreEmpty: Boolean): Boolean {
        val inputErrors = ArrayList<InputError>()

        input.expiry?.let { expiry ->
            if (expiry.isEmpty()) {
                if (!ignoreEmpty) {
                    inputErrors.add(InputError.ExpiryEmpty)
                }
            } else if (CreditCardUtils.parseDate(expiry) == null) {
                inputErrors.add(InputError.ExpiryInvalid)
            }
        }

        if (input.cvv.isEmpty()) {
            inputErrors.add(InputError.CVVEmpty)
        }

        if (input.cvv.isNotEmpty() && input.cvv.length < 3) {
            inputErrors.add(InputError.CVVInvalid)
           }
        else if (!cardType.isNullOrBlank())  {
            if (!isValidCvv(input.cvv, CreditCardUtils.CardType.fromBrandName(cardType))){
                inputErrors.add(InputError.CVVInvalid)
            }
        }

        if (SimplyConnect.installments.requirePersonalID) {
            val number = input.localPayment?.nationalId ?: ""
            if (number.isEmpty()) {
                if (!ignoreEmpty) {
                    inputErrors.add(InputError.PersonalIDEmpty)
                }
            } else {
                if (!PersonalIDValidator.isValid(number, Nuvei.hostAppDetails?.simCountryCode)) {
                    inputErrors.add(InputError.PersonalIDInvalid)
                }
            }
        }

        if (inputErrors.size > 0) {
            input.parsedInfo = UPOCardInput.ParsedInfo(
                inputErrors.map { it.ordinal }.toTypedArray()
            )

            return false
        }

        return true
    }

    override fun onLoadingChanged() {
        isLoading = creditCardFieldViewModel.isLoading
        listener?.onLoadingChanged()
    }

    override fun onInputParsed(input: CreditCardInput) {
        listener?.onInputParsed(input)
    }

    override fun onSubmitResponse(response: NVCreatePaymentOutput) {
        listener?.onSubmitResponse(response)
    }

    override fun onWebCheckoutRequired(url: String) {
        listener?.onWebCheckoutRequired(url)
    }
}



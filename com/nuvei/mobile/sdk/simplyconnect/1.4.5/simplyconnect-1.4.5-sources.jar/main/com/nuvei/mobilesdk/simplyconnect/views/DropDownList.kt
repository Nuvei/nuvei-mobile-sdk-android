package com.nuvei.mobilesdk.simplyconnect.views

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.InsetDrawable
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatSpinner
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.content.res.ResourcesCompat
import com.nuvei.mobilesdk.core.model.SimplyConnectUICustomization
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.simplyconnect.R

class DropDownList(context: Context, attrs: AttributeSet) : AppCompatSpinner(context, attrs) {

    @ColorInt var itemTextColor: Int =
        SimplyConnectUICustomization.textBoxCustomization.textColor
    var itemTextSizeSp: Float =
        SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
    @ColorInt var selectedTextColor: Int? = null
    var selectedTextSizeSp: Float? = null

    // Resolve SDK font once (you can call refreshFont() if customization changes at runtime)
    //private var sdkTypeface: Typeface? = resolveSdkTypeface(context)

    private val data = ArrayList<String>()

    private val styledAdapter = object : ArrayAdapter<String>(
        context, R.layout.spinner_item, R.id.tvItemName, data
    ) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getView(position, convertView, parent)
            styleText(v, isClosed = true)
            return v
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getDropDownView(position, convertView, parent)
            styleText(v, isClosed = false)
            return v
        }

        private fun styleText(v: View, isClosed: Boolean) {
            val tv = v.findViewById<TextView>(R.id.tvItemName) ?: (v as? TextView) ?: return
            val dm = tv.resources.displayMetrics

//            // Apply SDK typeface (keep existing style/bold/italic)
//            sdkTypeface?.let { base ->
//                val style = tv.typeface?.style ?: Typeface.NORMAL
//                tv.typeface = Typeface.create(base, style)
//            }
            tv.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)

            // text appearance
            tv.setTextColor(if (isClosed && selectedTextColor != null) selectedTextColor!! else itemTextColor)
            tv.setTextSize(
                TypedValue.COMPLEX_UNIT_SP,
                if (isClosed && selectedTextSizeSp != null) selectedTextSizeSp!! else itemTextSizeSp
            )
            tv.includeFontPadding = false

            // padding & arrow
            val start = (12 * dm.density).toInt()
            val topBottom = (10 * dm.density).toInt()

            if (isClosed) {
                val arrow = AppCompatResources.getDrawable(tv.context, R.drawable.ic_arrow_drop_down_24)!!.mutate()
                DrawableCompat.setTint(arrow, tv.currentTextColor)
                tv.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, arrow, null)
                tv.compoundDrawablePadding = (4 * dm.density).toInt()
                val endTight = (8 * dm.density).toInt()
                tv.setPaddingRelative(start, topBottom, endTight, topBottom)
            } else {
                tv.setCompoundDrawables(null, null, null, null)
                tv.setPaddingRelative(start, topBottom, start, topBottom)
            }
        }
    }

    var items: ArrayList<String>
        get() = data
        set(value) {
            data.clear()
            data.addAll(value)
            styledAdapter.notifyDataSetChanged()
        }

    val selectedItemId: Int
        get() = selectedItemPosition.takeIf { it != AdapterView.INVALID_POSITION } ?: 0

    var onSelectedItem: ((selectedItemId: Int) -> Unit)? = null

    init {
        adapter = styledAdapter

        // Trim Spinner end padding so the arrow sits close to the edge
        val dm = resources.displayMetrics
        val endTight = (8 * dm.density).toInt()
        setPaddingRelative(paddingStart, paddingTop, endTight, paddingBottom)

        // If background has intrinsic right padding, wrap it to reduce that inset
        background?.let { bg ->
            background = InsetDrawable(bg.mutate(), 0, 0, (4 * dm.density).toInt(), 0)
        }

        // Avoid tint reinflating default paddings/colors
        backgroundTintList = null
        backgroundTintMode = null
    }

    fun setItemTextStyle(
        @ColorInt color: Int,
        sizeSp: Float,
        @ColorInt selectedColor: Int? = null,
        selectedSizeSp: Float? = null
    ) {
        itemTextColor = color
        itemTextSizeSp = sizeSp
        selectedTextColor = selectedColor
        selectedTextSizeSp = selectedSizeSp
        styledAdapter.notifyDataSetChanged()

        // restyle currently shown closed view (if visible)
        (selectedView as? TextView)?.apply {
//            sdkTypeface?.let { base ->
//                val style = typeface?.style ?: Typeface.NORMAL
//                typeface = Typeface.create(base, style)
//            }
            setTextColor(selectedTextColor ?: itemTextColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, selectedSizeSp ?: itemTextSizeSp)
            applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)
        }
    }

    /** Call this if SimplyConnectUICustomization.fontSpec changes at runtime */
    fun refreshFont() {
        //sdkTypeface = resolveSdkTypeface(context)
        styledAdapter.notifyDataSetChanged()
        // also reapply on the closed view
        (selectedView as? TextView)?.let { tv ->
//            sdkTypeface?.let { base ->
//                val style = tv.typeface?.style ?: Typeface.NORMAL
//                tv.typeface = Typeface.create(base, style)
//            }
            tv.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)
        }
    }

    override fun setSelection(position: Int) {
        super.setSelection(position)
        onSelectedItem?.invoke(position)
    }

//    private fun resolveSdkTypeface(ctx: Context): Typeface? {
////        // Expecting you added fontSpec to SimplyConnectUICustomization as discussed
////        val spec = SimplyConnectUICustomization.fontSpec
////        spec?.typeface?.let { return it }
////        spec?.fontResId?.takeIf { it != 0 }?.let { return ResourcesCompat.getFont(ctx, it) }
////        spec?.familyName?.takeIf { it.isNotBlank() }?.let { return Typeface.create(it, Typeface.NORMAL) }
////        return null
//    }
}

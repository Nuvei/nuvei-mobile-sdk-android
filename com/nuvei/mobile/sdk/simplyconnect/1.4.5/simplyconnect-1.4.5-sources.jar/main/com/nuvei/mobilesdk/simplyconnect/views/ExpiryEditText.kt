package com.nuvei.mobilesdk.simplyconnect.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Paint.FontMetricsInt
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ReplacementSpan
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import java.util.regex.Pattern


class ExpiryEditText : AppCompatEditText, TextWatcher {
    private var isLastChangeAddition = false

    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyle: Int) : super(context, attrs, defStyle) {
        init()
    }

    fun getMonth(): String {
        val value = text.toString()
        return if (value.length < 2) {
            value
        } else value.substring(0, 2)
    }

    fun getYear(): String {
        val value = text.toString()
        return if (value.length >= 3) {
            value.substring(2)
        } else ""
    }

    fun getFullDate(): String {
        val month = getMonth()
        val year = getYear()

        return if (month.isNotEmpty()) {
            "$month/$year"
        } else {
            ""
        }
    }

    private fun init() {
        inputType = InputType.TYPE_CLASS_NUMBER
        setInputFilters()
        addTextChangedListener(this)
    }

    private fun setInputFilters() {
        val lengthFilter = InputFilter.LengthFilter(4)
        val digitsOnlyFilter: DigitsOnlyFilter = DigitsOnlyFilter.newInstance(4)
        val filters: Array<InputFilter> = arrayOf(digitsOnlyFilter, lengthFilter)
        setFilters(filters)
    }

    override fun onTextChanged(text: CharSequence, start: Int, lengthBefore: Int, lengthAfter: Int) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter)
        isLastChangeAddition = lengthAfter > lengthBefore
    }

    override fun afterTextChanged(editable: Editable) {
        if (isLastChangeAddition) {
            if (editable.length == 1 && Character.getNumericValue(editable[0]) >= 2) {
                prependLeadingZero(editable)
            }
        }
        val paddingSpans: Array<out SlashSpan> = editable.getSpans(0, editable.length, SlashSpan::class.java)
        for (span in paddingSpans) {
            editable.removeSpan(span)
        }

        addDateSlash(editable)
    }

    private fun prependLeadingZero(editable: Editable) {
        val firstChar = editable[0]
        editable.replace(0, 1, "0").append(firstChar)
    }

    private fun addDateSlash(editable: Editable) {
        val index = 2
        val length = editable.length
        if (index <= length) {
            editable.setSpan(
                SlashSpan(), index - 1, index,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
}

private class DigitsOnlyFilter private constructor(private val stringBuilder: StringBuilder) : InputFilter {
    private val digitsRegex = Pattern.compile("[0-9]")

    override fun filter(source: CharSequence, start: Int, end: Int, dest: Spanned, dstart: Int, dend: Int): CharSequence {
        stringBuilder.setLength(0)
        val numChars = source.length
        for (index in 0 until numChars) {
            val c = source.subSequence(index, index + 1)
            if (digitsRegex.matcher(c).matches()) {
                stringBuilder.append(c)
            }
        }
        return stringBuilder.toString()
    }

    companion object {
        fun newInstance(maxStringLength: Int): DigitsOnlyFilter {
            return newInstance(StringBuilder(maxStringLength))
        }

        private fun newInstance(stringBuilder: StringBuilder): DigitsOnlyFilter {
            return DigitsOnlyFilter(stringBuilder)
        }
    }
}

class SlashSpan : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: FontMetricsInt?): Int {
        val slash: Float = paint.measureText("/", 0, 1)
        val textSize: Float = paint.measureText(text, start, end)
        return (slash + textSize).toInt()
    }

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        canvas.drawText(text?.subSequence(start, end).toString() + "/", x, y.toFloat(), paint)
    }
}
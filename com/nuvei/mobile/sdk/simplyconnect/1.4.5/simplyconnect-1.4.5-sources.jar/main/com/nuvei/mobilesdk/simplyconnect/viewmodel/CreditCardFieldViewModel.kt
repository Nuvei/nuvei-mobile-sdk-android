package com.nuvei.mobilesdk.simplyconnect.viewmodel

import android.app.Activity
import android.os.Handler
import android.os.Looper
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.TokenizeCallback
import com.nuvei.mobilesdk.core.model.Addendums
import com.nuvei.mobilesdk.core.model.CardDetails
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.LocalPayment
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.model.PaymentOption
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.isValidCvv
import com.nuvei.mobilesdk.core.CheckoutI18N
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.NVCardDetailsInput
import com.nuvei.mobilesdk.core.model.NVCardDetailsOutput
import com.nuvei.mobilesdk.core.utils.CardBlockHelper
import com.nuvei.mobilesdk.simplyconnect.SimplyConnect
import java.io.Serializable

interface CreditCardFieldViewModelListener {
    fun onLoadingChanged()
    fun onInputParsed(input: CreditCardInput)
    fun onSubmitResponse(response: NVCreatePaymentOutput)
    fun onWebCheckoutRequired(url: String)
}

class CreditCardFieldViewModel {
    var isLoading = false
    var listener: CreditCardFieldViewModelListener? = null
    private var lastFetchedCardNumber: String? = null
    private var lastCardDetails: NVCardDetailsOutput? = null

    fun parseCreditCardInfo(input: CreditCardInput, hasFocus: Boolean = false, ignoreEmpty: Boolean = true, transactionDetails: CheckoutTransactionDetails? = null) {
        if (hasFocus) {
            // Clear stale blocked-card message so the old card's error doesn't stick
            CheckoutI18N.cardBlockedConstructed = ""

            val parsedCard = CreditCardUtils.parseCardNumber(input.number)
            val targetCvvLength = parsedCard?.type?.cvvLength ?: 4

            // Get existing errors and update CVV/Blocked status specifically
            val errors = input.parsedInfo?.errors?.toMutableList() ?: mutableListOf()
            errors.remove(InputError.CVVInvalid)
            errors.remove(InputError.CreditCardInvalid)

            // SURGICAL FIX: Proactively flag CVV if it mismatch the detected brand.
            // If brand is unknown, we allow both 3 and 4 to avoid nagging for the most common lengths.
            if (input.cvv.isNotEmpty()) {
                if (parsedCard == null) {
                    if (input.cvv.length != 3 && input.cvv.length != 4) {
                        errors.add(InputError.CVVInvalid)
                    }
                } else if (input.cvv.length != targetCvvLength) {
                    errors.add(InputError.CVVInvalid)
                }
            }

            input.parsedInfo = CreditCardInput.ParsedInfo(
                errors.toTypedArray(),
                CreditCardUtils.iconForCard(parsedCard),
                targetCvvLength
            )

            if (parsedCard != null && transactionDetails != null && CardBlockHelper.isConfigured(transactionDetails.blockCards)) {
                fetchCardDetailsIfNeeded(transactionDetails, input.number, object : com.nuvei.mobilesdk.core.InternalCallback<NVCardDetailsOutput> {
                    override fun onSuccess(response: NVCardDetailsOutput) {
                        if (CardBlockHelper.isCardBlocked(response, transactionDetails.blockCards)) {
                            applyBlockedCardError(input, response, transactionDetails.blockCards)
                            Handler(Looper.getMainLooper()).post {
                                listener?.onInputParsed(input)
                            }
                        }
                    }

                    override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                    }
                })
            }
        } else {
            parseAndValidateCreditCardInput(input, ignoreEmpty, transactionDetails)
        }

        listener?.onInputParsed(input)
    }

    fun tokenize(activity: Activity, input: CreditCardInput, transactionDetails: CheckoutTransactionDetails, callback: TokenizeCallback) {
        if (!parseAndValidateCreditCardInput(input, ignoreEmpty = false)) {
            listener?.onInputParsed(input)
            return
        }

        isLoading = true
        listener?.onLoadingChanged()

        if (CardBlockHelper.isConfigured(transactionDetails.blockCards)) {
            fetchCardDetailsIfNeeded(transactionDetails, input.number, object : com.nuvei.mobilesdk.core.InternalCallback<NVCardDetailsOutput> {
                override fun onSuccess(response: NVCardDetailsOutput) {
                    if (CardBlockHelper.isCardBlocked(response, transactionDetails.blockCards)) {
                        applyBlockedCardError(input, response, transactionDetails.blockCards)
                        Handler(Looper.getMainLooper()).post {
                            isLoading = false
                            listener?.onLoadingChanged()
                            listener?.onInputParsed(input)
                        }
                    } else {
                        proceedWithTokenize(activity, input, transactionDetails, callback)
                    }
                }

                override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                    proceedWithTokenize(activity, input, transactionDetails, callback)
                }
            })
        } else {
            proceedWithTokenize(activity, input, transactionDetails, callback)
        }
    }

    private fun proceedWithTokenize(activity: Activity, input: CreditCardInput, transactionDetails: CheckoutTransactionDetails, callback: TokenizeCallback) {
        Nuvei.internalTokenize(
            activity,
            getInputObject(input, transactionDetails),
            object : TokenizeCallback {
                override fun onComplete(token: String?, error: com.nuvei.mobilesdk.core.model.Error?, additionalInfo: Map<String, Any>?) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        isLoading = false
                        listener?.onLoadingChanged()

                        callback.onComplete(token, error, additionalInfo)
                    }, 100)
                }
            }
        )
    }

    fun submitCreditCardInput(
        activity: Activity,
        input: CreditCardInput,
        transactionDetails: CheckoutTransactionDetails,
        callback: Callback<NVCreatePaymentOutput>? = null
    ) {
        if (!parseAndValidateCreditCardInput(input, ignoreEmpty = false)) {
            listener?.onInputParsed(input)
            return
        }

        isLoading = true
        listener?.onLoadingChanged()

        if (CardBlockHelper.isConfigured(transactionDetails.blockCards)) {
            fetchCardDetailsIfNeeded(transactionDetails, input.number, object : com.nuvei.mobilesdk.core.InternalCallback<NVCardDetailsOutput> {
                override fun onSuccess(response: NVCardDetailsOutput) {
                    if (CardBlockHelper.isCardBlocked(response, transactionDetails.blockCards)) {
                        applyBlockedCardError(input, response, transactionDetails.blockCards)
                        Handler(Looper.getMainLooper()).post {
                            isLoading = false
                            listener?.onLoadingChanged()
                            listener?.onInputParsed(input)
                        }
                    } else {
                        proceedWithPaymentSubmission(activity, input, transactionDetails, callback)
                    }
                }

                override fun onFailure(result: String, errorCode: Int?, errorDescription: String?, rawResult: Map<String, Any>?) {
                    proceedWithPaymentSubmission(activity, input, transactionDetails, callback)
                }
            })
        } else {
            proceedWithPaymentSubmission(activity, input, transactionDetails, callback)
        }
    }

    private fun proceedWithPaymentSubmission(
        activity: Activity,
        input: CreditCardInput,
        transactionDetails: CheckoutTransactionDetails,
        callback: Callback<NVCreatePaymentOutput>? = null
    ) {
        Nuvei.sourceApplication = NetworkConstants.Values.SourceApplication.checkout
        Nuvei.internalCreatePayment(
            activity,
            getInputObject(input, transactionDetails),
            null,
            transactionDetails.forceWebChallenge,
            object : Callback<NVCreatePaymentOutput> {
                override fun onComplete(response: NVCreatePaymentOutput) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        isLoading = false
                        listener?.onLoadingChanged()

                        listener?.onSubmitResponse(response)
                        callback?.onComplete(response)
                    }, 100)
                }
            }
        )
    }

    private fun getInputObject(input: CreditCardInput, transactionDetails: CheckoutTransactionDetails): NVPayment {
        val expiryParts = input.expiry.split("/")

        val paymentOption = PaymentOption(
            card = CardDetails(
                input.number,
                input.cardHolderName,
                input.cvv,
                expiryParts[0],
                expiryParts[1]
            ),
            saveMethod = input.shouldSaveCard
        )

        var addendums: Addendums? = null

        if (input.localPayment != null) {
            addendums = Addendums()
            addendums.localPayment = input.localPayment
        }

        return with(transactionDetails) {
            NVPayment(
                sessionToken,
                merchantId,
                merchantSiteId,
                googlePayMerchantId,
                googlePayMerchantName,
                googlePayGateway,
                googlePayGatewayMerchantId,
                currency,
                amount,
                paymentOption,
                clientUniqueId,
                clientRequestId,
                customData,
                billingAddress,
                shippingAddress,
                notificationUrl,
                userDetails,
                merchantDetails,
                dynamicDescriptor,
                addendums = addendums,
                blockCards = blockCards
            )
        }
    }

    private fun fetchCardDetailsIfNeeded(
        transactionDetails: CheckoutTransactionDetails,
        cardNumber: String,
        callback: com.nuvei.mobilesdk.core.InternalCallback<NVCardDetailsOutput>
    ) {
        val normalizedCardNumber = normalizeCardNumber(cardNumber)
        if (normalizedCardNumber.isBlank()) {
            callback.onFailure("ERROR", null, "Missing card number", null)
            return
        }


        Nuvei.getCardDetails(
            NVCardDetailsInput(
                sessionToken = transactionDetails.sessionToken,
                merchantId = transactionDetails.merchantId,
                merchantSiteId = transactionDetails.merchantSiteId,
                clientRequestId = transactionDetails.clientRequestId,
                clientUniqueId = transactionDetails.clientUniqueId,
                cardNumber = normalizedCardNumber
            ),
            object : com.nuvei.mobilesdk.core.InternalCallback<NVCardDetailsOutput> {
                override fun onSuccess(response: NVCardDetailsOutput) {
                    lastFetchedCardNumber = normalizedCardNumber
                    lastCardDetails = response
                    callback.onSuccess(response)
                }

                override fun onFailure(
                    result: String,
                    errorCode: Int?,
                    errorDescription: String?,
                    rawResult: Map<String, Any>?
                ) {
                    callback.onFailure(result, errorCode, errorDescription, rawResult)
                }
            },
            true
        )
    }

    private fun applyBlockedCardError(input: CreditCardInput, response: NVCardDetailsOutput, blockCards: List<List<String>>?) {
        input.parsedInfo?.errors = (input.parsedInfo?.errors?.toMutableList() ?: mutableListOf()).apply {
            if (!contains(InputError.CreditCardBlocked)) {
                add(InputError.CreditCardBlocked)
            }
        }.toTypedArray()
        // Write to cardBlockedConstructed so the client-provided cardBlocked always takes priority
        CheckoutI18N.cardBlockedConstructed = CardBlockHelper.getBlockedCardMessageFromRules(response, blockCards)
    }

    private fun normalizeCardNumber(cardNumber: String): String = cardNumber.replace(" ", "")

    fun parseAndValidateCreditCardInput(input: CreditCardInput, ignoreEmpty: Boolean, transactionDetails: CheckoutTransactionDetails? = null): Boolean {
        val inputErrors = ArrayList<InputError>()
        var parsedCard: CreditCardUtils.ParsedCard? = null

        if (input.expiry.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.ExpiryEmpty)
            }
        } else if (CreditCardUtils.parseDate(input.expiry) == null) {
            inputErrors.add(InputError.ExpiryInvalid)
        }

        if (input.number.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.NumberEmpty)
            }
        } else {
            parsedCard = CreditCardUtils.parseCardNumber(input.number)
            if (parsedCard == null) {
                inputErrors.add(InputError.CreditCardInvalid)
            }
            else if (input.parsedInfo?.errors?.contains(InputError.CreditCardBlocked) == true) {
                inputErrors.add(InputError.CreditCardBlocked)
            }
        }

        if (input.cardHolderName.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.HolderNameEmpty)
            }
        } else if (input.cardHolderName.first().isDigit()) {
            inputErrors.add(InputError.HolderNameInvalid)
        }

        if (input.cvv.isEmpty()) {
            if (!ignoreEmpty) {
                inputErrors.add(InputError.CVVEmpty)
            }
        } else if (!isValidCvv(input.cvv, parsedCard?.type)) {
            inputErrors.add(InputError.CVVInvalid)
        }

        if (SimplyConnect.installments.requirePersonalID) {
            val number = input.localPayment?.nationalId ?: ""
            if (number.isEmpty()) {
                if (!ignoreEmpty) {
                    inputErrors.add(InputError.PersonalIDEmpty)
                }
            } else {
                if (!PersonalIDValidator.isValid(number, Nuvei.hostAppDetails?.simCountryCode)) {
                    inputErrors.add(InputError.PersonalIDInvalid)
                }
            }
        }

        input.parsedInfo = CreditCardInput.ParsedInfo(
            inputErrors.toTypedArray(),
            CreditCardUtils.iconForCard(parsedCard),
            parsedCard?.type?.cvvLength ?: 4
        )

        if (inputErrors.size > 0) {
            return false
        }

        return true
    }

    private fun isFutureDate(date: String): Boolean {
        return try {
            val (monthStr, yearStr) = date.split("/")
            com.nuvei.mobilesdk.core.isFutureDate(monthStr.toInt(), yearStr.toInt())
        } catch (e: Exception) {
            false
        }
    }
}

data class CreditCardInput(
    val index: Int? = null,
    var number: String = "",
    var expiry: String = "",
    var cvv: String = "",
    var cardHolderName: String = "",
    var shouldSaveCard: Boolean = false,
    var parsedInfo: ParsedInfo? = null,
    var localPayment: LocalPayment? = null,
) : Serializable {
    data class ParsedInfo(
        var errors: Array<InputError>? = null,
        var icon: Int? = null,
        var cvvLength: Int? = null
    ) : Serializable {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is ParsedInfo) return false

            val e1 = errors
            val e2 = other.errors
            val errorsEqual = when {
                e1 === e2 -> true
                e1 == null || e2 == null -> false
                else -> e1.contentEquals(e2)
            }

            return errorsEqual &&
                    icon == other.icon &&
                    cvvLength == other.cvvLength
        }

        override fun hashCode(): Int {
            var result = errors?.contentHashCode() ?: 0
            result = 31 * result + (icon ?: 0)
            result = 31 * result + (cvvLength ?: 0)
            return result
        }
    }
}

fun String.formatAsCreditCardNumber(): String {
    return this
        .filter { it.isDigit() }
        .take(20)
        .chunked(4)
        .joinToString(separator = " ")
}

fun String.formatAsExpiry(): String {
    return this
        .filter { it.isDigit() }
        .take(4)
        .chunked(2)
        .mapIndexed { index, s ->
            var result = s
            if (index == 0)  {
                val first = s.first()
                if (first != '0' && first != '1') {
                    result = "0${first}"
                }
            }
            return@mapIndexed result
        }
        .joinToString(separator = "/")
}

fun String.formatAsCVV(length: Int): String {
    return this
        .filter { it.isDigit() }
        .take(length)
}

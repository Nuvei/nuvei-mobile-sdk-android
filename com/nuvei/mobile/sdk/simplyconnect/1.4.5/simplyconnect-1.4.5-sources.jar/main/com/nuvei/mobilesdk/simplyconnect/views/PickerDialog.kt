package com.nuvei.mobilesdk.simplyconnect.views

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.nuvei.mobilesdk.simplyconnect.databinding.DialogBottomSheetTextPickerBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemTextPickerBinding

import android.content.DialogInterface

class PickerDialog(
    private val title: String,
    private val adapter: PickerDialogAdapter,
    var onDismissListener: (() -> Unit)? = null
) : BottomSheetDialogFragment() {

    private lateinit var binding: DialogBottomSheetTextPickerBinding

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        onDismissListener?.invoke()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogBottomSheetTextPickerBinding.inflate(layoutInflater)

        binding.titleTextView.text = title
        binding.recyclerView.adapter = adapter

        return binding.root
    }
}

class PickerDialogAdapter(
    val values: List<String>
) : RecyclerView.Adapter<PickerDialogAdapter.BaseViewHolder>() {
    var onValueSelected: ((index: Int) -> (Unit))? = null

    open class BaseViewHolder(val binding: ListItemTextPickerBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): BaseViewHolder {
        return BaseViewHolder(ListItemTextPickerBinding.inflate(LayoutInflater.from(viewGroup.context)))
    }

    override fun getItemCount(): Int {
        return values.size
    }

    override fun onBindViewHolder(viewHolder: BaseViewHolder, position: Int) {
        val value = values[position]

        with(viewHolder.binding) {
            valueTextView.text = value
            valueTextView.setOnClickListener {
                onValueSelected?.invoke(position)
            }
        }
    }
}
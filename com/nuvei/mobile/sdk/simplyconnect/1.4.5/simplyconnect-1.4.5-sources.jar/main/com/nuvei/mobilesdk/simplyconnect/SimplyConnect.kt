package com.nuvei.mobilesdk.simplyconnect

import android.app.Activity
import android.content.Intent
import androidx.fragment.app.FragmentActivity
import com.nuvei.mobilesdk.core.Callback
import com.nuvei.mobilesdk.core.Keys
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.ApiClient
import com.nuvei.mobilesdk.simplyconnect.model.Installments
import com.nuvei.mobilesdk.core.CardDetailsCallback
import com.nuvei.mobilesdk.core.NuveiCardField
import com.nuvei.mobilesdk.core.model.NVCardDetailsInput

class SimplyConnect {

    companion object : NuveiCardField {

        val installments = Installments

        var onPaymentFormChange: ((pm: String, label: String, action: String, oldValue: String, newValue: String, validation: String, paste: Boolean) -> Unit)? = null
        var onFormValidated: ((isFormValid: Boolean, invalidFields: List<String>) -> Unit)? = null

        @Transient var activeCardField: NuveiCardField? = null

        override fun getCardDetailsInput(): NVCardDetailsInput? {
            return activeCardField?.getCardDetailsInput()
        }

        fun checkout(
            activity: Activity,
            input: NVPayment,
            countryCode: String,
            additionalParams: Map<String, Any?>? = null,
            forceWebChallenge: Boolean,
            callback: Callback<NVOutput>,
            declineFallbackDecision: ((NVOutput, FragmentActivity, ((Nuvei.CheckoutCompletionAction)->Unit))->Unit)?
        ) {
            Nuvei.validateMandatoryParams(
                input,
                requireAmountAndCurrency = true,
                countryCode = countryCode,
                requireCountry = true
            )?.let { errorMessage ->
                android.util.Log.e("SimplyConnect", errorMessage)
                callback.onComplete(NVOutput(
                    result = NVOutput.ERROR,
                    errorCode = com.nuvei.mobilesdk.core.model.Error.MISSING_PARAMETER.errorCode,
                    errorDescription = errorMessage
                ))
                return
            }

            Nuvei.onCheckoutCompletionActionRequired = fun(activity, output, completion) {
                if (declineFallbackDecision == null) {
                    completion(Nuvei.CheckoutCompletionAction.dismiss)
                    callback.onComplete(output)
                } else {
                    declineFallbackDecision(output, activity, completion)
                }
            }

            val newAdditionalParams = additionalParams?.toMutableMap()

            val intent = Intent(activity, CheckoutActivity::class.java)
            intent.putExtra(Keys.checkoutTransactionDetails, CheckoutTransactionDetails(input, newAdditionalParams, forceWebChallenge))
            intent.putExtra(Keys.checkoutNVPayment, input)
            intent.putExtra(Keys.checkoutCountryCode, countryCode)
            activity.startActivity(intent)
        }
    }
}
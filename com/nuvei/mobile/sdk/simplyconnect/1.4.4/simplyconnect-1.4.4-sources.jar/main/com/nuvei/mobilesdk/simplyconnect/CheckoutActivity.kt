package com.nuvei.mobilesdk.simplyconnect

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.google.gson.GsonBuilder
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.lifecycle.ViewModelProvider
import com.nuvei.mobilesdk.core.Keys
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.applePayType
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.bankTransferType
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.creditCardType
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.googlePayType
import com.nuvei.mobilesdk.googlepay.GooglePayHandler
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.CreditCardUtils.Companion.creditCardIconMapper
import com.nuvei.mobilesdk.core.EdgeToEdgeHelper
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.getSerializable
import com.nuvei.mobilesdk.core.model.APMsOutput
import com.nuvei.mobilesdk.core.model.SimplyConnectUICustomization
import com.nuvei.mobilesdk.core.model.TypefaceApplier
import com.nuvei.mobilesdk.core.model.UPOsOutput
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.simplyconnect.adapter.APMInput
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodAdapter
import com.nuvei.mobilesdk.core.NuveiCardField
import com.nuvei.mobilesdk.core.model.NVCardDetailsInput
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodBaseListItem
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodListItem
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodsSection
import com.nuvei.mobilesdk.simplyconnect.adapter.UPOCardInput
import com.nuvei.mobilesdk.simplyconnect.databinding.ActivityCheckoutBinding
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CheckoutViewModel
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CheckoutViewModelListener
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CreditCardInput
import com.nuvei.mobilesdk.simplyconnect.views.ConfirmDeleteDialog
import com.nuvei.mobilesdk.core.web_view.WebCheckoutActivity


class CheckoutActivity : AppCompatActivity(), NuveiCardField {

    private val factory by lazy { SavedStateViewModelFactory(application, this, intent.extras) }
    private val viewModel by lazy { ViewModelProvider(this, factory)[CheckoutViewModel::class.java] }

    private lateinit var binding: ActivityCheckoutBinding
    private var transactionDetails: CheckoutTransactionDetails? = null
    private lateinit var googlePayHandler: GooglePayHandler
    private lateinit var countryCode: String

    private val sessionLogs = StringBuilder()
    private var clientOnPaymentFormChange: ((String, String, String, String, String, String, Boolean) -> Unit)? = null
    private var clientOnFormValidated: ((Boolean, List<String>) -> Unit)? = null

    private fun appendLog(logMsg: String) {
        sessionLogs.insert(0, logMsg + "\n")
    }

    private var webCheckoutActivityResultHandler = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val transactionDetails = transactionDetails ?: return@registerForActivityResult
        viewModel.verifyRedirectedPaymentCompleted(transactionDetails)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        googlePayHandler = GooglePayHandler(this)
        googlePayHandler.source = NetworkConstants.Values.SourceApplication.checkout

        val transactionDetails = intent.getSerializable(Keys.checkoutTransactionDetails, CheckoutTransactionDetails::class.java) ?: run {
            finish()
            return
        }

        val nvPayment = intent.getSerializable(Keys.checkoutNVPayment, NVPayment::class.java) ?: run {
            finish()
            return
        }
        countryCode = intent.getStringExtra(Keys.checkoutCountryCode).toString()

        this.transactionDetails = transactionDetails

        binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EdgeToEdgeHelper.enableEdgeToEdge(window,binding.root)
        //TypefaceApplier.installInActivity(this)
        with(SimplyConnectUICustomization){
//            binding.headerView.helpTextView.textSize = toolbarCustomization.textFontSize.toFloat()
//            binding.headerView.helpTextView.setTextColor(toolbarCustomization.textColor)
            binding.root.setBackgroundColor(recyclerViewCustomization.backgroundColor)
            binding.headerView.root.setBackgroundColor(toolbarCustomization.backgroundColor)
            binding.headerView.headerTextView.textSize = toolbarCustomization.textFontSize.toFloat()
            binding.headerView.headerTextView.setTextColor(toolbarCustomization.textColor)
            binding.headerView.headerTextView.text = toolbarCustomization.headerText
            binding.headerView.headerTextView.applyNuveiFont(toolbarCustomization.textFontName)
            val logoRes = toolbarCustomization.logoResId
            if (logoRes != null && logoRes != 0){
                binding.headerView.logoTextView.setImageResource(logoRes)
            }

            binding.headerView.closeImageView.imageTintList = ColorStateList.valueOf(toolbarCustomization.closeButtonBackgroundColor)
            binding.headerView.closeImageView.setOnClickListener {
                onBackPressed()
            }
        }

        binding.checkoutMethodsRecyclerView.setHasFixedSize(true)
        binding.checkoutMethodsRecyclerView.itemAnimator = null
        binding.checkoutMethodsRecyclerView.adapter = CheckoutMethodAdapter(this, nvPayment)

        checkoutMethodsAdapter.onDeleteButtonClicked = {
            it.upoId?.let { upoId ->
                val dialog = ConfirmDeleteDialog()
                dialog.onConfirm = {
                    viewModel.deleteUPO(upoId, transactionDetails, this)
                }
                dialog.show(this)
            }
        }

        checkoutMethodsAdapter.onPayButtonClicked = { item, input ->
            if (input is CreditCardInput) {
                viewModel.submitCreditCardInput(this, input, transactionDetails)
            } else if (item.data is UPOsOutput.PaymentMethod) {
                viewModel.submitUPOInput(this, input, item.data as UPOsOutput.PaymentMethod, transactionDetails)
            } else if (input is APMInput && item.data is APMsOutput.APM) {
                viewModel.submitAPMInput(this, input, item.data as APMsOutput.APM, transactionDetails)
            } else if (item.layoutId == R.layout.list_item_checkout_google_pay) {
                viewModel.externalPaymentStarted()

                 googlePayHandler.openGooglePay(nvPayment, transactionDetails.forceWebChallenge, countryCode!!) {
                    result ->

                    viewModel.isLoading = false
                    viewModel.listener?.onLoadingChanged()

                    val message = if (result != null && result.result == NVOutput.APPROVED) {
                        "Google Pay payment successful."
                    } else {
                        "Google Pay payment FAILED.\nResult: " + result?.result +  " (Error code: " + result?.errorCode + ")"
                    }

                    AlertDialog.Builder(this)
                        .setMessage(message)
                        .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                        .show()
                }
            }
        }

        checkoutMethodsAdapter.onInputUpdated = { _, input, hasFocus ->
            when (input) {
                is CreditCardInput -> { viewModel.parseCreditCardInfo(input, hasFocus, transactionDetails) }
                is UPOCardInput -> { viewModel.parseUPOCardInfo(input, hasFocus) }
            }
        }

        checkoutMethodsAdapter.onShowPicker = {
            it.show(supportFragmentManager, null)
        }

        checkoutMethodsAdapter.onItemExpanded = { item, index ->
            binding.checkoutMethodsRecyclerView.scrollToPosition(index)
            viewModel.onMethodExpanded(item, index, transactionDetails)
        }

        viewModel.listener = object : CheckoutViewModelListener {
            override fun onLoadingChanged() {
                binding.loadingIndicator.visibility = if (viewModel.isLoading) View.VISIBLE else View.GONE
            }

            override fun onInputParsed(input: Any) {
                if (!binding.checkoutMethodsRecyclerView.isComputingLayout) {
                    checkoutMethodsAdapter.handleItemInputUpdate(input)
                }
            }

            override fun onCheckoutMethodsResponse(uposResponse: UPOsOutput?, apmsResponse: APMsOutput?, error: NVOutput?) {
                if (error == null) {
//                    apmsResponse?.paymentMethods?.forEach {
//                        if (it.methodType == applePayType)
//                            it.methodType = googlePayType
//                    }
                    checkoutMethodsAdapter.setItems(createCheckoutMethods(uposResponse, apmsResponse))
                } else {
                    handlePaymentResponse(error)
                }
            }

            override fun onSubmitResponse(response: NVCreatePaymentOutput) {
                handlePaymentResponse(response)
            }

            override fun onWebCheckoutRequired(url: String) {
                val intent = Intent(this@CheckoutActivity, WebCheckoutActivity::class.java)
                intent.putExtra(Keys.checkoutPaymentMethodUrl, url)
                webCheckoutActivityResultHandler.launch(intent)
            }
        }

//        googlePayHandler.onPaymentResultListener = { token ->
//            if (token == null) {
//                viewModel.verifyRedirectedPaymentCompleted(transactionDetails)
//            } else {
//                viewModel.submitGooglePayPayment(this, transactionDetails, token)
//            }
//        }

        viewModel.getCheckoutMethods(transactionDetails, this, true)

        // Setup Event Parity Listeners & demo logs floating button
        clientOnPaymentFormChange = SimplyConnect.onPaymentFormChange
        clientOnFormValidated = SimplyConnect.onFormValidated
        SimplyConnect.activeCardField = this

        SimplyConnect.onPaymentFormChange = { pm, label, action, oldValue, newValue, validation, paste ->
            val logMsg = "\n[onPaymentFormChange]\n{\n  \"pm\": \"$pm\",\n  \"label\": \"$label\",\n  \"action\": \"$action\",\n  \"oldValue\": \"$oldValue\",\n  \"newValue\": \"$newValue\",\n  \"validation\": \"$validation\",\n  \"paste\": $paste\n}"
            appendLog(logMsg)
            clientOnPaymentFormChange?.invoke(pm, label, action, oldValue, newValue, validation, paste)
        }

        SimplyConnect.onFormValidated = { isFormValid, invalidFields ->
            val logMsg = "\n[onFormValidated]\n{\n  \"isFormValid\": $isFormValid,\n  \"invalidFields\": ${invalidFields.map { "\"$it\"" }}\n}"
            appendLog(logMsg)
            clientOnFormValidated?.invoke(isFormValid, invalidFields)
        }

        if (Nuvei.hostAppDetails?.isTestApp == true) {
            binding.fabDemoLogs.visibility = View.VISIBLE
            binding.fabDemoLogs.setOnClickListener {
                showLogsDialog()
            }
        }
    }

    private val checkoutMethodsAdapter: CheckoutMethodAdapter
        get() {
            return binding.checkoutMethodsRecyclerView.adapter as CheckoutMethodAdapter
        }

    private fun createCheckoutMethods(uposOutput: UPOsOutput?, apmsOutput: APMsOutput?): List<CheckoutMethodBaseListItem> {
        val transactionDetails = transactionDetails ?: return emptyList()

        var hasGooglePay = false

        val apmsSectionItems = ArrayList<CheckoutMethodListItem>()
        apmsOutput?.paymentMethods?.mapNotNull {
            if (it.methodType == googlePayType) {
                hasGooglePay = true
            }
            parseAPMMethod(it, transactionDetails)
        }?.let { apms -> apmsSectionItems.addAll(apms) }

        val uposSectionItems = ArrayList<CheckoutMethodListItem>()
        uposOutput?.methods?.mapNotNull {
            parseUPOMethod(it, transactionDetails)
        }?.let { upos -> uposSectionItems.addAll(upos) }

        val sections = ArrayList<CheckoutMethodBaseListItem>()

        // Add GooglePay to the list only if the current country is known
        if (hasGooglePay && countryCode == null) {
            hasGooglePay = false
        }

        if (hasGooglePay) {
            sections.add(
                CheckoutMethodListItem(
                    title = getString(R.string.checkout_method_google),
                    layoutId = R.layout.list_item_checkout_google_pay,
                    amount = transactionDetails.amount.toFloat(),
                    currency = transactionDetails.currency
                )
            )
        }

        if (uposSectionItems.isNotEmpty()) {
            sections.add(
                CheckoutMethodsSection(
                    getString(R.string.checkout_methods_section_upos),
                    items = uposSectionItems
                )
            )
        }

        if (apmsSectionItems.isNotEmpty()) {
            sections.add(
                CheckoutMethodsSection(
                    getString(R.string.checkout_methods_section_apms),
                    items = apmsSectionItems
                )
            )
        }

        return sections
    }

    private fun parseUPOMethod(method: UPOsOutput.PaymentMethod, transactionDetails: CheckoutTransactionDetails): CheckoutMethodListItem? {
        if (method.status != NetworkConstants.enabled) return null

        return with(method) {
            when (methodType) {
                creditCardType -> {
                    val cardType = method.upoData.brand?.let { CreditCardUtils.CardType.fromBrandName(it) }
                    val localLogo = cardType?.let { creditCardIconMapper.map(it) }
                    CheckoutMethodListItem(
                        title = upoData.ccNumber,
                        layoutId = R.layout.list_item_checkout_upo_card,
                        iconId = localLogo,
                        upoId = userPaymentOptionId,
                        amount = transactionDetails.amount.toFloat(),
                        currency = transactionDetails.currency,
                        data = method,
                        initialParsedInfo = UPOCardInput.InitialParsedInfo(
                            cvvLength = cardType?.cvvLength ?: 4
                        )
                    )
                }
                else -> CheckoutMethodListItem(
                    title = title,
                    layoutId = R.layout.list_item_checkout_upo_generic,
                    iconId = null,
                    iconUrl = viewModel.apmLogoCache[methodType],
                    upoId = userPaymentOptionId,
                    amount = transactionDetails.amount.toFloat(),
                    currency = transactionDetails.currency,
                    data = method
                )
            }
        }
    }

    private fun parseAPMMethod(method: APMsOutput.APM, transactionDetails: CheckoutTransactionDetails): CheckoutMethodListItem? {
        if (method.logoURL != null && method.logoURL!!.isNotEmpty()) {
            viewModel.apmLogoCache[method.methodType] = method.logoURL!!
        }

        return with(method) {
            when (methodType) {
                creditCardType -> {
                    val input = transactionDetails.paymentOption?.card?.let {
                        with(it) {
                            val expiry = "$expirationMonth/$expirationYear"
                            CreditCardInput(
                                0,
                                cardNumber.orEmpty(),
                                if (expiry.length == 5) expiry else "",
                                CVV.orEmpty(),
                                cardHolderName.orEmpty(),
                                false
                            )
                        }.also { input ->
                            viewModel.parseCreditCardInfo(input)
                        }
                    }

                    return CheckoutMethodListItem(
                        title = getString(R.string.checkout_method_card),
                        layoutId = R.layout.list_item_checkout_card,
                        amount = transactionDetails.amount.toFloat(),
                        currency = transactionDetails.currency,
                        isSelected = true,
                        input = input
                    )
                }
                bankTransferType -> {
                    CheckoutMethodListItem(
                        title = getString(R.string.checkout_method_bank_transfer),
                        layoutId = R.layout.list_item_checkout_apm_dynamic,
                        iconUrl = method.logoURL,
                        upoId = null,
                        amount = transactionDetails.amount.toFloat(),
                        currency = transactionDetails.currency,
                        data = method
                    )
                }
                googlePayType, applePayType -> return null
                else -> CheckoutMethodListItem(
                    title = title.find { it.language == "en" }?.message ?: "",
                    layoutId = if (fields.isEmpty()) R.layout.list_item_checkout_generic else R.layout.list_item_checkout_apm_dynamic,
                    iconUrl = method.logoURL,
                    upoId = null,
                    amount = transactionDetails.amount.toFloat(),
                    currency = transactionDetails.currency,
                    data = method
                )
            }
        }
    }

    private fun handlePaymentResponse(response: NVOutput) {
        Nuvei.onCheckoutCompletionActionRequired?.invoke(this, response) { action ->
            if (action != Nuvei.CheckoutCompletionAction.dismiss) {
                return@invoke
            }

            Nuvei.onCheckoutCompletionActionRequired = null
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        SimplyConnect.onPaymentFormChange = clientOnPaymentFormChange
        SimplyConnect.onFormValidated = clientOnFormValidated
        SimplyConnect.activeCardField = null
    }

    override fun getCardDetailsInput(): NVCardDetailsInput? {
        val adapter = checkoutMethodsAdapter
        val items = adapter.getItems()
        val selectedItem = items.filterIsInstance<CheckoutMethodListItem>().firstOrNull { it.isSelected } ?: return null

        val isNewCard = selectedItem.layoutId == R.layout.list_item_checkout_card

        return if (isNewCard) {
            val ccInput = selectedItem.input as? CreditCardInput
            val rawNum = ccInput?.number.orEmpty()
            val normalizedCardNumber = rawNum.replace(" ", "")
            if (normalizedCardNumber.isBlank()) return null
            NVCardDetailsInput(
                sessionToken = transactionDetails?.sessionToken.orEmpty(),
                merchantId = transactionDetails?.merchantId.orEmpty(),
                merchantSiteId = transactionDetails?.merchantSiteId.orEmpty(),
                clientRequestId = transactionDetails?.clientRequestId,
                clientUniqueId = transactionDetails?.clientUniqueId,
                cardNumber = normalizedCardNumber
            )
        } else {
            val upoId = selectedItem.upoId
            if (upoId.isNullOrBlank()) return null
            NVCardDetailsInput(
                sessionToken = transactionDetails?.sessionToken.orEmpty(),
                merchantId = transactionDetails?.merchantId.orEmpty(),
                merchantSiteId = transactionDetails?.merchantSiteId.orEmpty(),
                clientRequestId = transactionDetails?.clientRequestId,
                clientUniqueId = transactionDetails?.clientUniqueId,
                cardNumber = null,
                userPaymentOptionId = upoId
            )
        }
    }

    private fun showLogsDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_demo_logs, null)
        val tvLogs = dialogView.findViewById<TextView>(R.id.tvLogs)
        val btnGetCardDetails = dialogView.findViewById<View>(R.id.btnGetCardDetails)
        val btnClearLogs = dialogView.findViewById<View>(R.id.btnClearLogs)
        val btnClose = dialogView.findViewById<View>(R.id.btnClose)

        tvLogs.text = sessionLogs.toString()

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        btnGetCardDetails.setOnClickListener {
            triggerOnDemandGetCardDetails(tvLogs)
        }

        btnClearLogs.setOnClickListener {
            sessionLogs.clear()
            tvLogs.text = ""
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun triggerOnDemandGetCardDetails(tvLogs: TextView) {
        if (!com.nuvei.mobilesdk.core.Nuvei.getCardDetailsEnabled) {
            val logMsg = "\n[getCardDetails (Error)]\nFeature not enabled."
            appendLog(logMsg)
            tvLogs.text = sessionLogs.toString()
            return
        }

        val adapter = checkoutMethodsAdapter
        val items = adapter.getItems()
        val selectedItem = items.filterIsInstance<CheckoutMethodListItem>().firstOrNull { it.isSelected }

        if (selectedItem == null) {
            val logMsg = "\n[getCardDetails (Error)]\nNo expanded payment method selected."
            appendLog(logMsg)
            tvLogs.text = sessionLogs.toString()
            return
        }

        val detailsInput: com.nuvei.mobilesdk.core.model.NVCardDetailsInput
        val isNewCard = selectedItem.layoutId == R.layout.list_item_checkout_card

        if (isNewCard) {
            val ccInput = selectedItem.input as? CreditCardInput
            val rawNum = ccInput?.number.orEmpty()
            val normalizedCardNumber = rawNum.replace(" ", "")
            if (normalizedCardNumber.isBlank()) {
                val logMsg = "\n[getCardDetails (Error)]\nCard number is empty."
                appendLog(logMsg)
                tvLogs.text = sessionLogs.toString()
                return
            }
            detailsInput = com.nuvei.mobilesdk.core.model.NVCardDetailsInput(
                sessionToken = transactionDetails?.sessionToken.orEmpty(),
                merchantId = transactionDetails?.merchantId.orEmpty(),
                merchantSiteId = transactionDetails?.merchantSiteId.orEmpty(),
                clientRequestId = transactionDetails?.clientRequestId,
                clientUniqueId = transactionDetails?.clientUniqueId,
                cardNumber = normalizedCardNumber
            )
        } else {
            val upoId = selectedItem.upoId
            if (upoId.isNullOrBlank()) {
                val logMsg = "\n[getCardDetails (Error)]\nSelected payment method has no UPO ID."
                appendLog(logMsg)
                tvLogs.text = sessionLogs.toString()
                return
            }
            detailsInput = com.nuvei.mobilesdk.core.model.NVCardDetailsInput(
                sessionToken = transactionDetails?.sessionToken.orEmpty(),
                merchantId = transactionDetails?.merchantId.orEmpty(),
                merchantSiteId = transactionDetails?.merchantSiteId.orEmpty(),
                clientRequestId = transactionDetails?.clientRequestId,
                clientUniqueId = transactionDetails?.clientUniqueId,
                cardNumber = null,
                userPaymentOptionId = upoId
            )
        }

        Nuvei.getCardDetails(detailsInput, object : com.nuvei.mobilesdk.core.InternalCallback<com.nuvei.mobilesdk.core.model.NVCardDetailsOutput> {
            override fun onSuccess(response: com.nuvei.mobilesdk.core.model.NVCardDetailsOutput) {
                val gson = com.google.gson.GsonBuilder().setPrettyPrinting().create()
                val jsonOutput = gson.toJson(response)
                val logMsg = "\n[getCardDetails (Success)]\n$jsonOutput"
                appendLog(logMsg)
                runOnUiThread {
                    tvLogs.text = sessionLogs.toString()
                }
            }

            override fun onFailure(
                result: String,
                errorCode: Int?,
                errorDescription: String?,
                rawResult: Map<String, Any>?
            ) {
                val errMap = mapOf(
                    "result" to result,
                    "errorCode" to errorCode,
                    "errorDescription" to errorDescription
                )
                val gson = com.google.gson.GsonBuilder().setPrettyPrinting().create()
                val jsonOutput = gson.toJson(errMap)
                val logMsg = "\n[getCardDetails (Failure)]\n$jsonOutput"
                appendLog(logMsg)
                runOnUiThread {
                    tvLogs.text = sessionLogs.toString()
                }
            }
        })
    }
}
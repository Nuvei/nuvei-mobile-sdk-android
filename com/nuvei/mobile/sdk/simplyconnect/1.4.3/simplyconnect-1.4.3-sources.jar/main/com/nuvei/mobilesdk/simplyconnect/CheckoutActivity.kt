package com.nuvei.mobilesdk.simplyconnect

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.lifecycle.ViewModelProvider
import com.nuvei.mobilesdk.core.Keys
import com.nuvei.mobilesdk.core.model.CheckoutTransactionDetails
import com.nuvei.mobilesdk.core.model.NVCreatePaymentOutput
import com.nuvei.mobilesdk.core.model.NVOutput
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.applePayType
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.bankTransferType
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.creditCardType
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.googlePayType
import com.nuvei.mobilesdk.googlepay.GooglePayHandler
import com.nuvei.mobilesdk.core.CreditCardUtils
import com.nuvei.mobilesdk.core.CreditCardUtils.Companion.creditCardIconMapper
import com.nuvei.mobilesdk.core.EdgeToEdgeHelper
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.getSerializable
import com.nuvei.mobilesdk.core.model.APMsOutput
import com.nuvei.mobilesdk.core.model.SimplyConnectUICustomization
import com.nuvei.mobilesdk.core.model.TypefaceApplier
import com.nuvei.mobilesdk.core.model.UPOsOutput
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.simplyconnect.adapter.APMInput
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodAdapter
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodBaseListItem
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodListItem
import com.nuvei.mobilesdk.simplyconnect.adapter.CheckoutMethodsSection
import com.nuvei.mobilesdk.simplyconnect.adapter.UPOCardInput
import com.nuvei.mobilesdk.simplyconnect.databinding.ActivityCheckoutBinding
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CheckoutViewModel
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CheckoutViewModelListener
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CreditCardInput
import com.nuvei.mobilesdk.simplyconnect.views.ConfirmDeleteDialog
import com.nuvei.mobilesdk.core.web_view.WebCheckoutActivity


class CheckoutActivity : AppCompatActivity() {

    private val factory by lazy { SavedStateViewModelFactory(application, this, intent.extras) }
    private val viewModel by lazy { ViewModelProvider(this, factory)[CheckoutViewModel::class.java] }

    private lateinit var binding: ActivityCheckoutBinding
    private var transactionDetails: CheckoutTransactionDetails? = null
    private lateinit var googlePayHandler: GooglePayHandler
    private lateinit var countryCode: String

    private var webCheckoutActivityResultHandler = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val transactionDetails = transactionDetails ?: return@registerForActivityResult
        viewModel.verifyRedirectedPaymentCompleted(transactionDetails)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        googlePayHandler = GooglePayHandler(this)
        googlePayHandler.source = NetworkConstants.Values.SourceApplication.checkout

        val transactionDetails = intent.getSerializable(Keys.checkoutTransactionDetails, CheckoutTransactionDetails::class.java) ?: run {
            finish()
            return
        }

        val nvPayment = intent.getSerializable(Keys.checkoutNVPayment, NVPayment::class.java) ?: run {
            finish()
            return
        }
        countryCode = intent.getStringExtra(Keys.checkoutCountryCode).toString()

        this.transactionDetails = transactionDetails

        binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EdgeToEdgeHelper.enableEdgeToEdge(window,binding.root)
        //TypefaceApplier.installInActivity(this)
        with(SimplyConnectUICustomization){
//            binding.headerView.helpTextView.textSize = toolbarCustomization.textFontSize.toFloat()
//            binding.headerView.helpTextView.setTextColor(toolbarCustomization.textColor)
            binding.root.setBackgroundColor(recyclerViewCustomization.backgroundColor)
            binding.headerView.root.setBackgroundColor(toolbarCustomization.backgroundColor)
            binding.headerView.headerTextView.textSize = toolbarCustomization.textFontSize.toFloat()
            binding.headerView.headerTextView.setTextColor(toolbarCustomization.textColor)
            binding.headerView.headerTextView.text = toolbarCustomization.headerText
            binding.headerView.headerTextView.applyNuveiFont(toolbarCustomization.textFontName)
            val logoRes = toolbarCustomization.logoResId
            if (logoRes != null && logoRes != 0){
                binding.headerView.logoTextView.setImageResource(logoRes)
            }

            binding.headerView.closeImageView.imageTintList = ColorStateList.valueOf(toolbarCustomization.closeButtonBackgroundColor)
            binding.headerView.closeImageView.setOnClickListener {
                onBackPressed()
            }
        }

        binding.checkoutMethodsRecyclerView.setHasFixedSize(true)
        binding.checkoutMethodsRecyclerView.itemAnimator = null
        binding.checkoutMethodsRecyclerView.adapter = CheckoutMethodAdapter(this, nvPayment)

        checkoutMethodsAdapter.onDeleteButtonClicked = {
            it.upoId?.let { upoId ->
                val dialog = ConfirmDeleteDialog()
                dialog.onConfirm = {
                    viewModel.deleteUPO(upoId, transactionDetails, this)
                }
                dialog.show(this)
            }
        }

        checkoutMethodsAdapter.onPayButtonClicked = { item, input ->
            if (input is CreditCardInput) {
                viewModel.submitCreditCardInput(this, input, transactionDetails)
            } else if (item.data is UPOsOutput.PaymentMethod) {
                viewModel.submitUPOInput(this, input, item.data as UPOsOutput.PaymentMethod, transactionDetails)
            } else if (input is APMInput && item.data is APMsOutput.APM) {
                viewModel.submitAPMInput(this, input, item.data as APMsOutput.APM, transactionDetails)
            } else if (item.layoutId == R.layout.list_item_checkout_google_pay) {
                viewModel.externalPaymentStarted()

                 googlePayHandler.openGooglePay(nvPayment, transactionDetails.forceWebChallenge, countryCode!!) {
                    result ->

                    viewModel.isLoading = false
                    viewModel.listener?.onLoadingChanged()

                    val message = if (result != null && result.result == NVOutput.APPROVED) {
                        "Google Pay payment successful."
                    } else {
                        "Google Pay payment FAILED.\nResult: " + result?.result +  " (Error code: " + result?.errorCode + ")"
                    }

                    AlertDialog.Builder(this)
                        .setMessage(message)
                        .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                        .show()
                }
            }
        }

        checkoutMethodsAdapter.onInputUpdated = { _, input, hasFocus ->
            when (input) {
                is CreditCardInput -> { viewModel.parseCreditCardInfo(input, hasFocus, transactionDetails) }
                is UPOCardInput -> { viewModel.parseUPOCardInfo(input, hasFocus) }
            }
        }

        checkoutMethodsAdapter.onShowPicker = {
            it.show(supportFragmentManager, null)
        }

        checkoutMethodsAdapter.onItemExpanded = { item, index ->
            binding.checkoutMethodsRecyclerView.scrollToPosition(index)
            viewModel.onMethodExpanded(item, index, transactionDetails)
        }

        viewModel.listener = object : CheckoutViewModelListener {
            override fun onLoadingChanged() {
                binding.loadingIndicator.visibility = if (viewModel.isLoading) View.VISIBLE else View.GONE
            }

            override fun onInputParsed(input: Any) {
                if (!binding.checkoutMethodsRecyclerView.isComputingLayout) {
                    checkoutMethodsAdapter.handleItemInputUpdate(input)
                }
            }

            override fun onCheckoutMethodsResponse(uposResponse: UPOsOutput?, apmsResponse: APMsOutput?, error: NVOutput?) {
                if (error == null) {
//                    apmsResponse?.paymentMethods?.forEach {
//                        if (it.methodType == applePayType)
//                            it.methodType = googlePayType
//                    }
                    checkoutMethodsAdapter.setItems(createCheckoutMethods(uposResponse, apmsResponse))
                } else {
                    handlePaymentResponse(error)
                }
            }

            override fun onSubmitResponse(response: NVCreatePaymentOutput) {
                handlePaymentResponse(response)
            }

            override fun onWebCheckoutRequired(url: String) {
                val intent = Intent(this@CheckoutActivity, WebCheckoutActivity::class.java)
                intent.putExtra(Keys.checkoutPaymentMethodUrl, url)
                webCheckoutActivityResultHandler.launch(intent)
            }
        }

//        googlePayHandler.onPaymentResultListener = { token ->
//            if (token == null) {
//                viewModel.verifyRedirectedPaymentCompleted(transactionDetails)
//            } else {
//                viewModel.submitGooglePayPayment(this, transactionDetails, token)
//            }
//        }

        viewModel.getCheckoutMethods(transactionDetails, this, true)
    }

    private val checkoutMethodsAdapter: CheckoutMethodAdapter
        get() {
            return binding.checkoutMethodsRecyclerView.adapter as CheckoutMethodAdapter
        }

    private fun createCheckoutMethods(uposOutput: UPOsOutput?, apmsOutput: APMsOutput?): List<CheckoutMethodBaseListItem> {
        val transactionDetails = transactionDetails ?: return emptyList()

        var hasGooglePay = false

        val apmsSectionItems = ArrayList<CheckoutMethodListItem>()
        apmsOutput?.paymentMethods?.mapNotNull {
            if (it.methodType == googlePayType) {
                hasGooglePay = true
            }
            parseAPMMethod(it, transactionDetails)
        }?.let { apms -> apmsSectionItems.addAll(apms) }

        val uposSectionItems = ArrayList<CheckoutMethodListItem>()
        uposOutput?.methods?.mapNotNull {
            parseUPOMethod(it, transactionDetails)
        }?.let { upos -> uposSectionItems.addAll(upos) }

        val sections = ArrayList<CheckoutMethodBaseListItem>()

        // Add GooglePay to the list only if the current country is known
        if (hasGooglePay && countryCode == null) {
            hasGooglePay = false
        }

        if (hasGooglePay) {
            sections.add(
                CheckoutMethodListItem(
                    title = getString(R.string.checkout_method_google),
                    layoutId = R.layout.list_item_checkout_google_pay,
                    amount = transactionDetails.amount.toFloat(),
                    currency = transactionDetails.currency
                )
            )
        }

        if (uposSectionItems.isNotEmpty()) {
            sections.add(
                CheckoutMethodsSection(
                    getString(R.string.checkout_methods_section_upos),
                    items = uposSectionItems
                )
            )
        }

        if (apmsSectionItems.isNotEmpty()) {
            sections.add(
                CheckoutMethodsSection(
                    getString(R.string.checkout_methods_section_apms),
                    items = apmsSectionItems
                )
            )
        }

        return sections
    }

    private fun parseUPOMethod(method: UPOsOutput.PaymentMethod, transactionDetails: CheckoutTransactionDetails): CheckoutMethodListItem? {
        if (method.status != NetworkConstants.enabled) return null

        return with(method) {
            when (methodType) {
                creditCardType -> {
                    val cardType = method.upoData.brand?.let { CreditCardUtils.CardType.fromBrandName(it) }
                    val localLogo = cardType?.let { creditCardIconMapper.map(it) }
                    CheckoutMethodListItem(
                        title = upoData.ccNumber,
                        layoutId = R.layout.list_item_checkout_upo_card,
                        iconId = localLogo,
                        upoId = userPaymentOptionId,
                        amount = transactionDetails.amount.toFloat(),
                        currency = transactionDetails.currency,
                        data = method,
                        initialParsedInfo = UPOCardInput.InitialParsedInfo(
                            cvvLength = cardType?.cvvLength ?: 4
                        )
                    )
                }
                else -> CheckoutMethodListItem(
                    title = title,
                    layoutId = R.layout.list_item_checkout_upo_generic,
                    iconId = null,
                    iconUrl = viewModel.apmLogoCache[methodType],
                    upoId = userPaymentOptionId,
                    amount = transactionDetails.amount.toFloat(),
                    currency = transactionDetails.currency,
                    data = method
                )
            }
        }
    }

    private fun parseAPMMethod(method: APMsOutput.APM, transactionDetails: CheckoutTransactionDetails): CheckoutMethodListItem? {
        if (method.logoURL != null && method.logoURL!!.isNotEmpty()) {
            viewModel.apmLogoCache[method.methodType] = method.logoURL!!
        }

        return with(method) {
            when (methodType) {
                creditCardType -> {
                    val input = transactionDetails.paymentOption?.card?.let {
                        with(it) {
                            val expiry = "$expirationMonth/$expirationYear"
                            CreditCardInput(
                                0,
                                cardNumber.orEmpty(),
                                if (expiry.length == 5) expiry else "",
                                CVV.orEmpty(),
                                cardHolderName.orEmpty(),
                                false
                            )
                        }.also { input ->
                            viewModel.parseCreditCardInfo(input)
                        }
                    }

                    return CheckoutMethodListItem(
                        title = getString(R.string.checkout_method_card),
                        layoutId = R.layout.list_item_checkout_card,
                        amount = transactionDetails.amount.toFloat(),
                        currency = transactionDetails.currency,
                        isSelected = true,
                        input = input
                    )
                }
                bankTransferType -> {
                    CheckoutMethodListItem(
                        title = getString(R.string.checkout_method_bank_transfer),
                        layoutId = R.layout.list_item_checkout_apm_dynamic,
                        iconUrl = method.logoURL,
                        upoId = null,
                        amount = transactionDetails.amount.toFloat(),
                        currency = transactionDetails.currency,
                        data = method
                    )
                }
                googlePayType, applePayType -> return null
                else -> CheckoutMethodListItem(
                    title = title.find { it.language == "en" }?.message ?: "",
                    layoutId = if (fields.isEmpty()) R.layout.list_item_checkout_generic else R.layout.list_item_checkout_apm_dynamic,
                    iconUrl = method.logoURL,
                    upoId = null,
                    amount = transactionDetails.amount.toFloat(),
                    currency = transactionDetails.currency,
                    data = method
                )
            }
        }
    }

    private fun handlePaymentResponse(response: NVOutput) {
        Nuvei.onCheckoutCompletionActionRequired?.invoke(this, response) { action ->
            if (action != Nuvei.CheckoutCompletionAction.dismiss) {
                return@invoke
            }

            Nuvei.onCheckoutCompletionActionRequired = null
            finish()
        }
    }
}
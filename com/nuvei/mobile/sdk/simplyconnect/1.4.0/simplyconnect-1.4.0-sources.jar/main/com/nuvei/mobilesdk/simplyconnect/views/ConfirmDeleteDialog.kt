package com.nuvei.mobilesdk.simplyconnect.views

import android.app.AlertDialog
import android.content.Context
import com.nuvei.mobilesdk.simplyconnect.R

class ConfirmDeleteDialog {
    var onConfirm: (()->(Unit))? = null

    fun show(context: Context) {
        val builder = AlertDialog.Builder(context)

        builder.setTitle(R.string.checkout_method_dialog_confirm_delete_title)

        builder.setPositiveButton(R.string.checkout_method_dialog_confirm_delete_ok) { dialog, _ ->
            onConfirm?.invoke()
            dialog.dismiss()
        }

        builder.setNegativeButton(R.string.checkout_method_dialog_confirm_delete_cancel) { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }
}
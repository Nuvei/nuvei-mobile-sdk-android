package com.nuvei.mobilesdk.simplyconnect.viewmodel

object PersonalIDValidator {

    private fun isNumeric(string: String): Boolean {
        return string.all { char -> char.isDigit() }
    }

    private fun isAlphanumeric(string: String): Boolean {
        return string.matches(Regex("^[a-zA-Z0-9]+$"))
    }

    private fun testBrazilPassportId(passportId: String) : Boolean {
        val blacklist = arrayOf(
            "11111111111", "22222222222", "33333333333", "44444444444", "55555555555",
            "66666666666", "77777777777", "88888888888", "99999999999", "00000000000")

        val number = passportId.filter(Char::isDigit)

        if (number.length != 11 || blacklist.contains(number))
            return false

        val digits = ArrayList<Int>((number.toCharArray().map { it.digitToInt() }).take(9))
        var checkDigit1 = 0
        var checkDigit2 = 0
        var weight = 2

        digits.reversed().forEach { digit ->
            checkDigit1 += weight * digit
            checkDigit2 += (weight + 1) * digit;
            weight += 1;
        }

        checkDigit1 = if ((checkDigit1 % 11) < 2) 0 else 11 - (checkDigit1 % 11)
        checkDigit2 += 2 * checkDigit1
        checkDigit2 = if ((checkDigit2 % 11) < 2) 0 else 11 - (checkDigit2 % 11)

        digits.add(checkDigit1)
        digits.add(checkDigit2)
        return digits.joinToString(separator = "") { it.toString() } == number
    }

    fun isValid(number: String, countryCode: String?): Boolean {
        val length = number.length

        val isValid: Boolean

        when (countryCode) {
            // Argentina Length 7-9 or 11 numeric
            "AR" -> isValid = isNumeric(number) && (length == 11 || (length in 7..9))

            // Brazil Length 11 digits or 14 digits with symbols
            "BR" -> isValid = (length == 11 || length == 14) && testBrazilPassportId(number)

            // Chile/Peru Length 8-9 numeric
            "CL", "PE" -> isValid = isNumeric(number) && (length == 8 || length == 9)

            // Colombia length between 6 and 10 numeric
            "CO" -> isValid = isNumeric(number) && (length in 6..10)

            // Mexico length between 10 and 18 Alphanumeric
            "MX" -> isValid = isAlphanumeric(number) && (length in 10..18)

            // Paraguay/Uruguay Length 6-8 numeric
            "PY", "UY" -> isValid = isNumeric(number) && (length in 6..8)

            "IL" -> isValid = isNumeric(number) && (length == 9)

            else -> isValid = false
        }

        return isValid
    }
}
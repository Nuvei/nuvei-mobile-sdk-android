package com.nuvei.mobilesdk.simplyconnect.model

import android.app.Activity
import com.nuvei.mobilesdk.core.model.CheckoutI18N

object Installments {

    enum class Type {
        SINGLE_PAYMENT,
        DEFERRED_WITH_INTEREST,
        DEFERRED_WITHOUT_INTEREST,
        DEFERRED_WITHOUT_INTEREST_AND_GRACE_PERIOD;

        fun getDescription(): String {
            return when (this) {
                SINGLE_PAYMENT -> CheckoutI18N.singlePaymentText
                DEFERRED_WITH_INTEREST -> CheckoutI18N.deferredWithInterestText
                DEFERRED_WITHOUT_INTEREST -> CheckoutI18N.deferredWithoutInterestText
                DEFERRED_WITHOUT_INTEREST_AND_GRACE_PERIOD -> CheckoutI18N.deferredWithoutInterestAndGraceText
            }
        }
    }

    class Option(val type: Type, val installments: IntArray = intArrayOf()) {
        val isSinglePayment = installments.isEmpty()

        val installmentStrings: ArrayList<String>
            get() {
                return ArrayList(installments.map { type -> type.toString() })
            }

    }

    var options: ArrayList<Option> = ArrayList()
    var requirePersonalID: Boolean = false

    fun descriptionStrings(activity: Activity): ArrayList<String> {
        return ArrayList(options.map { option -> option.type.getDescription() })
    }
}
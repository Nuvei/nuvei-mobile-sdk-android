package com.nuvei.mobilesdk.simplyconnect

import android.content.Context.INPUT_METHOD_SERVICE
import android.view.View
import android.view.inputmethod.InputMethodManager


class KeyboardUtils {
    companion object {
        fun hideKeyboard(view: View) {
            try {
                val inputMethodManager: InputMethodManager? = view.context.getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                inputMethodManager?.hideSoftInputFromWindow(view.windowToken, 0)
            } catch (_: Exception) {
            }
        }
    }
}
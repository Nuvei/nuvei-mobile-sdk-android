package com.nuvei.mobilesdk.simplyconnect.adapter

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.children
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nuvei.mobilesdk.core.Nuvei
import com.nuvei.mobilesdk.core.Nuvei.tryOrNull
import com.nuvei.mobilesdk.core.model.LocalPayment
import com.nuvei.mobilesdk.core.model.NVPayment
import com.nuvei.mobilesdk.core.network.NetworkConstants
import com.nuvei.mobilesdk.core.network.NetworkConstants.Values.idealType
import com.nuvei.mobilesdk.googlepay.GooglePayHandler
import com.nuvei.mobilesdk.core.isFutureDate
import com.nuvei.mobilesdk.core.model.APMsOutput
import com.nuvei.mobilesdk.core.model.CheckoutApmI18NStore
import com.nuvei.mobilesdk.core.model.CheckoutI18N
import com.nuvei.mobilesdk.core.model.InputError
import com.nuvei.mobilesdk.core.model.SimplyConnectUICustomization
import com.nuvei.mobilesdk.core.model.UPOsOutput
import com.nuvei.mobilesdk.core.model.applyNuveiFont
import com.nuvei.mobilesdk.core.view.CheckoutErrorTextView
import com.nuvei.mobilesdk.simplyconnect.KeyboardUtils
import com.nuvei.mobilesdk.simplyconnect.R
import com.nuvei.mobilesdk.simplyconnect.SimplyConnect
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutApmDynamicBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutCardBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutGenericBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutGooglePayBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutSectionBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutUpoCardBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ListItemCheckoutUpoGenericBinding
import com.nuvei.mobilesdk.simplyconnect.databinding.ViewCheckoutTextFieldBinding
import com.nuvei.mobilesdk.simplyconnect.model.Installments
import com.nuvei.mobilesdk.simplyconnect.viewmodel.CreditCardInput
import com.nuvei.mobilesdk.simplyconnect.views.PickerDialog
import com.nuvei.mobilesdk.simplyconnect.views.PickerDialogAdapter
import java.io.Serializable

class CheckoutMethodAdapter(
    val activity: AppCompatActivity,
    val nvPayment: NVPayment
) : RecyclerView.Adapter<CheckoutMethodAdapter.BaseViewHolder>() {
    var onPayButtonClicked: ((CheckoutMethodListItem, input: Any?) -> (Unit))? = null
    var onDeleteButtonClicked: ((CheckoutMethodListItem) -> (Unit))? = null
    var onInputUpdated: ((CheckoutMethodListItem, input: Any?, hasFocus: Boolean) -> (Unit))? = null
    var onShowPicker: ((PickerDialog) -> (Unit))? = null
    var onItemExpanded: ((CheckoutMethodListItem, index: Int) -> (Unit))? = null
    val apmI18n = CheckoutApmI18NStore.get()

    private val viewTypeMapper = arrayOf(
        R.layout.list_item_checkout_generic,
        R.layout.list_item_checkout_card,
        R.layout.list_item_checkout_google_pay,
        R.layout.list_item_checkout_upo_card,
        R.layout.list_item_checkout_upo_generic,
        R.layout.list_item_checkout_section,
    )

    private var items: List<CheckoutMethodBaseListItem> = emptyList()

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): BaseViewHolder {
        val viewHolder = when (viewType) {
            R.layout.list_item_checkout_section -> SectionViewHolder(ListItemCheckoutSectionBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_card -> CardViewHolder(ListItemCheckoutCardBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_google_pay -> GooglePayViewHolder(
                ListItemCheckoutGooglePayBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_upo_card -> UPOCardViewHolder(ListItemCheckoutUpoCardBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_upo_generic -> UPOGenericViewHolder(ListItemCheckoutUpoGenericBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            R.layout.list_item_checkout_generic -> DefaultViewHolder(ListItemCheckoutGenericBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
            else -> DynamicFieldsViewHolder(ListItemCheckoutApmDynamicBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false))
        }

        return viewHolder
    }

    override fun onBindViewHolder(viewHolder: BaseViewHolder, position: Int) {
        val item = items[position]

        viewHolder.bind(item, position)
        viewHolder.updateWithSelectedState(item)

        if (item is CheckoutMethodListItem) {
            viewHolder.updateWithInput(item.input)
        }
    }

    override fun onBindViewHolder(viewHolder: BaseViewHolder, position: Int, payloads: MutableList<Any>) {
        if (viewHolder !is CardViewHolder) {
            onBindViewHolder(viewHolder, position)
        } else if (payloads.isEmpty()) {
            onBindViewHolder(viewHolder, position)
        } else {
            val item = items[position] as? CheckoutMethodListItem ?: run { onBindViewHolder(viewHolder, position); return }

            payloads.forEach {
                if (it == PayloadKeys.inputUpdated) {
                    viewHolder.updateWithInput(item.input)
                } else if (it == PayloadKeys.selectedStateUpdated) {
                    viewHolder.updateWithSelectedState(item)
                }
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val item = items[position]
        return if (item.layoutId == R.layout.list_item_checkout_apm_dynamic) {
            viewTypeMapper.size + position
        } else {
            viewTypeMapper.find { it == item.layoutId } ?: 0
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun setItems(newItems: List<CheckoutMethodBaseListItem>) {
        val allItems = ArrayList<CheckoutMethodBaseListItem>()

        newItems.forEach {
            allItems.add(it)

            if (it is CheckoutMethodsSection) {
                allItems.addAll(it.items)
            }
        }

        items = allItems

        notifyDataSetChanged()
    }

    fun handleItemInputUpdate(input: Any) {
        val index = when (input) {
            is CreditCardInput -> { input.index }
            is UPOCardInput -> { input.index }
            else -> { -1 }
        }

        notifyItemChanged(index!!, PayloadKeys.inputUpdated)
    }

    abstract inner class BaseViewHolder(view: ViewGroup) : RecyclerView.ViewHolder(view) {
        abstract fun bind(item: CheckoutMethodBaseListItem, position: Int)
        abstract fun updateWithSelectedState(item: CheckoutMethodBaseListItem)
        abstract fun updateWithInput(input: Any?)

        internal fun toggleSelected(newIndex: Int) {
            for (index in items.indices) {
                val item = items[index] as? CheckoutMethodListItem ?: continue

                if (newIndex == index) {
                    item.isSelected = !item.isSelected
                    notifyItemChanged(newIndex, PayloadKeys.selectedStateUpdated)
                    if (item.isSelected) {
                        onItemExpanded?.invoke(item, index)
                    }
                } else if (item.isSelected) {
                    item.isSelected = false
                    notifyItemChanged(index, PayloadKeys.selectedStateUpdated)
                }
            }
        }

        internal fun updateIcon(item: CheckoutMethodListItem, iconImageView: ImageView) {
            if (item.iconUrl == null) {
                iconImageView.setImageResource(item.iconId ?: R.drawable.ic_credit_card)
            } else {
                Glide
                    .with(itemView)
                    .load(alignedImageUrl(item.iconUrl))
                    .centerCrop()
                    .placeholder(R.drawable.ic_credit_card)
                    .into(iconImageView)
            }
        }
    }

    private inner class DefaultViewHolder(val binding: ListItemCheckoutGenericBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            val apm = item.data as? APMsOutput.APM
            val isAPM = apm != null

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            // --- title ---
            binding.titleTextView.text = if (isAPM) {
                apmI18n.title(apm!!.methodType) ?: item.title
            } else {
                item.title
            }

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            // --- icon ---
            updateIcon(item, binding.iconImageView)

            // --- item click ---
            itemView.setOnClickListener { toggleSelected(position) }

            // --- pay button ---
            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)
                    item.input = APMInput(position, emptyList(), binding.saveCheckBox.isChecked)
                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = if (isAPM) {
                    String.format(
                        apmI18n.apmUiStrings.payButtonTitleText,
                        item.amount,
                        item.currency
                    )
                } else {
                    String.format(
                        CheckoutI18N.payButtonTitle,
                        item.amount,
                        item.currency
                    )
                }

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            if (isAPM){
                binding.saveCheckBox.text = apmI18n.apmUiStrings.saveDetailsText
            }

            binding.saveCheckBox.setTextColor(SimplyConnectUICustomization.checkboxButtonCustomization.textColor)
            binding.saveCheckBox.applyNuveiFont(SimplyConnectUICustomization.checkboxButtonCustomization.textFontName)
            binding.saveCheckBox.buttonTintList = ColorStateList.valueOf(SimplyConnectUICustomization.checkboxButtonCustomization.backgroundColor)
            binding.saveCheckBox.textSize = SimplyConnectUICustomization.checkboxButtonCustomization.textFontSize.toFloat()

        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class SectionViewHolder(val binding: ListItemCheckoutSectionBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodsSection) return

            binding.titleTextView.apply {
                text = item.title
                with(SimplyConnectUICustomization.recyclerViewCustomization){
                    textSize = sectionTextFontSize.toFloat()
                    setTextColor(sectionTextColor)
                    applyNuveiFont(sectionTextFontName)
                }
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class UPOCardViewHolder(val binding: ListItemCheckoutUpoCardBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = item.title
            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            binding.tvExpiryDate.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvExpiryDate.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvExpiryDate.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvCVV.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvCVV.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvCVV.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvInstallmentProgram.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvInstallmentProgram.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvInstallmentProgram.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvNumberOfInstallments.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvNumberOfInstallments.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvNumberOfInstallments.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
            binding.tvPersonalId.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
            binding.tvPersonalId.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
            binding.tvPersonalId.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)

            applyCustomization(
                binding.expiryEditText,
                binding.cvvEditText,
                binding.personalIdEditText,
                binding.ddlInstallmentsProgram,
                binding.ddlNumberOfInstallments
            )

            binding.ddlInstallmentsProgram
            binding.ddlNumberOfInstallments


            with(CheckoutI18N){
                binding.tvExpiryDate.text = expirationDateTitle
                binding.expiryEditText.setHintWithSizeAndColor(expirationDatePlaceholder)
                binding.tvCVV.text = cvvTitle
                binding.cvvEditText.setHintWithSizeAndColor(cvvPlaceholder)
                binding.tvInstallmentProgram.text = installmentsProgramTitle
                binding.tvNumberOfInstallments.text = numberOfInstallmentsTitle
                binding.tvPersonalId.text = personalIdTitle
                binding.personalIdEditText.setHintWithSizeAndColor(personalIdPlaceholder)
                binding.payButton.text = payButtonTitle
            }

            updateIcon(item, binding.iconImageView)

            var hasExpiry = false

            (item.data as? UPOsOutput.PaymentMethod)?.upoData?.let {
                val month = it.ccExpiryMonth.toIntOrNull() ?: return
                val year = it.ccExpiryYear.toIntOrNull() ?: return

                if (!isFutureDate(month, year)) {
                    hasExpiry = true
                    binding.expiryTextInputLayout.visibility = View.VISIBLE
                }
            }

            (item.initialParsedInfo as? UPOCardInput.InitialParsedInfo)?.let { parsedInfo ->
                binding.cvvErrorTextView.maxLength = parsedInfo.cvvLength
                binding.cvvEditText.setHintWithSizeAndColor(if (parsedInfo.cvvLength == 4) CheckoutI18N.cvvPlaceholderAMEX else CheckoutI18N.cvvPlaceholder)
            }

            if (!hasExpiry) {
                binding.expiryTextInputLayout.visibility = View.GONE
            }

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            binding.deleteImageView.setOnClickListener {
                onDeleteButtonClicked?.invoke(item)
            }

            if (SimplyConnect.installments.options.isNotEmpty()) {
                binding.installmentsProgramInputLayout.visibility = View.VISIBLE
                binding.ddlInstallmentsProgram.items = SimplyConnect.installments.descriptionStrings(activity)
                showInstallments(binding.ddlInstallmentsProgram.selectedItemId)

                binding.ddlInstallmentsProgram.onSelectedItem = {
                        selectedItemId ->
                    showInstallments(selectedItemId)
                }
                binding.ddlInstallmentsProgram.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }

                binding.ddlNumberOfInstallments.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }
            }

            if (SimplyConnect.installments.requirePersonalID) {
                binding.personalIdTextInputLayout.visibility = View.VISIBLE

                binding.personalIdEditText.setHintWithSizeAndColor(CheckoutI18N.personalIdPlaceholder + " (" + (Nuvei.hostAppDetails?.simCountryCode ?: "") +")")
                if (Nuvei.hostAppDetails?.simCountryCode == "MX"
                    || Nuvei.hostAppDetails?.simCountryCode == "BR") {
                    binding.personalIdEditText.inputType = InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                }
            }

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    allErrorFields().forEach {
                        it.clearErrorMessage()
                    }

                    item.input = filledInput(position)

                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = String.format(
                    CheckoutI18N.payButtonTitle,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            val inputErrors = InputError

            fun performInputUpdate(hasFocus: Boolean = false) {
                val newInput = filledInput(position)

                item.input = newInput
                onInputUpdated?.invoke(item, newInput, hasFocus)
            }

            binding.expiryErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.expiryErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.cvvErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.cvvErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.personalIDErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.personalIDErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {
            val fields = allErrorFields()

            (input as? UPOCardInput)?.apply {
                with(binding) {
                    expiryErrorTextView.setInputValue(expiry ?: "")
                    cvvErrorTextView.setInputValue(cvv)
                }

                parsedInfo?.errors?.forEach {
                    setError(fields, it)
                }
            }

            fields.forEach {
                it.clearErrorMessage()
            }
        }

        private fun showInstallments(selectedItemId: Int) {
            if (SimplyConnect.installments.options[selectedItemId].isSinglePayment) {
                binding.ddlNumberOfInstallments.items.clear()
                binding.installmentsNumberInputLayout.visibility = View.GONE
            } else {
                binding.ddlNumberOfInstallments.items = Installments.options[selectedItemId].installmentStrings
                binding.installmentsNumberInputLayout.visibility = View.VISIBLE
            }
        }

        fun allErrorFields(): ArrayList<CheckoutErrorTextView> {
            return with(binding) {
                arrayListOf(
                    personalIDErrorTextView,
                    expiryErrorTextView,
                    cvvErrorTextView
                )
            }
        }

        fun filledInput(position: Int): UPOCardInput {
            return with(binding) {
                var localPayment: LocalPayment? = null
                if (SimplyConnect.installments.options.isNotEmpty()) {
                    val selectedOption = SimplyConnect.installments.options[binding.ddlInstallmentsProgram.selectedItemId]

                    var selectedInstallmentsCount: String? = null
                    if (selectedOption.installments.isNotEmpty()) {
                        selectedInstallmentsCount = selectedOption.installments[binding.ddlNumberOfInstallments.selectedItemId].toString()
                    }

                    localPayment = LocalPayment(
                        null,
                        selectedOption.type.ordinal.toString(),
                        selectedInstallmentsCount
                    )
                }

                if (SimplyConnect.installments.requirePersonalID) {
                    val personalID = binding.personalIdEditText.text.toString().trim()
                    if (localPayment != null) {
                        localPayment.nationalId = personalID
                    } else {
                        localPayment = LocalPayment(nationalId= personalID)
                    }
                }

                UPOCardInput(
                    index = position,
                    expiry = if (expiryTextInputLayout.visibility == View.VISIBLE) expiryEditText.getFullDate() else null,
                    cvv = cvvEditText.text.toString(),
                    localPayment = localPayment
                )
            }
        }

        fun clearInputErrors(item: CheckoutMethodListItem, clearedErrors: Array<InputError>) {
            (item.input as? UPOCardInput)?.parsedInfo?.let { parsedInfo ->
                val existingErrors = parsedInfo.errors ?: return

                val newErrors = ArrayList<Int>()

                existingErrors.forEach { existingError ->
                    var shouldKeep = true
                    for (clearedError in clearedErrors) {
                        if (clearedError.ordinal == existingError) {
                            shouldKeep = false
                            break
                        }
                    }
                    if (shouldKeep) {
                        newErrors.add(existingError)
                    }
                }

                parsedInfo.errors = newErrors.toTypedArray()
            }
        }

        fun setError(fields: ArrayList<CheckoutErrorTextView>, error: Int) {
            with(binding) {
                when (val checkoutInputError = InputError.values()[error]) {
                    InputError.CVVInvalid -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvInvalid, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.CVVEmpty -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvEmpty, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.ExpiryEmpty -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryEmpty, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.ExpiryInvalid -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryInvalid, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.PersonalIDEmpty -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDEmpty, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }
                    InputError.PersonalIDInvalid -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDInvalid, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }
                    else -> {}
                }
            }
        }
    }

    private inner class UPOGenericViewHolder(val binding: ListItemCheckoutUpoGenericBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = item.title
            updateIcon(item, binding.iconImageView)

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            binding.deleteImageView.setOnClickListener {
                onDeleteButtonClicked?.invoke(item)
            }

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    onPayButtonClicked?.invoke(item, null)
                }

                text = String.format(
                    CheckoutI18N.payButtonTitle,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class GooglePayViewHolder(val binding: ListItemCheckoutGooglePayBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = item.title

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            GooglePayHandler.initializeButton(binding.googlePayButton)

            binding.googlePayButton.setOnClickListener {
                onPayButtonClicked?.invoke(item, null)
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}
    }

    private inner class DynamicFieldsViewHolder(val binding: ListItemCheckoutApmDynamicBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            val apm = item.data as? APMsOutput.APM ?: return

            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)
            binding.titleTextView.text = apmI18n.title(apm.methodType) ?: item.title
            updateIcon(item, binding.iconImageView)

            itemView.setOnClickListener {
                toggleSelected(position)
            }

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    val (valid, firstErrorView) = validateFields(apm.methodType)
                    if (!valid) {
                        firstErrorView?.requestFocus()
                        return@setOnClickListener
                    }

                    item.input = filledInput(position, apm)
                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = String.format(
                    apmI18n.apmUiStrings.payButtonTitleText,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            binding.saveCheckBox.text = apmI18n.apmUiStrings.saveDetailsText
            binding.saveCheckBox.setTextColor(SimplyConnectUICustomization.checkboxButtonCustomization.textColor)
            binding.saveCheckBox.applyNuveiFont(SimplyConnectUICustomization.checkboxButtonCustomization.textFontName)
            binding.saveCheckBox.buttonTintList = ColorStateList.valueOf(SimplyConnectUICustomization.checkboxButtonCustomization.backgroundColor)
            binding.saveCheckBox.textSize = SimplyConnectUICustomization.checkboxButtonCustomization.textFontSize.toFloat()

            if (binding.containerView.childCount == 0) {
                createFields(apm, apm.fields)
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected
                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {}

        fun createFields(apm: APMsOutput.APM, fields: List<APMsOutput.Field>) {
            val updatedFields = fields.toMutableList()

            when (apm.methodType) {
                idealType -> {
                    createTextField(
                        itemView.context.getString(R.string.checkout_method_ideal_first_name),
                        NetworkConstants.Values.Fields.idealPayerName
                    )
                    createTextField(
                        itemView.context.getString(R.string.checkout_method_ideal_last_name),
                        NetworkConstants.Values.Fields.idealPayerName
                    )
                    createTextField(
                        itemView.context.getString(R.string.checkout_method_ideal_email),
                        NetworkConstants.Values.Fields.idealEmail
                    )
                    updatedFields.removeAll { it.name.compareTo(NetworkConstants.Values.Fields.idealPayerName, true) == 0 }
                }
            }

            updatedFields.forEach {
                when (it.type) {
                    "text" -> createTextField(
                        apmI18n.text(apm.methodType, it.name) ?: it.caption.firstOrNull()?.message,
                        it.name,
                        it.values,
                        methodId = apm.methodType
                    )
                }
            }
        }

        fun createTextField(
            title: String?,
            fieldName: String,
            values: List<APMsOutput.ListValue>? = null,
            methodId: String? = null
        ) {
            ViewCheckoutTextFieldBinding.inflate(
                LayoutInflater.from(binding.containerView.context),
                binding.containerView,
                true
            ).also { tf ->
                applyCustomization(tf.editText)
                tf.root.setTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME, fieldName)
                tf.titleTextView.text = title
                tf.titleTextView.setTextColor(SimplyConnectUICustomization.textBoxCustomization.headingTextFontColor)
                tf.titleTextView.textSize = SimplyConnectUICustomization.textBoxCustomization.headingTextFontSize.toFloat()
                tf.titleTextView.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.headingTextFontName)
                tf.editText.setHintWithSizeAndColor(title)
                tf.editText.setTextColor(SimplyConnectUICustomization.textBoxCustomization.textColor)
                tf.editText.textSize = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                tf.editText.applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)
                tf.clearError()

                if (values?.isNotEmpty() == true) {
                    // Picker mode
                    tf.editText.inputType = InputType.TYPE_NULL
                    tf.editText.isFocusable = false
                    tf.editText.setOnClickListener {
                        val displayOptions = values.map { value ->
                            val code = value.code
                            val overridden = methodId?.let { apmI18n.option(it, fieldName, code) }
                            overridden ?: value.caption
                        }
                        val pickerDialogAdapter = PickerDialogAdapter(displayOptions)
                        val dialog = PickerDialog(tf.titleTextView.text.toString(), pickerDialogAdapter)

                        pickerDialogAdapter.onValueSelected = { index ->
                            tf.editText.setText(displayOptions[index])
                            tf.editText.setTag(R.id.TAG_APM_TEXT_FIELD_CODE, values[index].code)
                            tf.clearError() // clear error on selection
                            dialog.dismiss()
                        }

                        onShowPicker?.invoke(dialog)
                    }
                } else {
                    // Text input: clear error as user types
                    tf.editText.doAfterTextChanged {
                        tf.clearError()
                    }
                }
            }
        }


        fun filledInput(position: Int, apm: APMsOutput.APM): APMInput {
            val valueForCombinedFields = fun(fieldName: String, isPicker: Boolean): APMInput.Field {
                var result: String? = ""
                val views = binding.containerView.children
                for (view in views) {
                    val textFieldBinding = tryOrNull { ViewCheckoutTextFieldBinding.bind(view) } ?: continue
                    if (textFieldBinding.root.getTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME) == fieldName) {
                        if (isPicker) {
                            result = textFieldBinding.editText.getTag(R.id.TAG_APM_TEXT_FIELD_CODE) as? String
                        } else {
                            result += textFieldBinding.editText.text.toString()
                        }
                    }
                }
                return APMInput.Field(
                    fieldName,
                    result ?: ""
                )
            }

            val baseFields = apm.fields.map { field ->
                valueForCombinedFields(
                    field.name,
                    field.values?.isNotEmpty() == true
                )
            }

            val additionalFields = when (apm.methodType) {
                idealType -> listOf(
                    valueForCombinedFields(NetworkConstants.Values.Fields.idealEmail, false)
                )
                else -> null
            }

            return APMInput(
                index = position,
                fields = buildList {
                    addAll(baseFields)
                    additionalFields?.let { addAll(it) }
                },
                shouldSave = binding.saveCheckBox.isChecked
            )
        }

        private fun ViewCheckoutTextFieldBinding.showError(text: String) {
            errorTextView.text = text
            errorTextView.textSize = SimplyConnectUICustomization.errorBoxCustomization.textFontSize.toFloat()
            errorTextView.setTextColor(SimplyConnectUICustomization.errorBoxCustomization.textColor)
            errorTextView.applyNuveiFont(SimplyConnectUICustomization.errorBoxCustomization.textFontName)
            errorTextView.visibility = View.VISIBLE
        }

        private fun ViewCheckoutTextFieldBinding.clearError() {
            errorTextView.text = null
            errorTextView.visibility = View.GONE
        }

        /** Try to bind; returns null if this child isn't a text field layout */
        private fun bindChildOrNull(view: View): ViewCheckoutTextFieldBinding? =
            try {
                ViewCheckoutTextFieldBinding.bind(view)
            } catch (_: Throwable) {
                null
            }

        /** Returns (isValid, firstErrorViewForFocusOrNull) */
        private fun validateFields(methodId: String): Pair<Boolean, View?> {
            var firstErrorView: View? = null
            var allValid = true

            binding.containerView.children.forEach { child ->
                val tf = bindChildOrNull(child) ?: return@forEach

                val fieldName = tf.root.getTag(R.id.TAG_APM_TEXT_FIELD_FIELD_NAME) as? String ?: return@forEach
                // Picker fields set a code tag; text fields keep plain text
                val pickedCode = tf.editText.getTag(R.id.TAG_APM_TEXT_FIELD_CODE) as? String
                val value = pickedCode ?: tf.editText.text?.toString()
                val empty = value.isNullOrBlank()

                if (empty) {
                    allValid = false
                    // Prefer client-provided error; fallback to a generic one
                    val msg = apmI18n.error(methodId, fieldName) ?: apmI18n.apmUiStrings.emptyFieldErrorText
                    tf.showError(msg)
                    if (firstErrorView == null) firstErrorView = tf.editText
                } else {
                    tf.clearError()
                }
            }

            return allValid to firstErrorView
        }
    }

    private inner class CardViewHolder(val binding: ListItemCheckoutCardBinding) : BaseViewHolder(binding.root) {
        override fun bind(item: CheckoutMethodBaseListItem, position: Int) {
            if (item !is CheckoutMethodListItem) return

            itemView.setOnClickListener {
                toggleSelected(position)
                KeyboardUtils.hideKeyboard(itemView)
            }
            binding.mainFrame.setBackgroundColor(SimplyConnectUICustomization.recyclerViewCustomization.cellBackgroundColor)

            with(CheckoutI18N){
                binding.tvCardholderName.text = cardHolderNameTitle
                binding.holderNameEditText.setHintWithSizeAndColor(cardHolderNamePlaceholder)
                binding.tvCardNumber.text = cardNumberTitle
                binding.numberEditText.setHintWithSizeAndColor(cardNumberPlaceholder)
                binding.tvExpiryDate.text = expirationDateTitle
                binding.expiryEditText.setHintWithSizeAndColor(expirationDatePlaceholder)
                binding.tvCVV.text = cvvTitle
                binding.cvvEditText.setHintWithSizeAndColor(cvvPlaceholder)
                binding.tvInstallmentProgram.text = installmentsProgramTitle
                binding.tvNumberOfInstallments.text = numberOfInstallmentsTitle
                binding.tvPersonalId.text = personalIdTitle
                binding.personalIdEditText.setHintWithSizeAndColor(personalIdPlaceholder)
                binding.saveCheckBox.text = saveDetailsText
                binding.payButton.text = payButtonTitle
            }

            binding.titleTextView.textSize = SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontSize.toFloat()
            binding.titleTextView.setTextColor(SimplyConnectUICustomization.recyclerViewCustomization.cellTextColor)
            binding.titleTextView.applyNuveiFont(SimplyConnectUICustomization.recyclerViewCustomization.cellTextFontName)

            with(SimplyConnectUICustomization.textBoxCustomization){
                binding.tvCardholderName.textSize = headingTextFontSize.toFloat()
                binding.tvCardholderName.setTextColor(headingTextFontColor)
                binding.tvCardholderName.applyNuveiFont(headingTextFontName)
                binding.tvCardNumber.textSize = headingTextFontSize.toFloat()
                binding.tvCardNumber.setTextColor(headingTextFontColor)
                binding.tvCardNumber.applyNuveiFont(headingTextFontName)
                binding.tvExpiryDate.textSize = headingTextFontSize.toFloat()
                binding.tvExpiryDate.setTextColor(headingTextFontColor)
                binding.tvExpiryDate.applyNuveiFont(headingTextFontName)
                binding.tvCVV.textSize = headingTextFontSize.toFloat()
                binding.tvCVV.setTextColor(headingTextFontColor)
                binding.tvCVV.applyNuveiFont(headingTextFontName)
                binding.tvInstallmentProgram.textSize = headingTextFontSize.toFloat()
                binding.tvInstallmentProgram.setTextColor(headingTextFontColor)
                binding.tvInstallmentProgram.applyNuveiFont(headingTextFontName)
                binding.tvNumberOfInstallments.textSize = headingTextFontSize.toFloat()
                binding.tvNumberOfInstallments.setTextColor(headingTextFontColor)
                binding.tvNumberOfInstallments.applyNuveiFont(headingTextFontName)
                binding.tvPersonalId.textSize = headingTextFontSize.toFloat()
                binding.tvPersonalId.setTextColor(headingTextFontColor)
                binding.tvPersonalId.applyNuveiFont(headingTextFontName)
                binding.saveCheckBox.setTextColor(SimplyConnectUICustomization.checkboxButtonCustomization.textColor)
                binding.saveCheckBox.applyNuveiFont(SimplyConnectUICustomization.checkboxButtonCustomization.textFontName)
                binding.saveCheckBox.buttonTintList = ColorStateList.valueOf(SimplyConnectUICustomization.checkboxButtonCustomization.backgroundColor)
                binding.saveCheckBox.textSize = SimplyConnectUICustomization.checkboxButtonCustomization.textFontSize.toFloat()

                applyCustomization(
                    binding.holderNameEditText,
                    binding.numberEditText,
                    binding.expiryEditText,
                    binding.cvvEditText,
                    binding.personalIdEditText,
                    binding.ddlInstallmentsProgram,
                    binding.ddlNumberOfInstallments
                )

            }

            binding.payButton.apply {
                setOnClickListener {
                    KeyboardUtils.hideKeyboard(itemView)

                    allErrorFields().forEach {
                        it.clearErrorMessage()
                    }

                    item.input = filledInput(position)
                    onPayButtonClicked?.invoke(item, item.input!!)
                }

                text = String.format(
                    CheckoutI18N.payButtonTitle,
                    item.amount,
                    item.currency
                )

                textSize = SimplyConnectUICustomization.payButtonCustomization.textFontSize.toFloat()
                setTextColor(SimplyConnectUICustomization.payButtonCustomization.textColor)
                applyNuveiFont(SimplyConnectUICustomization.payButtonCustomization.textFontName)
                setBackgroundColor(SimplyConnectUICustomization.payButtonCustomization.backgroundColor)
                cornerRadius = SimplyConnectUICustomization.payButtonCustomization.cornerRadius
            }

            val inputErrors = InputError

            fun performInputUpdate(hasFocus: Boolean = false) {
                val newInput = filledInput(position)
                if (item.creditCardInput?.parsedInfo != null) {
                    newInput.parsedInfo = item.creditCardInput?.parsedInfo
                    newInput.parsedInfo?.icon = null
                }

                item.input = newInput
                onInputUpdated?.invoke(item, newInput, hasFocus)
            }

            binding.numberErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.numberErrors)
                performInputUpdate(hasFocus)
            }

            binding.holderNameErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.holderNameErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.expiryErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.expiryErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.cvvErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.cvvErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            binding.personalIDErrorTextView.onValidateInput = { _, hasFocus ->
                clearInputErrors(item, inputErrors.personalIDErrors)
                if (!hasFocus) {
                    performInputUpdate()
                }
            }

            if (SimplyConnect.installments.options.isNotEmpty()) {
                binding.installmentsProgramInputLayout.visibility = View.VISIBLE
                binding.ddlInstallmentsProgram.items = SimplyConnect.installments.descriptionStrings(activity)
                showInstallments(binding.ddlInstallmentsProgram.selectedItemId)

                binding.ddlInstallmentsProgram.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }

                binding.ddlNumberOfInstallments.apply {
                    setItemTextStyle(
                        color = SimplyConnectUICustomization.textBoxCustomization.textColor,
                        sizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat(),
                        selectedColor = SimplyConnectUICustomization.textBoxCustomization.textColor,     // same as popup rows, or different if you like
                        selectedSizeSp = SimplyConnectUICustomization.textBoxCustomization.textFontSize.toFloat()
                    )
                }

                binding.ddlInstallmentsProgram.onSelectedItem = {
                        selectedItemId ->
                    showInstallments(selectedItemId)
                }
            }

            if (SimplyConnect.installments.requirePersonalID) {
                binding.personalIdTextInputLayout.visibility = View.VISIBLE
                binding.personalIdEditText.setHintWithSizeAndColor(binding.personalIdEditText.hint.toString() + " (" + (Nuvei.hostAppDetails?.simCountryCode
                    ?: "") +")")
                if (Nuvei.hostAppDetails?.simCountryCode == "MX"
                    || Nuvei.hostAppDetails?.simCountryCode == "BR") {
                    binding.personalIdEditText.inputType = InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                }
            }
        }

        private fun showInstallments(selectedItemId: Int) {
            if (SimplyConnect.installments.options[selectedItemId].isSinglePayment) {
                binding.ddlNumberOfInstallments.items.clear()
                binding.installmentsNumberInputLayout.visibility = View.GONE
            } else {
                binding.ddlNumberOfInstallments.items = Installments.options[selectedItemId].installmentStrings
                binding.installmentsNumberInputLayout.visibility = View.VISIBLE
            }
        }

        override fun updateWithSelectedState(item: CheckoutMethodBaseListItem) {
            if (item !is CheckoutMethodListItem) return
            with(binding) {
                root.isChecked = item.isSelected

                if (item.isSelected) {
                    expandedGroup.visibility = View.VISIBLE
                    mainFrame.isFocusable = true
                    mainFrame.isClickable = true
                } else {
                    expandedGroup.visibility = View.GONE
                    mainFrame.isFocusable = false
                    mainFrame.isClickable = false
                }
            }
        }

        override fun updateWithInput(input: Any?) {
            val fields = allErrorFields()

            (input as? CreditCardInput)?.apply {
                with(binding) {
                    holderNameErrorTextView.setInputValue(cardHolderName)
                    numberErrorTextView.setInputValue(number)
                    expiryErrorTextView.setInputValue(expiry)
                    cvvErrorTextView.setInputValue(cvv)

                    cvvErrorTextView.maxLength = input.parsedInfo?.cvvLength ?: 3
                    cvvEditText.setHintWithSizeAndColor(if (input.parsedInfo?.cvvLength == 4) CheckoutI18N.cvvPlaceholderAMEX else CheckoutI18N.cvvPlaceholder)
                    if (input.parsedInfo?.icon == null) {
                        cardIcon.setImageDrawable(null)
                    } else {
                        cardIcon.setImageResource(input.parsedInfo?.icon!!)
                    }
                }

                parsedInfo?.errors?.forEach {
                    setError(fields, it)
                }
            }

            fields.forEach {
                it.clearErrorMessage()
            }
        }

        fun allErrorFields(): ArrayList<CheckoutErrorTextView> {
            return with(binding) {
                arrayListOf(
                    numberErrorTextView,
                    holderNameErrorTextView,
                    expiryErrorTextView,
                    cvvErrorTextView
                )
            }
        }

        fun filledInput(position: Int): CreditCardInput {
            var localPayment: LocalPayment? = null
            if (SimplyConnect.installments.options.isNotEmpty()) {
                val selectedOption = SimplyConnect.installments.options[binding.ddlInstallmentsProgram.selectedItemId]

                var selectedInstallmentsCount: String? = null
                if (selectedOption.installments.isNotEmpty()) {
                    selectedInstallmentsCount = selectedOption.installments[binding.ddlNumberOfInstallments.selectedItemId].toString()
                }

                localPayment = LocalPayment(
                    null,
                    selectedOption.type.ordinal.toString(),
                    selectedInstallmentsCount
                )
            }

            if (SimplyConnect.installments.requirePersonalID) {
                val personalID = binding.personalIdEditText.text.toString().trim()
                if (localPayment != null) {
                    localPayment.nationalId = personalID
                } else {
                    localPayment = LocalPayment(nationalId = personalID)
                }
            }

            return with(binding) {
                CreditCardInput(
                    index = position,
                    cardHolderName = holderNameEditText.text.toString(),
                    number = numberEditText.text.toString(),
                    expiry = expiryEditText.getFullDate(),
                    cvv = cvvEditText.text.toString(),
                    shouldSaveCard = saveCheckBox.isChecked,
                    localPayment = localPayment
                )
            }
        }

        fun clearInputErrors(item: CheckoutMethodListItem, clearedErrors: Array<InputError>) {
            item.creditCardInput?.parsedInfo?.let { parsedInfo ->
                val existingErrors = parsedInfo.errors ?: return

                val newErrors = ArrayList<InputError>()

                existingErrors.forEach { existingError ->
                    var shouldKeep = true
                    for (clearedError in clearedErrors) {
                        if (clearedError == existingError) {
                            shouldKeep = false
                            break
                        }
                    }
                    if (shouldKeep) {
                        newErrors.add(existingError)
                    }
                }

                parsedInfo.errors = newErrors.toTypedArray()
            }
        }

        fun setError(fields: ArrayList<CheckoutErrorTextView>, checkoutInputError: InputError) {
            with(binding) {
                when (checkoutInputError) {
                    InputError.CreditCardInvalid -> {
                        numberErrorTextView.setErrorMessage(CheckoutI18N.creditCardInvalid, checkoutInputError)
                        fields.removeAll { it == numberErrorTextView }
                    }
                    InputError.NumberEmpty -> {
                        numberErrorTextView.setErrorMessage(CheckoutI18N.numberEmpty, checkoutInputError)
                        fields.removeAll { it == numberErrorTextView }
                    }
                    InputError.CVVEmpty -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvEmpty, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.CVVInvalid -> {
                        cvvErrorTextView.setErrorMessage(CheckoutI18N.cvvInvalid, checkoutInputError)
                        fields.removeAll { it == cvvErrorTextView }
                    }
                    InputError.ExpiryEmpty -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryEmpty, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.ExpiryInvalid -> {
                        expiryErrorTextView.setErrorMessage(CheckoutI18N.expiryInvalid, checkoutInputError)
                        fields.removeAll { it == expiryErrorTextView }
                    }
                    InputError.HolderNameEmpty -> {
                        holderNameErrorTextView.setErrorMessage(CheckoutI18N.holderNameEmpty, checkoutInputError)
                        fields.removeAll { it == holderNameErrorTextView }
                    }
                    InputError.HolderNameInvalid -> {
                        holderNameErrorTextView.setErrorMessage(CheckoutI18N.holderNameInvalid, checkoutInputError)
                        fields.removeAll { it == holderNameErrorTextView }
                    }
                    InputError.PersonalIDEmpty -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDEmpty, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }
                    InputError.PersonalIDInvalid -> {
                        binding.personalIDErrorTextView.setErrorMessage(CheckoutI18N.personalIDInvalid, checkoutInputError)
                        fields.removeAll { it == binding.personalIDErrorTextView }
                    }

                    InputError.CreditCardBlocked ->{
                        binding.numberErrorTextView.setErrorMessage(CheckoutI18N.invalidCardNumber, checkoutInputError)
                        fields.removeAll { it == binding.numberErrorTextView }
                    }
                }
            }
        }
    }

    private fun makeRingDrawable(
        @ColorInt strokeColor: Int,
        strokeWidthDp: Int,
        cornerRadiusDp: Int,
        v: View,
        @ColorInt fillColor: Int? = null
    ): Drawable {
        val dm = v.resources.displayMetrics
        val stroke = strokeWidthDp * dm.density
        val r = cornerRadiusDp * dm.density

        val outer = floatArrayOf(r, r, r, r, r, r, r, r)
        val innerR = (r - stroke).coerceAtLeast(0f)
        val inner = floatArrayOf(innerR, innerR, innerR, innerR, innerR, innerR, innerR, innerR)

        // 1) Border drawn as a *ring* so corners aren’t thicker
        val ring = ShapeDrawable(
            RoundRectShape(outer, RectF(stroke, stroke, stroke, stroke), inner)
        ).apply {
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.color = strokeColor
        }

        // 2) Optional fill under the ring
        return if (fillColor == null) {
            ring
        } else {
            val fill = ShapeDrawable(RoundRectShape(outer, null, null)).apply {
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = fillColor
            }
            LayerDrawable(arrayOf(fill, ring))
        }
    }


    fun applyCustomization(vararg views: View) {
        val cfg = SimplyConnectUICustomization.textBoxCustomization

        views.forEach { v ->
            v.post {
                // remove tints that can override our backgrounds
                ViewCompat.setBackgroundTintList(v, null)
                ViewCompat.setBackgroundTintMode(v, null)

                val pL = v.paddingLeft;
                val pT = v.paddingTop
                val pR = v.paddingRight;
                val pB = v.paddingBottom

                when (v) {
                    is EditText -> {
                        // text appearance
                        v.setTextColor(cfg.textColor)
                        v.textSize = cfg.textFontSize.toFloat()

                        // closed-state border
                        v.background = makeRingDrawable(
                            cfg.borderColor,
                            cfg.borderWidth,
                            cfg.cornerRadius,
                            v,
                            cfg.backgroundColor
                        ).mutate()
                        v.applyNuveiFont(cfg.textFontName)
                        v.setPadding(pL, pT, pR, pB)
                        v.invalidate()
                    }

                    is Spinner -> {
                        // ONLY style the closed view. Do not touch popup background.
                        v.background = makeRingDrawable(
                            cfg.borderColor,
                            cfg.borderWidth,
                            cfg.cornerRadius,
                            v,
                            cfg.backgroundColor
                        ).mutate()
                        v.setPadding(pL, pT, pR, pB)

                        // color/size for the *selected* row (the text shown when closed)
                        val styleSelected: () -> Unit = {
                            (v.selectedView as? TextView)?.apply {
                                setTextColor(cfg.textColor)
                                textSize = cfg.textFontSize.toFloat()
                                applyNuveiFont(cfg.textFontName)
                            }
                        }
                        // apply now and whenever selection changes
                        styleSelected()
                        v.viewTreeObserver?.addOnGlobalLayoutListener { styleSelected() }
                        v.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(
                                parent: android.widget.AdapterView<*>?,
                                view: View?,
                                position: Int,
                                id: Long
                            ) = styleSelected()
                            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                        })
                    }

                    is TextView -> {
                        // in case you pass labels here too
                        v.setTextColor(cfg.headingTextFontColor)
                        v.textSize = cfg.headingTextFontSize.toFloat()
                        v.applyNuveiFont(cfg.textFontName)
                    }

                    else -> {
                        // for any other view just keep padding if we ever set a bg later
                        v.setPadding(pL, pT, pR, pB)
                    }
                }
            }
        }
    }


    fun TextView.setHintWithSizeAndColor(hintText: String?) {
        if (!hintText.isNullOrEmpty()){
            val s = SpannableString(hintText).apply {
                setSpan(AbsoluteSizeSpan(SimplyConnectUICustomization.textBoxCustomization.placeholderTextFontSize, /* dip = */ true), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(ForegroundColorSpan(SimplyConnectUICustomization.textBoxCustomization.placeholderFontColor), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                applyNuveiFont(SimplyConnectUICustomization.textBoxCustomization.textFontName)
            }
            hint = s
        }
    }

    companion object {
        object PayloadKeys {
            const val inputUpdated = "payload_inputUpdated"
            const val selectedStateUpdated = "payload_selectedUpdated"
        }
    }
}

interface CheckoutMethodBaseListItem {
    val title: String
    val layoutId: Int?
}

data class CheckoutMethodsSection(
    override val title: String,
    override val layoutId: Int = R.layout.list_item_checkout_section,
    val items: List<CheckoutMethodListItem>,
) : CheckoutMethodBaseListItem

data class CheckoutMethodListItem(
    override val title: String,
    override val layoutId: Int?,
    val iconId: Int? = null,
    val iconUrl: String? = null,
    val amount: Float? = null,
    val currency: String? = null,
    val upoId: String? = null,
    var isSelected: Boolean = false,
    var input: Any? = null,
    var data: Any? = null,
    var initialParsedInfo: Any? = null
) : CheckoutMethodBaseListItem {
    val creditCardInput: CreditCardInput?
        get() = input as? CreditCardInput
}

data class APMInput(
    val index: Int,
    val fields: List<Field>,
    var shouldSave: Boolean,
) {
    data class Field(
        val fieldName: String,
        val fieldValue: Any,
    )
}

data class UPOCardInput(
    val index: Int,
    var expiry: String?,
    var cvv: String,
    var localPayment: LocalPayment? = null,
    var parsedInfo: ParsedInfo? = null
) : Serializable {
    data class ParsedInfo(
        var errors: Array<Int>? = null
    ) : Serializable
    data class InitialParsedInfo(
        val cvvLength: Int
    )
}

private fun alignedImageUrl(url: String): String {
    return url
        .replace("default_cc_card.svg", "default_cc_new.png")
        .replace("solid_white/", "")
        .replace("/svg/", "/png/")
        .replace(".svg", ".png")
}


